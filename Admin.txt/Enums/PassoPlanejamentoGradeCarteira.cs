﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    /// <summary>
    /// Usado para direcionar passo a passo do planejamento.
    /// </summary>
    public enum PassoPlanejamentoGradeCarteira
    {
        /// <summary>
        /// Não iniciado
        /// </summary>
        NaoIniciado = 0,
        /// <summary>
        /// Desafio preenchido
        /// </summary>
        Desafio = 1,
        /// <summary>
        /// Distribuição feita
        /// </summary>
        Distribuicao = 2,
        /// <summary>
        /// Passou pelas etapas do planejamento
        /// </summary>
        Concluido = 3
    }
}
