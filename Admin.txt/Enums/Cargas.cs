﻿namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum Cargas
    {
        VpRealizado = 1,
        VpAnalitico = 2,
        InnerLoopLigacoes = 3,
        Notificacoes = 4,
        Feriados = 5,
        BaixaAderencia = 6,
        VendaAtiva = 7,
        Reclamacoes = 8,
        NPS = 9,
        Alavancas = 10,
        Agencia = 11,
        Colaborador = 12,
        Grade = 13,
        Meta = 14,
        IcmHistorico = 15,
        InnerLoopArvoreDecisoes = 16,
        InnerLoopLiberacaoFuncionalidade = 17,
        CarteiraGradeFake = 18,
        VendaAtivaSaibaMais = 19,
        GradePersonnalite = 20,
        MetasPersonnalite = 21,
        NPSComentario = 23,
    }
}
