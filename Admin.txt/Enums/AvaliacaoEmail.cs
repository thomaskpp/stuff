﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum AvaliacaoEmail
    {
        Bom = 1,
        Ruim = 2
    }
}
