﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum RetornoContato
    {
        Aceitou = 1,
        Recusou = 2,
        NaoLocalizado = 3,
        ClienteSubstituido = 4,
        Reagendou = 5
    }
}
