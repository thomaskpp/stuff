﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum Campos
    {
        Integer,
        Decimal,
        DataReferencia,
        DataContabilizacao,
        Carteira,
        CarteiraColaborador,
        Segmento,
        CodigoItem,
        NomeProduto,
        Agencia,
        Funcional,
        AgenciaComPlanejamento,
        ClienteConta,
        ClienteAgencia,
        ValorProducao,
        ValorPonderado,
        ValorProducaoPonderada,
        ValorPontuacao,
        Status,
        Canal,
        ICM,
        Regiao,
        Platger,
        DataDisparo,
        QuantidadeDetrator,
        QuantidadeInvalido,
        QuantidadeNeutro,
        QuantidadePromotor,
        QuantidadeValorSATX,
        ValorNPS,
        ValorBench,
        RemetenteID,
        Remetente,
        RemetenteCaminhoImagem,
        VendaAtiva,
        Genero,
        DataNascimento,
        ReclamacoesOcorrencia,
        ReclamacoesReclamante,
        ReclamacoesAssuntoCompleto,
        ReclamacoesAssunto,
        Alavancas,
        ICMCiclo,
        ValoresAlavancas,
        Data,
        Long,
        Hora,
        NotificacaoCodigoExibicao,
        NotificacaoTipoExibicao,
        NotificacaoCodigo,
        String,
        Porcentagem
    }
}
