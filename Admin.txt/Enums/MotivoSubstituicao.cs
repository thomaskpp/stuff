﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum MotivoSubstituicao
    {
        JaContateiOferteiRecentemente = 1,
        ClienteAtritado = 2,
        OutroMotivo = 3
    }
}
