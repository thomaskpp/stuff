﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum Funcionalidades
    {
        Home = 1,
        Checkin = 2
    }
}
