﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum AdminAbaAtiva
    {
        Status,
        Carregar,
        Visualizar,
        Configuracao,
        Concluidas,
    }
}
