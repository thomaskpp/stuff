﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum MotivoDelegacao
    {
        Ferias = 0,
        LicencaSaude = 1,
        Treinamento = 2,
        ConvencaoComite = 3,
        Visita = 4,
        Outros = 5
    }
}
