﻿namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum Estrutura
    {
        Varejo = 1,
        Personnalite = 2,
        Operacional = 3,
        Empresas = 4,
        Adm = 5,
        Outros = 6
    }
}
