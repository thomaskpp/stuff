﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    /// <summary>
    /// Indica se o colaborador é elegível para cálculo do engajamento
    /// </summary>
    public enum ElegivelEngajamento
    {
        /// <summary>
        /// 0
        /// </summary>
        Inelegivel = 0,
        /// <summary>
        /// 1
        /// </summary>
        ElegivelParaTodos = 1,
        /// <summary>
        /// 1
        /// </summary>
        InelegivelParaPlanejamento = 2
    }
}
