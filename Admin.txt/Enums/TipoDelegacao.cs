﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum TipoDelegacao
    {
        Solicitacao = 0,
        Delegacao = 1
    }
}
