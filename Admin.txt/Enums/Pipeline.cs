﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum PipelineProduto
    {
        Lis = 1,
        ContaGarantida = 2,
        GiroAval = 3,
        GiroGarantias = 4,
        LongoPrazo = 5,
        LongoPrazoCDC = 6,
        TradeACCACE = 7,
        Trade2770 = 8,
        DescontoDuplicatas = 9,
        DescontoCheque = 10,
        AntecipacaoCartoes = 11,
        Cambio = 12,
        Cobranca = 13,
        FolhaPagamentos = 14,
        Credenciamento = 15,
        Troca = 16,
        FlexVista = 17,
        FlexParcelado = 18,
        SeguroVidaGlobal = 19,
        SeguroVidaEmpresarial = 20,
        Consorcio = 21,
        CartaoBusiness = 22,
        Preventivo = 23,
        Renegociacao = 24,
        PMT = 25
    }

    public enum PipelineStatus
    {
        Planejado = 1,
        Passados = 2,
        Efetivado = 3,
        Cancelado = 4
    }
}
