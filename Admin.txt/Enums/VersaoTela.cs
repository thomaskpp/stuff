﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum VersaoTela
    {
        Antiga = 1,
        Nova = 2
    }
}
