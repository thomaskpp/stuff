﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum StatusCheckCompromisso : byte
    {
        NaoIniciado = 0,
        Iniciado = 1,
        Concluido = 2
    }
}
