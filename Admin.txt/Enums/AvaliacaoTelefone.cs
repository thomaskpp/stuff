﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum AvaliacaoTelefone
    {
        Bom = 1,
        Ruim = 2
    }
}
