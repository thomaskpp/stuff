﻿using System.ComponentModel;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum Cargos
    {
        Desconhecido = 0,

        [Description("Assistentes e Agentes")]
        A = 1,
        [Description("Gerente Geral Comercial")]
        GGC = 2,
        [Description("Gerente Regional Agencias")]
        GRA = 3,
        [Description("Superintendente Comercial")]
        SUPT = 4,
        [Description("Diretor Comercial")]
        DICOM = 5,
        [Description("Gerente Relacionamento Uniclass")]
        GRU = 6,
        [Description("Gerente de Relacionamento Uniclass e Empresas")]
        GRUE = 7,
        [Description("Gerente Relacionamento Uniclass Digital")]
        GRUD = 8,
        [Description("Gerente Geral Digital")]
        GGD = 9,
        [Description("Gerente de Relacionamento Nucleo")]
        GRN = 10,
        [Description("Gerente Geral Nucleo")]
        GGN = 11,
        [Description("Gerente de Relacionamento Empresas")]
        GRE = 12,
        [Description("Agente de Negocios Operacional")]
        AGN = 13,
        [Description("Caixa Operacional")]
        CAIXA = 14,
        [Description("Supervisor Operacional")]
        SPV = 15,
        [Description("Gerente Operacional")]
        GO = 16,
        [Description("Gerente Regional Operacional")]
        GSO = 17,
        [Description("Superintendente Operacional")]
        SOP = 18,
        [Description("Diretor Operacional")]
        DIOP = 19,
        [Description("Agente de Qualidade Empresas")]
        AQE = 20,
        [Description("Coordenador de Qualidade Empresas")]
        CQE = 21,
        [Description("Agente de Qualidade Uniclass")]
        AQU = 22,
        [Description("Coordenador de Qualidade Uniclass")]
        CQU = 23,
        [Description("Agente de Qualidade Personnalite")]
        AQP = 24,
        [Description("Coordenador de Qualidade Personnalité")]
        CQP = 25,
        [Description("Assistente e Agente Personnalité")]
        AP = 26,
        [Description("Gerente Relacionamento Personnalité")]
        GRP = 27,
        [Description("Gerente Geral Comercial Personnalité")]
        GA = 28,
        [Description("Gerente Regional Personnalite")]
        GRAP = 29,
        [Description("Atendente Negocios Empresas")]
        AN = 30,
        [Description("Gerente Negocios Empresas")]
        GN = 31,
        [Description("Gerente Geral Empresas")]
        GGE = 32,
        [Description("Gerente Regional Empresas 3")]
        GRE3 = 33,
        [Description("Admistrativo")]
        ADM = 34,
        [Description("Presidente")]
        PRES = 35,
        [Description("Vice Presidente")]
        VP = 36,
        [Description("Diretor Geral")]
        DTRGER = 37,
        [Description("Diretor Executivo")]
        DTREXC = 38,
        [Description("Diretor")]
        DTR = 39,
        [Description("Libero")]
        LIBERO = 40,
        [Description("Estagiário")]
        ESTAG = 41,
        [Description("Gmf")]
        GMF = 42,
        [Description("ASP")]
        ASP = 43,
        [Description("GR")]
        GR = 44,
        [Description("GRED")]
        GRED = 45,
        [Description("Libero Personnalite")]
        LIBEROIP = 46
    }
}
