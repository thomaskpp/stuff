﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Enums
{
    /// <summary>
    /// Indica a qual regra de cálculo o item se aplica
    /// </summary>
    public enum RegraCalculoICMAgrupamento
    {
        /// <summary>
        /// Cálculo de performance
        /// </summary>
        PerformanceTime = 1,
        /// <summary>
        /// Cálculo para itens com subitens
        /// </summary>
        SubItem = 2,
        /// <summary>
        /// Cálculo Geral/Padrão
        /// </summary>
        Geral = 3,
        /// <summary>
        /// Itens de ICM
        /// </summary>
        ICM = 4,
        /// <summary>
        /// 
        /// </summary>
        Regra5 = 5,
        /// <summary>
        /// 
        /// </summary>
        Regra6 = 6,
        /// <summary>
        /// 
        /// </summary>
        Regra7 = 7,
        /// <summary>
        /// 
        /// </summary>
        Regra8 = 8,
        /// <summary>
        /// 
        /// </summary>
        Regra9 = 9,
        /// <summary>
        /// 
        /// </summary>
        Regra10 = 10,
        /// <summary>
        /// 
        /// </summary>
        Regra11 = 11,
        /// <summary>
        /// 
        /// </summary>
        Regra16 = 16,
        /// <summary>
        /// Não definido
        /// </summary>
        Nenhum = 0
    }
}
