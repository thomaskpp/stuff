﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum TipoProcesso_ControlM
    {
        Engajamento = 1,
        VisaoGerencial = 2,
        DelegacaoAcessos = 3,
        ExpurgoNotificacoes = 4,
        ExpurgoDestinatario = 5,
        PersonnaliteVisaoGerencial = 6
    }
}
