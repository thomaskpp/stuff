﻿namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum StatusCheckout
    {
        Nenhum = -1,
        Formalizado = 0,
        AguardandoFormalizacao = 1,
        AguardandoDebito = 2,
        CancelamentoResgate = 3
    }
}
