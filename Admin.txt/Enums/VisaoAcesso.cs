﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum VisaoAcesso
    {
        Cliente = 1,
        Produto = 2
    }
}
