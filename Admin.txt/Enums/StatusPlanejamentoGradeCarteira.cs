﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum StatusPlanejamentoGradeCarteira
    {
        Pendente = 0,
        Recebido = 1,
        Ok = 2
    }
}
