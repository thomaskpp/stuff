﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum VisualizarArquivoVisao
    {
        Metas = 1,
        Grade = 2
    }
}
