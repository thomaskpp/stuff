﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum StatusDelegacao
    {
        AguardandoAprovacaoGRA = 0,
        Aprovado = 1,
        Recusado = 2,
        Expirado = 3,
        Cancelado = 4
    }
}
