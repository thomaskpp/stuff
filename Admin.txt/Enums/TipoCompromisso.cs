﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum TipoCompromisso
    {
        Compromisso = 0,
        Tarefa = 1
    }
}
