﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum CargasTipoPeriodo
    {
        Diario = 1, //ESCOLHE UM DIA EXATO
        Semanal = 2, // TODA SEMANA
        Mensal = 3, //
        Anual = 4
    }
}
