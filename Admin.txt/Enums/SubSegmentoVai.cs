﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum SubSegmentoVai
    {
        [Display(Description = "IA-DIGITAL")]
        IaDigital = 3,
        [Display(Description = "OPERACIONAL")]
        Operacional = 4,
        [Display(Description = "EMPRESAS")]
        Empresas = 5
    }
}
