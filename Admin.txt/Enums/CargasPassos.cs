﻿using System.ComponentModel.DataAnnotations;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum CargasPassos
    {
        [Display(Description = "Validação")]
        Validacao = 1,
        [Display(Description = "Remoção")]
        Remocao = 2,
        [Display(Description = "Inserção")]
        Insercao = 3,
        [Display(Description = "PosExecução")]
        PosExecucao = 4
    }
}
