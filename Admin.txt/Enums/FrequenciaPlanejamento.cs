﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    /// <summary>
    /// Indica se o item é de planejamento diário, semanal ou nenhum dos dois
    /// </summary>
    public enum FrequenciaPlanejamento
    {
        /// <summary>
        /// 0
        /// </summary>
        Nenhum = 0,
        /// <summary>
        /// 1
        /// </summary>
        Diario = 1,
        /// <summary>
        /// 1
        /// </summary>
        Semanal = 2
    }
}
