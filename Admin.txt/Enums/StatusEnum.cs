﻿namespace Itau.SZ7.GPS.Admin.Domain.Carga.Enums
{
    public enum StatusEnum
    {
        /// <summary>
        /// Verde: O processo está no prazo. A data de atualização é maior ou igual à data de próxima atualização
        /// </summary>
        Prazo = 1,

        /// <summary>
        /// Amarelo: O processo deve ocorrer no dia. A data de próxima atualização é a data vigente e o processo ainda não foi executado
        /// </summary>
        Dia = 2,

        /// <summary>
        /// Vermelho: O processo está em atraso. A data de atualização é menor que a data de proxima atualização
        /// </summary>
        Atraso = 3
    }
}
