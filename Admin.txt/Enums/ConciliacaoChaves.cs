﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum ConciliacaoChaves
    {
        //Seção utilizada para criar a chave de colunas utilizada para o “cruzamento”, seria no SQL as condições que ficam no JOIN
        Chave = 1,

        //Seção utilizada para definir o critério aprovado de colunas utilizada no “cruzamento”, seria no SQL as condições que ficariam no WHERE
        CriterioAprovado = 2,

        //Seção utilizada para definir o critério aprovado similar  de colunas utilizada no “cruzamento”, seria no SQL as condições que ficariam no WHERE (QUANDO ENCOTNRAMOS ALGO QUE NÃO FOI APROVADO MAS FOI SIMILAR)
        CriterioAprovadoSimilar = 3,

        //Seção utilizada para definir o critério inválido de colunas utilizada no “cruzamento”, seria no SQL as condições que ficariam no WHERE (QUANDO ENCOTNRAMOS ALGO PARA INVALIDAR O REGISTRO)
        CriterioInvalido = 4
    }
}
