﻿namespace Itau.SZ7.GPS.Admin.Domain.Planejamento.Enums
{
    /// <summary>
    /// Indicadores com as possibilidades de DE-PARA do checkout
    /// </summary>
    public enum IndicadorColaboradorCheckout
    {
        DeMimParaMim = 0,
        DeAlguemParaMim = 1,
        DeMimParaAlguem = 2,
        DeAlguemParaAlguem = 3
    }
}
