﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum AvaliacaoReceptividade
    {
        Boa = 1,
        Neutra = 2,
        Ruim = 3
    }
}
