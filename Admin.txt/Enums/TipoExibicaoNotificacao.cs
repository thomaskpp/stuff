﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    /// <summary>
    /// Indica onde será exibida a notificacao no APP. 1 - Exibição na home como alerta, 2 - Exibição sem alerta
    /// </summary>
    public enum TipoExibicaoNotificacao
    {
        /// <summary>
        /// 
        /// </summary>
        AlertaMobile = 1,
        /// <summary>
        /// 
        /// </summary>
        MensagemMobile = 2,
        /// <summary>
        /// 
        /// </summary>
        MensagemWeb = 3,
        /// <summary>
        ///
        /// </summary>
        AlertaWeb = 4,
        /// <summary>
        /// 
        /// </summary>
        DelegacaoAcessoMobile = 5,
        /// <summary>
        /// 
        /// </summary>
        DelegacaoAcessoWeb = 6
    }
}
