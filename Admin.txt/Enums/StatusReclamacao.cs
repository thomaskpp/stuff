﻿
namespace Itau.SZ7.GPS.Admin.Enums
{
    public enum StatusReclamacao
    {
        ContatoPendente = 0,
        ContatoRealizado = 1
    }
}
