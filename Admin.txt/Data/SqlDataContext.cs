﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Data
{
    public class SqlDataContext : ISqlDataContext
    {
        private readonly string _connectionString;

        public SqlDataContext(IAppConfiguration appConfiguration)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public SqlDataContext(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IEnumerable<T> SelectQueryToList<T>(string selectQuery) where T : class
        {
            return SelectQueryToList<T>(selectQuery, CommandType.Text, null);
        }

        public async Task<IEnumerable<T>> SelectQueryToListAsync<T>(string selectQuery) where T : class
        {
            return await SelectQueryToListAsync<T>(selectQuery, CommandType.Text, null);
        }

        public IEnumerable<T> SelectQueryToList<T>(string selectQuery, Dictionary<string, object> parameters) where T : class
        {
            return SelectQueryToList<T>(selectQuery, CommandType.Text, parameters);
        }

        public async Task<IEnumerable<T>> SelectQueryToListAsync<T>(string selectQuery, Dictionary<string, object> parameters) where T : class
        {
            return await SelectQueryToListAsync<T>(selectQuery, CommandType.Text, parameters);
        }

        public async Task<IEnumerable<T>> SelectQueryStoredProcedureToListAsync<T>(string selectQuery, Dictionary<string, object> parameters) where T : class
        {
            return await SelectQueryToListAsync<T>(selectQuery, CommandType.StoredProcedure, parameters);
        }

        public IEnumerable<T> SelectQueryToList<T>(string selectQuery, CommandType commandType, Dictionary<string, object> parameters) where T : class
        {
            IList<T> retorno = new List<T>();

            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection))
                {
                    sqlCommand.CommandType = commandType;

                    if (parameters != null && parameters.Count > 0)
                        CreateParameter(sqlCommand, parameters);

                    sqlConnection.Open();

                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        while (sqlDataReader.Read())
                        {
                            T item = SqlDataReaderToObject<T>(sqlDataReader);

                            retorno.Add(item);
                        }
                    }
                }
            }

            return retorno;
        }
        
        public async Task<IEnumerable<T>> SelectQueryToListAsync<T>(string selectQuery, CommandType commandType, Dictionary<string, object> parameters) where T : class
        {
            IList<T> retorno = new List<T>();

            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection))
                {
                    sqlCommand.CommandType = commandType;

                    if (parameters != null && parameters.Count > 0)
                        CreateParameter(sqlCommand, parameters);

                    await sqlConnection.OpenAsync();

                    using (SqlDataReader sqlDataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        while (await sqlDataReader.ReadAsync())
                        {
                            T item = SqlDataReaderToObject<T>(sqlDataReader);

                            retorno.Add(item);
                        }
                    }
                }
            }

            return retorno;
        }

        public IEnumerable<IEnumerable<object>> SelectQueryToList(string selectQuery, Dictionary<string, object> parameters)
        {
            return SelectQueryToListAsync(selectQuery, CommandType.Text, parameters).Result;
        }

        public async Task<IEnumerable<IEnumerable<object>>> SelectQueryToListAsync(string selectQuery, Dictionary<string, object> parameters)
        {
            return await SelectQueryToListAsync(selectQuery, CommandType.Text, parameters);
        }

        public IEnumerable<IEnumerable<object>> SelectQueryToList(string selectQuery, CommandType commandType, Dictionary<string, object> parameters)
        {
            IList<IEnumerable<object>> retorno = null;
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection))
            {
                sqlCommand.CommandType = commandType;

                if (parameters != null && parameters.Count > 0)
                    CreateParameter(sqlCommand, parameters);

                sqlConnection.Open();
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    if (retorno is null)
                        retorno = new List<IEnumerable<object>>();

                    List<object> item = sqlDataReader.SqlDataReaderToObject();
                    retorno.Add(item);
                }
            }
            return retorno;
        }

        public async Task<IEnumerable<IEnumerable<object>>> SelectQueryToListAsync(string selectQuery, CommandType commandType, Dictionary<string, object> parameters)
        {
            IList<IEnumerable<object>> retorno = null;
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection))
            {
                sqlCommand.CommandType = commandType;

                if (parameters != null && parameters.Count > 0)
                    CreateParameter(sqlCommand, parameters);

                await sqlConnection.OpenAsync();
                SqlDataReader sqlDataReader = await sqlCommand.ExecuteReaderAsync();

                while (await sqlDataReader.ReadAsync())
                {
                    if (retorno is null)
                        retorno = new List<IEnumerable<object>>();

                    List<object> item = sqlDataReader.SqlDataReaderToObject();
                    retorno.Add(item);
                }
            }
            return retorno;
        }

        public IEnumerable<IEnumerable<object>> SelectQueryToObjectList<T>(string selectQuery, CommandType commandType, T model)
        {
            IList<IEnumerable<object>> retorno = null;
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection))
            {
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandTimeout = 300;

                if (model != null)
                    CreateParameter(sqlCommand, model);

                sqlConnection.Open();
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    if (retorno is null)
                        retorno = new List<IEnumerable<object>>();

                    List<object> item = sqlDataReader.SqlDataReaderToObject();
                    retorno.Add(item);
                }
            }
            return retorno;
        }

        public async Task<IEnumerable<IEnumerable<object>>> SelectQueryToObjectListAsync<T>(string selectQuery, CommandType commandType, T model)
        {
            IList<IEnumerable<object>> retorno = null;
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection))
            {
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandTimeout = 300;

                if (model != null)
                    CreateParameter(sqlCommand, model);

                await sqlConnection.OpenAsync();
                SqlDataReader sqlDataReader = await sqlCommand.ExecuteReaderAsync();

                while (await sqlDataReader.ReadAsync())
                {
                    if (retorno is null)
                        retorno = new List<IEnumerable<object>>();

                    List<object> item = sqlDataReader.SqlDataReaderToObject();
                    retorno.Add(item);
                }
            }
            return retorno;
        }

        public T SelectQuerySingleOrDefault<T>(string selectQuery) where T : class, new()
        {
            return SelectQuerySingleOrDefault<T>(selectQuery, null);
        }

        public T SelectQuerySingleOrDefault<T>(string selectQuery, Dictionary<string, object> parameters, CommandType commandType = CommandType.Text) where T : class, new()
        {
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection))
                {
                    sqlCommand.CommandType = commandType;

                    if (parameters != null && parameters.Count > 0)
                        CreateParameter(sqlCommand, parameters);

                    sqlConnection.Open();

                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        if (sqlDataReader.Read())
                        {
                            return SqlDataReaderToObject<T>(sqlDataReader) ?? new T();
                        }
                    }
                }
            }

            return new T();
        }

        public async Task<T> SelectQuerySingleOrDefaultAsync<T>(string selectQuery, Dictionary<string, object> parameters, CommandType commandType = CommandType.Text) where T : class, new()
        {
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection))
                {
                    sqlCommand.CommandType = commandType;

                    if (parameters != null && parameters.Count > 0)
                        CreateParameter(sqlCommand, parameters);

                    await sqlConnection.OpenAsync();

                    using (SqlDataReader sqlDataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (sqlDataReader.Read())
                        {
                            return SqlDataReaderToObject<T>(sqlDataReader) ?? new T();
                        }
                    }
                }
            }

            return new T();
        }

        public async Task<T> SelectQuerySingleOrDefaultAsync<T>(string selectQuery) where T : class, new()
        {
            return await SelectMultiQueryToObjectListAsync<T>(selectQuery, null);
        }

        public async Task<T> SelectMultiQueryToObjectListAsync<T>(string selectQuery, Dictionary<string, object> parameters, CommandType commandType = CommandType.Text) where T : class, new()
        {
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection))
                {
                    sqlCommand.CommandType = commandType;

                    if (parameters != null && parameters.Count > 0)
                        CreateParameter(sqlCommand, parameters);

                    await sqlConnection.OpenAsync();

                    using (SqlDataReader sqlDataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (await sqlDataReader.ReadAsync())
                        {
                            return SqlDataReaderToObject<T>(sqlDataReader) ?? new T();
                        }
                    }
                }
            }

            return new T();
        }

        public int ExecuteNonQuery(string command, Dictionary<string, object> parameters)
        {
            return ExecuteNonQueryAsync(command, CommandType.Text, parameters).Result;
        }

        public async Task<int> ExecuteNonQueryAsync(string command, Dictionary<string, object> parameters)
        {
            return await ExecuteNonQueryAsync(command, CommandType.Text, parameters);
        }

        public int ExecuteNonQuery(string command, CommandType commandType, Dictionary<string, object> parameters)
        {
            int retorno = 0;
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection))
            {
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandTimeout = 300;

                if (parameters != null && parameters.Count > 0)
                    CreateParameter(sqlCommand, parameters);

                sqlConnection.Open();
                retorno = sqlCommand.ExecuteNonQuery();
            }

            return retorno;
        }

        public async Task<int> ExecuteNonQueryAsync(string command, CommandType commandType, Dictionary<string, object> parameters)
        {
            int retorno = 0;
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection))
            {
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandTimeout = 300;

                if (parameters != null && parameters.Count > 0)
                    CreateParameter(sqlCommand, parameters);

                await sqlConnection.OpenAsync();
                retorno = await sqlCommand.ExecuteNonQueryAsync(); 
            }

            return retorno;
        }

        public int ExecuteNonQuery<T>(string command, CommandType commandType, T model)
        {
            int retorno = 0;

            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection))
            {
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandTimeout = 300;

                if (model != null)
                    CreateParameter(sqlCommand, model);

                sqlConnection.Open();
                retorno = sqlCommand.ExecuteNonQuery();
            }

            return retorno;
        }

        public async Task<int> ExecuteNonQueryAsync<T>(string command, CommandType commandType, T model)
        {
            int retorno = 0;

            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection))
            {
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandTimeout = 300;

                if (model != null)
                    CreateParameter(sqlCommand, model);

                await sqlConnection.OpenAsync();
                retorno = await sqlCommand.ExecuteNonQueryAsync();
            }

            return retorno;
        }

        public object ExecuteScalar(string command, Dictionary<string, object> parameters)
        {
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection))
                {
                    sqlCommand.CommandType = CommandType.Text;

                    if (parameters != null && parameters.Count > 0)
                        CreateParameter(sqlCommand, parameters);

                    sqlConnection.Open();

                    return sqlCommand.ExecuteScalar();
                }
            }
        }

        public async Task<object> ExecuteScalarAsync(string command, Dictionary<string, object> parameters)
        {
            return await ExecuteScalarAsync(command, CommandType.Text, parameters);
        }
        
        public object ExecuteScalar(string command, CommandType commandType, Dictionary<string, object> parameters)
        {
            object retorno = null;
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection))
            {
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandTimeout = 300;

                if (parameters != null && parameters.Count > 0)
                    CreateParameter(sqlCommand, parameters);

                sqlConnection.Open();
                retorno = sqlCommand.ExecuteScalar();
            }

            return retorno;
        }

        public async Task<object> ExecuteScalarAsync(string command, CommandType commandType = CommandType.Text, Dictionary<string, object> parameters = null)
        {
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection))
                {
                    sqlCommand.CommandType = commandType;

                    if (parameters != null && parameters.Count > 0)
                        CreateParameter(sqlCommand, parameters);

                    await sqlConnection.OpenAsync();

                    return await sqlCommand.ExecuteScalarAsync();
                }
            }
        }

        public object ExecuteScalar<T>(string command, CommandType commandType, T model)
        {
            object retorno = null;

            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection))
            {
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandTimeout = 300;

                if (model != null)
                    CreateParameter(sqlCommand, model);

                sqlConnection.Open();
                retorno = sqlCommand.ExecuteScalar();
            }

            return retorno;
        }

        public async Task<object> ExecuteScalarAsync<T>(string command, CommandType commandType, T model)
        {
            object retorno = null;

            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection))
            {
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandTimeout = 300;

                if (model != null)
                    CreateParameter(sqlCommand, model);

                await sqlConnection.OpenAsync();
                retorno = await sqlCommand.ExecuteScalarAsync();
            }

            return retorno;
        }

        public IEnumerable<IEnumerable<IEnumerable<object>>> SelectMultiQueryToObjectList<T>(string selectQuery, CommandType commandType, T model)
        {
            return SelectMultiQueryToObjectListAsync(selectQuery, commandType, model).Result;
        }

        public async Task<IEnumerable<IEnumerable<IEnumerable<object>>>> SelectMultiQueryToObjectListAsync<T>(string selectQuery, CommandType commandType, T model)
        {
            var retorno = new List<IEnumerable<IEnumerable<object>>>();

            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection))
            {
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandTimeout = 300;

                if (model != null)
                    CreateParameter(sqlCommand, model);

                await sqlConnection.OpenAsync();
                SqlDataReader sqlDataReader = await sqlCommand.ExecuteReaderAsync();

                while (sqlDataReader.HasRows)
                {
                    var rows = new List<IEnumerable<object>>();

                    while (await sqlDataReader.ReadAsync())
                    {
                        List<object> item = sqlDataReader.SqlDataReaderToObject();

                        rows.Add(item);
                    }

                    retorno.Add(rows);

                    sqlDataReader.NextResult();
                }
            }

            return retorno;
        }

        public IEnumerable<T> ObjectToEntityList<T>(IEnumerable<IEnumerable<object>> objectList)
        {
            Type dataType = GetType<T>();
            PropertyInfo[] properties = GetProperties(dataType);
            var resultado = new List<T>();

            if (objectList != null)
                foreach (List<object> item in objectList)
                {
                    T instance = CreateInstance<T>(dataType);

                    if (properties.Length.Equals(item.Count()))
                    {
                        for (var x = 0; x < properties.Length; x++)
                        {
                            object value = item[x];
                            SetValue(instance, properties[x], value);
                        }
                    }

                    resultado.Add(instance);
                }

            return resultado;
        }

        void CreateParameter(SqlCommand sqlCommand, Dictionary<string, object> parameters)
        {
            foreach (var item in parameters)
            {
                sqlCommand.Parameters.AddWithValue(item.Key, item.Value ?? DBNull.Value);
            }
        }

        void CreateParameter<T>(SqlCommand sqlCommand, T model)
        {
            Type dataType = GetType<T>();
            PropertyInfo[] properties = GetProperties(dataType);

            foreach (var item in properties)
            {
                sqlCommand.Parameters.Add(new SqlParameter(item.Name, GetValue(item, model) ?? DBNull.Value));
            }
        }

        

        #region [ Reflection Methods ]

        T SqlDataReaderToObject<T>(SqlDataReader sqlDataReader)
        {
            Type dataType = GetType<T>();

            switch (dataType)
            {
                case var exp when dataType == typeof(string):
                    return SqlDataReaderToType<T>(sqlDataReader);
                default:
                    PropertyInfo[] properties = GetProperties(dataType);
                    T instance = CreateInstance<T>(dataType);

                    IEnumerable<string> dataReaderColuns = sqlDataReader.GetColumnsName().Select(x => x.ToUpper());

                    foreach (var prop in properties)
                    {
                        if (dataReaderColuns.Contains(prop.Name.ToUpper()))
                        {
                            object value = sqlDataReader[prop.Name];
                            SetValue(instance, prop, value);
                        }
                    }

                    return instance;
            }
        }

        T SqlDataReaderToType<T>(SqlDataReader sqlDataReader)
        {
            try
            {
                return (T)Convert.ChangeType(sqlDataReader[0], typeof(T));
            }
            catch (InvalidCastException)
            {
                return default(T);
            }
        }

        T CreateInstance<T>(Type genericType)
        {
            var instance = (T)Activator.CreateInstance(genericType);
            return instance;
        }

        Type GetType<T>()
        {
            return typeof(T);
        }

        PropertyInfo[] GetProperties(Type genericType)
        {
            return genericType.GetProperties();
        }

        void SetValue<T>(T instance, PropertyInfo prop, object value)
        {
            if (!(value is null) && value.GetType() != DBNull.Value.GetType())
            {
                prop.SetValue(instance, value);
            }
        }

        object GetValue<T>(PropertyInfo prop, T model)
        {
            return prop?.GetValue(model);
        }

        #endregion
    }

    public static class SqlDataReaderExtensions
    {
        public static List<string> GetColumnsName(this SqlDataReader sqlDataReader)
        {
            List<string> columns = new List<string>();

            for (int i = 0; i < sqlDataReader.FieldCount; i++)
            {
                columns.Add(sqlDataReader.GetName(i));
            }

            return columns;
        }

        public static List<object> SqlDataReaderToObject(this SqlDataReader sqlDataReader)
        {
            List<object> colunas = new List<object>();

            for (int i = 0; i < sqlDataReader.FieldCount; i++)
            {
                object value = sqlDataReader.GetFieldValue<object>(i);
                colunas.Add(value);
            }

            return colunas;
        }

        public static T SqlDataReaderToObject<T>(this SqlDataReader sqlDataReader)
        {
            Type dataType = typeof(T);

            switch (dataType)
            {
                case var exp when dataType == typeof(string):
                    return SqlDataReaderToType<T>(sqlDataReader);
                default:
                    PropertyInfo[] properties = dataType.GetProperties();
                    T instance = CreateInstance<T>(dataType);

                    IEnumerable<string> dataReaderColuns = sqlDataReader.GetColumnsName().Select(x => x.ToUpper());

                    foreach (var prop in properties)
                    {
                        if (dataReaderColuns.Contains(prop.Name.ToUpper()))
                        {
                            object value = sqlDataReader[prop.Name];
                            SetValue(instance, prop, value);
                        }
                    }

                    return instance;
            }
        }

        private static T SqlDataReaderToType<T>(SqlDataReader sqlDataReader)
        {
            try
            {
                return (T)Convert.ChangeType(sqlDataReader[0], typeof(T));
            }
            catch (InvalidCastException)
            {
                return default(T);
            }
        }

        private static T CreateInstance<T>(Type genericType)
        {
            var instance = (T)Activator.CreateInstance(genericType);
            return instance;
        }

        private static void SetValue<T>(T instance, PropertyInfo prop, object value)
        {
            if (!(value is null) && value.GetType() != DBNull.Value.GetType())
            {
                prop.SetValue(instance, value);
            }
        }
    }

    
}
