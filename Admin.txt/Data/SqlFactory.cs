﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using System;

namespace Itau.SZ7.GPS.Admin.Data.Sql
{
    public class SqlFactory : ISqlFactory
    {
        private readonly string _connectionString;

        public SqlFactory(IAppConfiguration appConfiguration)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public SqlFactory(string connectionString)
        {
            _connectionString = connectionString;
        }

        /// <summary>
        /// Criar uma instância de uma classe do tipo T.
        /// </summary>
        /// <typeparam name="T">Tipo da instância que será criada</typeparam>
        /// <returns>Retorna uma instãncia de T. Se não achar o tipo retorna null.</returns>
        public T Build<T>()
        {
            var type = typeof(T);

            switch (type)
            {
                case Type intType when intType == typeof(ISqlMultipleResult):
                    return (T)BuildMultipleResult();
                default:
                    return default;
            }
        }

        private ISqlMultipleResult BuildMultipleResult()
        {
            return new SqlMultipleResult(_connectionString);
        }
    }
}
