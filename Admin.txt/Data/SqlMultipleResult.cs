﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Data.Sql
{
    /// <summary>
    /// Executa n querys sql e retorna n result sets.
    /// </summary>
    internal class SqlMultipleResult : ISqlMultipleResult, ISqlResult
    {
        public SqlConnection _sqlConnection;
        public SqlCommand _sqlCommand;
        private SqlDataReader _sqlDataReader;
        public bool HasNextResult { get; private set; }
        public bool HasRows { get { return _sqlDataReader.HasRows; } }
        private bool disposed = false;

        public SqlMultipleResult(IAppConfiguration appConfiguration)
        {
            CreateInstances(appConfiguration.GetConnectionStrings("GPSConnection"));
        }

        public SqlMultipleResult(string connectionString)
        {
            CreateInstances(connectionString);
        }
        
        /// <summary>
        /// Define que o tipo de execução será stored procedure
        /// </summary>
        /// <param name="procedure">Nome da procedure</param>
        /// <returns>Retorna ISqlResult <see cref="ISqlMultipleResult"/></returns>
        public ISqlMultipleResult StoredProcedure(string procedure)
        {
            _sqlCommand.CommandType = CommandType.StoredProcedure;
            _sqlCommand.CommandText = procedure;

            return this;
        }

        /// <summary>
        /// Define que o tipo de execução será query (texto)
        /// </summary>
        /// <param name="query">Query sql</param>
        /// <returns>Retorna ISqlResult <see cref="ISqlMultipleResult"/></returns>
        public ISqlMultipleResult Query(string query)
        {
            _sqlCommand.CommandType = CommandType.Text;
            _sqlCommand.CommandText = query;

            return this;
        }

        /// <summary>
        /// Executa o comando no banco de dados.
        /// </summary>
        /// <returns>Retorna ISqlResult <see cref="ISqlResult"/></returns>
        public async Task<ISqlResult> ExecuteAsync()
        {
            try
            {
                await _sqlConnection.OpenAsync();

                _sqlCommand.Connection = _sqlConnection;
                _sqlDataReader = await _sqlCommand.ExecuteReaderAsync();
            }
            catch (Exception ex) {
                Close(); }

            return this;
        }

        /// <summary>
        /// Executa o comando no banco de dados.
        /// </summary>
        /// <returns>Retorna ISqlResult <see cref="ISqlResult"/></returns>
        public ISqlResult Execute()
        {
            try
            {
                _sqlConnection.Open();

                _sqlCommand.Connection = _sqlConnection;
                _sqlDataReader = _sqlCommand.ExecuteReader();
            }
            catch { Close(); }

            return this;
        }

        /// <summary>
        /// Convert o result set no tipo respectivo.
        /// É necessário executar o método Cast para cada DataReader que a consulta retornar.
        /// </summary>
        /// <typeparam name="T">Tipo que o resultado do select deverá ser convertido.</typeparam>
        /// <param name="result">Variável que deverá receber o resultado da conversão. Pode ser um built-in types ou um custom type.</param>
        /// <returns>Retorna ISqlMultipleResults <see cref="ISqlMultipleResults"/>.</returns>
        public ISqlResult Cast<T>(out IEnumerable<T> result)
        {
            result = Enumerable.Empty<T>();

            if (_sqlDataReader.HasRows)
            {
                result = Getlist<T>().ToList();
            }

            HasNextResult = _sqlDataReader.NextResult();

            if (!HasNextResult)
            {
                Close();

                Dispose();
            }

            return this;
        }

        /// </summary>
        /// <typeparam name="T">Tipo que o resultado do select deverá ser convertido.</typeparam>
        /// <param name="result">Variável que deverá receber o resultado da conversão. Pode ser um built-in types ou um custom type.</param>
        /// <returns>Retorna ISqlMultipleResults <see cref="ISqlMultipleResults"/>.</returns>
        public async Task<IEnumerable<T>> CastAsync<T>()
        {
            var result = Enumerable.Empty<T>();

            if (_sqlDataReader.HasRows)
            {
                result = await GetlistAsync<T>();
            }

            HasNextResult = await _sqlDataReader.NextResultAsync();

            if (!HasNextResult)
            {
                Close();

                Dispose();
            }

            return result;
        }

        /// <summary>
        /// Utilizado para valores únicos, por exemplo string.
        /// É necessário executar o método Cast para cada DataReader que a consulta retornar.
        /// </summary>
        /// <typeparam name="T">Tipo que o resultado do select deverá ser convertido.</typeparam>
        /// <param name="result">Variável que deverá receber o resultado da conversão. Pode ser um built-in types ou um custom type.</param>
        /// <returns>Retorna ISqlMultipleResults <see cref="ISqlMultipleResults"/>.</returns>
        public ISqlResult CastSingle<T>(out T result)
        {
            result = default;

            if (_sqlDataReader.IsClosed)
            {
                return this;
            }

            if (_sqlDataReader.Read())
            {
                result = _sqlDataReader.SqlDataReaderToObject<T>();
            }

            HasNextResult = _sqlDataReader.NextResult();

            if (!HasNextResult)
            {
                Dispose();
            }

            return this;
        }

        /// <summary>
        /// Utilizado para valores únicos, por exemplo string.
        /// É necessário executar o método Cast para cada DataReader que a consulta retornar.
        /// </summary>
        /// <typeparam name="T">Tipo que o resultado do select deverá ser convertido.</typeparam>
        /// <param name="result">Variável que deverá receber o resultado da conversão. Pode ser um built-in types ou um custom type.</param>
        /// <returns>Retorna ISqlMultipleResults <see cref="ISqlMultipleResults"/>.</returns>
        public async Task<T> CastSingleAsync<T>()
        {
            T result = default;

            if (_sqlDataReader.IsClosed)
            {
                return result;
            }

            if (await _sqlDataReader.ReadAsync())
            {
                result = _sqlDataReader.SqlDataReaderToObject<T>();
            }

            HasNextResult = await _sqlDataReader.NextResultAsync();

            if (!HasNextResult)
            {
                Dispose();
            }

            return result;
        }

        /// <summary>
        /// Adiciona um parâmetro para ser utilizado na query sql.
        /// </summary>
        /// <param name="name">Nome do parãmetro.</param>
        /// <param name="value">Valor do parãmetro.</param>
        /// <returns>Retorna ISqlMultipleResults <see cref="ISqlMultipleResults"/>.</returns>
        public ISqlMultipleResult AddParameter(string name, object value)
        {
            _sqlCommand.Parameters.AddWithValue(name, value ?? DBNull.Value);

            return this;
        }

        /// <summary>
        /// Adiciona parâmetros para serem utilizados na query sql.
        /// </summary>
        /// <typeparam name="T">Tipo que o resultado do select deverá ser convertido.</typeparam>
        /// <param name="lambdaExpression">Expressão com os campos dos parâmetros</param>
        /// <param name="entity">Objeto que contém os valores que serão utilizados para construir os parâmetros.</param>
        /// <returns>Retorna ISqlMultipleResults <see cref="ISqlMultipleResults"/>.</returns>
        public ISqlMultipleResult AddParameter<T>(Expression<Func<T, dynamic>> lambdaExpression, T entity)
        {
            if (lambdaExpression.Body is NewExpression newExpression)
            {
                foreach (var member in newExpression.Members)
                {
                    var propertyInfo = member as PropertyInfo;
                    AddParameter<T>(entity, propertyInfo.Name);
                }
            }
            else if (lambdaExpression.Body is MemberExpression memberExpression)
            {
                AddParameter<T>(entity, memberExpression.Member.Name);
            }

            return this;
        }

        /// <summary>
        /// Força o fechamento da conexão
        /// </summary>
        public void Close()
        {
            if (_sqlConnection?.State == ConnectionState.Open)
            {
                _sqlConnection.Close();
            }

            if (_sqlDataReader?.IsClosed == false)
            {
                _sqlDataReader.Close();
            }
        }

        private void CreateInstances(string connectionString)
        {
            _sqlConnection = new SqlConnection(connectionString);
            _sqlCommand = new SqlCommand();
        }

        private void CreateParameter(Dictionary<string, object> parameters)
        {
            foreach (var item in parameters)
            {
                _sqlCommand.Parameters.AddWithValue(item.Key, item.Value ?? DBNull.Value);
            }
        }

        private void AddParameter<T>(T entity, string propName)
        {
            var type = entity.GetType();
            var properties = type.GetProperties();
            var prop = properties.First(x => x.Name == propName);

            _sqlCommand.Parameters.AddWithValue(propName, prop.GetValue(entity) ?? DBNull.Value);
        }

        private IEnumerable<T> Getlist<T>()
        {
            while (_sqlDataReader.Read())
            {
                yield return _sqlDataReader.SqlDataReaderToObject<T>();
            }
        }

        private async Task<IEnumerable<T>> GetlistAsync<T>()
        {
            var list = new Collection<T>();

            while (await _sqlDataReader.ReadAsync())
            {
                list.Add(_sqlDataReader.SqlDataReaderToObject<T>());
            }

            return list;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                Close();

                if (_sqlDataReader != null)
                {
                    _sqlDataReader.Dispose();
                }

                if (_sqlCommand != null)
                {
                    _sqlCommand.Dispose();
                }

                if (_sqlConnection != null)
                {
                    _sqlConnection.Dispose();
                }
            }

            disposed = true;
        }
    }
}
