﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Data
{
    internal class HttpRequestHeaderHandler : DelegatingHandler
    {

        public HttpRequestHeaderHandler()
        {
        }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            CabecalhoPadrao(request);
            return base.SendAsync(request, cancellationToken);
        }

        void CabecalhoPadrao(HttpRequestMessage requisicao)
        {
            //AdicionarItemCabecalho(requisicao, ChavesPadrao.AuthenticationRequestGuidName, _sessao?.Guid);
            //AdicionarItemCabecalho(requisicao, ChavesPadrao.CABECALHO_COLABORADOR, _sessao?.IdColaborador.ToString());
            //AdicionarItemCabecalho(requisicao, ChavesPadrao.CABECALHO_COLABORADORAGIR, _sessao?.IdColaboradorAgir.ToString());
            //AdicionarItemCabecalho(requisicao, ChavesPadrao.CABECALHO_FUNCIONALIDADE, _sessao?.IdFuncionalidade.GetHashCode().ToString());

            //AdicionarItemCabecalho(requisicao, ChavesPadrao.AuthenticationRequestApiGuid, _sessao?.ApiGuid, true);
            //AdicionarItemCabecalho(requisicao, ChavesPadrao.CABECALHO_PLATAFORMA, Plataforma.Api.ToString(), true);
            AdicionarItemCabecalho(requisicao, "X-fdad_apitoken", "DB6C2579-EEA1-4E6D-807F-C80CE2993BD0", true);
        }

        void AdicionarItemCabecalho(HttpRequestMessage requisicao, string nomeItem, string valorItem)
        {
            if (!requisicao.Headers.Contains(nomeItem))
                requisicao.Headers.Add(nomeItem, valorItem);
        }

        void AdicionarItemCabecalho(HttpRequestMessage requisicao, string nomeItem, string valorItem, bool removerExistente)
        {
            if (removerExistente)
                requisicao.Headers.Remove(nomeItem);

            AdicionarItemCabecalho(requisicao, nomeItem, valorItem);
        }
    }
}
