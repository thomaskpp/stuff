﻿using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Data
{
    public class GpsHttpClient : IGpsHttpClient
    {
        private readonly HttpClient _httpClient;

        public GpsHttpClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<GpsHttpResponse<TSaida>> EnviarAsync<TSaida>(HttpMethod metodo, string url)
        {
            HttpRequestMessage requisicao = CriarRequisicao(metodo, url, null, null);
            return await ExecutarRequisicao<TSaida>(requisicao);
        }

        public async Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, TEntrada corpo)
        {
            HttpRequestMessage requisicao = CriarRequisicao(metodo, url, corpo, null);
            return await ExecutarRequisicao<TSaida>(requisicao);
        }

        public async Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, Dictionary<string, string> cabecalho)
        {
            HttpRequestMessage requisicao = CriarRequisicao(metodo, url, null, cabecalho);
            return await ExecutarRequisicao<TSaida>(requisicao);
        }

        public async Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, TEntrada corpo, Dictionary<string, string> cabecalho)
        {
            HttpRequestMessage requisicao = CriarRequisicao(metodo, url, corpo, cabecalho);
            return await ExecutarRequisicao<TSaida>(requisicao);
        }

        HttpRequestMessage CriarRequisicao(HttpMethod metodo, string url, object corpo, Dictionary<string, string> cabecalho)
        {
            HttpRequestMessage requisicao = new HttpRequestMessage(metodo, url);

            PreencherCabecalho(requisicao, cabecalho);
            PreencherCorpo(requisicao, corpo);

            return requisicao;
        }

        async Task<GpsHttpResponse<TSaida>> ExecutarRequisicao<TSaida>(HttpRequestMessage requisicao)
        {
            var retorno = await _httpClient.SendAsync(requisicao);
            var respostaPadrao = new GpsHttpResponse<TSaida>(retorno);
            await respostaPadrao.CarregarConteudo();
            return respostaPadrao;
        }

        void PreencherCabecalho(HttpRequestMessage requisicao, Dictionary<string, string> cabecalho)
        {
            if (!(cabecalho is null))
            {
                foreach (var item in cabecalho)
                {
                    requisicao.Headers.TryAddWithoutValidation(item.Key, item.Value);
                }
            }
        }

        void PreencherCorpo<TEntrada>(HttpRequestMessage requisicao, TEntrada corpo)
        {
            if (corpo != null)
            {
                requisicao.Content = new StringContent(JsonConvert.SerializeObject(corpo), Encoding.UTF8, "application/json");
            }
        }
    }
}
