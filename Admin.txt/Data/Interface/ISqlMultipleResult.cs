﻿using System;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Data.Sql
{
    public interface ISqlMultipleResult : IDisposable
    {
        /// <summary>
        /// Adiciona um parâmetro para ser utilizado na query sql
        /// </summary>
        /// <typeparam name="T">Tipo que o resultado do select deverá ser convertido.</typeparam>
        /// <param name="lambdaExpression">Expressão com os campos dos parâmetros</param>
        /// <param name="entity">Objeto que contém os valores que serão utilizados para construir os parâmetros.</param>
        /// <returns>Retorna ISqlMultipleResults <see cref="ISqlMultipleResults"/>.</returns>
        ISqlMultipleResult AddParameter<T>(Expression<Func<T, dynamic>> lambdaExpression, T entity);

        /// <summary>
        /// Adiciona parâmetros para serem utilizados na query sql.
        /// </summary>
        /// <param name="name">Nome do parãmetro.</param>
        /// <param name="value">Valor do parãmetro.</param>
        /// <returns>Retorna ISqlMultipleResults <see cref="ISqlMultipleResults"/>.</returns>
        ISqlMultipleResult AddParameter(string name, object value);

        /// <summary>
        /// Define que o tipo de execução será stored procedure
        /// </summary>
        /// <param name="procedure">Nome da procedure</param>
        /// <returns>Retorna ISqlResult <see cref="ISqlMultipleResult"/></returns>        
        ISqlMultipleResult StoredProcedure(string procedure);

        /// <summary>
        /// Define que o tipo de execução será query (texto)
        /// </summary>
        /// <param name="query">Query sql</param>
        /// <returns>Retorna ISqlResult <see cref="ISqlMultipleResult"/></returns>
        ISqlMultipleResult Query(string query);

        /// <summary>
        /// Executa o comando no banco de dados.
        /// </summary>
        /// <returns>Retorna ISqlResult <see cref="ISqlResult"/></returns>
        Task<ISqlResult> ExecuteAsync();

        /// <summary>
        /// Executa o comando no banco de dados.
        /// </summary>
        /// <returns>Retorna ISqlResult <see cref="ISqlResult"/></returns>
        ISqlResult Execute();
    }
}
