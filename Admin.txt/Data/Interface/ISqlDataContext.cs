﻿using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Data.Interface
{
    public interface ISqlDataContext
    {
        IEnumerable<T> SelectQueryToList<T>(string selectQuery) where T : class;
        Task<IEnumerable<T>> SelectQueryToListAsync<T>(string selectQuery) where T : class;

        IEnumerable<T> SelectQueryToList<T>(string selectQuery, Dictionary<string, object> parameters) where T : class;
        Task<IEnumerable<T>> SelectQueryToListAsync<T>(string selectQuery, Dictionary<string, object> parameters) where T : class;

        IEnumerable<T> SelectQueryToList<T>(string selectQuery, CommandType commandType, Dictionary<string, object> parameters) where T : class;
        Task<IEnumerable<T>> SelectQueryToListAsync<T>(string selectQuery, CommandType commandType, Dictionary<string, object> parameters) where T : class;

        IEnumerable<IEnumerable<object>> SelectQueryToList(string selectQuery, Dictionary<string, object> parameters);
        Task<IEnumerable<IEnumerable<object>>> SelectQueryToListAsync(string selectQuery, Dictionary<string, object> parameters);

        IEnumerable<IEnumerable<object>> SelectQueryToList(string selectQuery, CommandType commandType, Dictionary<string, object> parameters);
        Task<IEnumerable<IEnumerable<object>>> SelectQueryToListAsync(string selectQuery, CommandType commandType, Dictionary<string, object> parameters);

        IEnumerable<IEnumerable<object>> SelectQueryToObjectList<T>(string selectQuery, CommandType commandType, T model);
        Task<IEnumerable<IEnumerable<object>>> SelectQueryToObjectListAsync<T>(string selectQuery, CommandType commandType, T model);

        T SelectQuerySingleOrDefault<T>(string selectQuery) where T : class, new();
        Task<T> SelectQuerySingleOrDefaultAsync<T>(string selectQuery) where T : class, new();

        T SelectQuerySingleOrDefault<T>(string selectQuery, Dictionary<string, object> parameters, CommandType commandType = CommandType.Text) where T : class, new();
        Task<T> SelectQuerySingleOrDefaultAsync<T>(string selectQuery, Dictionary<string, object> parameters, CommandType commandType = CommandType.Text) where T : class, new();

        int ExecuteNonQuery(string command, Dictionary<string, object> parameters);
        Task<int> ExecuteNonQueryAsync(string command, Dictionary<string, object> parameters);

        int ExecuteNonQuery(string command, CommandType commandType, Dictionary<string, object> parameters);
        Task<int> ExecuteNonQueryAsync(string command, CommandType commandType, Dictionary<string, object> parameters);

        int ExecuteNonQuery<T>(string command, CommandType commandType, T model);
        Task<int> ExecuteNonQueryAsync<T>(string command, CommandType commandType, T model);

        object ExecuteScalar(string command, Dictionary<string, object> parameters);

        object ExecuteScalar(string command, CommandType commandType, Dictionary<string, object> parameters);

        Task<object> ExecuteScalarAsync(string command, CommandType commandType = CommandType.Text, Dictionary<string, object> parameters = null);
        Task<object> ExecuteScalarAsync(string command, Dictionary<string, object> parameters);

        object ExecuteScalar<T>(string command, CommandType commandType, T model);
        Task<object> ExecuteScalarAsync<T>(string command, CommandType commandType, T model);

        IEnumerable<T> ObjectToEntityList<T>(IEnumerable<IEnumerable<object>> objectList);

        IEnumerable<IEnumerable<IEnumerable<object>>> SelectMultiQueryToObjectList<T>(string selectQuery, CommandType commandType, T model);

        Task<IEnumerable<IEnumerable<IEnumerable<object>>>> SelectMultiQueryToObjectListAsync<T>(string selectQuery, CommandType commandType, T model);

        Task<IEnumerable<T>> SelectQueryStoredProcedureToListAsync<T>(string selectQuery, Dictionary<string, object> parameters) where T : class;
    }
}
