﻿namespace Itau.SZ7.GPS.Admin.Data.Sql
{
    public interface ISqlFactory
    {
        /// <summary>
        /// Criar uma instância de uma classe do tipo T.
        /// </summary>
        /// <typeparam name="T">Tipo da instância que será criada</typeparam>
        /// <returns>Retorna uma instãncia de T. Se não achar o tipo retorna null.</returns>
        T Build<T>();
    }
}
