﻿using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Data.Interface
{
    public interface IGpsHttpClient
    {
        //IGpsHttpClient Init(Entidade.Sessao sessao);

        Task<GpsHttpResponse<TSaida>> EnviarAsync<TSaida>(HttpMethod metodo, string url);

        Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, TEntrada corpo);

        Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, Dictionary<string, string> cabecalho);

        Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, TEntrada corpo, Dictionary<string, string> cabecalho);
    }
}
