﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Data.Sql
{
    public interface ISqlResult
    {
        /// <summary>
        /// Convert o result set no tipo respectivo.
        /// É necessário executar o método Cast para cada DataReader que a consulta retornar.
        /// </summary>
        /// <typeparam name="T">Tipo que o resultado do select deverá ser convertido.</typeparam>
        /// <param name="result">Variável que deverá receber o resultado da conversão. Pode ser um built-in types ou um custom type.</param>
        /// <returns>Retorna ISqlMultipleResults <see cref="ISqlMultipleResults"/>.</returns>
        ISqlResult Cast<T>(out IEnumerable<T> result);

        /// <summary>
        /// Convert o result set no tipo respectivo.
        /// É necessário executar o método Cast para cada DataReader que a consulta retornar.
        /// </summary>
        /// <typeparam name="T">Tipo que o resultado do select deverá ser convertido.</typeparam>
        /// <returns>Retorna um IEnumerable<T>.</returns>
        Task<T> CastSingleAsync<T>();

        /// <summary>
        /// Convert o result set no tipo respectivo.
        /// É necessário executar o método Cast para cada DataReader que a consulta retornar.
        /// </summary>
        /// <typeparam name="T">Tipo que o resultado do select deverá ser convertido.</typeparam>
        /// <returns>Retorna um IEnumerable<T>.</returns>
        Task<IEnumerable<T>> CastAsync<T>();

        /// <summary>
        /// Utilizado para valores únicos, por exemplo string.
        /// É necessário executar o método Cast para cada DataReader que a consulta retornar.
        /// </summary>
        /// <typeparam name="T">Tipo que o resultado do select deverá ser convertido.</typeparam>
        /// <param name="result">Variável que deverá receber o resultado da conversão. Pode ser um built-in types ou um custom type.</param>
        /// <returns>Retorna ISqlMultipleResults <see cref="ISqlMultipleResults"/>.</returns>
        ISqlResult CastSingle<T>(out T result);

        /// <summary>
        /// Força o fechamento da conexão
        /// </summary>
        void Close();
    }
}
