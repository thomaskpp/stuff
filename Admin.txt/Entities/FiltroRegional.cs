﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class FiltroRegional
    {
        public FiltroRegional()
        {
        }

        public FiltroRegional(int idPoloRegional, int idPoloRegiao, int idPoloDICOM, int codigoPolo, string funcional, string nome)
        {
            IdPoloRegional = idPoloRegional;
            IdPoloRegiao = idPoloRegiao;
            IdPoloDICOM = idPoloDICOM;
            CodigoPolo = codigoPolo;
            Funcional = funcional;
            Nome = nome;
        }

        public int IdPoloRegional { get; set; }
        public int IdPoloRegiao { get; set; }
        public int IdPoloDICOM { get; set; }
        public int CodigoPolo { get; set; }
        public string Funcional { get; set; }
        public string Nome { get; set; }
    }
}
