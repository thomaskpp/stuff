﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class FuncionalidadeHome : Funcionalidade
    {
        public bool Home { get; set; }
    }
}
