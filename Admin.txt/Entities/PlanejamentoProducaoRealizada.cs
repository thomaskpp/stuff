﻿
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Extensions;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PlanejamentoProducaoRealizada
    {
        public Int64 Id { get; set; }
        public int IdPlanejamentoItem { get; set; }
        public int IdColaboradorAgir { get; set; }
        public int CodigoItem { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public DateTime DataReferencia { get; set; }
        public decimal ValorProducaoRealizada { get; set; }
        public decimal ValorICMRealizado { get; set; }
        public decimal ValorPontuacaoRealizada { get; set; }

        [NotMapped]
        public int Linha { get; set; }

        [NotMapped]
        public string Carteira { get; set; }

        [NotMapped]
        public short Mes { get; set; }

        [NotMapped]
        public short Ano { get; set; }

        [NotMapped]
        public int IdSegmento { get; set; }

        public PlanejamentoItemGradeCarteira PlanejamentoItemGradeCarteira { get; set; }

        public static List<PlanejamentoProducaoRealizada> ConverteColunas(List<int> linhas, List<string> colunas, Enums.Segmentos segmento)
        {
            var result = new List<PlanejamentoProducaoRealizada>();
            var dtAtual = DateTime.Now;

            for (var x = 0; x < colunas.Count; x++)
            {
                try
                {
                    var arrayColunas = colunas[x].Split(';');

                    var planejamentoProducaoRealizada = new PlanejamentoProducaoRealizada();

                    switch (segmento)
                    {
                        case Enums.Segmentos.Agencias:

                            planejamentoProducaoRealizada = new PlanejamentoProducaoRealizada()
                            {
                                Carteira = $"01_{IntExtension.TryParse(arrayColunas[3])}",
                                //NomeSegmento = "AGENCIAS",
                                IdSegmento = (int)Enums.Segmentos.Agencias,
                                CodigoItem = IntExtension.TryParse(arrayColunas[7]),
                                DataCriacao = dtAtual,
                                DataAtualizacao = dtAtual,
                                DataReferencia = DateTimeExtension.TryParse(arrayColunas[16]),
                                ValorProducaoRealizada = DecimalExtension.TryParse(arrayColunas[8], "en-us"),
                                ValorICMRealizado = DecimalExtension.TryParse(arrayColunas[10], "en-us") / 100,
                                ValorPontuacaoRealizada = DecimalExtension.TryParse(arrayColunas[12], "en-us"),
                                Mes = ShortExtension.TryParse(DateTimeExtension.TryParse(arrayColunas[0]).Month.ToString()),
                                Ano = ShortExtension.TryParse(DateTimeExtension.TryParse(arrayColunas[0]).Year.ToString()),
                                //CodigoAgencia = IntExtension.TryParse(arrayColunas[3]),
                                //Grade = ShortExtension.TryParse(arrayColunas[6]),
                                Linha = linhas[x]
                            };

                            break;

                        case Enums.Segmentos.Uniclass:

                            planejamentoProducaoRealizada = new PlanejamentoProducaoRealizada()
                            {
                                CodigoItem = IntExtension.TryParse(arrayColunas[8]),
                                DataCriacao = dtAtual,
                                DataAtualizacao = dtAtual,
                                DataReferencia = DateTimeExtension.TryParse(arrayColunas[15]),
                                ValorProducaoRealizada = DecimalExtension.TryParse(arrayColunas[9], "en-us"),
                                ValorICMRealizado = DecimalExtension.TryParse(arrayColunas[11], "en-us") / 100,
                                ValorPontuacaoRealizada = DecimalExtension.TryParse(arrayColunas[13], "en-us"),

                                Carteira = $"{arrayColunas[5].Substring(arrayColunas[5].Length - 2, 2)}_{ (arrayColunas[1].Equals("80") ? arrayColunas[4] : arrayColunas[3]) }",
                                Mes = ShortExtension.TryParse(DateTimeExtension.TryParse(arrayColunas[0]).Month.ToString()),
                                Ano = ShortExtension.TryParse(DateTimeExtension.TryParse(arrayColunas[0]).Year.ToString()),
                                IdSegmento = (int)Enums.Segmentos.Uniclass,

                                //NomeSegmento = "UNICLASS",
                                //DataCriacao = dtAtual,
                                //ValorPontuacaoRealizada = DecimalExtension.TryParse(arrayColunas[13], "en-us"),
                                //ValorProducaoRealizada = DecimalExtension.TryParse(arrayColunas[9], "en-us"),
                                //DataAtualizacao = dtAtual,
                                //DataReferencia = DateTimeExtension.TryParse(arrayColunas[15]),
                                //CodigoAgencia = IntExtension.TryParse(arrayColunas[3]),
                                //ValorICMRealizado = DecimalExtension.TryParse(arrayColunas[11], "en-us") / 100,
                                //Grade = ShortExtension.TryParse(arrayColunas[7]),
                                //CodigoItem = IntExtension.TryParse(arrayColunas[8]),
                                Linha = linhas[x]
                            };

                            break;
                        case Enums.Segmentos.Personnalite:

                            planejamentoProducaoRealizada = new PlanejamentoProducaoRealizada()
                            {
                                CodigoItem = IntExtension.TryParse(arrayColunas[8]),
                                DataCriacao = dtAtual,
                                DataAtualizacao = dtAtual,
                                DataReferencia = DateTimeExtension.TryParse(arrayColunas[15]),
                                ValorProducaoRealizada = DecimalExtension.TryParse(arrayColunas[9], "en-us"),
                                ValorICMRealizado = DecimalExtension.TryParse(arrayColunas[11], "en-us") / 100,
                                ValorPontuacaoRealizada = DecimalExtension.TryParse(arrayColunas[13], "en-us"),
                                Carteira = arrayColunas[5],
                                Mes = ShortExtension.TryParse(DateTimeExtension.TryParse(arrayColunas[0]).Month.ToString()),
                                Ano = ShortExtension.TryParse(DateTimeExtension.TryParse(arrayColunas[0]).Year.ToString()),
                                IdSegmento = (int)Enums.Segmentos.Personnalite,

                                //NomeSegmento = "IP",
                                //DataCriacao = dtAtual,
                                //ValorPontuacaoRealizada = DecimalExtension.TryParse(arrayColunas[13].Replace(",", "."), "en-us"),
                                //ValorProducaoRealizada = DecimalExtension.TryParse(arrayColunas[9].Replace(",", "."), "en-us"),
                                //DataAtualizacao = dtAtual,
                                //DataReferencia = DateTimeExtension.TryParse(arrayColunas[15]),
                                //CodigoAgencia = IntExtension.TryParse(arrayColunas[3]),
                                //ValorICMRealizado = DecimalExtension.TryParse(arrayColunas[11].Replace(",", "."), "en-us") / 100,
                                //Grade = ShortExtension.TryParse(arrayColunas[7]),
                                //CodigoItem = IntExtension.TryParse(arrayColunas[8]),
                                Linha = linhas[x]
                            };

                            break;

                        case Enums.Segmentos.Empresas4:


                            //#### IGNORA REGISTROS INVÁLIDOS #####
                            //Se agência (gestora ggc) está em branco
                            //Se agência igual a zero
                            //Se região diferente de 11 e 'platger' é vazio
                            //Se região igual a 11 e grade diferente de 20 e 31
                            if (string.IsNullOrWhiteSpace(arrayColunas[3])
                                || IntExtension.TryParse(arrayColunas[3]) == 0
                                || ((IntExtension.TryParse(arrayColunas[2]) != 11 && string.IsNullOrWhiteSpace(arrayColunas[5]))
                                    || (IntExtension.TryParse(arrayColunas[2]) == 11 &&
                                        (IntExtension.TryParse(arrayColunas[7]) != 20 && IntExtension.TryParse(arrayColunas[7]) != 31))))
                                break;


                            planejamentoProducaoRealizada = new PlanejamentoProducaoRealizada()
                            {
                                CodigoItem = IntExtension.TryParse(arrayColunas[8]),
                                DataCriacao = dtAtual,
                                DataAtualizacao = dtAtual,
                                DataReferencia = DateTimeExtension.TryParse(arrayColunas[15]),
                                ValorProducaoRealizada = DecimalExtension.TryParse(arrayColunas[9], "en-us"),
                                ValorICMRealizado = DecimalExtension.TryParse(arrayColunas[11], "en-us") / 100,
                                ValorPontuacaoRealizada = DecimalExtension.TryParse(arrayColunas[13], "en-us"),
                                Carteira = arrayColunas[2].Equals("11")
                                    ? $"50_{arrayColunas[3]}"
                                    : $"{arrayColunas[5].Substring(arrayColunas[5].Length - 2, 2)}_{arrayColunas[3]}",
                                Mes = ShortExtension.TryParse(DateTimeExtension.TryParse(arrayColunas[0]).Month.ToString()),
                                Ano = ShortExtension.TryParse(DateTimeExtension.TryParse(arrayColunas[0]).Year.ToString()),
                                IdSegmento = (int)Enums.Segmentos.Empresas4,

                                //NomeSegmento = "EMPRESAS",
                                //DataCriacao = dtAtual,
                                //ValorPontuacaoRealizada = DecimalExtension.TryParse(arrayColunas[13], "en-us"),
                                //ValorICMRealizado = DecimalExtension.TryParse(arrayColunas[11], "en-us") / 100,
                                //DataAtualizacao = dtAtual,
                                //DataReferencia = DateTimeExtension.TryParse(arrayColunas[15]),
                                //CodigoAgencia = IntExtension.TryParse(arrayColunas[3]),
                                //ValorProducaoRealizada = DecimalExtension.TryParse(arrayColunas[9], "en-us"),
                                //Grade = ShortExtension.TryParse(arrayColunas[7]),
                                //CodigoItem = IntExtension.TryParse(arrayColunas[8]),
                                Linha = linhas[x]
                            };

                            break;
                    }

                    if (planejamentoProducaoRealizada.CodigoItem > 0)
                        result.Add(planejamentoProducaoRealizada);
                }
                catch
                {
                    //TODO: log
                }
            }

            colunas = null;

            return result;
        }

        public static List<PlanejamentoProducaoRealizada> ConverteColunasDistinct(List<int> linhas, List<string> colunas, Enums.Segmentos segmento)
        {
            var model = ConverteColunas(linhas, colunas, segmento);

            return model
                .Select(a => new
                {
                    a.Mes,
                    a.Ano,
                    a.IdSegmento
                })
                .Distinct()
                .Select(a => new PlanejamentoProducaoRealizada()
                {
                    Mes = a.Mes,
                    Ano = a.Ano,
                    IdSegmento = a.IdSegmento
                })
                .ToList();
        }

        public static List<PlanejamentoProducaoRealizada> ConverteColunasDistinctItemCarteira(List<int> linhas, List<string> colunas, Enums.Segmentos segmento)
        {
            var model = ConverteColunas(linhas, colunas, segmento);

            return model
                .Select(a => new
                {
                    a.Mes,
                    a.Ano,
                    a.Carteira,
                    a.CodigoItem
                })
                .Distinct()
                .Select(a => new PlanejamentoProducaoRealizada()
                {
                    Mes = a.Mes,
                    Ano = a.Ano,
                    Carteira = a.Carteira,
                    CodigoItem = a.CodigoItem
                })
                .ToList();
        }
    }

    public class PlanejamentoProducaoRealizadaColaboradorAgir
    {
        public int IdPlanejamentoItem { get; set; }
        public int IdColaboradorAgir { get; set; }
        public int Grade { get; set; }
    }
}