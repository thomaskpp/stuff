﻿using Itau.SZ7.GPS.Admin.Enums;
using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VendaAtivaResultadoOfertas : ModelBase
    {
        public DateTime DataAtuacao { get; set; }
        public long NumeroCPFCNPJ { get; set; }
        public long? IdOferta { get; set; }
        public string FuncionalResponsavel { get; set; }
        public string AbreviacaoNaturezaPessoa { get; set; }
        public VisaoAcesso CodigoVisaoAcesso { get; set; }
        public RetornoContato CodigoRetornoContato { get; set; }

        public MotivoSubstituicao? CodigoMotivoSubstituicao { get; set; }
        public string ComentarioMotivoSubstituicao { get; set; }
        public string NomeProdutoOferta { get; set; }
        public AvaliacaoReceptividade? CodigoAvaliacaoReceptividade { get; set; }
        public string ComentarioReceptividade { get; set; }
        public string NomeProduto { get; set; }
        public decimal? valorOferta { get; set; }
        public decimal? ValorPonderador { get; set; }
        public DateTime? DataDebito { get; set; }
        public int? CodigoStatusProdutoOferta { get; set; }
        public int? CodigoMotivoRecusaProduto { get; set; }
        public int? CodigoMotivoNaoLocalizado { get; set; }
        public string SegmentoColaborador { get; set; }
        public string OfertaPrincipal { get; set; }
        public string NomeProdutoOfertaAtuado { get; set; }
        public string PessoaContatada { get; set; }
        public DateTime? DataReagendamento { get; set; }
        public string CodcahNew { get; set; }
        public string ComentarioReagendamento { get; set; }
        public string CodigoArgumento { get; set; }
        public int CodigoAgencia { get; set; }
        public string Carteira { get; set; }
        public int NumeroAgenciaCliente { get; set; }
        public int NumeroContaCliente { get; set; }

        public VendaAtivaClientes VendaAtivaClientesNavigation { get; set; }
        public VendaAtivaOfertas VendaAtivaOfertasNavigation { get; set; }
        public Colaborador ColaboradorResponsavelNavigation { get; set; }

    }
}