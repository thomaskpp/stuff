﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Componente
    {
        public int Id { get; set; }
        public int IdFuncionalidade { get; set; }
        public string Nome { get; set; }
    }
}
