﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class AgenciaCoordenadoraRetroativo
    {
        public string CodigoAgenciaCoordenadora { get; set; }
        public string CodigoAgenciaFilha { get; set; }

    }
}
