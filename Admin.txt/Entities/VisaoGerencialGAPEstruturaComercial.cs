﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoGerencialGapEstruturaComercial : ICloneable
    {
        public int Id { get; set; }
        public int IdPoloDicom { get; set; }
        public int IdPoloRegiao { get; set; }
        public int IdPoloRegional { get; set; }
        public DateTime DataReferencia { get; set; }
        public string Nome { get; set; }
        public decimal ValorRealizado { get; set; }
        public decimal ValorRealizadoDiaAnterior { get; set; }
        public string NomeSegmento { get; set; }
        public int Ranking { get; set; }
        public int RankingBanco { get; set; }
        public string AbreviacaoCargo { get; set; }
        public string FuncionalResponsavel { get; set; }

        public object Clone()
        {
            return MemberwiseClone();
        }
    }
}
