﻿using Itau.SZ7.GPS.Admin.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class GerenciadorCarga
    {
        public GerenciadorCarga()
        {
            FileStream = new MemoryStream();
            Passos = new List<GerenciadorCargaPasso>();
            GravaCarga = true;
            Segmento = Segmentos.Desconhecido;
            IdSegmento = (int)Segmentos.Desconhecido;
        }

        public int Id { get; set; }

        public int IdGerenciadorCargaConfiguracao { get; set; }
        public int IdColaborador { get; set; }
        public int IdSegmento { get; set; }
        public string Arquivo { get; set; }
        public DateTime Inicio { get; set; }
        public DateTime? Fim { get; set; }
        public int TotalLinhas { get; set; }
        public bool PopupConclusao { get; set; }


        public Funcionalidade.Enum IdFuncionalidade { get; set; }
        public string NomeFuncionalidade { get; set; }

        public string NomeFuncionalidadeFormatado
        {
            get
            {
                switch (IdFuncionalidade)
                {
                    case Funcionalidade.Enum.CargaVPRealizadoAdmin:
                        return FormatarNomeVpRealizado();
                    case Funcionalidade.Enum.CargaVPAnaliticoAdmin:
                        return FormatarNomeVpAnalitico();
                    case Funcionalidade.Enum.ConfiguracoesConciliacaoAutomaticaVP:
                        return FormatarNomeConciliacaoAutomatica();
                    default:
                        return NomeFuncionalidade;
                }
            }
        }

        private string FormatarNomeConciliacaoAutomatica()
        {
            return $@"{NomeFuncionalidade} - {Arquivo}";
        }

        private string FormatarNomeVpAnalitico()
        {
            if (IdSegmento != 5)
            {
                return $@"{NomeFuncionalidade} - {Arquivo.Replace(".csv", string.Empty)
                                .Replace("-", "/")
                                .Replace("_", "-")}";
            }

            return NomeFuncionalidade;
        }

        private string FormatarNomeVpRealizado()
        {
            if (IdSegmento != 5)
            {
                var nomeArray = Arquivo.Replace(".csv", string.Empty).Split("_");
                var data = nomeArray.LastOrDefault() ?? string.Empty;

                if (data.Length == 6)
                {
                    var ano = data.Substring(0, 4);
                    var mes = data.Substring(4, 2);

                    return $@"{NomeFuncionalidade} - {ObterSegmento()} {mes}/{ano}";
                }

                return $"{NomeFuncionalidade} - {IdSegmento.ToString()}";
            }

            return NomeFuncionalidade;
        }

        private string ObterSegmento()
        {
            switch (IdSegmento)
            {
                case 1: return "IA";
                case 2: return "IU";
                case 3: return "EMP";
                default: return string.Empty;
            }
        }

        public string Funcional { get; set; }
        public string NomeFuncional { get; set; }
        public Enums.Segmentos Segmento { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }


        [NotMapped]
        public List<GerenciadorCargaPasso> Passos { get; set; }

        [NotMapped]
        [JsonIgnore]
        public MemoryStream FileStream { get; set; }

        [NotMapped]
        public string InicioFormatado
        {
            get
            {
                return Inicio.ToString("dd/MM/yy HH:mm:ss");
            }
        }

        [NotMapped]
        public string FimFormatado
        {
            get
            {
                return Fim.HasValue ? Fim.Value.ToString("dd/MM/yy HH:mm:ss") : string.Empty;
            }
        }

        [NotMapped]
        public string FimDataFormatado
        {
            get
            {
                return Fim.HasValue ? Fim.Value.ToString("dd/MM/yy") : string.Empty;
            }
        }

        [NotMapped]
        public string FimHoraFormatado
        {
            get
            {
                return Fim.HasValue ? Fim.Value.ToString("HH:mm:ss") : string.Empty;
            }
        }

        [NotMapped]
        public string TempoTermino
        {
            get
            {
                var tempo = Fim.HasValue ? Fim.Value.Subtract(Inicio) : DateTime.Now.TimeOfDay;
                return tempo.ToString();
            }
        }

        [NotMapped]
        public decimal ProgressoAtual
        {
            get
            {
                if (!Fim.HasValue && TotalLinhas > 0 && Passos.Count > 0)
                {
                    var valor1 = (Convert.ToDecimal(Passos.Sum(x => x.LinhasProcessadas)))
                        / Convert.ToDecimal(TotalLinhas * Passos.Count);

                    if (valor1 > 1)
                        valor1 = 1;

                    var valor2 = (100 / Convert.ToDecimal(Passos.Count));

                    var valor3 = (Passos.Count(x => x.Fim.HasValue) * valor2) + (valor2 * valor1);

                    if (valor3 > 100)
                        valor3 = 100;

                    if (valor3 < 1)
                        valor3 = 1;

                    return Math.Ceiling(valor3);
                }
                else
                    return 0;
            }
        }

        [NotMapped]
        public string PassoAtual
        {
            get
            {
                return Passos.Count > 0 ? PassoAtualModel.Nome : "Iniciando";
            }
        }

        public GerenciadorCargaPasso PassoAtualModel
        {
            get
            {
                if (Passos.Any(x => x.Fim == null))
                    return Passos.First(x => x.Fim == null);
                else
                    return Passos.Last();
            }
        }

        [NotMapped]
        public decimal PassoAtualProgresso
        {
            get
            {
                if (!Fim.HasValue && TotalLinhas > 0 && Passos.Count > 0)
                {
                    return Math.Ceiling((Convert.ToDecimal(PassoAtualModel.LinhasProcessadas) * 100)
                        / Convert.ToDecimal(TotalLinhas));
                }
                else
                    return 0;
            }
        }

        [NotMapped]
        public int PassoAtualLinhasProcessadas
        {
            get
            {
                return Passos.Count > 0 ? PassoAtualModel.LinhasProcessadas : 0;
            }
        }

        [NotMapped]
        public string PassoAtualAtualizadoEmFormatado
        {
            get
            {
                var data = Passos.Count > 0 && PassoAtualModel.Atualizado.HasValue
                    ? PassoAtualModel.Atualizado.Value
                    : DateTime.Now;

                return data.ToString("dd/MM/yy HH:mm:ss");

            }
        }

        [NotMapped]
        public string PassoAtualTempoDecorrido
        {
            get
            {
                var data = Passos.Count > 0 && PassoAtualModel.Atualizado.HasValue
                    ? PassoAtualModel.Atualizado.Value
                    : DateTime.Now;

                return DateTime.Now.Subtract(data).ToString("hh\\:mm\\:ss");

            }
        }

        [NotMapped]
        public bool Finalizado
        {
            get
            {
                return Fim.HasValue;
            }
        }

        [NotMapped]
        public bool ContemErro
        {
            get
            {
                return Passos.Any(x => x.Erro);
            }
        }

        [NotMapped]
        public string ArquivoApelido { get; set; }

        [NotMapped]
        public bool GravaCarga { get; set; }

        [NotMapped]
        public string TempoDecorrido
        {
            get
            {
                return DateTime.Now.Subtract(Inicio).ToString("hh\\:mm\\:ss");
            }
        }

        [NotMapped]
        public int TotalLinhasInseridas
        {
            get
            {
                var passoInsercao = Passos.FirstOrDefault(x => x.Passo == CargasPassos.Insercao);

                if (passoInsercao != null)
                    return passoInsercao.LinhasProcessadas;
                else
                    return 0;
            }
        }

        public string TotalLinhasInseridasPercentual
        {
            get
            {
                if (TotalLinhasInseridas > 0)
                {
                    var perc = (Convert.ToDouble(TotalLinhasInseridas) / Convert.ToDouble(TotalLinhas)) * 100;

                    return $"{(perc > 99.5 ? 100 : Math.Round(perc, 2))}%";
                }
                else
                {
                    return "0%";
                }

            }
        }

        [NotMapped]
        public GerenciadorCargaConfiguracao Configuracao { get; set; }

        [NotMapped]
        public string IdControleCarga { get; set; }
    }
}
