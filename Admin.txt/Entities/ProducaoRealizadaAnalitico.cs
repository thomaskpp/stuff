﻿
using Itau.SZ7.GPS.Admin.Extensions;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ProducaoRealizadaAnalitico : ModelBase
    {
        public int Id { get; set; }
        public int IdAgencia { get; set; }
        public string Carteira { get; set; }
        public int CodigoItem { get; set; }
        public int IdSegmento { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public DateTime DataReferencia { get; set; }
        public DateTime Data { get; set; }
        public DateTime DataDebito { get; set; }
        public string DescricaoProduto { get; set; }
        public string ClienteAgencia { get; set; }
        public string ClienteConta { get; set; }
        public string DescricaoCanal { get; set; }
        public string NomeColaborador { get; set; }
        public decimal ValorProducao { get; set; }
        public decimal ValorPonderado { get; set; }
        public decimal ValorProducaoPonderada { get; set; }
        public string DescricaoStatus { get; set; }

        [NotMapped]
        public int Linha { get; set; }

        [NotMapped]
        public string Segmento { get; set; }

        [NotMapped]
        public string CodAgencia { get; set; }

        public static ProducaoRealizadaAnalitico ConverteColunas(int linha, string colunas)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                return new ProducaoRealizadaAnalitico()
                {
                    DataReferencia = DateTimeExtension.TryParse(arrayColunas[0]),
                    CodAgencia = arrayColunas[1],
                    Carteira = arrayColunas[2],
                    Segmento = arrayColunas[5],
                    CodigoItem = IntExtension.TryParse(arrayColunas[6]),
                    ClienteAgencia = arrayColunas[9],
                    ClienteConta = arrayColunas[10],
                    ValorProducao = string.IsNullOrWhiteSpace(arrayColunas[11]) ? -1 : DecimalExtension.TryParse(arrayColunas[11].Replace(',', '.')),
                    ValorPonderado = DecimalExtension.TryParse(arrayColunas[12].Replace(',', '.')),
                    DescricaoProduto = arrayColunas[13],
                    ValorProducaoPonderada = string.IsNullOrWhiteSpace(arrayColunas[14]) ? -1 : DecimalExtension.TryParse(arrayColunas[14].Replace(',', '.')),
                    DataDebito = DateTimeExtension.TryParse(arrayColunas[15]),
                    DescricaoStatus = arrayColunas[16],
                    DescricaoCanal = arrayColunas[17],

                    DataAtualizacao = DateTime.Now,
                    DataCriacao = DateTime.Now,

                    Linha = linha
                };
            }
            catch
            {
                return null;
            }
        }

        public static List<ProducaoRealizadaAnalitico> ConverteColunas(List<int> linhas, List<string> colunas)
        {
            var result = new List<ProducaoRealizadaAnalitico>();

            for (var x = 0; x < colunas.Count; x++)
            {
                var model = ConverteColunas(linhas[x], colunas[x]);

                if (model != null)
                    result.Add(model);
            }

            return result;
        }

        #region [Métodos Auxiliares]

        public const string CODIGO_UNICLASS = "IU";
        public const string CODIGO_EMPRESAS = "EMP4";
        public const string CODIGO_AGENCIAS = "IA";

        #endregion
    }

    public class PlanejamentoProducaoRealizadaAnaliticoSimples
    {
        public int IdAgencia { get; set; }
        public string CodigoAgencia { get; set; }
        public int CodigoItem { get; set; }
        public int Ano { get; set; }
        public int Mes { get; set; }
        public string Carteira { get; set; }

        public static List<PlanejamentoProducaoRealizadaAnaliticoSimples> ConverteColunas(List<string> colunas)
        {
            var result = new List<PlanejamentoProducaoRealizadaAnaliticoSimples>();

            foreach (var coluna in colunas)
            {
                try
                {
                    var arrayColunas = coluna.Split(';');
                    var dataref = DateTimeExtension.TryParse(arrayColunas[0]);

                    var item = new PlanejamentoProducaoRealizadaAnaliticoSimples()
                    {
                        Ano = dataref.Year,
                        Mes = dataref.Month,
                        CodigoAgencia = arrayColunas[1],
                        //Segmento = arrayColunas[5],
                        CodigoItem = IntExtension.TryParse(arrayColunas[6]),
                        Carteira = arrayColunas[2]
                    };

                    result.Add(item);
                }
                catch
                {
                    //TODO: LOG ERRO
                }
            }

            return result
                .Select(a => new
                {
                    a.Ano,
                    a.Mes,
                    a.CodigoAgencia,
                    //a.Segmento,
                    a.CodigoItem,
                    a.Carteira
                })
                .Distinct()
                .Select(a => new PlanejamentoProducaoRealizadaAnaliticoSimples()
                {
                    Ano = a.Ano,
                    Mes = a.Mes,
                    CodigoAgencia = a.CodigoAgencia,
                    //Segmento = a.Segmento,
                    CodigoItem = a.CodigoItem,
                    Carteira = a.Carteira
                })
                .ToList();

        }

    }
}
