﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class CompromissoParticipante
    {
        public int IdCompromissoColaborador { get; set; }
        public string FuncionalParticipante { get; set; }

        public Colaborador ColaboradorParticipanteNavigation { get; set; }
        public CompromissoColaborador CompromissoColaboradorNavigation { get; set; }
    }
}