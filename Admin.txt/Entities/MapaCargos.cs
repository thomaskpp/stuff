﻿using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class MapaCargos : ModelBase
    {
        [Key]
        public Cargos CodigoCargo { get; set; }
        public string Cargo { get; set; }        

    }
}
