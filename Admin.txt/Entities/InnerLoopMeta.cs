﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopMeta : ModelBase
    {
        public int Id { get; set; }
        public int IdSegmento { get; set; }
        public string Cargo { get; set; }
        public int Programacao { get; set; }
        public int Periodo { get; set; }
        public int Janela { get; set; }
    }
}
