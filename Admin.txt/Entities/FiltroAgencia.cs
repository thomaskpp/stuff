﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class FiltroAgencia
    {
        public FiltroAgencia()
        {
        }

        public FiltroAgencia(int idPoloRegional, int idPoloRegiao, int idPoloDICOM, int codigoAgencia)
        {
            IdPoloRegional = idPoloRegional;
            IdPoloRegiao = idPoloRegiao;
            IdPoloDICOM = idPoloDICOM;
            CodigoAgencia = codigoAgencia;
        }

        public int IdPoloRegional { get; set; }
        public int IdPoloRegiao { get; set; }
        public int IdPoloDICOM { get; set; }
        public int CodigoAgencia { get; set; }
    }
}
