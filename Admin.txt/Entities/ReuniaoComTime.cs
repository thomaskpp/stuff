﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ReuniaoComTime
    {
        public int IdReuniaoComTime { get; set; }
        [JsonIgnore]
        public string Funcional { get; set; }
        public IList<ReuniaoComTimeComentario> Comentarios { get; set; }
        public DateTime DataCriacao { get; set; }
        public int CodigoAgencia { get; set; }
        public int IdSegmento { get; set; }

        public const int QTDEDIASREGISTROS = 90;
    }
}