﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopLigacaoListagem
    {
        public int Id { get; set; }
        public string Produto { get; set; }
        public int Nota { get; set; }
        public int Expirar { get; set; }
        public int IdStatus { get; set; }
        public string NomeStatus { get; set; }
        public string MotivoNaoAtendida { get; set; }
        public DateTime? DataAgendamento { get; set; }
        public string SegmentoCliente { get; set; }
    }
}
