﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoGerencialItensGapPorSegmentoCargo
    {
        public int CodItem { get; set; }
        public string NomeSegmento { get; set; }
        public string AbreviacaoCargo { get; set; }
    }
}
