﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ComentarioPlanejamentoCarteira
    {
        public ComentarioPlanejamentoCarteira()
        {

        }

        public int CodigoAgencia { get; set; }
        public string Carteira { get; set; }
        public short Grade { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
        public DateTime DataComentario { get; set; }
        public string DescricaoComentario { get; set; }
        public string Funcional { get; set; }
        public bool IndicadorLeitura { get; set; }

        public Colaborador ColaboradorNavigation { get; set; }
        public PlanejamentoGradeCarteira PlanejamentoGradeCarteira { get; set; }
    }
}