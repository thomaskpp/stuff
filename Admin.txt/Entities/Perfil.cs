﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Perfil : ModelBase
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public IEnumerable<PerfilPermissao> PerfilPermissoes { get; set; }
    }
}
