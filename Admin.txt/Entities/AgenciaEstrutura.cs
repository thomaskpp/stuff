﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class AgenciaEstrutura
    {
        public int Id { get; set; }
        public bool Ativo { get; set; }
        public int IdAgencia { get; set; }
        public short? IdPoloDicom { get; set; }
        public short? IdPoloRegiao { get; set; }
        public short? IdPoloRegional { get; set; }
        public int IdSegmento { get; set; }
        public int IdHierarquiaNivel { get; set; }
    }
}
