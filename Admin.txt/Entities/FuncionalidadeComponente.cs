﻿using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class FuncionalidadeComponente : FuncionalidadeHome
    {
        public FuncionalidadeComponente()
        {
            Componentes = Enumerable.Empty<Componente>();
        }

        public IEnumerable<Componente> Componentes { get; set; }
    }
}
