﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ProdutoGradeItem : ModelBase
    {
        public ProdutoGradeItem()
        {

        }

        public ProdutoGradeItem(string codigoProduto, short grade, short ano, short mes, int codigoItem, string nomeSegmento, string nomeProduto,
            bool indicadorAtivo, bool indicadorExibirValor, int idSegmento)
        {
            CodigoProduto = codigoProduto;
            Grade = grade;
            Ano = ano;
            Mes = mes;
            CodigoItem = codigoItem;
            NomeSegmento = nomeSegmento;
            NomeProduto = nomeProduto;
            IndicadorAtivo = indicadorAtivo;
            IndicadorExibirValor = indicadorExibirValor;
            IdSegmento = idSegmento;
        }

        public string CodigoProduto { get; set; }
        public short Grade { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
        public int CodigoItem { get; set; }
        public int IdSegmento { get; set; }
        public string NomeSegmento { get; set; }
        public string NomeProduto { get; set; }
        public bool IndicadorAtivo { get; set; }
        public bool IndicadorExibirValor { get; set; }
        public decimal? ICM_PARAM { get; set; }
        public decimal? PONDERADOR { get; set; }
        public decimal? PONDERADOR_MAX { get; set; }


        public ICollection<PlanejamentoCheckout> PlanejamentoCheckout { get; set; }

        public static string CODIGO_PRODUTO_CHECKOUTSEMVENDA => "CHECKOUTSEMVENDA";
        public static string DESCRICAO_PRODUTO_CHECKOUTSEMVENDA => "Sem negócios nesta data";

        public static ProdutoGradeItem ProdutoGradeItemCheckoutSemVenda(short grade, short ano, short mes, string nomeSegmento, int idSegmento)
        {
            ProdutoGradeItem produtoGradeItem = new ProdutoGradeItem(CODIGO_PRODUTO_CHECKOUTSEMVENDA, grade, ano, mes, 0, nomeSegmento, DESCRICAO_PRODUTO_CHECKOUTSEMVENDA, true, true, idSegmento);

            return produtoGradeItem;
        }
    }
}