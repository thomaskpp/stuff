﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopStatus : ModelBase
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        //Propriedades de Navegação
        public ICollection<InnerLoopHistorico> InnerLoopHistoricoNavigation { get; set; }
    }
}