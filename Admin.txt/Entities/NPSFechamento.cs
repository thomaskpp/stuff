﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class NPSFechamento : ModelBase
    {      
        public int Id { get; set; }
        public int Ano { get; set; }
        public int Mes { get; set; }
        public DateTime DataFechamento { get; set; }

        public const int QNTDE_MESES_ANTERIORES = -12;
    }
}
