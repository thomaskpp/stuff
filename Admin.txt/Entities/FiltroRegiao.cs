﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class FiltroRegiao
    {
        public FiltroRegiao()
        {
        }

        public FiltroRegiao(int idPoloRegiao, int idPoloDICOM, int codigoPolo, string funcional, string nome)
        {
            IdPoloRegiao = idPoloRegiao;
            IdPoloDICOM = idPoloDICOM;
            CodigoPolo = codigoPolo;
            Funcional = funcional;
            Nome = nome;
        }

        public int IdPoloRegiao { get; set; }
        public int IdPoloDICOM { get; set; }
        public int CodigoPolo { get; set; }
        public string Funcional { get; set; }
        public string Nome { get; set; }
    }
}
