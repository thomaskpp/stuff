﻿using System;


namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ModelBase
    {
        public DateTime DataCriacao { get; set; }

        public DateTime DataAtualizacao { get; set; }
    }
}
