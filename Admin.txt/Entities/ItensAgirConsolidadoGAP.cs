﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ItensAgirConsolidadoGap
    {
        public string FuncionalResponsavel { get; set; }
        public decimal ValorPontuacaoRealizado { get; set; }
    }
}
