﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopAgenciaNucleo
    {
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public int IdAgencia { get; set; }
        public bool AtendidaPeloNucleo { get; set; }
    }
}