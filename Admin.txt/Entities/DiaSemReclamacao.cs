﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class DiaSemReclamacao
    {
        public int IdAgenciaCoordenadora { get; set; }

        public DateTime DataUltimaReclamacao { get; set; }

        public int IdEstrutura { get; set; }

        [NotMapped]
        public string CodigoAgenciaCoordenadora { get; set; }

        [NotMapped]
        public int Linha { get; set; }
    }
}
