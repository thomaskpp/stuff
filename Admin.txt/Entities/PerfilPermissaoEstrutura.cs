﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilPermissaoEstrutura : ModelBase
    {
        public int Id { get; set; }
        public int IdPermissao { get; set; }
        public bool FgPermissao { get; set; }
        public int IdEstrutura { get; set; }
    }
}
