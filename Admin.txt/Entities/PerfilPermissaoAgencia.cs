﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilPermissaoAgencia
    {
        public int Id { get; set; }
        public int IdPerfilPermissao { get; set; }
        public bool Permissao { get; set; }
        public int IdAgencia { get; set; }
        public string Codigo { get; set; }
    }
}
