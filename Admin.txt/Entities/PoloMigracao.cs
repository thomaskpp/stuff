﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PoloMigracao
    {
        public short Id { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public int Codigo { get; set; }
        public int IdColaboradorResponsavel { get; set; }
        public int IdEstrutura { get; set; }
        public IEnumerable<AgenciaEstrutura> AgenciaEstruturas { get; set; }

        public Estrutura Estrutura { get; set; }

    }
}
