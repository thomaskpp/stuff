﻿using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Reclamacao
    {
        public int Id { get; set; }
        public DateTime DataCriacao { get; set; }

        public int IdEstrutura { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public int IdAgencia { get; set; }
        public int IdSegmento { get; set; }
        public string IdentificadorOcorrencia { get; set; }
        public DateTime DataOcorrencia { get; set; }
        public DateTime DataSolucaoOcorrencia { get; set; }
        public int CodigoAgenciaCliente { get; set; }
        public int NumeroContaCliente { get; set; }
        public string NomeReclamante { get; set; }
        public string AgrupadorCanal { get; set; }
        public string AnoMes { get; set; }
        public string TipoCanal { get; set; }
        public string TipoAssunto { get; set; }
        public string Assunto { get; set; }
        public string AssuntoCompleto { get; set; }
        public string MeioComunicacao { get; set; }
        public string Telefone { get; set; }
        public bool? AtuacaoGGC { get; set; }
        public bool? AtuacaoGRA { get; set; }
        public bool VisaoMetasDicom { get; set; }
        public bool VisaoMetasDiop { get; set; }
        public bool Ativo { get; set; }
        public bool Ciente { get; set; }
        public int StatusOcorrencia { get; set; }
        public int IdAgenciaCoordenadora { get; set; }
        public int IdAgenciaOcorrencia { get; set; }
        public DateTime DataVisualizacaoOcorrencia { get; set; }
        public string CpfCnpj { get; set; }
        public string RelatoCliente { get; set; }

        [NotMapped]
        public int Linha { get; set; }
    }

}
