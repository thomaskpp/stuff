﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Funcionalidade
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int IdPlataforma { get; set; }
        public string DsUrl { get; set; }
        public string Descricao { get; set; }
        public string Icone { get; set; }
        public int Ordem { get; set; }
        public int LinkTipo { get; set; }
        public bool FgMenu { get; set; }
        public int IdFuncionalidadePai { get; set; }
        public string GrupoNome { get; set; }
        public int GrupoOrdem { get; set; }

        public enum Enum
        {
            Desconhecido = 0,
            Login = 1,
            HomeProducao = 2,
            HomeSatisfacao = 3,
            PlanejamentoDesafio = 4,
            PlanejamentoDistribuicao = 5,
            PlanejamentoResumoGGC = 6,
            PlanejamentoAprovacao = 7,
            Checkin = 8,
            Checkout = 9,
            VerificadorDeProducaoA = 10,
            Notificacoes = 11,
            FaleConosco = 12,
            DetalheNPS = 13,
            Reclamacoes = 14,
            VendaAtiva = 15,
            DelegacaoAgencia = 16,
            DelegacaoColaborador = 17,
            HomeSatisfacaoOutrosSegmentos = 18,
            InnerLoopResumo = 19,
            InnerLoopAtendimento = 20,
            InnerLoopRelatorio = 21,
            Administrador = 22,
            VisaoGerencial = 23,
            Engajamento = 24,
            Home = 25,
            CoachClick = 26,
            VerificadorDeProducao = 27,
            Acompanhamento = 28,
            VisaoGerencialAderencia = 29,
            VisaoGerencialProducao = 30,
            ReuniaoComTime = 31,
            PapoDeCliente = 32,
            PlanejamentoResumo = 33,
            PlanejamentoVisao = 34,
            PlanejamentoEdicao = 35,
            VAIReagendamentos = 36,
            HomeSegmentos = 37,
            Digitaumetro = 38,

            //Admin
            HomeTemplateAdmin = 39,
            CargasAdmin = 40,
            CargaAgenciaAdmin = 41,
            CargaAlavancaAdmin = 42,
            CargaBaixaAderenciaAdmin = 43,
            CargaColaboradorAdmin = 44,
            CargaFeriadoAdmin = 45,
            CargaGradeAdmin = 46,
            CargaGradeCarteiraFakeAdmin = 47,
            CargaICMHistoricoAdmin = 48,
            CargaInnerLoopArvoreDecisoesAdmin = 49,
            CargaLiberacaoFuncionalidadeAdmin = 50,
            CargaInnerLoopLigacoesAdmin = 51,
            CargaMetaAdmin = 52,
            CargaNotificacaoAdmin = 53,
            CargaNPSAdmin = 54,
            CargaReclamacoesAdmin = 55,
            CargaVendaAtivaAdmin = 56,
            CargaVPAnaliticoAdmin = 57,
            CargaVPRealizadoAdmin = 58,
            CargaVisualizarArquivoAdmin = 59,
            TemplateNotificaçãoAdmin = 60,
            HomeAdmin = 61,
            Portal = 62,
            MetasPersonnaliteAdmin = 63,
            GradePersonnaliteAdmin = 64,
            CargaVendaAtivaSaibaMaisAdmin = 65,
            Acompanhamentov2 = 66,
            VAIAcompanhamento = 67,
            GestaoAcessoAdmin = 68,
            CargaDiasSemReclamacoes = 69,
            Hub = 71,
            ConfiguracoesConciliacaoAutomaticaVP = 85,
            CargaNPSComentarioPersonnaliteAdmin = 79,
            CargaNPSAgendaPersonnaliteAdmin = 80,
            CargaNPSGlobalPersonnaliteAdmin = 81,
            CargaNPSPersonnaliteAdmin = 82,
            CargaVPAnaliticoPersonnaliteAdmin = 101,
            ConciliacaoPersonnalite = 102,
            PerformancePersonnaliteV2 = 103,
            CargaPipelineCliente = 104,
            CargaPipeline = 105,
            CheckoutsPendentes = 126,

            CargaNPSCliente = 115,
            Chatbot = 116,
            HubManager = 117,
            CargaGMF = 118,
            CargaContratoMetasPersonnaliteAdmin = 120,
            CargaReclamacao = 121,
            CargaConfiguracaoVPAnaliticoPersonnalite = 122,
            TemplateSecao = 132
        }

        public IEnumerable<PerfilPermissaoAgencia> PerfilPermissaoAgencias { get; set; }
        public IEnumerable<PerfilPermissaoCarteira> PerfilPermissaoCarteiras { get; set; }
        public IEnumerable<PerfilPermissaoCargo> PerfilPermissaoCargos { get; set; }
        public IEnumerable<PerfilPermissaoColaborador> PerfilPermissaocolaborador { get; set; }
        public IEnumerable<PerfilPermissaoSegmento> PerfilPermissaoSegmentos { get; set; }
    }
}
