﻿using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Polo : ModelBase, IEquatable<Polo>
    {
        public int Id { get; set; }
        public int CodigoPolo { get; set; }
        public string AbreviacaoCargoResponsavel { get; set; }
        public string FuncionalResponsavel { get; set; }
        public decimal? ValorPesoSegmentoIA { get; set; }
        public decimal? ValorPesoSegmentoIU { get; set; }
        public decimal? ValorPesoSegmentoEmp4 { get; set; }
        public List<PoloPeso> Pesos { get; set; }

        public Colaborador ColaboradorResponsavelNavigation { get; set; }
        public ICollection<Agencia> AgenciaRegional { get; set; }
        public ICollection<Agencia> AgenciaRegiao { get; set; }
        public ICollection<Agencia> AgenciaDICOM { get; set; }
        public ICollection<ColaboradorEngajamento> ColaboradorEngajamentoRegional { get; set; }
        public ICollection<ColaboradorEngajamento> ColaboradorEngajamentoRegiao { get; set; }

        public override bool Equals(object obj)
        {
            return Equals(obj as Polo);
        }

        public bool Equals(Polo other)
        {
            return other != null &&
                   CodigoPolo == other.CodigoPolo;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(CodigoPolo);
        }
        public ICollection<ColaboradorEngajamento> ColaboradorEngajamentoDICOM { get; set; }
    }

    public class PoloSimplificado
    {
        public short Id { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public int Codigo { get; set; }
        public int IdColaboradorResponsavel { get; set; }
        public short IdEstrutura { get; set; }
        public string FuncionalResponsavel { get; set; }
    }
}
