﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Colaborador : ColaboradorAgir
    {
        public new int Id { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public string Funcional { get; set; }
        public string RACF { get; set; }
        public string Nome { get; set; }
        public string NomeCompleto { get; set; }
        public string AbreviacaoCargo { get; set; }
        public string NomeSegmento { get; set; }
        public bool IndicadorAtivo { get; set; }
        public int? CodigoAgencia { get; set; }
        public bool IndicadorAcessouFerramenta { get; set; }
        public string FuncionalGGC { get; set; }
        public byte CodigoElegivelEngajamento { get; set; }
        public int DiasIndisponiveis { get; set; }
        public string FuncionalGestorDireto { get; set; }
        public int IdCargo { get; set; }
        public Enums.Cargos Cargo
        {
            get
            {
                return (Enums.Cargos)IdCargo;
            }
         }
        public Enums.Segmentos Segmento
        {
            get
            {
                return (Enums.Segmentos)IdSegmento;
            }
        }
        public ICollection<ColaboradorFerias> ColaboradorFerias { get; set; }


        public const string CODIGO_DICOM = "DICOM";
        public const string CODIGO_SUPT = "SUPT";
        public const string CODIGO_GRA = "GRA";
        public const string CODIGO_GGC = "GGC";
        public const string CODIGO_GMF = "GMF";
        public const string CODIGO_GGN = "GGN";
        public const string CODIGO_GGD = "GGD";
        public const string CODIGO_LIBERO = "LIBERO";
        public const string CODIGO_GRE = "GRE";
        public const string CODIGO_GRUE = "GRUE";
        public const string CODIGO_GRU = "GRU";
        public const string CODIGO_GRUD = "GRUD";
        public const string CODIGO_GRN = "GRN";
        public const string CODIGO_ASSISTENTE = "A";
        public const string CODIGO_GRP = "GRP";
        public const string CODIGO_GA = "GA";
        public const string CODIGO_GP = "GP";
        public const string CODIGO_GRAP = "GRAP";
        public const string CODIGO_GGE_EMP2 = "GGE";
        public const string CODIGO_GRE3 = "GRE3";
        public const string CODIGO_GGE_EMP3 = "GGE";
        public const string CODIGO_GO_OP = "GO";
        public const string CODIGO_GSO_OP_IP = "GSO";
        public const string CODIGO_GO_OP_IP = "GO";
        public const string CODIGO_GSO_OP_DIG_IP = "GO";
        public const string CODIGO_CQP = "CQP";
        public const string CODIGO_CQU = "CQU";
        public const string CODIGO_CQE = "CQE";
        public const string CODIGO_GRED = "GRED";

        public static bool IsGerenteGeral(string cargo)
        {
            if (cargo == null)
                return false;

            return
                cargo.ToUpper().Equals(CODIGO_GGC) ||
                cargo.ToUpper().Equals(CODIGO_GGN) ||
                cargo.ToUpper().Equals(CODIGO_GGD) ||
                cargo.ToUpper().Equals(CODIGO_LIBERO) ||
                cargo.ToUpper().Equals(CODIGO_GA);
        }

        public bool IsGerenteGeral()
        {
            return IsGerenteGeral(AbreviacaoCargo);
        }

    }

    public class ColaboradorSimplificado
    {
        public int Id { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public string Funcional { get; set; }
        public string Racf { get; set; }
        public string Nome { get; set; }
        public string NomeCompleto { get; set; }
        public int? IdCargo { get; set; }
        public int? IdCargoAntigo { get; set; }
        public bool Ativo { get; set; }
        public int IdColaboradorGestorDireto { get; set; }
        public int DiasIndisponiveis { get; set; }
        public bool ElegivelEngajamento { get; set; }

        public IEnumerable<ColaboradorFerias> ColaboradorFerias { get; set; }

        public ColaboradorAgir ColaboradorAgir { get; set; }

        public static implicit operator Task<object>(ColaboradorSimplificado v)
        {
            throw new NotImplementedException();
        }
    }

    public class ColaboradorAgir
    {
        public int Id { get; set; }
        public int IdColaboradorAgir { get; set; }
        public int IdSegmento { get; set; }
        public int IdAgencia { get; set; }
        public string Carteira { get; set; }
        public short? Grade { get; set; }
        public int IdColaborador { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }

        public int? IdPlanejamento { get; set; }
        public int IdColaboradorAgirPlanejamento { get; set; }
        public int? IdCarteiraVazia { get; set; }
    }
}
