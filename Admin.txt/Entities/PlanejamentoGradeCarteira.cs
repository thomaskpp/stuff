﻿using Itau.SZ7.GPS.Admin.Entities.DTO;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PlanejamentoGradeCarteira : ModelBase
    {
        public int IdAgencia { get; set; }
        public string Carteira { get; set; }
        public short Grade { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
        public decimal ValorPontuacaoInicial { get; set; }
        public decimal ValorPontuacaoMinima { get; set; }
        public decimal ValorPontuacaoMaxima { get; set; }
        public decimal ValorPontuacaoDesafio { get; set; }
        public decimal ValorPontuacaoPlanejada { get; set; }
        public string FuncionalResponsavel { get; set; }
        public int IdAgenciaEstrutura { get; set; }
        public int IdColaboradorAgir { get; set; }
        public int IdSegmento { get; set; }
        public string NomeSegmento { get; set; }

        public int IdPlanejamento { get; set; }
        public bool AtualizarPlanejamento { get; set; }
        public int IdColaboradorResponsavel { get; set; }


        public StatusPlanejamentoGradeCarteira IndicadorStatus { get; set; }
        public DateTime? DataAprovacao { get; set; }
        public PassoPlanejamentoGradeCarteira CodigoPassoAtual { get; set; }

        public Agencia AgenciaNavigation { get; set; }
        public Colaborador ColaboradorResponsavelNavigation { get; set; }
        public ICollection<ComentarioPlanejamentoCarteira> ComentarioPlanejamentoCarteira { get; set; }
        public ICollection<PlanejamentoItemGradeCarteira> PlanejamentoItemGradeCarteira { get; set; }
        public ICollection<RegraFaixaParametrizacao> FaixaParametrizacaoAgir { get; set; }

        #region [ Métodos Auxiliares ]

        public static string CARTEIRA_SEM_RESPONSAVEL => "CARTEIRA VAZIA {0} AG {1}";
        public static string CARTEIRA_VAZIA => "CARTEIRA VAZIA";
        public static string NOME_SEGMENTO_AGENCIAS => "AGENCIAS";

        public DateTime? GetDataUltimaAtualizacaoVP()
        {
            var ultimosCheckouts = PlanejamentoItemGradeCarteira?.Select(p => p.GetDataUltimaAtualizacaoVP());

            return !(ultimosCheckouts is null) && ultimosCheckouts.Any() ?
                    ultimosCheckouts.Max() : null;
        }

        public string NomeCarteiraVazia => string.Format(CARTEIRA_SEM_RESPONSAVEL, Carteira, IdAgencia);

        #endregion

        public override bool Equals(object obj)
        {
            var carteira = obj as PlanejamentoGradeCarteira;
            return carteira != null &&
                   IdAgencia == carteira.IdAgencia &&
                   Carteira == carteira.Carteira &&
                   Grade == carteira.Grade &&
                   Ano == carteira.Ano &&
                   Mes == carteira.Mes;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(IdAgencia, Carteira, Grade, Ano, Mes);
        }

    }

    public class PlanejamentoGradeCarteiraCarga : PlanejamentoGradeCarteira
    {
        public PlanejamentoGradeCarteira PlanejamentoAnterior { get; set; }
        public int Linha { get; set; }
        public int? IdPoloRegiao { get; set; }
        public int? IdPoloRegional { get; set; }
        public int? IdPoloDICOM { get; set; }
      
        public static PlanejamentoGradeCarteiraCarga ConverteColunas(string colunas, short ano, short mes)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                return new PlanejamentoGradeCarteiraCarga()
                 {
                     IdAgencia = IntExtension.TryParse(arrayColunas[4]),
                     Carteira = arrayColunas[0],
                     Grade = ShortExtension.TryParse(arrayColunas[1]),
                     Ano = ano,
                     Mes = mes,
                     NomeSegmento = arrayColunas[5],
                     DataAtualizacao = DateTime.Now,
                     DataCriacao = DateTime.Now
                 };
            }
            catch
            {
                return null;
            }
        }

        public static List<PlanejamentoGradeCarteiraCarga> ConverteColunas(List<string> colunas, short ano, short mes)
        {
            var result = new List<PlanejamentoGradeCarteiraCarga>();

            for (var x = 0; x < colunas.Count; x++)
            {
                var model = ConverteColunas(colunas[x], ano, mes);

                if (model != null)
                    result.Add(model);
            }

            return result;
        }
    }

    public class PlanejamentoGradeCarteiraSimples
    {
        public string Carteira { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }

        public static List<PlanejamentoGradeCarteiraSimples> ConverteColunas(List<string> colunas, short ano, short mes)
        {
            var resultado = new List<PlanejamentoGradeCarteiraSimples>();

            foreach (var coluna in colunas)
            {
                try
                {
                    var arrayColunas = coluna.Split(';');

                    resultado.Add(new PlanejamentoGradeCarteiraSimples()
                    {
                        Ano = ano,
                        Mes = mes,
                        Carteira = arrayColunas[0]
                    });
                }
                catch { }

            }

            return resultado.Distinct().ToList();
        }
    }

    public class PlanejamentoGradeCarteiraCalculado : PlanejamentoGradeCarteira
    {
        public decimal ValorPontuacaoInformada { get; set; }
        public decimal ValorPontuacaoRealizada { get; set; }

        public List<PlanejamentoItemGradeCarteiraCalculado> PlanejamentoItemGradeCarteiraCalculado { get; set; }
        public PlanejamentoGradeCarteira PlanejamentoPrincipal { get; set; }
    }
}
