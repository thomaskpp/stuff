﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilPermissaoEntrada
    {
        public int? IdEstrutura { get; set; }
        public int? IdSegmento { get; set; }
        public int? IdAgencia { get; set; }
        public string Carteira { get; set; }
        public int? IdCargo { get; set; }
        public int IdColaborador { get; set; }
        public int IdPlataforma { get; set; }

    }
}
