﻿using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopLiberacaoFuncionalidade
    {
        public int Id { get; set; }
        public int IdSegmentoColaborador { get; set; }
        public int AgenciaResponsavel { get; set; }
        public DateTime DataCriacao { get; set; }

        public Agencia AgenciaColaboradorNavigation { get; set; }
        public Segmento SegmentoColaboradorNavigation { get; set; }

        [NotMapped]
        public int Linha { get; set; }
    }
}