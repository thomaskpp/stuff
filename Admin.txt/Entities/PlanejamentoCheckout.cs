﻿using Itau.SZ7.GPS.Admin.Enums;
using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PlanejamentoCheckout : ModelBase
    {
        public PlanejamentoCheckout()
        {

        }

        public PlanejamentoCheckout(long id, DateTime DataCheckout, int idagencia, string carteira, short grade,
            short ano, short mes, int? codigoItem, int idSegmento, string agenciaContaDac,
            StatusCheckout indicadorStatus, DateTime dataDebito, decimal valorCheckout, decimal valorpontuacao, decimal valorProducao,
            decimal valorICM, string cpf,string comentario)
        {
            Id = id;
            Data = DataCheckout;
            IdAgencia = idagencia;
            Carteira = carteira;
            Grade = grade;
            Ano = ano;
            Mes = mes;
            CodigoItem = codigoItem;
            IdSegmento = idSegmento;
            AgenciaContaDac = agenciaContaDac;
            IndicadorStatus = indicadorStatus;
            DataDebito = dataDebito;
            ValorCheckout = valorCheckout;
            ValorPontuacao = valorpontuacao;
            ValorProducao = valorProducao;
            ValorICM = valorICM;
            CPF = cpf;
            Comentario = comentario;

        }


        public long Id { get; set; }
        public DateTime Data { get; private set; }
        public DateTime DataCheckout { get; set; }
        public string CodigoProduto { get; private set; }
        public int IdColaborador { get; set; }
        public int IdAgencia { get; set; }
        public int CodigoAgencia { get; private set; }
        public int IdSegmento { get; set; }
        public string NomeSegmento { get; set; }
        public string Carteira { get; set; }
        public short Grade { get; private set; }
        public decimal ValorPontuacao { get; set; }
        public short Ano { get; private set; }
        public short Mes { get; private set; }
        public int? CodigoItem { get; private set; }
        public string Funcional { get; private set; }
        public string AgenciaContaDac { get; private set; }
        public string CPF { get; private set; }
        public string Comentario { get; set; }
        public StatusCheckout IndicadorStatus { get; private set; }
        public DateTime DataDebito { get; private set; }
        public decimal ValorCheckout { get; private set; }
        public decimal ValorPontos { get; private set; }
        public decimal ValorProducao { get; private set; }
        public decimal ValorICM { get; private set; }

        public decimal ValorPonderador { get; set; }
        public decimal ValorPontosInformado { get; private set; }
        public decimal ValorPesoInformado { get; private set; }
        public bool IndicadorApurado { get; set; }

        public Colaborador ColaboradorNavigation { get; private set; }
        public Agencia AgenciaNavigation { get; private set; }
        public PlanejamentoItemGradeCarteira PlanejamentoItemGradeCarteira { get; private set; }
        public ProdutoGradeItem ProdutoGradeItemCarteiraAgencia { get; private set; }

        public void CalcularValorICM(decimal valorMeta)
        {
            ValorICM = valorMeta == 0 ? 0 : ValorProducao / valorMeta;
        }

        public void CalcularValorPontosInformado(decimal valorMeta, decimal valorPeso)
        {
            CalcularValorICM(valorMeta);
            ValorPontosInformado = ValorICM * valorPeso;
        }

        public void SetarColaborador(Colaborador colaborador)
        {
            ColaboradorNavigation = colaborador;
        }

        public void SetValorPontos(decimal? pontos)
        {
            if (pontos != null)
                this.ValorPontos = (decimal)pontos;
        }

        public void SetProducao(bool isNegativo)
        {
            if (isNegativo)
                this.ValorProducao = (this.ValorCheckout * this.ValorPontos) * -1;
            else
                this.ValorProducao = this.ValorCheckout * this.ValorPontos;

        }

        public void TransformaValorProducao()
        {
            this.ValorProducao *= -1;
        }
    }
}
