﻿
using Itau.SZ7.GPS.Admin.Extensions;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ColaboradorPerfilAcesso : ModelBase
    {
        public int CodigoPerfilAcesso { get; set; }
        public string Funcional { get; set; }

        public Colaborador ColaboradorNavigation { get; set; }
        public PerfilAcesso PerfilAcessoNavigation { get; set; }
        public class BaixaAderenciaPerfil
        {
            public int CodigoPerfilAcesso { get; set; }
            public string Funcional { get; set; }

            public static BaixaAderenciaPerfil ConverteColunas(int linha, string colunas)
            {
                try
                {
                    var arrayColunas = colunas.Split(';');

                    return new BaixaAderenciaPerfil()
                    {
                        CodigoPerfilAcesso = IntExtension.TryParse(arrayColunas[0]),
                        Funcional = arrayColunas[1]

                    };
                }
                catch
                {
                    return null;
                }
            }
            public static List<BaixaAderenciaPerfil> ConverteColunas(List<int> linhas, List<string> colunas)
            {
                var result = new List<BaixaAderenciaPerfil>();

                for (var x = 0; x < colunas.Count; x++)
                {
                    var model = ConverteColunas(linhas[x], colunas[x]);

                    if (model != null)
                        result.Add(model);
                }

                return result;
            }
        }
    }
}