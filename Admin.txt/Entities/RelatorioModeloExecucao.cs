﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class RelatorioModeloExecucao
    {

        public RelatorioModeloExecucao(string nivel, int idPolo, int codigoPolo, string nomeSegmento, string nome, decimal valorPlanejamentoMes, decimal? valorPlanejamentoBanco, decimal valorCheckinMes, decimal valorCheckinHoje, decimal valorCheckoutMes, decimal valorCheckoutHoje, decimal notificacoesLidas, int totalNotificacoes, bool possuiSubPolo, decimal valorPlanejado, decimal valorSimulacao)
        {
            Nivel = nivel;
            IdPolo = idPolo;
            CodigoPolo = codigoPolo;
            NomeSegmento = nomeSegmento;
            Nome = nome;
            ValorPlanejamentoMes = valorPlanejamentoMes;
            ValorPlanejamentoBanco = valorPlanejamentoBanco;
            ValorCheckinMes = valorCheckinMes;
            ValorCheckinHoje = valorCheckinHoje;
            ValorCheckoutMes = valorCheckoutMes;
            ValorCheckoutHoje = valorCheckoutHoje;
            NotificacoesLidas = notificacoesLidas;
            TotalNotificacoes = totalNotificacoes;
            PossuiSubPolo = possuiSubPolo;
            ValorPlanejado = valorPlanejado;
            ValorSimulacao = valorSimulacao;
            Grupo = new List<RelatorioModeloExecucaoGrupo>();
        }

        public string Nivel { get; set; }
        public int IdPolo { get; set; }
        public int CodigoPolo { get; set; }
        public string NomeSegmento { get; set; }
        public string Nome { get; set; }
        public decimal ValorPlanejamentoMes { get; set; }
        public decimal? ValorPlanejamentoBanco { get; set; }
        public decimal ValorCheckinMes { get; set; }
        public decimal ValorCheckinHoje { get; set; }
        public decimal ValorCheckoutMes { get; set; }
        public decimal ValorCheckoutHoje { get; set; }
        public decimal NotificacoesLidas { get; set; }
        public decimal ValorPlanejado { get; set; }
        public decimal ValorSimulacao { get; set; }
        public int TotalNotificacoes { get; set; }
        public bool PossuiSubPolo { get; set; }
        public List<RelatorioModeloExecucaoGrupo> Grupo { get; set; }
    }

    public class RelatorioModeloExecucaoGrupo
    {
        internal RelatorioModeloExecucaoGrupo()
        {

        }

        public RelatorioModeloExecucaoGrupo(string descricao, List<RelatorioModeloExecucao> subpolos)
        {
            Descricao = descricao;
            Subpolos = subpolos;
        }

        public string Descricao { get; set; }
        public List<RelatorioModeloExecucao> Subpolos { get; set; }
    }
}
