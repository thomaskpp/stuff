﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilPermissaoResposta
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int IdPlataforma { get; set; }
        public string Url { get; set; }
        public string Descricao { get; set; }
        public string Icone { get; set; }
        public int Ordem { get; set; }
        public int IdFuncionalidadeLinkTipo { get; set; }
        public bool Menu { get; set; }
        public int IdFuncionalidadePai { get; set; }
        public int IdFuncionalidadeGrupo { get; set; }
        public string GrupoNome { get; set; }
        public int GrupoOrdem { get; set; }
    }
}
