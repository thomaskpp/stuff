﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class GradeCarteira
    {
        public int Id { get; set; }
        public string Carteira { get; set; }
        public short Grade { get; set; }
        public int Mes { get; set; }
        public int Ano { get; set; }
        public int IdAgencia { get; set; }

        public override bool Equals(object obj)
        {
            return obj is GradeCarteira carteira &&
                   Grade == carteira.Grade &&
                   Carteira == carteira.Carteira;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Grade, Carteira, IdAgencia);
        }
    }
}
