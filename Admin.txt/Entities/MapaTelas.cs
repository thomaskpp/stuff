﻿
using System.ComponentModel.DataAnnotations;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class MapaTelas : ModelBase
    {
        [Key]
        public Funcionalidade.Enum CodigoFuncionalidade { get; set; }
        public string Tela { get; set; }

    }
}
