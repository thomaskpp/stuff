﻿using Itau.SZ7.GPS.Admin.Enums;
using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class DelegacaoAcesso : ModelBase
    {
        public DateTime DataInicioVigencia { get; set; }
        public DateTime DataFimVigencia { get; set; }
        public int CodigoAgenciaOrigem { get; set; }
        public string CarteiraOrigem { get; set; }
        public string FuncionalDelegacao { get; set; }
        public string FuncionalOrigem { get; set; }
        public int CodigoAgenciaDestino { get; set; }
        public string CarteiraDestino { get; set; }
        public string FuncionalDestino { get; set; }
        public string AbreviacaoCargoOrigem { get; set; }
        public string AbreviacaoCargoDestino { get; set; }
        public StatusDelegacao CodigoStatusDelegacao { get; set; }
        public MotivoDelegacao CodigoMotivoDelegacao { get; set; }
        public TipoDelegacao CodigoTipoDelegacao { get; set; }
        public long? IdNotificacaoAprovacaoGRA { get; set; }

        public Agencia AgenciaOrigemNavigation { get; set; }
        public Agencia AgenciaDestinoNavigation { get; set; }
        public Colaborador ColaboradorOrigemNavigation { get; set; }
        public Colaborador ColaboradorDestinoNavigation { get; set; }
        public Colaborador ColaboradorDelegacaoNavigation { get; set; }
        public Notificacoes NotificacaoAprovacaoGRANavigation { get; set; }
    }
}
