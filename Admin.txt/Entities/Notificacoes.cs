﻿using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public partial class Notificacoes : ModelBase
    {
        public Notificacoes()
        {
            Destinatario = new HashSet<Destinatario>();
        }

        public long Id { get; set; }
        public long? CodigoNotificacao { get; set; }
        public string Status { get; set; }
        public string Template { get; set; }
        public string ArquivoTemplate { get; set; }
        public string Texto { get; set; }
        public string Img { get; set; }
        public string Urlatalho { get; set; }
        public string Resumo { get; set; }
        public DateTime DataPublicacao { get; set; }
        public TimeSpan Hora { get; set; }
        public short? Ano { get; set; }
        public short? Mes { get; set; }
        public long IdRemetente { get; set; }
        public TipoExibicaoNotificacao? CodigoTipoExibicao { get; set; }
        public int IdNotificacoesTemplate { get; set; }

        public Remetente RemetenteNavigation { get; set; }
        public NotificacoesTemplate TemplateNavigation { get; set; }
        public ICollection<Destinatario> Destinatario { get; set; }

        [NotMapped]
        public int Linha { get; set; }


        public string EhValido()
        {

            //TEMPLATE INVALIDO
            if ((this.Template.Length > 0 &&
                this.Template.IndexOf("TEXTO") == 0 &&
                this.Template.IndexOf("IMAGE") == 0 &&
                this.Template.IndexOf("ATALHO") == 0) &&
                (((this.Template.IndexOf("TEXTO") != 0 &&
                this.Texto.Length == 0) &&
                 (this.Template.IndexOf("IMAGEM") != 0 &&
                this.Texto.Length == 0) &&
                  (this.Template.IndexOf("ATALHO") != 0 &&
                this.Texto.Length == 0))))
            {
                return "Template Inválido";
            }

            //STATUS INVALIDO
            if (this.Status.Length == 0 || this.Status.Length > 1 || (this.Status != "S" && this.Status != "N"))
            {
                return "Status Inválido";
            }

            //IMAGEM INVALIDA
            if (this.Img.Length != 0 &&
                this.Img.ToUpper().IndexOf("JPG") == 0 &&
                this.Img.ToUpper().IndexOf("JPEG") == 0 &&
                this.Img.ToUpper().IndexOf("PNG") == 0 &&
                this.Img.ToUpper().IndexOf("GIF") == 0)
            {
                return "Imagem Inválida";
            }

            //TIPO EXIBICAO INVALIDO    
            if (this.CodigoTipoExibicao == null)
            {
                return "Tipo de exibição Inválido";
            }

            return string.Empty;
        }
        public ICollection<DelegacaoAcesso> DelegacaoAcesso { get; set; }

        public static Notificacoes ConverteColunas(int linha, string colunas)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                return new Notificacoes()
                {
                    Id = LongExtension.TryParse(arrayColunas[0]),
                    Status = arrayColunas[1],
                    Template = arrayColunas[2],
                    ArquivoTemplate = arrayColunas[3],
                    Texto = arrayColunas[4],
                    Img = arrayColunas[5],
                    Urlatalho = arrayColunas[6],
                    Resumo = arrayColunas[7],
                    DataPublicacao = DateTimeExtension.TryParse(arrayColunas[8]),
                    Hora = TimeSpanExtension.TryParse(arrayColunas[9]),
                    IdRemetente = LongExtension.TryParse(arrayColunas[10]),
                    CodigoTipoExibicao = EnumExtension.ToEnum<TipoExibicaoNotificacao>(arrayColunas[11]),
                    IdNotificacoesTemplate = IntExtension.TryParse(arrayColunas[12]),
                    Linha = linha
                };
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static List<Notificacoes> ConverteColunas(List<int> linhas, List<string> colunas)
        {
            var resultado = new List<Notificacoes>();

            for (var x = 0; x < colunas.Count; x++)
            {
                var model = ConverteColunas(linhas[x], colunas[x]);

                if (model != null)
                    resultado.Add(model);
            }

            return resultado;
        }
    }
}
