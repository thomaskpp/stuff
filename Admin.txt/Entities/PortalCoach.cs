﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PortalCoach
    {
        public int codigoFuncionalidade { get; set; }
        public int codigoCargo { get; set; }

        public string titulo { get; set; }
        public string descricao { get; set; }

        public string imagem { get; set; }

        public int passo { get; set; }

    }
}
