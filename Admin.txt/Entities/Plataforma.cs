﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Plataforma
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public enum Enum
        {
            App = 1,
            Web = 2,
            Admin = 3
        }
    }
}
