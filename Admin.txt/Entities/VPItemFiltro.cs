﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VPItemFiltro
    {
        /// <summary>
        /// 
        /// </summary>
        public VPItemFiltro()
        {

        }

        /// <summary>
        /// codigo do item
        /// </summary>
        /// <value>Nome do item</value>
        [JsonProperty("codigo")]
        public int Codigo { get; set; }

        /// <summary>
        /// codigo do item
        /// </summary>
        /// <value>Nome do item</value>
        [JsonProperty("codigoFilhos")]
        public List<int> CodigoFilhos { get; set; }

        /// <summary>
        /// Nome do item
        /// </summary>
        /// <value>Nome do item</value>
        [JsonProperty("nome")]
        public string Nome { get; set; }

        /// <summary>
        /// Icone do item
        /// </summary>
        /// <value>Icone do item</value>
        [JsonProperty("icone")]
        public string Icone { get; set; }

        /// <summary>
        /// Pontuação apurada pelo colaborador para o item
        /// </summary>
        /// <value>Pontuação apurada pelo colaborador para o item</value>
        [JsonProperty("pontuacaoAGIRApurada")]
        public decimal PontuacaoAGIRApurada { get; set; }

        /// <summary>
        /// Pontuação realizada para o item
        /// </summary>
        /// <value>Pontuação realizada para o item</value>
        [JsonProperty("pontuacaoAGIRRealizada")]
        public decimal PontuacaoAGIRRealizada { get; set; }

        /// <summary>
        /// Data da ultima atualização do realizado
        /// </summary>
        /// <value> Data da ultima atualização do realizado</value>
        [JsonProperty("dataAtualizacaoRealizado")]
        public DateTime? DataAtualizacaoRealizado { get; set; }

        /// <summary>
        /// Data da ultima atualização do realizado
        /// </summary>
        /// <value> Data da ultima atualização do realizado</value>
        [JsonProperty("exibirPontuacaoRealizada")]
        public bool ExibirPontuacaoRealizada { get; set; }

        /// <summary>
        /// Data da ultima atualização do realizado
        /// </summary>
        /// <value> Data da ultima atualização do realizado</value>
        [JsonProperty("exibirPontuacaoApurada")]
        public bool ExibirPontuacaoApurada { get; set; }

        /// <summary>
        /// Data da ultima atualização do realizado
        /// </summary>
        /// <value> Data da ultima atualização do realizado</value>
        [JsonProperty("exibirIndicadorAlteracao")]
        public bool ExibirIndicadorAlteracao { get; set; }
    }
}