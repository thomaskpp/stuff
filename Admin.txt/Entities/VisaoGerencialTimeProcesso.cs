﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoGerencialTimeProcesso : ModelBase
    {
        public bool EfetuarProcesso { get; set; }
    }

}
