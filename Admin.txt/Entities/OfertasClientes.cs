﻿using Itau.SZ7.GPS.Admin.Domain.VendaAtiva.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.VendaAtiva.Models
{
    public class OfertasClientes
    {
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public long Id { get; set; }
        public string Carteira { get; set; }
        public long NumeroCPFCNPJ { get; set; }
        public string NomeProdutoOferta { get; set; }
        public int IdSegmento { get; set; }
        public string NomeSegmento { get; set; }
        public string CodigoArgumento { get; set; }
        public string DescricaoArgumento { get; set; }
        public int CodigoAgencia { get; set; }
        public int NumeroAgenciaCliente { get; set; }
        public int NumeroContaCliente { get; set; }
        public int OrdemExibicaoProdutoOferta { get; set; }
        public int OrdemExibicaoVisaoPorCliente { get; set; }
        public int OrdemExibicaoVisaoPorProduto { get; set; }
        public string FuncionalAtuandoOferta { get; set; }
        public DateTime DataAtuandoOferta { get; set; }
        public DateTime DataFinalDescanso { get; set; }
        public bool IndicaOfertaFinalizada { get; set; }
        public string CodcahNew { get; set; }
        public string NomeCliente { get; set; }
        public DateTime DataNascimento { get; set; }
        public string AbreviaturaGenero { get; set; }
        public string SociosPJ { get; set; }
        public string NomeProduto { get; set; }
        public string DescricaoProduto { get; set; }
        public string LinkProduto { get; set; }
        public string Emails { get; set; }
        public string Telefones { get; set; }

    }
}
