﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilAcesso : ModelBase
    {
        public int CodigoPerfilAcesso { get; set; }
        public string NomePerfilAcesso { get; set; }

        public ICollection<ColaboradorPerfilAcesso> ColaboradorPerfilAcesso { get; set; }
    }
}