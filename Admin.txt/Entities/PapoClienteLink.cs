﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Entities
{
   public class PapoClienteLink
    {
        public int Id { get; set; }

        public DateTime DataCriacao { get; set; }

        public DateTime DataAtualizacao { get; set; }

        public string Link { get; set; }

    }
}
