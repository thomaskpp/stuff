﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public partial class Destinatario
    {

        public int Id { get; set; }

        public string Funcional { get; set; }

        public DateTime DataCriacao { get; set; }

        public DateTime DataAtualizacao { get; set; }
        public int IdColaborador { get; set; }
        public long IdNotificacao { get; set; }
        public string DadosVariaveis { get; set; }
        public string Status { get; set; }
        public int Push { get; set; }
        public int Lido { get; set; }
        public string DataLeitura { get; set; }

        public int StatusLike { get; set; }

        public DateTime DataPlanejamento { get; set; }

        public Colaborador FuncionalNavigation { get; set; }
        public Notificacoes NotificacaoNavigation { get; set; }

        [NotMapped]
        public int Linha { get; set; }

        #region [Métodos Auxiliares]
        public const int QTDE_NOTIFICACOES = 12;
        public const int UPDATE_TYPE_FIRSTSYNC = 0;
        public const int UPDATE_TYPE_PROXIMAS = 1;
        public const int UPDATE_TYPE_ANTERIORES = 2;
        public const string TIPO_ATALHO = "ATALHO";
        public const string TIPO_IMAGEM = "IMAGEM";
        public const string TIPO_TEXTO_IMAGEM = "TEXTO_IMAGEM";
        public const string TIPO_TEXTO = "TEXTO";
        public const string TIPO_HTML = "HTML";
        #endregion
    }
}
