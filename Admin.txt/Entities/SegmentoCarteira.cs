﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.VendaAtiva.Models
{
    public class SegmentoCarteira
    {
        public string NomeSegmento { get; set; }
        public string Carteira { get; set; }
        public string Funcional { get; set; }
    }
}
