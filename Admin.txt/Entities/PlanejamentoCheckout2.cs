﻿using Itau.SZ7.GPS.Admin.Enums;
using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PlanejamentoCheckout2 : ModelBase
    {
        private PlanejamentoCheckout2()
        {

        }

        public PlanejamentoCheckout2(DateTime data, string codigoProduto, int codigoAgencia, string carteira, short grade,
            short ano, short mes, int? codigoItem, string funcional, string nomeSegmento, string agenciaContaDac,
            StatusCheckout indicadorStatus, DateTime dataDebito, decimal valorCheckout, decimal valorPontos, decimal valorProducao,
            decimal valorICM, decimal valorPontosInformado, string cpf, int idSegmento, string comentario)
        {
            Data = data;
            CodigoProduto = codigoProduto;
            CodigoAgencia = codigoAgencia;
            Carteira = carteira;
            Grade = grade;
            Ano = ano;
            Mes = mes;
            CodigoItem = codigoItem;
            Funcional = funcional;
            NomeSegmento = nomeSegmento;
            IdSegmento = idSegmento;
            AgenciaContaDac = agenciaContaDac;
            IndicadorStatus = indicadorStatus;
            DataDebito = dataDebito;
            ValorCheckout = valorCheckout;
            ValorPontos = valorPontos;
            ValorProducao = valorProducao;
            ValorICM = valorICM;
            ValorPontosInformado = valorPontosInformado;
            CPF = cpf;
            Comentario = comentario;

        }

        public DateTime Data { get; private set; }
        public string CodigoProduto { get; private set; }
        public int CodigoAgencia { get; private set; }
        public string NomeSegmento { get; set; }
        public int IdSegmento { get; set; }
        public string Carteira { get; private set; }
        public short Grade { get; private set; }
        public short Ano { get; private set; }
        public short Mes { get; private set; }
        public int? CodigoItem { get; private set; }
        public string Funcional { get; private set; }
        public string AgenciaContaDac { get; private set; }
        public string CPF { get; private set; }
        public string Comentario { get; set; }
        public StatusCheckout IndicadorStatus { get; private set; }
        public DateTime DataDebito { get; private set; }
        public decimal ValorCheckout { get; private set; }
        public decimal ValorPontos { get; private set; }
        public decimal ValorProducao { get; private set; }
        public decimal ValorICM { get; private set; }
        public decimal ValorPontosInformado { get; private set; }
        public decimal ValorPesoInformado { get; private set; }
        public bool IndicadorApurado { get; set; }

        public Colaborador ColaboradorNavigation { get; private set; }
        public Agencia AgenciaNavigation { get; private set; }
        public PlanejamentoItemGradeCarteira PlanejamentoItemGradeCarteira { get; private set; }
        public ProdutoGradeItem ProdutoGradeItemCarteiraAgencia { get; private set; }

        public void CalcularValorICM(decimal valorMeta)
        {
            ValorICM = valorMeta == 0 ? 0 : ValorProducao / valorMeta;
        }

        public void CalcularValorPontosInformado(decimal valorMeta, decimal valorPeso)
        {
            CalcularValorICM(valorMeta);
            ValorPontosInformado = ValorICM * valorPeso;
        }

        public void SetarColaborador(Colaborador colaborador)
        {
            ColaboradorNavigation = colaborador;
        }

        public void SetValorPontos(decimal? pontos)
        {
            if (pontos != null)
                this.ValorPontos = (decimal)pontos;
        }

        public void TransformaValorProducao()
        {
            this.ValorProducao *= -1;
        }
    }
}
