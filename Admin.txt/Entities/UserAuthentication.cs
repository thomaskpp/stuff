﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    /// <summary>
    /// Model para autenticação
    /// </summary>
    public class UserAuthentication
    {
        /// <summary>
        /// Login
        /// </summary>
        public string L { get; set; }

        /// <summary>
        /// Password
        /// </summary>
        public string P { get; set; }
    }
}
