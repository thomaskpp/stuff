﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class FiltroDicom
    {
        public FiltroDicom()
        {
        }

        public FiltroDicom(int idPoloDICOM, int codigoPolo, string funcional, string nome)
        {
            IdPoloDICOM = idPoloDICOM;
            CodigoPolo = codigoPolo;
            Funcional = funcional;
            Nome = nome;
        }

        public int IdPoloDICOM { get; set; }
        public int CodigoPolo { get; set; }
        public string Funcional { get; set; }
        public string Nome { get; set; }
    }
}
