﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class HomeTemplate
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Html { get; set; }
        public int Status { get; set; }
        public string ModeloTemplate { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime? DataAtualizacao { get; set; }
        public IEnumerable<string> Funcionais { get; set; }
    }
}
