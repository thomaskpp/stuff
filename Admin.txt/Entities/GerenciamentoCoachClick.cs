﻿using System.ComponentModel.DataAnnotations;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class GerenciamentoCoachClick : ModelBase
    {
        [Key]
        public int Id { get; set; }
        public int CodigoFuncionalidade { get; set; }
        public int CodigoCargo { get; set; }
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public string Imagem { get; set; }
        public int Passo { get; set; }
        public bool Ativo { get; set; }

    }

}
