﻿using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using Itau.SZ7.GPS.Admin.Extensions;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PlanejamentoItemGradeCarteira : ModelBase
    {
        public PlanejamentoItemGradeCarteira()
        {
            PlanejamentoCheckout = new List<PlanejamentoCheckout>();
        }

        public int CodigoAgencia { get; set; }
        public int IdAgencia { get; set; }
        public string Carteira { get; set; }
        public short Grade { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
        public string NomeSegmento { get; set; }
        public int IdSegmento { get; set; }
        public int CodigoItem { get; set; }
        public string NomeItem { get; set; }
        public int? CodigoItemPai { get; set; }
        public decimal ValorPeso { get; set; }
        public decimal ValorMeta { get; set; }
        public bool Bonus { get; set; }
        public bool Vocacao { get; set; }
        public decimal ValorICMMaximo { get; set; }
        public decimal ValorICMHistorico { get; set; }
        public decimal ValorPonderador { get; set; }
        public decimal ValorPontuacaoMinima { get; set; }
        public decimal ValorPontuacaoMaxima { get; set; }
        public decimal ValorPontuacaoMaximaItem { get; set; }
        public decimal ValorProducaoMaxima { get; set; }
        public string NomeIconeItem { get; set; }
        public bool IndicadorAlteracao { get; set; }
        public bool Alteracao { get; set; }

        public int IdColaboradorAgir { get; set; }
        public int IdPlanejamento { get; set; }
        public int IdPlanejamentoItem { get; set; }
        public int? IdPlanejamentoItemPai { get; set; }
        public int IdGradeItem { get; set; }



        public RegraCalculoICMAgrupamento RegraCalculoICM { get; set; }
        public FrequenciaPlanejamento FrequenciaPlanejamento { get; set; }

        public decimal ValorICMPlanejado { get; set; }
        public decimal ValorPontuacaoPlanejada { get; set; }
        public decimal ValorProducaoPlanejada { get; set; }
        public decimal ValorICMMinimo { get; set; }


        public PlanejamentoGradeCarteira PlanejamentoGradeCarteira { get; set; }
        public ICollection<PlanejamentoCheckin> PlanejamentoCheckin { get; set; }
        public ICollection<PlanejamentoCheckout> PlanejamentoCheckout { get; set; }
        public ICollection<PlanejamentoProducaoRealizada> PlanejamentoProducaoRealizada { get; set; }

        #region [ Métodos Auxiliares ]

        /// <summary>
        /// 
        /// </summary>
        /// <param name="planejamentoItemGradeCarteira"></param>
        /// <returns></returns>
        public DateTime? GetDataUltimaAtualizacaoVP()
        {
            return GetLastUpdate(item => item.PlanejamentoProducaoRealizada, realizado => realizado.DataAtualizacao);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="item"></param>
        /// <param name="listSelector"></param>
        /// <param name="datetimeSelector"></param>
        /// <returns></returns>
        public DateTime? GetLastUpdate<T>(Func<PlanejamentoItemGradeCarteira, ICollection<T>> listSelector, Func<T, DateTime> datetimeSelector)
        {
            bool hasItens = !(listSelector(this) is null) && listSelector(this).Any();

            return hasItens ?
                    listSelector(this)?.Max(datetimeSelector) : null;
        }

        public decimal GetICMPlanejado(ICollection<PlanejamentoItemGradeCarteira> planejamentoItemsGradeCarteira)
        {
            decimal sumItem;
            decimal icmPlanejado;
            if (planejamentoItemsGradeCarteira.Count(i => this.CodigoItem.Equals(i.CodigoItemPai)) > 1)
            {
                sumItem = ValorPontuacaoPlanejada;
                icmPlanejado = CalcICM(sumItem, ValorPeso);
            }

            else
            {
                sumItem = ValorProducaoPlanejada;
                icmPlanejado = CalcICM(sumItem, ValorMeta);
            }

            return icmPlanejado;
        }

        /// <summary>
        /// ICM Informado por item
        /// </summary>
        /// <param name="planejamentoItemGradeCarteira">item</param>
        /// <returns></returns>
        public decimal GetICMInformado(IEnumerable<PlanejamentoItemGradeCarteira> planejamentoItemsGradeCarteira, Predicate<PlanejamentoCheckout> predicate, bool travarProducaoMaxima)
        {
            if (!(CodigoItemPai is null) && CodigoItem.Equals(CodigoItemPai))
                return 0;

            decimal sumItem;
            decimal icmInformado;
            if (planejamentoItemsGradeCarteira.Count(i => this.CodigoItem.Equals(i.CodigoItemPai)) > 1)
            {
                sumItem = GetPontuacaoInformada(planejamentoItemsGradeCarteira, predicate, travarProducaoMaxima);
                icmInformado = CalcICM(sumItem, ValorPeso);
            }

            else
            {
                sumItem = GetProducaoInformada(planejamentoItemsGradeCarteira, predicate, travarProducaoMaxima);
                icmInformado = CalcICM(sumItem, ValorMeta);
            }

            return icmInformado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public decimal GetICMMaximo()
        {
            return ValorICMMaximo * 100;
        }

        /// <summary>
        /// Pontuacao Planejada por Item
        /// </summary>
        /// <param name="planejamentoItemGradeCarteira">Item Planejamento</param>
        /// <returns>Pontuação Planejada Total do Item</returns>
        private decimal GetPontuacaoInformada(Predicate<PlanejamentoCheckout> predicate, bool travarProducaoMaxima)
        {
            var pontos = SumCheckout(p => p.ValorPontosInformado, predicate);
            pontos = travarProducaoMaxima && pontos > ValorPontuacaoMaxima ? ValorPontuacaoMaxima : pontos;
            return pontos;
        }

        private decimal GetPontuacaoInformadaItemBonus(IEnumerable<PlanejamentoItemGradeCarteira> planejamentoItemsGradeCarteira, bool travarProducaoMaxima)
        {
            var itemPrincipal = planejamentoItemsGradeCarteira.SingleOrDefault(i => i.CodigoItem.Equals(this.CodigoItemPai));

            if (!PlanejamentoItemGradeCarteira.AtingiuMetaICM(itemPrincipal.GetICMInformado(planejamentoItemsGradeCarteira, checkout => checkout.CodigoItem == itemPrincipal.CodigoItem, travarProducaoMaxima)))
                return 0;
            else
                return CalcValorPontuacao(ValorMeta, ValorMeta, ValorPeso);
        }

        private decimal GetPontuacaoInformadaItemComposto(IEnumerable<PlanejamentoItemGradeCarteira> planejamentoItemsGradeCarteira, bool travarProducaoMaxima)
        {
            var subItens = planejamentoItemsGradeCarteira.Where(i => this.CodigoItem.Equals(i.CodigoItemPai) && !i.Bonus);
            var icmSubItens = subItens.Sum(i => i.GetICMInformado(planejamentoItemsGradeCarteira, checkout => checkout.CodigoItem == i.CodigoItem, travarProducaoMaxima)) / subItens.Count();

            var totalAgir = PlanejamentoItemGradeCarteira.CalcByICM(
                icmSubItens,
                ValorPeso
            );

            return totalAgir;
        }

        private decimal GetPontuacaoInformadaItemBonusCheckin(ICollection<PlanejamentoItemGradeCarteira> planejamentoItemsGradeCarteira, Predicate<PlanejamentoCheckout> predicate, bool travarProducaoMaxima)
        {
            var itemPrincipal = planejamentoItemsGradeCarteira.SingleOrDefault(i => i.CodigoItem.Equals(this.CodigoItemPai));

            if (!PlanejamentoItemGradeCarteira.AtingiuMetaICM(itemPrincipal.GetICMInformado(planejamentoItemsGradeCarteira, checkout => predicate(checkout) && checkout.CodigoItem == itemPrincipal.CodigoItem, travarProducaoMaxima)))
                return 0;
            else
                return CalcValorPontuacao(ValorMeta, ValorMeta, ValorPeso);
        }

        private decimal GetPontuacaoInformadaItemCompostoCheckin(ICollection<PlanejamentoItemGradeCarteira> planejamentoItemsGradeCarteira, Predicate<PlanejamentoCheckout> predicate, bool travarProducaoMaxima)
        {
            var subItens = planejamentoItemsGradeCarteira.Where(i => this.CodigoItem.Equals(i.CodigoItemPai) && !i.Bonus);
            var icmSubItens = subItens.Sum(i => i.GetICMInformado(planejamentoItemsGradeCarteira, checkout => predicate(checkout) && checkout.CodigoItem == i.CodigoItem, travarProducaoMaxima)) / subItens.Count();

            var totalAgir = PlanejamentoItemGradeCarteira.CalcByICM(
                icmSubItens,
                ValorPeso
            );

            return totalAgir;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="planejamentoItemsGradeCarteira"></param>
        /// <returns></returns>
        public decimal GetPontuacaoInformada(IEnumerable<PlanejamentoItemGradeCarteira> planejamentoItemsGradeCarteira, Predicate<PlanejamentoCheckout> predicate, bool travarProducaoMaxima, bool ignorarNegativo = false)
        {
            if (!(CodigoItemPai is null) && CodigoItem.Equals(CodigoItemPai))
                return 0;

            decimal pontuacaoInformada = 0;

            if (planejamentoItemsGradeCarteira.Count(i => this.CodigoItem.Equals(i.CodigoItemPai) && !i.Bonus) > 1)
            {
                pontuacaoInformada = GetPontuacaoInformadaItemComposto(planejamentoItemsGradeCarteira, travarProducaoMaxima);
            }
            else if (Bonus && planejamentoItemsGradeCarteira.Any(i => this.CodigoItemPai.Equals(i.CodigoItem)))
            {
                pontuacaoInformada = GetPontuacaoInformadaItemBonus(planejamentoItemsGradeCarteira, travarProducaoMaxima);
            }
            else
            {
                pontuacaoInformada = GetPontuacaoInformada(predicate, travarProducaoMaxima);
            }

            if (ignorarNegativo && pontuacaoInformada < 0) return 0;

            if (IdSegmento == (int)Enums.Segmentos.Personnalite)
            {
                decimal icmInformado = 0;
                var itemPrincipal = planejamentoItemsGradeCarteira.SingleOrDefault(i => i.CodigoItem.Equals(this.CodigoItemPai));
                if (itemPrincipal is null)
                    icmInformado = this.GetICMInformado(planejamentoItemsGradeCarteira, checkout => checkout.CodigoItem == this.CodigoItem, true);
                else
                    icmInformado = itemPrincipal.GetICMInformado(planejamentoItemsGradeCarteira, checkout => checkout.CodigoItem == itemPrincipal.CodigoItem, true);

                if (this.ValorICMMinimo > 0 && icmInformado < (this.ValorICMMinimo * 100))
                    return 0;
            }

            if (ignorarNegativo && pontuacaoInformada < 0) return 0;

            if (IdSegmento == (int)Enums.Segmentos.Personnalite)
            {
                decimal icmInformado = 0;
                var itemPrincipal = planejamentoItemsGradeCarteira.SingleOrDefault(i => i.CodigoItem.Equals(this.CodigoItemPai));
                if (itemPrincipal is null)
                    icmInformado = this.GetICMInformado(planejamentoItemsGradeCarteira, checkout => checkout.CodigoItem == this.CodigoItem, true);
                else
                    icmInformado = itemPrincipal.GetICMInformado(planejamentoItemsGradeCarteira, checkout => checkout.CodigoItem == itemPrincipal.CodigoItem, true);

                if (this.ValorICMMinimo > 0 && icmInformado < (this.ValorICMMinimo * 100))
                    return 0;
            }

            return pontuacaoInformada;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="planejamentoItemsGradeCarteira"></param>
        /// <returns></returns>
        public decimal GetPontuacaoInformadaCheckin(ICollection<PlanejamentoItemGradeCarteira> planejamentoItemsGradeCarteira, Predicate<PlanejamentoCheckout> predicate, bool travarProducaoMaxima)
        {
            if (!(CodigoItemPai is null) && CodigoItem.Equals(CodigoItemPai))
                return 0;

            if (planejamentoItemsGradeCarteira.Count(i => this.CodigoItem.Equals(i.CodigoItemPai) && !i.Bonus) > 1)
            {
                return GetPontuacaoInformadaItemCompostoCheckin(planejamentoItemsGradeCarteira, predicate, travarProducaoMaxima);
            }
            else if (Bonus && planejamentoItemsGradeCarteira.Any(i => this.CodigoItemPai.Equals(i.CodigoItem)))
            {
                return GetPontuacaoInformadaItemBonusCheckin(planejamentoItemsGradeCarteira, predicate, travarProducaoMaxima);
            }
            else
            {
                return GetPontuacaoInformada(predicate, travarProducaoMaxima);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public decimal GetProducaoInformada(bool travarProducaoMaxima)
        {
            return GetProducaoInformada(p => p.CodigoItem.Equals(CodigoItem), travarProducaoMaxima);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public decimal GetProducaoInformada(IEnumerable<PlanejamentoItemGradeCarteira> planejamentoItemsGradeCarteira, bool travarProducaoMaxima)
        {
            return GetProducaoInformada(planejamentoItemsGradeCarteira, p => p.CodigoItem.Equals(CodigoItem), travarProducaoMaxima);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="planejamentoItemsGradeCarteira"></param>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public decimal GetProducaoInformada(IEnumerable<PlanejamentoItemGradeCarteira> planejamentoItemsGradeCarteira, Predicate<PlanejamentoCheckout> predicate, bool travarProducaoMaxima)
        {
            if (!(CodigoItemPai is null) && CodigoItem.Equals(CodigoItemPai))
                return 0;

            var itemPrincipal = planejamentoItemsGradeCarteira.SingleOrDefault(i => i.CodigoItem.Equals(this.CodigoItemPai));
            if (Bonus && !(itemPrincipal is null) && PlanejamentoItemGradeCarteira.AtingiuMetaICM(itemPrincipal.GetICMInformado(planejamentoItemsGradeCarteira, checkout => checkout.CodigoItem == itemPrincipal.CodigoItem, travarProducaoMaxima)))
            {
                return ValorMeta;
            }
            else
                return GetProducaoInformada(predicate, travarProducaoMaxima);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        private decimal GetProducaoInformada(Predicate<PlanejamentoCheckout> predicate, bool travarProducaoMaxima)
        {
            var producao = SumCheckout(p => p.ValorProducao, predicate);
            producao = travarProducaoMaxima && producao > ValorProducaoMaxima ? ValorProducaoMaxima : producao;
            return producao;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selector"></param>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public decimal SumCheckout(Func<PlanejamentoCheckout, decimal> selector, Predicate<PlanejamentoCheckout> predicate)
        {
            return PlanejamentoCheckout.Where(p => predicate(p)).Sum(f => selector(f));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selector"></param>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public decimal SumCheckin(Func<PlanejamentoCheckin, decimal> selector, Predicate<PlanejamentoCheckin> predicate)
        {
            return PlanejamentoCheckin.Where(p => predicate(p)).Sum(f => selector(f));
        }

        /// <summary>
        /// Regra para exibicao da produção do item
        /// </summary>
        /// <param name="planejamentoItemGradeCarteira">item</param>
        /// <returns>True: Exibir</returns>
        public bool IsItemProducao(ICollection<PlanejamentoItemGradeCarteira> itemsGradeCarteira)
        {
            return Bonus || Vocacao || (itemsGradeCarteira.Count(i => CodigoItem.Equals(i.CodigoItemPai)) <= 1);

        }

        /// <summary>
        /// Regra para exibicao da produção do item
        /// </summary>
        /// <param name="planejamentoItemGradeCarteira">item</param>
        /// <returns>True: Exibir</returns>
        public bool IsItemPontuacao()
        {
            return CodigoItemPai is null ||
                CodigoItem == CodigoItemPai.Value ||
                Bonus ||
                Vocacao;
        }

        public decimal GetPontuacaoRealizada(bool travarPontuacaoMaxima)
        {
            if (this.IdSegmento == (int)Enums.Segmentos.Personnalite)
            {
                if (this.ValorICMMinimo > 0 && this.GetICMRealizado(true) < this.ValorICMMinimo * 100)
                    return 0;
            }

            var pontos = SumProducaoRealizada(p => p.ValorPontuacaoRealizada, p => p.CodigoItem == CodigoItem);
            pontos = travarPontuacaoMaxima && pontos > ValorPontuacaoMaxima ? ValorPontuacaoMaxima : pontos;
            return pontos;
        }

        public decimal GetProducaoRealizada(bool travarProducaoMaxima)
        {
            var producao = SumProducaoRealizada(p => p.ValorProducaoRealizada, p => p.CodigoItem == CodigoItem);
            producao = travarProducaoMaxima && producao > ValorProducaoMaxima ? ValorProducaoMaxima : producao;
            return producao;
        }

        public decimal GetICMRealizado(bool travarICMMaximo)
        {
            var icm = SumProducaoRealizada(p => p.ValorICMRealizado, p => p.CodigoItem == CodigoItem);
            icm = travarICMMaximo && icm > ValorICMMaximo ? ValorICMMaximo : icm;
            icm *= 100;
            return icm;
        }

        public decimal SumProducaoRealizada(Func<PlanejamentoProducaoRealizada, decimal> selector, Predicate<PlanejamentoProducaoRealizada> predicate)
        {
            if (PlanejamentoProducaoRealizada is null) return 0;
            return PlanejamentoProducaoRealizada.Where(p => predicate(p)).Sum(f => selector(f));
        }

        #endregion

        #region [ Fórmulas ]
        //ICM = producao / meta
        //producao /
        //agir = (producao / meta) * peso

        public static readonly Func<decimal, bool> PerfomanceAtingida = (pontuacao) =>
        {
            return pontuacao >= 1000;
        };

        public static readonly Func<decimal, decimal, decimal> CalcValorPontuacaoPorICM = (icm, peso) =>
        {
            return (icm / 100) * peso;
        };

        public static readonly Func<decimal, decimal, decimal, decimal> CalcValorPontuacao = (producao, meta, peso) =>
        {
            if (meta == 0) return 0;

            return (producao / meta) * peso;
        };

        public static readonly Func<decimal, decimal, decimal> CalcICM = (producao, meta) =>
        {
            if (meta == 0) return 0;
            return (producao / meta) * 100;
        };

        public static readonly Func<decimal, decimal, decimal> CalcByICM = (ICM, multiplicador) =>
        {
            return ((ICM / 100) * multiplicador);
        };

        public static decimal SetarPontuacaoMaxima(decimal pontuacao, decimal pontuacaoMaxima)
        {
            if (pontuacao > pontuacaoMaxima) return pontuacaoMaxima;
            else return pontuacao;
        }

        public static readonly Func<decimal, bool> AtingiuMetaICM = (icm) =>
        {
            return icm >= 100;
        };

        #endregion

        #region [ Cáculos para GGD/GGN/GRA ]

        #region [ RegraCalculoICMAgrupamento.PerformanceTime ]

        public decimal ItemPerformanceProducaoCalculator<T>(ICollection<T> planejamentosGradeCarteira, Func<T, decimal> selectorToCalc)
        {
            return planejamentosGradeCarteira.Count(p => PlanejamentoItemGradeCarteira.PerfomanceAtingida(selectorToCalc(p)));
        }

        public decimal ItemPerformancePontuacaoCalculator(decimal valorICM)
        {
            return PlanejamentoItemGradeCarteira.CalcValorPontuacaoPorICM(valorICM, ValorPeso);
        }

        public decimal ItemPerformanceICMCalculator(decimal valorProducao, bool isGRA = false)
        {
            decimal icm = CalcICM(valorProducao, ValorMeta);

            if (isGRA)
                return ItemICMToGRAICM(icm);
            else
                return ItemICMToGGDGGNICM(icm);
        }

        private static decimal ItemICMToGRAICM(decimal CalculatedICM)
        {
            decimal GRAICM = 0;
            CalculatedICM = CalculatedICM.Round(decimals: 2);

            if (CalculatedICM < 50)
                GRAICM = 50;
            else if (CalculatedICM >= 50 && CalculatedICM <= 54.999m)
                GRAICM = 60;
            else if (CalculatedICM >= 55 && CalculatedICM <= 59.999m)
                GRAICM = 70;
            else if (CalculatedICM >= 60 && CalculatedICM <= 64.999m)
                GRAICM = 80;
            else if (CalculatedICM >= 65 && CalculatedICM <= 69.999m)
                GRAICM = 90;
            else if (CalculatedICM >= 70 && CalculatedICM <= 74.999m)
                GRAICM = 100;
            else if (CalculatedICM >= 75 && CalculatedICM <= 79.999m)
                GRAICM = 110;
            else if (CalculatedICM >= 80 && CalculatedICM <= 84.999m)
                GRAICM = 120;
            else if (CalculatedICM >= 85 && CalculatedICM <= 89.999m)
                GRAICM = 130;
            else if (CalculatedICM >= 90 && CalculatedICM <= 94.999m)
                GRAICM = 140;
            else if (CalculatedICM >= 95)
                GRAICM = 150;

            return GRAICM;

        }

        private decimal ItemICMToGGDGGNICM(decimal CalculatedICM)
        {
            decimal GGDGGNICM = 0;
            CalculatedICM = CalculatedICM.Round(decimals: 2);

            if (CalculatedICM < 40.1m)
                GGDGGNICM = 50;
            else if (CalculatedICM >= 40.1m && CalculatedICM <= 46.67m)
                GGDGGNICM = 75;
            else if (CalculatedICM >= 46.68m && CalculatedICM <= 53.33m)
                GGDGGNICM = 90;
            else if (CalculatedICM >= 53.34m && CalculatedICM <= 60m)
                GGDGGNICM = 105;
            else if (CalculatedICM >= 60.1m && CalculatedICM <= 66.67m)
                GGDGGNICM = 120;
            else if (CalculatedICM >= 66.68m && CalculatedICM <= 73.33m)
                GGDGGNICM = 135;
            else if (CalculatedICM >= 73.34m && CalculatedICM <= 80)
                GGDGGNICM = 150;
            else if (CalculatedICM >= 80.1m)
                GGDGGNICM = 150;

            return GGDGGNICM;

        }

        #endregion

        #region [ RegraCalculoICMAgrupamento.SubItem ]

        public decimal ItemSubItemICMCalculator(ICollection<PlanejamentoItemGradeCarteira> planejamentoItemGradeCarteiraGG, ICollection<PlanejamentoGradeCarteira> planejamentosGradeCarteira, Func<PlanejamentoItemGradeCarteira, decimal> selectorToCalcICM, Func<PlanejamentoItemGradeCarteira, decimal> selectorValorProducao = null)
        {
            var itensFilhos = planejamentosGradeCarteira
                .SelectMany(p => p.PlanejamentoItemGradeCarteira)
                .Where(p => CodigoItem.Equals(p.CodigoItemPai)).ToList();

            if (!(itensFilhos is null) && itensFilhos.Any())
            {
                var itens = itensFilhos.Where(i => !i.Bonus).ToList();

                if (itens.Count < 1)
                    return 0;

                var childrensSum = itens.GroupBy(i => i.CodigoItem).Select(p => new
                {
                    p.FirstOrDefault().CodigoItem,
                    ValorTotal = p.Sum(selectorValorProducao)
                });

                int qtdeFilhos = childrensSum.Count();

                var valorProducao = childrensSum.Sum(s => PlanejamentoItemGradeCarteira.CalcICM(
                    s.ValorTotal,
                    planejamentoItemGradeCarteiraGG.Single(i => s.CodigoItem == i.CodigoItem).ValorMeta)
                );

                var icm = valorProducao / qtdeFilhos;

                return icm;
            }
            else
            {
                var valorProducao = ItemSubItemProducaoCalculator(planejamentosGradeCarteira, selectorValorProducao);
                return PlanejamentoItemGradeCarteira.CalcICM(valorProducao, ValorMeta);
            }
        }

        public decimal ItemSubItemPontuacaoCalculator(ICollection<PlanejamentoItemGradeCarteira> planejamentoItemGradeCarteiraGG, ICollection<PlanejamentoGradeCarteira> planejamentosGradeCarteira, Func<PlanejamentoItemGradeCarteira, decimal> selectorToCalcICM, Func<PlanejamentoItemGradeCarteira, decimal> selectorValorProducao = null)
        {
            var itensFilhos = planejamentosGradeCarteira
                .SelectMany(p => p.PlanejamentoItemGradeCarteira)
                .Where(p => CodigoItem.Equals(p.CodigoItemPai)).ToList();

            if (!(itensFilhos is null) && itensFilhos.Any())
            {
                var valorICM = ItemSubItemICMCalculator(planejamentoItemGradeCarteiraGG, planejamentosGradeCarteira, selectorToCalcICM, selectorValorProducao);
                return PlanejamentoItemGradeCarteira.CalcByICM(valorICM, ValorPeso);
            }
            else
            {
                var valorProducao = ItemSubItemProducaoCalculator(planejamentosGradeCarteira, selectorValorProducao);
                return PlanejamentoItemGradeCarteira.CalcValorPontuacao(valorProducao, ValorMeta, ValorPeso);
            }
        }

        public decimal ItemSubItemProducaoCalculator(ICollection<PlanejamentoGradeCarteira> planejamentosGradeCarteira, Func<PlanejamentoItemGradeCarteira, decimal> selectorValorProducao)
        {
            var itensFilhos = planejamentosGradeCarteira
                .SelectMany(p => p.PlanejamentoItemGradeCarteira)
                .Where(p => CodigoItem.Equals(p.CodigoItemPai)).ToList();

            if (!(itensFilhos is null) && itensFilhos.Any())
            {
                return 0;
            }
            else
            {
                var itens = planejamentosGradeCarteira.SelectMany(p => p.PlanejamentoItemGradeCarteira).Where(p => p.CodigoItem.Equals(CodigoItem)).ToList();
                return itens.Sum(selectorValorProducao);
            }
        }

        #endregion

        #region [ RegraCalculoICMAgrupamento.Geral ]

        public decimal ItemGeralProducaoCalculator<T, TList>(
            ICollection<T> planejamentosGradeCarteira,
            Func<T, IEnumerable<TList>> listSelector,
            Func<TList, bool> filter,
            Func<TList, decimal> selectorToCalc)
        {
            if (ValorMeta <= 0)
                return 0;

            var itens = planejamentosGradeCarteira
                .SelectMany(listSelector)
                .Where(filter)
                .ToList();

            return itens.Sum(selectorToCalc);
        }

        public decimal ItemGeralProducaoCalculator(ICollection<PlanejamentoGradeCarteira> planejamentosGradeCarteira, Func<PlanejamentoItemGradeCarteira, decimal> selectorToCalc, bool travaMeta = true)
        {
            if (travaMeta)
            {
                return ItemGeralProducaoCalculator(
                planejamentosGradeCarteira,
                p => p.PlanejamentoItemGradeCarteira,
                i => i.CodigoItem.Equals(CodigoItem) && i.ValorMeta > 0,
                selectorToCalc);
            }
            else
            {
                return ItemGeralProducaoCalculator(
                planejamentosGradeCarteira,
                p => p.PlanejamentoItemGradeCarteira,
                i => i.CodigoItem.Equals(CodigoItem),
                selectorToCalc);
            }

        }

        public decimal ItemGeralPontuacaoCalculator(decimal valorProducao)
        {
            return PlanejamentoItemGradeCarteira.CalcValorPontuacao(valorProducao, ValorMeta, ValorPeso);
        }

        public decimal ItemGeralICMCalculator(decimal valorProducao)
        {
            return PlanejamentoItemGradeCarteira.CalcICM(valorProducao, ValorMeta);
        }

        #endregion

        #region [ RegraCalculoICMAgrupamento.ICM ]

        public decimal ItemICMRuleICMCalculator<T, TList>(
            ICollection<T> planejamentosGradeCarteira,
            Func<T, IEnumerable<TList>> listSelector,
            Func<TList, bool> filter,
            Func<TList, decimal> selectorToCalc)
        {
            var qtdeColaboradores = planejamentosGradeCarteira.SelectMany(listSelector).Count(filter);

            if (qtdeColaboradores == 0)
                return 0;

            var itens = planejamentosGradeCarteira
                .SelectMany(listSelector)
                .Where(filter)
                .ToList();

            return itens.Sum(selectorToCalc) / qtdeColaboradores;
        }

        public decimal ItemICMRuleICMCalculator(ICollection<PlanejamentoGradeCarteira> planejamentosGradeCarteira, Func<PlanejamentoItemGradeCarteira, decimal> selectorToCalc)
        {
            return ItemICMRuleICMCalculator(
                planejamentosGradeCarteira,
                p => p.PlanejamentoItemGradeCarteira,
                i => i.CodigoItem.Equals(CodigoItem) && i.ValorMeta > 0,
                selectorToCalc);
        }

        public decimal ItemICMRulePontuacaoCalculator(decimal valorICM)
        {
            return PlanejamentoItemGradeCarteira.CalcByICM(valorICM, ValorPeso);
        }

        public decimal ItemICMRuleProducaoCalculator(decimal valorICM)
        {
            return PlanejamentoItemGradeCarteira.CalcByICM(valorICM, ValorMeta);
        }

        #endregion

        #endregion

        public override bool Equals(object obj)
        {
            var carteira = obj as PlanejamentoItemGradeCarteira;
            return carteira != null &&
                   CodigoAgencia == carteira.CodigoAgencia &&
                   Carteira == carteira.Carteira &&
                   Grade == carteira.Grade &&
                   Ano == carteira.Ano &&
                   Mes == carteira.Mes &&
                   CodigoItem == carteira.CodigoItem;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(CodigoAgencia, Carteira, Grade, Ano, Mes, CodigoItem);
        }

        #region Regras Itens Atendimento

        public static readonly List<string> ItensAtendimento = new List<string> { "Atendimento", "NPS", "Processos", "SQV", "RECLAMAÇÕES" };
        public static readonly List<string> ItemSQV = new List<string> { "SQV" };
        public static readonly List<string> ItensAtendimentoGRE = new List<string> { "Atendimento", "NPS", "SQV", "RECLAMAÇÕES" };
        public static readonly Func<PlanejamentoItemGradeCarteira, bool> eDeUmGRE = item => item.PlanejamentoGradeCarteira != null && item.PlanejamentoGradeCarteira.ColaboradorResponsavelNavigation != null && Colaborador.CODIGO_GRE.Equals(item.PlanejamentoGradeCarteira.ColaboradorResponsavelNavigation.AbreviacaoCargo);
        public static readonly Func<PlanejamentoItemGradeCarteira, bool> eUmItemDeAtendimento = item => (eDeUmGRE(item)) ? ItensAtendimentoGRE.Contains(item.NomeItem) : ItensAtendimento.Contains(item.NomeItem);
        public static readonly Func<PlanejamentoItemGradeCarteira, bool> naoEUmItemDeAtendimento = item => !eUmItemDeAtendimento(item);

        #endregion
    }

    public class PlanejamentoItemGradeCarteiraSimplificado
    {
        public int IdAgencia { get; set; }
        public string Carteira { get; set; }
        public short Grade { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
        public int IdSegmento { get; set; }
        public int CodigoItem { get; set; }
        public string NomeItem { get; set; }
        public int? CodigoItemPai { get; set; }
        public decimal ValorPeso { get; set; }
        public decimal ValorMeta { get; set; }
        public bool IndicadorBonus { get; set; }
        public bool IndicadorVocacao { get; set; }
        public decimal ValorICMMaximo { get; set; }
        public decimal? ValorICMHistorico { get; set; }
        public decimal ValorPonderador { get; set; }
        public byte ValorPontuacaoMinima { get; set; }
        public decimal ValorPontuacaoMaxima { get; set; }
        public decimal ValorProducaoMaxima { get; set; }
        public string NomeIconeItem { get; set; }
        public bool IndicadorAlteracao { get; set; }


        public RegraCalculoICMAgrupamento CodigoRegraCalculoICMAgrupamento { get; set; }

        public FrequenciaPlanejamento CodigoFrequenciaPlanejamento { get; set; }
    }

    [NotMapped]
    public class PlanejamentoItemGradeCarteiraCarga : PlanejamentoItemGradeCarteira
    {
        public bool AtualizarPlanejamentoItem { get; set; }

        public int Linha { get; set; }
        public decimal? MetaPerformance { get; set; }

        public decimal? MetaItem { get; set; }
        public decimal? MetaItemDB { get; set; }
        public decimal? ValorICMPlanejadoSubItem { get; set; }
        public decimal? ValorICMPlanejadoBonus { get; set; }
        public DateTime? DataCriacaoAnterior { get; set; }
        public decimal? ValorICMPlanejadoAnterior { get; set; }
        public int? IdPoloRegional { get; set; }
        public int? IdPoloRegiao { get; set; }
        public int? IdPoloDICOM { get; set; }
        public string CarteiraMeta { get; set; }
        public int? AgenciaAnterior { get; set; }
        public int? ItemPai { get; set; }
        public new decimal ValorICMMinimo { get; set; }

        public int IdColaboradorResponsavel { get; set; }

        public PlanejamentoItemGradeCarteira PlanejamentoAnterior { get; set; }
        public bool ExibicaoPlanejamento { get; set; }
        public short ExibicaoPerformance { get; set; }

        public static PlanejamentoItemGradeCarteiraCarga ConverteColunas(string colunas, short ano, short mes)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                return new PlanejamentoItemGradeCarteiraCarga()
                {
                    CodigoAgencia = IntExtension.TryParse(arrayColunas[4]),
                    Carteira = arrayColunas[0],
                    Grade = ShortExtension.TryParse(arrayColunas[1]),
                    CodigoItem = IntExtension.TryParse(arrayColunas[2]),
                    ValorMeta = DecimalExtension.TryParse(arrayColunas[3]),
                    MetaItem = DecimalExtension.TryParse(arrayColunas[3]),
                    NomeSegmento = arrayColunas[5],
                    ValorICMMinimo = DecimalExtension.TryParse(arrayColunas[6]),
                    Ano = ano,
                    Mes = mes,
                    DataAtualizacao = DateTime.Now,
                    DataCriacao = DateTime.Now,
                };
            }
            catch
            {
                return null;
            }
        }

        public static List<PlanejamentoItemGradeCarteiraCarga> ConverteColunas(List<string> colunas, short ano, short mes)
        {
            var result = new List<PlanejamentoItemGradeCarteiraCarga>();

            for (var x = 0; x < colunas.Count; x++)
            {
                var model = ConverteColunas(colunas[x], ano, mes);

                if (model != null)
                    result.Add(model);
            }

            return result;
        }
    }


    public class PlanejamentoItemGradeCarteiraSimples
    {
        public string Carteira { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }

        public static List<PlanejamentoItemGradeCarteiraSimples> ConverteColunas(List<string> colunas, short ano, short mes)
        {
            var resultado = new List<PlanejamentoItemGradeCarteiraSimples>();

            foreach (var coluna in colunas)
            {
                try
                {
                    var arrayColunas = coluna.Split(';');

                    resultado.Add(new PlanejamentoItemGradeCarteiraSimples()
                    {
                        Ano = ano,
                        Mes = mes,
                        Carteira = arrayColunas[0]
                    });
                }
                catch { }
            }

            return resultado.Distinct().ToList();
        }
    }

    public class PlanejamentoItemGradeCarteiraCalculado : PlanejamentoItemGradeCarteira
    {
        public PlanejamentoItemGradeCarteiraCalculado()
        {
            this.PlanejamentoCheckout = new List<PlanejamentoCheckout>();
        }

        public decimal ValorICMInformado { get; set; }
        public decimal ValorPontuacaoInformada { get; set; }
        public decimal ValorProducaoInformada { get; set; }
        public decimal ValorICMRealizado { get; set; }
        public decimal ValorPontuacaoRealizada { get; set; }
        public decimal ValorProducaoRealizada { get; set; }
        public new bool IsItemPontuacao { get; set; }
        public new bool IsItemProducao { get; set; }
        public DateTime? DataUltimoCheckout { get; set; }
        public DateTime? DataUltimoVP { get; set; }
        public DateTime? DataUltimaAtualizacaoVP { get; set; }

        #region Regras Itens Atendimento

        public static readonly Func<PlanejamentoItemGradeCarteiraCalculado, bool> eDeUmGRE = item => item.PlanejamentoGradeCarteira != null && item.PlanejamentoGradeCarteira.ColaboradorResponsavelNavigation != null && Colaborador.CODIGO_GRE.Equals(item.PlanejamentoGradeCarteira.ColaboradorResponsavelNavigation.AbreviacaoCargo);
        public static readonly Func<PlanejamentoItemGradeCarteiraCalculado, bool> eUmItemDeAtendimento = item => (eDeUmGRE(item)) ? ItensAtendimentoGRE.Contains(item.NomeItem) : ItensAtendimento.Contains(item.NomeItem);
        public static readonly Func<PlanejamentoItemGradeCarteiraCalculado, bool> naoEUmItemDeAtendimento = item => !eUmItemDeAtendimento(item);


        #endregion
    }
}
