﻿using System;
using System.Collections.Generic;
using static Itau.SZ7.GPS.Admin.Domain.VendaAtiva.Entities.VendaAtivaClientesCarga;

namespace Itau.SZ7.GPS.Admin.VendaAtiva.Models
{
    public class ClientesOfertas
    {
        public string AbreviaturaGenero { get; internal set; }
        public List<ClienteEmails> VendaAtivaClientesEmail { get; internal set; }
        public List<ClientesTelefone> VendaAtivaClientesTelefone { get; internal set; }
        public DateTime DataNascimento { get; internal set; }
        public string NomeCliente { get; internal set; }
        public long NumeroCPFCNPJ { get; internal set; }
        public string SociosPJ { get; internal set; }
        public List<OfertasClientes> VendaAtivaOfertas { get; internal set; }
        public List<OfertasReagendadas> VendaAtivaOfertasReagendas { get; internal set; }
    }
}
