﻿using Itau.SZ7.GPS.Admin.Enums;

namespace Itau.SZ7.GPS.Admin.Entities
{
    /// <summary>
    /// Entidade utilizada para enviar e recuperar estrtura de uma carteira
    /// </summary>
    public class VisaoGerencialEstruturaCarteira
    {
        public string Carteira { get; set; }
        public int CodigoAgencia { get; set; }
        public string Funcional { get; set; }
        public string AbreviacaoCargo { get; set; }
        public int CodigoItem { get; set; }        
        public string NomeItem { get; set; }
        public decimal ValorMeta { get; set; }
        public decimal ICMMinimo { get; set; }
        public RegraCalculoICMAgrupamento CodigoRegraCalculoICMAgrupamento { get; set; }
        public int IdPoloDICOM { get; set; }
        public int IdPoloRegiao { get; set; }
        public int IdPoloRegional { get; set; }
        public string FuncDICOM { get; set; }
        public string FuncSUPT { get; set; }
        public string FuncGRA { get; set; }
    }
}
