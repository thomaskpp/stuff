﻿
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopPergunta
    {
        public int Id { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public int IdSegmento { get; set; }
        public int NumeroPergunta { get; set; }
        public string Descricao { get; set; }
        public string Relatorio { get; set; }
        public string Tipo { get; set; }
        public int IdPergunta { get; set; }
        public bool Ativo { get; set; }
        public int NumeroPerguntaPai { get; set; }

        public ICollection<InnerLoopResposta> InnerLoopRespostaNavigation { get; set; }


        [NotMapped]
        public int Linha { get; set; }

        public static List<InnerLoopPergunta> ConverteColunas(List<int> linhas, List<string> colunas, int segmento)
        {
            var result = new List<InnerLoopPergunta>();
            var dtAtual = DateTime.Now;

            for (var x = 0; x < colunas.Count; x++)
            {
                var arrayColunas = colunas[x].Split(';');

                var perguntasInnerLoop = new InnerLoopPergunta();

                perguntasInnerLoop = new InnerLoopPergunta()
                {
                    DataCriacao = DateTime.Now,
                    DataAtualizacao = DateTime.Now,
                    NumeroPergunta = IntExtension.TryParse(arrayColunas[0]),
                    Descricao = arrayColunas[1],
                    NumeroPerguntaPai = IntExtension.TryParse(arrayColunas[2]),
                    Tipo = (arrayColunas[3] == "") ? null : arrayColunas[3],
                    Relatorio = (arrayColunas[4] == "") ? null : arrayColunas[4],
                    IdSegmento = segmento
                };

                result.Add(perguntasInnerLoop);
            }

            colunas = null;

            return result;
        }
    }
}