﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public partial class Trava : ModelBase
    {
        public int Id { get; set; }

        public string Funcional { get; set; }
    }
}
