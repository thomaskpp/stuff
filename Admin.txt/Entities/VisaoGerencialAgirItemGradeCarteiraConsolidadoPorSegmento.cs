﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoGerencialAgirItemGradeCarteiraConsolidadoPorSegmento
    {
        public int? IdPoloDicom { get; set; }
        public int? IdPoloRegiao { get; set; }
        public int? IdPoloRegional { get; set; }
        public int Ano { get; set; }
        public int Mes { get; set; }
        public string FuncionalResponsavel { get; set; }
        public string AbreviacaoCargo { get; set; }
        public string NomeSegmento { get; set; }
        public string Carteira { get; set; }
        public int CodItem { get; set; }
        public string NomeItem { get; set; }
        public decimal ValorRealizado { get; set; }
        public decimal ValorMetaPlanejado { get; set; }
        public decimal ValorICMPlanejado { get; set; }
        public decimal ValorICMRealizado { get; set; }
        public decimal ValorGAPPonto { get; set; }
        public int? CodigoAgencia { get; set; }
        public int Grade { get; set; }
        public decimal ValorPontuacaoRealizado { get; set; }
        public bool Bonus { get; set; }
        public int? IdSegmento { get; set; }
    }
}
