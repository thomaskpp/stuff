﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class RelatorioPorCarteira
    {
        public int Id { get; set; }
        public int Mes { get; set; }
        public int Ano { get; set; }
        public int CodigoPoloDicom { get; set; }
        public int CodigoPoloRegiao { get; set; }
        public int CodigoPoloRegional { get; set; }
        public int CodigoAgencia { get; set; }
        public string Carteira { get; set; }
        public string FuncionalResponsavel { get; set; }
        public string NomeResponsavel { get; set; }
        public string GGResponsavel { get; set; }
        public string NomeItem { get; set; }
        public int CodigoItem { get; set; }
        public int CodigoItemPai { get; set; }
        public decimal ValorPlanejamentoMensal { get; set; }
        public decimal ValorMetaItem { get; set; }
        public decimal ValorAgirRealizado { get; set; }
        public decimal ValorGAPEmProducao { get; set; }
        public decimal ValorNaoApurado { get; set; }
        public decimal ValorAgirSimulado { get; set; }
        public string NomeSegmento { get; set; }
        public DateTime DataReferencia { get; set; }
    }
}
