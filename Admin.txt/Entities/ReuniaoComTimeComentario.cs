﻿using Newtonsoft.Json;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ReuniaoComTimeComentario
    {
        public int IdReuniaoComTimeComentario { get; set; }
        [JsonIgnore]
        public int IdReuniaoComTime { get; set; }
        public string Comentario { get; set; }
    }
}
