﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoNotificacoes
    {
        public int Id { get; set; }
        public string NomeSegmento { get; set; }
        public int QuantidadeNotificacoes { get; set; }
        public int QuantidadeNotificacoesLidas { get; set; }
        public string Nome { get; set; }
    }
}
