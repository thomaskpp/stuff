﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Entities
{
    /// <summary>
    /// Entidade utilizada para enviar e recuperar estrtura de uma carteira
    /// </summary>
    public class VisaoGerencialProducaoFuncionalSuperior
    {
        public int CodigoItem { get; set; }
        public decimal SomaDeProducao { get; set; }
        public decimal SomaDeValorICM { get; set; }
        public decimal SomaDeValorPontos { get; set; }
        public int IdPoloDICOM { get; set; }
        public int IdPoloRegiao { get; set; }
        public int IdPoloRegional { get; set; }
        public string FuncDICOM { get; set; }
        public string FuncSUPT { get; set; }
        public string FuncGRA { get; set; }
    }
}
