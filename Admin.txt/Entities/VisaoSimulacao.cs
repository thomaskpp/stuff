﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoSimulacao
    {
        public int Id { get; set; }
        public int IdSegmento { get; set; }
        public decimal ValorSimulacao { get; set; }
    }
}
