﻿using Itau.SZ7.GPS.Admin.Enums;
using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class GradeItem
    {
        public int Id { get; set; }

        public int Mes { get; set; }

        public int Ano { get; set; }

        public DateTime DataCriacao { get; set; }

        public DateTime DataAtualizacao { get; set; }

        public short Grade { get; set; }

        public string Nome { get; set; }

        public Decimal ValorPeso { get; set; }

        public Decimal ValorICMMaximo { get; set; }

        public String ValorICMMaximoStr {
            get {
                System.Globalization.NumberFormatInfo n = new System.Globalization.NumberFormatInfo();
                n.NumberDecimalSeparator = ".";

                return ValorICMMaximo.ToString(n);
            }
        }

        public decimal ValorPonderador { get; set; }

        public int RegraCalculoICM { get; set; }

        public int FrequenciaPlanejamento { get; set; }

        public bool Bonus { get; set; }

        public bool Vocacao { get; set; }

        public int CodigoItem { get; set; }

        public int? CodigoItemPai { get; set; }

        public string CodigoItemPaiStr {
            get {
                return CodigoItemPai.HasValue ? CodigoItemPai.ToString() : "null";
            }
        }

        public int IdSegmento { get; set; }

        public string NomeItem { get; set; }
        public string NomeSegmento { get; set; }
        public bool ExibicaoPlanejamento { get; set; }

        public short ExibicaoPerformance { get; set; }
    }
}
