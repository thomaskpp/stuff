﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ValorPesosSegmentos
    {
        public int IdAgencia { get; set; }
        public int CodigoAgencia { get; set; }
        public string ChavePeso { get; set; }
        public string ValorPesoIA { get; set; }
        public string ValorPesoIU { get; set; }
        public string ValorPesoEMP4 { get; set; }
    }
}
