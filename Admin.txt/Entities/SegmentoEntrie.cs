﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public struct SegmentoEntrie
    {
        public int Id { get; private set; }

        public int IdEstrutura { get; private set; }

        public string Nome { get; private set; }

        public string Sigla { get; private set; }

        private readonly string[] _sinonimos;

        public SegmentoEntrie(int id, int idEstrutura, string nome, string sigla, string[] sinonimos)
        {
            Id = id;
            IdEstrutura = idEstrutura;
            Nome = nome;
            Sigla = sigla;
            _sinonimos = sinonimos;
        }

        public bool ExisteSinonimo(string nome)
        {
            foreach (var sinonimo in _sinonimos)
            {
                if (string.Equals(nome, sinonimo, StringComparison.InvariantCultureIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

    }
}
