﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Entities;

using System;
using System.Collections.Generic;
using System.Linq;
using Itau.SZ7.GPS.Admin.Extensions;

namespace Itau.SZ7.GPS.Admin.Domain.VendaAtiva.Entities
{
    public class VendaAtivaClientesCarga : ModelBase
    {
        public long NumeroCPFCNPJ { get; set; }
        public string NomeCliente { get; set; }
        public DateTime? DataNascimento { get; set; }
        public string AbreviaturaGenero { get; set; }
        public string Emails { get; set; }
        public string Telefones { get; set; }
        public string SociosPJ { get; set; }
        public string PES { get; set; }

        //Validação de Inserção ou Update
        public bool ClienteExists { get; set; }


        public static List<VendaAtivaClientesCarga> ConverteColunas(List<int> linhas, List<string> colunas, Enums.Segmentos segmento)
        {
            var result = new List<VendaAtivaClientesCarga>();
            var dtAtual = DateTime.Now;

            for (var x = 0; x < colunas.Count; x++)
            {
                try
                {
                    var arrayColunas = colunas[x].Split(';');

                    var cliente = new VendaAtivaClientesCarga();

                    //Adiciona telefones
                    //var telefones = arrayColunas[4].Split('|');

                    //List<ClientesTelefone> listTelefones = new List<ClientesTelefone>();
                    //for (int i = 0; i < telefones.Length; i++)
                    //    listTelefones.Add(new ClientesTelefone() { Telefone = telefones[i], Ordem = i });
                    //
                    ////Adiciona emails
                    //var emails = arrayColunas[5].Split('|');
                    //
                    //List<ClienteEmails> listEmails = new List<ClienteEmails>();
                    //for (int i = 0; i < emails.Length; i++)
                    //    listEmails.Add(new ClienteEmails() { Email = emails[i], Ordem = i });

                    cliente = new VendaAtivaClientesCarga()
                    {
                        NumeroCPFCNPJ = Convert.ToInt64(arrayColunas[0]),
                        NomeCliente = arrayColunas[1],
                        DataNascimento = DateTimeExtension.TryParse(arrayColunas[2]),
                        AbreviaturaGenero = (arrayColunas[3] == "") ? null : arrayColunas[3],
                        SociosPJ = (arrayColunas[6] == "") ? null : arrayColunas[6],
                        Emails = arrayColunas[5],
                        Telefones = arrayColunas[4]
                    };
                    result.Add(cliente);
                }
                catch (Exception ex)
                {
                    //TODO: log
                }
            }

            colunas = null;

            return result;

        }

        public static List<VendaAtivaClientesCarga> ConverteColunasDistinct(List<int> linhas, List<string> colunas, Enums.Segmentos segmento)
        {
            var model = ConverteColunas(linhas, colunas, segmento);

            return model
                .Select(a => new
                {
                    a.NumeroCPFCNPJ
                })
                .Distinct()
                .Select(a => new VendaAtivaClientesCarga()
                {
                    NumeroCPFCNPJ = a.NumeroCPFCNPJ

                })
                .ToList();
        }

        public class ClientesTelefone
        {
            public string Telefone { get; set; }
            public AvaliacaoTelefone? CodigoAvaliacaoTelefone { get; set; }
            public int? Ordem { get; set; }

        }

        public class ClienteEmails
        {
            public string Email { get; set; }
            public AvaliacaoEmail? CodigoAvaliacaoEmail { get; set; }
            public int? Ordem { get; set; }
        }
    }
}
