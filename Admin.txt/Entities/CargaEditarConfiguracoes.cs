﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public  class CargaEditarConfiguracoes
    {
        public int IdCarga { get; set; }
        public string Nome { get; set; }
        public int TipoPeriodo { get; set; }
        public int TipoCarga { get; set; }
        public string ValorPeriodo { get; set; }

        public int Value { get; set; }
        public string Dia { get; set; }

        public int IdFuncionalidade { get; set; }

        public bool TravaSimultanea { get; set; }


        public static List<CargaEditarConfiguracoes> GetAllDiasSemanais()
        {
            var listaDias = new List<CargaEditarConfiguracoes>();

            listaDias.Add(new CargaEditarConfiguracoes
            {
                Value = 1,
                Dia = "Toda Segunda-Feira"
            });
            listaDias.Add(new CargaEditarConfiguracoes
            {
                Value = 2,
                Dia = "Toda Terça-Feira"
            });
            listaDias.Add(new CargaEditarConfiguracoes
            {
                Value = 3,
                Dia = "Toda Quarta-Feira"
            });
            listaDias.Add(new CargaEditarConfiguracoes
            {
                Value = 4,
                Dia = "Toda Quinta-Feira"
            });
            listaDias.Add(new CargaEditarConfiguracoes
            {
                Value = 5,
                Dia = "Toda Sexta-Feira"
            });

            return listaDias;
        }
    }
}
