﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilPermissao
    {
        public int Id { get; set; }
        public int IdPerfil { get; set; }
        public string Nome { get; set; }
        public int IdFuncionalidade { get; set; }
        public bool Home { get; set; }
        public int IdPerfilPermissaoNivel { get; set; }
        public Funcionalidade Funcionalidade { get; set; }
    }
}
