﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilFuncionalidade
    {
        public IEnumerable<string> Perfis { get; set; }
        public IEnumerable<FuncionalidadeHome> FuncionalidadesAdmin { get; set; }
        public IEnumerable<FuncionalidadeHome> FuncionalidadesPortal { get; set; }
    }
}
