﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class NPSRespostaCliente
    {
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public DateTime DataContato { get; set; }
        public int Nota { get; set; }
        public string Comentario { get; set; }
        public string Produto { get; set; }
        public int IdSegmento { get; set; }
        public int IdAgenciaContato { get; set; }
        public int IdEstrutura { get; set; }
        public int Linha { get; set; }

    }
}
