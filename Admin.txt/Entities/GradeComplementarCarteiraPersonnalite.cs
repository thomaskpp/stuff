﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class GradeComplementarCarteiraPersonnalite
    {
        public int IdColaboradorAgir { get; set; }
        public short Grade { get; set; }
        public int Agrupamento { get; set; }
    }
}
