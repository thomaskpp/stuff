﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class AgenciaPeso : ModelBase
    {
        public int Id { get; set; }
        public int IdAgencia { get; set; }
        public int IdSegmento { get; set; }
        public decimal? Peso { get; set; }

        public Agencia AgenciaNavigation { get; set; }
    }
}