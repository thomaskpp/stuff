﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class AgenciaSimplificado
    {
        public int IdAgencia { get; set; }
        public string Codigo { get; set; }
    }
}
