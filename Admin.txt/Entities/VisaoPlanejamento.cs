﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoPlanejamento
    {
        public VisaoPlanejamento()
        {
        }

        public VisaoPlanejamento(string nomeSegmento, int carteiras, int carteirasPlanejadas)
        {
            NomeSegmento = nomeSegmento;
            Carteiras = carteiras;
            CarteirasPlanejadas = carteirasPlanejadas;
        }

        public string NomeSegmento { get; set; }
        public int Carteiras { get; set; }
        public int CarteirasPlanejadas { get; set; }
    }
}
