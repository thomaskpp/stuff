﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class IdLigacaoQuery
    {
        public int IdLigacao { get; set; }
    }
}
