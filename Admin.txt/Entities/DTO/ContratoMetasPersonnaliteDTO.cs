﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ContratoMetasPersonnaliteDTO
    {
        public int Id { get; set; }
        public string DataReferencia { get; set; }
        public int Grade { get; set; }
        public int IdAgencia { get; set; }
        public string Carteira { get; set; }
        public int IdGradeItem { get; set; }
        public string ValorN1 { get; set; }
        public string ValorN2 { get; set; }
        public string ValorN3 { get; set; }
        public string ValorN4 { get; set; }
        public string ValorN5 { get; set; }
        public string ValorProducao { get; set; }
        public decimal ValorPosicao { get; set; }

    }
}
