﻿using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities.DTO
{
    public class Reclamacao
    {
        public int Id { get; set; }
        public int CodigoAgencia { get; set; }
        public string IdentificadorOcorrencia { get; set; }
        public int IdSegmento { get; set; }
        public string NomeSegmento { get; set; }
        public string CodigoSegmento { get; set; }
        public int IdEstrutura { get; set; }
        public DateTime DataOcorrencia { get; set; }
        public DateTime DataSolucaoOcorrencia { get; set; }
        public DateTime DataVisualizacaoOcorrencia { get; set; }
        public int CodigoAgenciaCliente { get; set; }
        public int NumeroContaCliente { get; set; }
        public string NomeReclamante { get; set; }
        public string NomeAgrupadorCanal { get; set; }
        public string AnoMes { get; set; }
        public string NomeTipoCanal { get; set; }
        public string NomeTipoAssunto { get; set; }
        public string TextoAssunto { get; set; }
        public string TextoAssuntoCompleto { get; set; }
        public string NomeMeioComunicacao { get; set; }
        public string Telefone { get; set; }
        public bool? IndicadorAtuacaoGGC { get; set; }
        public bool? IndicadorAtuacaoGRA { get; set; }
        public bool IndicadorVisaoMetasDicom { get; set; }
        public bool IndicadorVisaoMetasDiop { get; set; }
        public bool IndicadorCiente { get; set; }
        public StatusReclamacao CodigoStatusOcorrencia { get; set; }
        public bool IndicadorAtivo { get; set; }
        public int CodigoAgenciaCoordenadora { get; set; }
        public int CodigoAgenciaOcorrencia { get; set; }
        public Agencia AgenciaNavigation { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }

        public string Tipo { get; set; }

        public string CpfCnpj { get; set; }

        public string RelatoCliente { get; set; }
        [NotMapped]
        public int Linha { get; set; }


        public static Reclamacao ConverteColunas(int linha, string colunas)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                return new Reclamacao()
                {
                    IdentificadorOcorrencia = arrayColunas[0],
                    CodigoAgenciaCliente = IntExtension.TryParse(arrayColunas[1]),
                    NumeroContaCliente = IntExtension.TryParse(arrayColunas[2]),
                    NomeReclamante = arrayColunas[3],
                    AnoMes = arrayColunas[4],
                    NomeTipoAssunto = arrayColunas[5],
                    TextoAssuntoCompleto = arrayColunas[6],
                    DataOcorrencia = DateTimeExtension.TryParse(arrayColunas[7]),
                    DataSolucaoOcorrencia = DateTimeExtension.TryParse(arrayColunas[8]),
                    CodigoAgenciaOcorrencia = IntExtension.TryParse(arrayColunas[9]),
                    NomeMeioComunicacao = arrayColunas[10],
                    IndicadorVisaoMetasDicom = BooleanExtension.TryParse(arrayColunas[11]),
                    IndicadorVisaoMetasDiop = BooleanExtension.TryParse(arrayColunas[12]),
                    CodigoSegmento = arrayColunas[13],
                    NomeSegmento = arrayColunas[13],
                    NomeAgrupadorCanal = arrayColunas[14],
                    NomeTipoCanal = arrayColunas[15],
                    //Telefone = arrayColunas[16],
                    TextoAssunto = arrayColunas[16],
                    //IndicadorAtuacaoGRA = BooleanExtension.TryParse(arrayColunas[18]),
                    //IndicadorAtuacaoGGC = BooleanExtension.TryParse(arrayColunas[19]),
                    CodigoAgenciaCoordenadora = IntExtension.TryParse(arrayColunas[17]),
                    CodigoStatusOcorrencia = StatusReclamacao.ContatoRealizado,
                    IndicadorAtivo = true,
                    CodigoAgencia = IntExtension.TryParse(arrayColunas[17]),
                    RelatoCliente = arrayColunas[18].Trim(),
                    CpfCnpj = arrayColunas[19].Trim(),

                    DataAtualizacao = DateTime.Now,
                    DataCriacao = DateTime.Now,

                    Linha = linha
                };
            }
            catch
            {
                return null;
            }
        }

        public static List<Reclamacao> ConverteColunas(List<int> linhas, List<string> colunas)
        {
            var result = new List<Reclamacao>();

            for (var x = 0; x < colunas.Count; x++)
            {
                var model = ConverteColunas(linhas[x], colunas[x]);

                if (model != null)
                    result.Add(model);
            }

            return result;
        }
    }
}

