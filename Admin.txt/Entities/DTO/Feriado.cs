﻿using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities.DTO
{
    public class Feriado
    {
        public int CodigoAgencia { get; set; }
        public DateTime Data { get; set; }


        [NotMapped]
        public int Linha { get; set; }

        public Agencia AgenciaNavigation { get; set; }

        public static Feriado ConverteColunas(int linha, string colunas)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                return new Feriado()
                {
                    CodigoAgencia = IntExtension.TryParse(arrayColunas[0]),
                    Data = DateTimeExtension.TryParse(arrayColunas[1])
                };
            }
            catch
            {
                return null;
            }
        }
        public static List<Feriado> ConverteColunas(List<int> linhas, List<string> colunas)
        {
            var result = new List<Feriado>();

            for (var x = 0; x < colunas.Count; x++)
            {
                var model = ConverteColunas(linhas[x], colunas[x]);

                if (model != null)
                    result.Add(model);

            }
            return result;
        }
    }
}
