﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities.DTO
{
    public class TemplateSecaoHtml
    {
        public int IdTemplateSecao { get; set; }
        public int? IdFuncionalidade { get; set; }
        public int IdTemplateHtml { get; set; }
        public string Html { get; set; }
    }
}
