﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities.DTO
{
    public class AgenciaMigracaoCargaDTO : Agencia
    {
        public string ValorLongitudeString { get; set; }

        public string ValorLatitudeString { get; set; }

    }
}
