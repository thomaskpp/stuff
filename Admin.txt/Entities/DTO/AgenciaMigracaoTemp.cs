﻿namespace Itau.SZ7.GPS.Admin.Entities.DTO
{
    public class AgenciaMigracaoTemp : AgenciaMigracao
    {
        public int[] IdSegmentos { get; set; }

        public string ValorLongitudeString { get; set; }

        public string ValorLatitudeString { get; set; }

    }
}
