﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities.DTO
{
    public class NPS
    {
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public int Id { get; set; }
        public int CodigoAgencia { get; set; }
        public int IdSegmento { get; set; }
        public string NomeSegmento { get; set; }
        public DateTime DataDisparo { get; set; }
        public string NomeProduto { get; set; }
        public int QuantidadeDetrator { get; set; }
        public int QuantidadeInvalido { get; set; }
        public int QuantidadeNeutro { get; set; }
        public int QuantidadePromotor { get; set; }
        public int QuantidadeValorSAT_X { get; set; }
        public decimal ValorNPS { get; set; }
        public int ValorBench { get; set; }
        public string VisaoNPS { get; set; }
        public string Estrutura { get; set; }

        [NotMapped]
        public int Linha { get; set; }

    }
}
