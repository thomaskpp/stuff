﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities.DTO
{
    public class GerenciadorCargaAgendada
    {
        public int Id { get; set; }
        public string Colaborador { get; set; }
        public string Funcional { get; set; }
        public string Carga { get; set; }
        public DateTime Inicio { get; set; }

        [NotMapped]
        public string inicioformatado
        {
            get
            {
                return Inicio.ToString("dd/MM/yyyy HH:mm:ss");
            }
        }
    }
}
