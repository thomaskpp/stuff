﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities.DTO
{
    public class NPSRespostaCliente
    {
        public int Linha { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public int Id { get; set; }
        public DateTime DataContato { get; set; }
        public int Nota { get; set; }
        public string Comentario { get; set; }
        public string Produto { get; set; }
        public string Segmento { get; set; }
        public int AgenciaContato { get; set; }
        public string Estrutura { get; set; }

    }
}
