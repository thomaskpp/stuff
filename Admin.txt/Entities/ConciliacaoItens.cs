﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ConciliacaoItens
    {
        public int CodigoItem { get; set; }
        public string NomeItem { get; set; }

        public string NomeSegmento { get; set; }
    }
}
