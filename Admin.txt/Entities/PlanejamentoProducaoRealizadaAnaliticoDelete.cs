﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PlanejamentoProducaoRealizadaAnaliticoDelete
    {
        public int Id { get; set; }
        public int CodigoAgencia { get; set; }
        public int CodigoItem { get; set; }
        public int Ano { get; set; }
        public int Mes { get; set; }
        public string Carteira { get; set; }
    }
}
