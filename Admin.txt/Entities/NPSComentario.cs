﻿using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class NPSComentario : ModelBase
    {
        public int Id { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
        public int IdSegmento { get; set; }
        public string NomeSegmento { get; set; }
        public int Plataforma { get; set; }
        public string Produto { get; set; }
        public int Carteira { get; set; }
        public string Assunto { get; set; }
        public decimal? Detrator { get; set; }
        public decimal? Neutro { get; set; }
        public decimal? Promotor { get; set; }
        public int Respondentes { get; set; }

        [NotMapped]
        public int Linha { get; set; }

        public static List<NPSComentario> ConverteColunas(List<int> linhas, List<string> colunas, Enums.Segmentos segmento, short mes, short ano)
        {
            var result = new List<NPSComentario>();
            var dtAtual = DateTime.Now;

            for (var x = 0; x < colunas.Count; x++)
            {
                try
                {
                    var arrayColunas = colunas[x].Split(';');
                    NPSComentario NPS = null;

                    NPS = new NPSComentario()
                    {
                        DataCriacao = dtAtual,
                        DataAtualizacao = dtAtual,
                        Ano = ano,
                        Mes = mes,
                        IdSegmento = (int)(segmento),
                        Plataforma = Convert.ToInt32(arrayColunas[2].Replace("%","")),
                        NomeSegmento = arrayColunas[1],
                        Carteira = Convert.ToInt32(arrayColunas[3]),
                        Produto = arrayColunas[4],
                        Assunto = arrayColunas[5],
                        Detrator = string.IsNullOrEmpty(arrayColunas[6])? (decimal?)null : Convert.ToDecimal(arrayColunas[6].Replace("%", "")) / 100,
                        Neutro = string.IsNullOrEmpty(arrayColunas[7])? (decimal?)null : Convert.ToDecimal(arrayColunas[7].Replace("%", "")) / 100,
                        Promotor = string.IsNullOrEmpty(arrayColunas[8])? (decimal?)null : Convert.ToDecimal(arrayColunas[8].Replace("%", "")) / 100,
                        Respondentes = Convert.ToInt32(arrayColunas[9]),

                        Linha = linhas[x]
                    };

                    result.Add(NPS);
                }
                catch
                {
                    //TODO: log
                }
            }

            colunas = null;

            return result;
        }

    }
}
