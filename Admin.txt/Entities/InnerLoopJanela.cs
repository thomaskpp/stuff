﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopJanela
    {
        public int Janela { get; set; }

        public int Descanso { get; set; }
    }
}
