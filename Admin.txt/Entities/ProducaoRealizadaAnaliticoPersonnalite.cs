﻿
using Itau.SZ7.GPS.Admin.Extensions;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ProducaoRealizadaAnaliticoPersonnalite : ModelBase
    {
        public int Id { get; set; }
        public int IdAgencia { get; set; }
        public string Carteira { get; set; }
        public int CodigoItem { get; set; }
        public int IdSegmento { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public DateTime DataReferencia { get; set; }
        public DateTime Data { get; set; }
        public DateTime DataDebito { get; set; }
        public string DescricaoProduto { get; set; }
        public string ClienteAgencia { get; set; }
        public string ClienteConta { get; set; }
        public string DescricaoCanal { get; set; }
        public string NomeColaborador { get; set; }
        public decimal ValorProducao { get; set; }
        public decimal ValorPonderado { get; set; }
        public decimal ValorProducaoPonderada { get; set; }
        public string DescricaoStatus { get; set; }
        public int IdCheckout { get; set; }
        public string DATA_REF { get; set; }
        public string DICOM { get; set; }
        public string REGIAO { get; set; }
        public string REGIONAL { get; set; }
        public string AGENCIA { get; set; }
        public string PLATAFORMA { get; set; }
        public string CONTA_DAC { get; set; }
        public string NOME_CLIENTE { get; set; }
        public string APOLICE { get; set; }
        public string DATA_INICIO_VIGENCIA { get; set; }
        public string DATA_FIM_VIGENCIA { get; set; }
        public string DATA_DEBITO { get; set; }
        public string DATA_CANCELAMENTO { get; set; }
        public string MOTIVO { get; set; }
        public string STATUS { get; set; }
        public string PRODUTO { get; set; }
        public string TIPO_PROTECAO { get; set; }
        public string VLR_PREMIO { get; set; }
        public string PONDERADOR { get; set; }
        public string NUM_CARTAO { get; set; }
        public string BANDEIRA { get; set; }
        public string DATA_VENDA { get; set; }
        public string DATA_DESBLOQUEIO { get; set; }
        public string TIPO_CARTAO { get; set; }
        public string TITULAR_ADICIONAL { get; set; }
        public string ENTRADA { get; set; }
        public string SAIDA { get; set; }
        public string STATUS_GESTAO_DE_PATRIMÔNIO { get; set; }
        public string DATA_GESTAO_DE_PATRIMÔNIO { get; set; }
        public string STATUS_ASSESSORIA_DEDICADA { get; set; }
        public string DATA_ASSESSORIA_DEDICADA { get; set; }
        public string VALIDO_PARA_O_AGIR { get; set; }
        public string CONTRATO { get; set; }
        public string VALOR { get; set; }
        public string DIAS { get; set; }
        public string REV_PDD_A_VISTA { get; set; }
        public string REV_PDD_PARCELADO { get; set; }
        public string CONTRATO_RENEGOCIADO { get; set; }
        public string A_VISTA { get; set; }
        public string ORIGEM { get; set; }
        public string MES_LIBERACAO_DA_CONTA { get; set; }
        public string BIOMETRIA { get; set; }
        public string SENHA { get; set; }
        public string CARTAO { get; set; }
        public string CARTAO_PROVISORIO { get; set; }
        public string CEP_PLUS { get; set; }
        public string CHAVES_VALIDAS { get; set; }
        public string VOLUME_RECURSOS { get; set; }
        public string CAP_M4 { get; set; }
        public string CAP_M3 { get; set; }
        public string CAP_M2 { get; set; }
        public string CAP_M1 { get; set; }
        public string CAP_M0 { get; set; }
        public string CAPLIQ_ACUMULADA { get; set; }
        public string SALDO_EM_CREDITO { get; set; }
        public string PREMIO_DE_PROTECOES { get; set; }
        public string CREDITO_IMOBILIARIO { get; set; }
        public string CANAL_CREDITO_IMOBILIARIO { get; set; }
        public string CPF { get; set; }
        public string NUM_OPERACAO { get; set; }
        public string DATA_CONTRATACAO { get; set; }
        public string DATA_LIQUIDACAO { get; set; }
        public string SEGURO_PRESTAMISTA { get; set; }
        public string CONSIGNADO { get; set; }
        public string COM_GARANTIA { get; set; }
        public string VALOR_CONTRATACAO { get; set; }
        public string PONDERADOR_AGIR { get; set; }
        public string COD_PROP { get; set; }
        public string DATA_EMISSAO { get; set; }
        public string PAGAMENTO_1_PARCELA { get; set; }
        public string MF_RECURSOS { get; set; }
        public string MF_EMPRESTIMOS { get; set; }
        public string MF_OPERACOES_EM_ATRASO { get; set; }
        public string MF_CARTAO_DE_CREDITO { get; set; }
        public string MF_SERVICOS { get; set; }
        public string MF_SEGUROS { get; set; }
        public string SUBTOTAL_PRODUTO_BANCARIO { get; set; }
        public string REM_FOLHA_DE_PAGAMENTO { get; set; }
        public string RES_CAPITAL_DE_GIRO { get; set; }
        public string PISCOFINSISS { get; set; }
        public string PB_TOTAL { get; set; }
        public string PDD_ESPEC { get; set; }
        public string PB_SUBTOTAL_PDD_ESPEC { get; set; }
        public string COR { get; set; }
        public string DT_ABERTURA_CONTA { get; set; }
        public string DT_ENCERRAMENTO_CONTA { get; set; }
        public string DT_ROLLOUT { get; set; }
        public string QTD_CONTAS_PERSONNALITE { get; set; }
        public string QTD_CONTAS_CONGLOMERADO { get; set; }
        public string VOLUME_INVESTIMENTO_GP33 { get; set; }
        public string VOLUME_INVESTIMENTO_TOMBADO { get; set; }
        public string DATA_DE_ABERTURA { get; set; }
        public string DATA_DE_LIBERACAO { get; set; }
        public string DATA_DO_BLOQUEIO_T { get; set; }
        public string DATA_DE_ENCERRAMENTO { get; set; }
        public string QTDE_DE_CONTAS_NO_PERSONNALITE { get; set; }
        public string QTDE_DE_CONTAS_NO_CONGLOMERADO { get; set; }
        public string PRODUCAO_AGIR { get; set; }

        [NotMapped]
        public int Linha { get; set; }

        [NotMapped]
        public string Segmento { get; set; }

        [NotMapped]
        public string CodAgencia { get; set; }
        public string AgenciaContaDac { get; private set; }

        public class Colunas
        {
            #region [DE]
            public const string DE_ID = "Id";
            public const string DE_DATACRIACAO = "DataCriacao";
            public const string DE_DATAATUALIZACAO = "DataAtualizacao";
            public const string DE_DATAREFERENCIA = "DataReferencia";
            public const string DE_DATA = "Data";
            public const string DE_DATADEBITO = "DataDebito";
            public const string DE_DESCRICAOPRODUTO = "DescricaoProduto";
            public const string DE_CLIENTEAGENCIA = "ClienteAgencia";
            public const string DE_CLIENTECONTA = "ClienteConta";
            public const string DE_DESCRICAOCANAL = "DescricaoCanal";
            public const string DE_NOMECOLABORADOR = "NomeColaborador";
            public const string DE_VALORPRODUCAO = "ValorProducao";
            public const string DE_VALORPONDERADO = "ValorPonderado";
            public const string DE_VALORPRODUCAOPONDERADA = "ValorProducaoPonderada";
            public const string DE_DESCRICAOSTATUS = "DescricaoStatus";
            public const string DE_CARTEIRA = "Carteira";
            public const string DE_CODIGOITEM = "CodigoItem";
            public const string DE_IDAGENCIA = "IdAgencia";
            public const string DE_IDCHECKOUT = "IdCheckout";
            public const string DE_DATA_REF = "DATA_REF";
            public const string DE_DICOM = "DICOM";
            public const string DE_REGIAO = "REGIAO";
            public const string DE_REGIONAL = "REGIONAL";
            public const string DE_AGENCIA = "AGENCIA";
            public const string DE_PLATAFORMA = "PLATAFORMA";
            public const string DE_CONTA_DAC = "CONTA_DAC";
            public const string DE_NOME_CLIENTE = "NOME_CLIENTE";
            public const string DE_APOLICE = "APOLICE";
            public const string DE_DATA_INICIO_VIGENCIA = "DATA INICIO VIGENCIA";
            public const string DE_DATA_FIM_VIGENCIA = "DATA FIM VIGENCIA";
            public const string DE_DATA_DEBITO = "DATA DEBITO";
            public const string DE_DATA_CANCELAMENTO = "DATA CANCELAMENTO";
            public const string DE_MOTIVO = "MOTIVO";
            public const string DE_STATUS = "STATUS";
            public const string DE_PRODUTO = "PRODUTO";
            public const string DE_TIPO_PROTECAO = "TIPO PROTECAO";
            public const string DE_VLR_PREMIO = "VLR PREMIO";
            public const string DE_PONDERADOR = "PONDERADOR";
            public const string DE_NUM_CARTAO = "NUM_CARTAO";
            public const string DE_BANDEIRA = "BANDEIRA";
            public const string DE_DATA_VENDA = "DATA_VENDA";
            public const string DE_DATA_DESBLOQUEIO = "DATA_DESBLOQUEIO";
            public const string DE_TIPO_CARTAO = "TIPO_CARTAO";
            public const string DE_TITULAR_ADICIONAL = "TITULAR_ADICIONAL";
            public const string DE_ENTRADA = "ENTRADA";
            public const string DE_SAIDA = "SAÍDA";
            public const string DE_STATUS_GESTAO_DE_PATRIMÔNIO = "STATUS GESTÃO DE PATRIMÔNIO";
            public const string DE_DATA_GESTAO_DE_PATRIMÔNIO = "DATA GESTÃO DE PATRIMÔNIO";
            public const string DE_STATUS_ASSESSORIA_DEDICADA = "STATUS ASSESSORIA DEDICADA";
            public const string DE_DATA_ASSESSORIA_DEDICADA = "DATA ASSESSORIA DEDICADA";
            public const string DE_VALIDO_PARA_O_AGIR = "VÁLIDO PARA O AGIR";
            public const string DE_CONTRATO = "CONTRATO";
            public const string DE_VALOR = "VALOR";
            public const string DE_DIAS = "DIAS";
            public const string DE_REV_PDD_A_VISTA = "REV PDD A VISTA";
            public const string DE_REV_PDD_PARCELADO = "REV PDD PARCELADO";
            public const string DE_CONTRATO_RENEGOCIADO = "CONTRATO RENEGOCIADO";
            public const string DE_A_VISTA = "A VISTA";
            public const string DE_ORIGEM = "ORIGEM";
            public const string DE_MES_LIBERACAO_DA_CONTA = "MES_LIBERACAO_DA_CONTA";
            public const string DE_BIOMETRIA = "BIOMETRIA";
            public const string DE_SENHA = "SENHA";
            public const string DE_CARTAO = "CARTAO";
            public const string DE_CARTAO_PROVISORIO = "CARTAO_PROVISORIO";
            public const string DE_CEP_PLUS = "CEP_PLUS";
            public const string DE_CHAVES_VALIDAS = "CHAVES_VALIDAS";
            public const string DE_VOLUME_RECURSOS = "VOLUME_RECURSOS";
            public const string DE_CAP_M4 = "CAP_M-4";
            public const string DE_CAP_M3 = "CAP_M-3";
            public const string DE_CAP_M2 = "CAP_M-2";
            public const string DE_CAP_M1 = "CAP_M-1";
            public const string DE_CAP_M0 = "CAP_M-0";
            public const string DE_CAPLIQ_ACUMULADA = "CAPLIQ_ACUMULADA";
            public const string DE_SALDO_EM_CREDITO = "SALDO_EM_CREDITO";
            public const string DE_PREMIO_DE_PROTECOES = "PREMIO_DE_PROTECOES";
            public const string DE_CREDITO_IMOBILIARIO = "CREDITO_IMOBILIARIO";
            public const string DE_CANAL_CREDITO_IMOBILIARIO = "CANAL_CREDITO_IMOBILIARIO";
            public const string DE_CPF = "CPF";
            public const string DE_NUM_OPERACAO = "NUM OPERAÇÃO";
            public const string DE_DATA_CONTRATACAO = "DATA CONTRATAÇÃO";
            public const string DE_DATA_EMISSAO = "DATA EMISSÃO";
            public const string DE_DATA_LIQUIDACAO = "DATA LIQUIDAÇÃO";
            public const string DE_SEGURO_PRESTAMISTA = "SEGURO PRESTAMISTA";
            public const string DE_CONSIGNADO = "CONSIGNADO";
            public const string DE_COM_GARANTIA = "COM GARANTIA";
            public const string DE_VALOR_CONTRATACAO = "VALOR CONTRATAÇÃO";
            public const string DE_PONDERADOR_AGIR = "PONDERADOR AGIR";
            public const string DE_COD_PROP = "cod_prop";
            public const string DE_DATA_EMISSAO_1 = "DATA_EMISSAO";
            public const string DE_PAGAMENTO_1_PARCELA = "pagamento_1_parcela";
            public const string DE_MF_RECURSOS = "MF Recursos";
            public const string DE_MF_EMPRESTIMOS = "MF Empréstimos";
            public const string DE_MF_OPERACOES_EM_ATRASO = "MF Operações em Atraso";
            public const string DE_MF_CARTAO_DE_CREDITO = "MF Cartão de Crédito";
            public const string DE_MF_SERVICOS = "MF Serviços";
            public const string DE_MF_SEGUROS = "MF Seguros";
            public const string DE_SUBTOTAL_PRODUTO_BANCARIO = "Subtotal Produto Bancário";
            public const string DE_REM_FOLHA_DE_PAGAMENTO = "Rem. Folha de Pagamento";
            public const string DE_RES_CAPITAL_DE_GIRO = "Res. Capital de Giro";
            public const string DE_PISCOFINSISS = "PIS/COFINS/ISS";
            public const string DE_PB_TOTAL = "PB Total";
            public const string DE_PDD_ESPEC = "PDD Espec.";
            public const string DE_PB_SUBTOTAL_PDD_ESPEC = "PB Subtotal - PDD Espec.";
            public const string DE_COR = "COR";
            public const string DE_DT_ABERTURA_CONTA = "DT_ABERTURA_CONTA";
            public const string DE_DT_ENCERRAMENTO_CONTA = "DT_ENCERRAMENTO_CONTA";
            public const string DE_DT_ROLLOUT = "DT_ROLLOUT";
            public const string DE_QTD_CONTAS_PERSONNALITE = "QTD_CONTAS_PERSONNALITE";
            public const string DE_QTD_CONTAS_CONGLOMERADO = "QTD_CONTAS_CONGLOMERADO";
            public const string DE_VOLUME_INVESTIMENTO_GP33 = "VOLUME INVESTIMENTO GP33";
            public const string DE_VOLUME_INVESTIMENTO_TOMBADO = "VOLUME INVESTIMENTO TOMBADO";
            public const string DE_DATA_DE_ABERTURA = "DATA DE ABERTURA";
            public const string DE_DATA_DE_LIBERACAO = "DATA DE LIBERAÇÃO";
            public const string DE_DATA_DO_BLOQUEIO_T = "DATA DO BLOQUEIO T";
            public const string DE_DATA_DE_ENCERRAMENTO = "DATA DE ENCERRAMENTO";
            public const string DE_QTDE_DE_CONTAS_NO_PERSONNALITE = "QTDE DE CONTAS NO PERSONNALITÉ";
            public const string DE_QTDE_DE_CONTAS_NO_CONGLOMERADO = "QTDE DE CONTAS NO CONGLOMERADO";
            public const string DE_PRODUCAO_AGIR = "PRODUCAO_AGIR";

            #endregion

            #region [PARA] 
            public const string PARA_ID = "Id";
            public const string PARA_DATACRIACAO = "DataCriacao";
            public const string PARA_DATAATUALIZACAO = "DataAtualizacao";
            public const string PARA_DATAREFERENCIA = "DataReferencia";
            public const string PARA_DATA = "Data";
            public const string PARA_DATADEBITO = "DataDebito";
            public const string PARA_DESCRICAOPRODUTO = "DescricaoProduto";
            public const string PARA_CLIENTEAGENCIA = "ClienteAgencia";
            public const string PARA_CLIENTECONTA = "ClienteConta";
            public const string PARA_DESCRICAOCANAL = "DescricaoCanal";
            public const string PARA_NOMECOLABORADOR = "NomeColaborador";
            public const string PARA_VALORPRODUCAO = "ValorProducao";
            public const string PARA_VALORPONDERADO = "ValorPonderado";
            public const string PARA_VALORPRODUCAOPONDERADA = "ValorProducaoPonderada";
            public const string PARA_DESCRICAOSTATUS = "DescricaoStatus";
            public const string PARA_CARTEIRA = "Carteira";
            public const string PARA_CODIGOITEM = "CodigoItem";
            public const string PARA_IDAGENCIA = "IdAgencia";
            public const string PARA_IDCHECKOUT = "IdCheckout";
            public const string PARA_DATA_REF = "DATA_REF";
            public const string PARA_DICOM = "DICOM";
            public const string PARA_REGIAO = "REGIAO";
            public const string PARA_REGIONAL = "REGIONAL";
            public const string PARA_AGENCIA = "AGENCIA";
            public const string PARA_PLATAFORMA = "PLATAFORMA";
            public const string PARA_CONTA_DAC = "CONTA_DAC";
            public const string PARA_NOME_CLIENTE = "NOME_CLIENTE";
            public const string PARA_APOLICE = "APOLICE";
            public const string PARA_DATA_INICIO_VIGENCIA = "DATA_INICIO_VIGENCIA";
            public const string PARA_DATA_FIM_VIGENCIA = "DATA_FIM_VIGENCIA";
            public const string PARA_DATA_DEBITO = "DATA_DEBITO";
            public const string PARA_DATA_CANCELAMENTO = "DATA_CANCELAMENTO";
            public const string PARA_MOTIVO = "MOTIVO";
            public const string PARA_STATUS = "STATUS";
            public const string PARA_PRODUTO = "PRODUTO";
            public const string PARA_TIPO_PROTECAO = "TIPO_PROTECAO";
            public const string PARA_VLR_PREMIO = "VLR_PREMIO";
            public const string PARA_PONDERADOR = "PONDERADOR";
            public const string PARA_NUM_CARTAO = "NUM_CARTAO";
            public const string PARA_BANDEIRA = "BANDEIRA";
            public const string PARA_DATA_VENDA = "DATA_VENDA";
            public const string PARA_DATA_DESBLOQUEIO = "DATA_DESBLOQUEIO";
            public const string PARA_TIPO_CARTAO = "TIPO_CARTAO";
            public const string PARA_TITULAR_ADICIONAL = "TITULAR_ADICIONAL";
            public const string PARA_ENTRADA = "ENTRADA";
            public const string PARA_SAIDA = "SAIDA";
            public const string PARA_STATUS_GESTAO_DE_PATRIMÔNIO = "STATUS_GESTAO_DE_PATRIMÔNIO";
            public const string PARA_DATA_GESTAO_DE_PATRIMÔNIO = "DATA_GESTAO_DE_PATRIMÔNIO";
            public const string PARA_STATUS_ASSESSORIA_DEDICADA = "STATUS_ASSESSORIA_DEDICADA";
            public const string PARA_DATA_ASSESSORIA_DEDICADA = "DATA_ASSESSORIA_DEDICADA";
            public const string PARA_VALIDO_PARA_O_AGIR = "VALIDO_PARA_O_AGIR";
            public const string PARA_CONTRATO = "CONTRATO";
            public const string PARA_VALOR = "VALOR";
            public const string PARA_DIAS = "DIAS";
            public const string PARA_REV_PDD_A_VISTA = "REV_PDD_A_VISTA";
            public const string PARA_REV_PDD_PARCELADO = "REV_PDD_PARCELADO";
            public const string PARA_CONTRATO_RENEGOCIADO = "CONTRATO_RENEGOCIADO";
            public const string PARA_A_VISTA = "A_VISTA";
            public const string PARA_ORIGEM = "ORIGEM";
            public const string PARA_MES_LIBERACAO_DA_CONTA = "MES_LIBERACAO_DA_CONTA";
            public const string PARA_BIOMETRIA = "BIOMETRIA";
            public const string PARA_SENHA = "SENHA";
            public const string PARA_CARTAO = "CARTAO";
            public const string PARA_CARTAO_PROVISORIO = "CARTAO_PROVISORIO";
            public const string PARA_CEP_PLUS = "CEP_PLUS";
            public const string PARA_CHAVES_VALIDAS = "CHAVES_VALIDAS";
            public const string PARA_VOLUME_RECURSOS = "VOLUME_RECURSOS";
            public const string PARA_CAP_M4 = "CAP_M4";
            public const string PARA_CAP_M3 = "CAP_M3";
            public const string PARA_CAP_M2 = "CAP_M2";
            public const string PARA_CAP_M1 = "CAP_M1";
            public const string PARA_CAP_M0 = "CAP_M0";
            public const string PARA_CAPLIQ_ACUMULADA = "CAPLIQ_ACUMULADA";
            public const string PARA_SALDO_EM_CREDITO = "SALDO_EM_CREDITO";
            public const string PARA_PREMIO_DE_PROTECOES = "PREMIO_DE_PROTECOES";
            public const string PARA_CREDITO_IMOBILIARIO = "CREDITO_IMOBILIARIO";
            public const string PARA_CANAL_CREDITO_IMOBILIARIO = "CANAL_CREDITO_IMOBILIARIO";
            public const string PARA_CPF = "CPF";
            public const string PARA_NUM_OPERACAO = "NUM_OPERACAO";
            public const string PARA_DATA_CONTRATACAO = "DATA_CONTRATACAO";
            public const string PARA_DATA_LIQUIDACAO = "DATA_LIQUIDACAO";
            public const string PARA_SEGURO_PRESTAMISTA = "SEGURO_PRESTAMISTA";
            public const string PARA_CONSIGNADO = "CONSIGNADO";
            public const string PARA_COM_GARANTIA = "COM_GARANTIA";
            public const string PARA_VALOR_CONTRATACAO = "VALOR_CONTRATACAO";
            public const string PARA_PONDERADOR_AGIR = "PONDERADOR_AGIR";
            public const string PARA_COD_PROP = "COD_PROP";
            public const string PARA_DATA_EMISSAO = "DATA_EMISSAO";
            public const string PARA_PAGAMENTO_1_PARCELA = "PAGAMENTO_1_PARCELA";
            public const string PARA_MF_RECURSOS = "MF_RECURSOS";
            public const string PARA_MF_EMPRESTIMOS = "MF_EMPRESTIMOS";
            public const string PARA_MF_OPERACOES_EM_ATRASO = "MF_OPERACOES_EM_ATRASO";
            public const string PARA_MF_CARTAO_DE_CREDITO = "MF_CARTAO_DE_CREDITO";
            public const string PARA_MF_SERVICOS = "MF_SERVICOS";
            public const string PARA_MF_SEGUROS = "MF_SEGUROS";
            public const string PARA_SUBTOTAL_PRODUTO_BANCARIO = "SUBTOTAL_PRODUTO_BANCARIO";
            public const string PARA_REM_FOLHA_DE_PAGAMENTO = "REM_FOLHA_DE_PAGAMENTO";
            public const string PARA_RES_CAPITAL_DE_GIRO = "RES_CAPITAL_DE_GIRO";
            public const string PARA_PISCOFINSISS = "PISCOFINSISS";
            public const string PARA_PB_TOTAL = "PB_TOTAL";
            public const string PARA_PDD_ESPEC = "PDD_ESPEC";
            public const string PARA_PB_SUBTOTAL_PDD_ESPEC = "PB_SUBTOTAL_PDD_ESPEC";
            public const string PARA_COR = "COR";
            public const string PARA_DT_ABERTURA_CONTA = "DT_ABERTURA_CONTA";
            public const string PARA_DT_ENCERRAMENTO_CONTA = "DT_ENCERRAMENTO_CONTA";
            public const string PARA_DT_ROLLOUT = "DT_ROLLOUT";
            public const string PARA_QTD_CONTAS_PERSONNALITE = "QTD_CONTAS_PERSONNALITE";
            public const string PARA_QTD_CONTAS_CONGLOMERADO = "QTD_CONTAS_CONGLOMERADO";
            public const string PARA_VOLUME_INVESTIMENTO_GP33 = "VOLUME_INVESTIMENTO_GP33";
            public const string PARA_VOLUME_INVESTIMENTO_TOMBADO = "VOLUME_INVESTIMENTO_TOMBADO";
            public const string PARA_DATA_DE_ABERTURA = "DATA_DE_ABERTURA";
            public const string PARA_DATA_DE_LIBERACAO = "DATA_DE_LIBERACAO";
            public const string PARA_DATA_DO_BLOQUEIO_T = "DATA_DO_BLOQUEIO_T";
            public const string PARA_DATA_DE_ENCERRAMENTO = "DATA_DE_ENCERRAMENTO";
            public const string PARA_QTDE_DE_CONTAS_NO_PERSONNALITE = "QTDE_DE_CONTAS_NO_PERSONNALITE";
            public const string PARA_QTDE_DE_CONTAS_NO_CONGLOMERADO = "QTDE_DE_CONTAS_NO_CONGLOMERADO";
            public const string PARA_PRODUCAO_AGIR = "PRODUCAO_AGIR";
            #endregion

            public class DePara
            {
                public DePara(string de_, string para_)
                {
                    this.De = de_;
                    this.Para = para_;
                }
                public string De { get; private set; }
                public string Para { get; private set; }
            }

            public static List<DePara> ConfiguracaoDePara = new List<DePara>()
            {
                new DePara(DE_ID, PARA_ID),
                new DePara(DE_DATACRIACAO, PARA_DATACRIACAO),
                new DePara(DE_DATAATUALIZACAO, PARA_DATAATUALIZACAO),
                new DePara(DE_DATAREFERENCIA, PARA_DATAREFERENCIA),
                new DePara(DE_DATA, PARA_DATA),
                new DePara(DE_DATADEBITO, PARA_DATADEBITO),
                new DePara(DE_DESCRICAOPRODUTO, PARA_DESCRICAOPRODUTO),
                new DePara(DE_CLIENTEAGENCIA, PARA_CLIENTEAGENCIA),
                new DePara(DE_CLIENTECONTA, PARA_CLIENTECONTA),
                new DePara(DE_DESCRICAOCANAL, PARA_DESCRICAOCANAL),
                new DePara(DE_NOMECOLABORADOR, PARA_NOMECOLABORADOR),
                new DePara(DE_VALORPRODUCAO, PARA_VALORPRODUCAO),
                new DePara(DE_VALORPONDERADO, PARA_VALORPONDERADO),
                new DePara(DE_VALORPRODUCAOPONDERADA, PARA_VALORPRODUCAOPONDERADA),
                new DePara(DE_DESCRICAOSTATUS, PARA_DESCRICAOSTATUS),
                new DePara(DE_CARTEIRA, PARA_CARTEIRA),
                new DePara(DE_CODIGOITEM, PARA_CODIGOITEM),
                new DePara(DE_IDAGENCIA, PARA_IDAGENCIA),
                new DePara(DE_IDCHECKOUT, PARA_IDCHECKOUT),
                new DePara(DE_DATA_REF, PARA_DATA_REF),
                new DePara(DE_DICOM, PARA_DICOM),
                new DePara(DE_REGIAO, PARA_REGIAO),
                new DePara(DE_REGIONAL, PARA_REGIONAL),
                new DePara(DE_AGENCIA, PARA_AGENCIA),
                new DePara(DE_PLATAFORMA, PARA_PLATAFORMA),
                new DePara(DE_CONTA_DAC, PARA_CONTA_DAC),
                new DePara(DE_NOME_CLIENTE, PARA_NOME_CLIENTE),
                new DePara(DE_APOLICE, PARA_APOLICE),
                new DePara(DE_DATA_INICIO_VIGENCIA, PARA_DATA_INICIO_VIGENCIA),
                new DePara(DE_DATA_FIM_VIGENCIA, PARA_DATA_FIM_VIGENCIA),
                new DePara(DE_DATA_DEBITO, PARA_DATA_DEBITO),
                new DePara(DE_DATA_CANCELAMENTO, PARA_DATA_CANCELAMENTO),
                new DePara(DE_MOTIVO, PARA_MOTIVO),
                new DePara(DE_STATUS, PARA_STATUS),
                new DePara(DE_PRODUTO, PARA_PRODUTO),
                new DePara(DE_TIPO_PROTECAO, PARA_TIPO_PROTECAO),
                new DePara(DE_VLR_PREMIO, PARA_VLR_PREMIO),
                new DePara(DE_PONDERADOR, PARA_PONDERADOR),
                new DePara(DE_NUM_CARTAO, PARA_NUM_CARTAO),
                new DePara(DE_BANDEIRA, PARA_BANDEIRA),
                new DePara(DE_DATA_VENDA, PARA_DATA_VENDA),
                new DePara(DE_DATA_DESBLOQUEIO, PARA_DATA_DESBLOQUEIO),
                new DePara(DE_TIPO_CARTAO, PARA_TIPO_CARTAO),
                new DePara(DE_TITULAR_ADICIONAL, PARA_TITULAR_ADICIONAL),
                new DePara(DE_ENTRADA, PARA_ENTRADA),
                new DePara(DE_SAIDA, PARA_SAIDA),
                new DePara(DE_STATUS_GESTAO_DE_PATRIMÔNIO, PARA_STATUS_GESTAO_DE_PATRIMÔNIO),
                new DePara(DE_DATA_GESTAO_DE_PATRIMÔNIO, PARA_DATA_GESTAO_DE_PATRIMÔNIO),
                new DePara(DE_STATUS_ASSESSORIA_DEDICADA, PARA_STATUS_ASSESSORIA_DEDICADA),
                new DePara(DE_DATA_ASSESSORIA_DEDICADA, PARA_DATA_ASSESSORIA_DEDICADA),
                new DePara(DE_VALIDO_PARA_O_AGIR, PARA_VALIDO_PARA_O_AGIR),
                new DePara(DE_CONTRATO, PARA_CONTRATO),
                new DePara(DE_VALOR, PARA_VALOR),
                new DePara(DE_DIAS, PARA_DIAS),
                new DePara(DE_REV_PDD_A_VISTA, PARA_REV_PDD_A_VISTA),
                new DePara(DE_REV_PDD_PARCELADO, PARA_REV_PDD_PARCELADO),
                new DePara(DE_CONTRATO_RENEGOCIADO, PARA_CONTRATO_RENEGOCIADO),
                new DePara(DE_A_VISTA, PARA_A_VISTA),
                new DePara(DE_ORIGEM, PARA_ORIGEM),
                new DePara(DE_MES_LIBERACAO_DA_CONTA, PARA_MES_LIBERACAO_DA_CONTA),
                new DePara(DE_BIOMETRIA, PARA_BIOMETRIA),
                new DePara(DE_SENHA, PARA_SENHA),
                new DePara(DE_CARTAO, PARA_CARTAO),
                new DePara(DE_CARTAO_PROVISORIO, PARA_CARTAO_PROVISORIO),
                new DePara(DE_CEP_PLUS, PARA_CEP_PLUS),
                new DePara(DE_CHAVES_VALIDAS, PARA_CHAVES_VALIDAS),
                new DePara(DE_VOLUME_RECURSOS, PARA_VOLUME_RECURSOS),
                new DePara(DE_CAP_M4, PARA_CAP_M4),
                new DePara(DE_CAP_M3, PARA_CAP_M3),
                new DePara(DE_CAP_M2, PARA_CAP_M2),
                new DePara(DE_CAP_M1, PARA_CAP_M1),
                new DePara(DE_CAP_M0, PARA_CAP_M0),
                new DePara(DE_CAPLIQ_ACUMULADA, PARA_CAPLIQ_ACUMULADA),
                new DePara(DE_SALDO_EM_CREDITO, PARA_SALDO_EM_CREDITO),
                new DePara(DE_PREMIO_DE_PROTECOES, PARA_PREMIO_DE_PROTECOES),
                new DePara(DE_CREDITO_IMOBILIARIO, PARA_CREDITO_IMOBILIARIO),
                new DePara(DE_CANAL_CREDITO_IMOBILIARIO, PARA_CANAL_CREDITO_IMOBILIARIO),
                new DePara(DE_CPF, PARA_CPF),
                new DePara(DE_NUM_OPERACAO, PARA_NUM_OPERACAO),
                new DePara(DE_DATA_CONTRATACAO, PARA_DATA_CONTRATACAO),
                new DePara(DE_DATA_EMISSAO_1, PARA_DATA_EMISSAO),
                new DePara(DE_DATA_LIQUIDACAO, PARA_DATA_LIQUIDACAO),
                new DePara(DE_SEGURO_PRESTAMISTA, PARA_SEGURO_PRESTAMISTA),
                new DePara(DE_CONSIGNADO, PARA_CONSIGNADO),
                new DePara(DE_COM_GARANTIA, PARA_COM_GARANTIA),
                new DePara(DE_VALOR_CONTRATACAO, PARA_VALOR_CONTRATACAO),
                new DePara(DE_PONDERADOR_AGIR, PARA_PONDERADOR_AGIR),
                new DePara(DE_COD_PROP, PARA_COD_PROP),
                new DePara(DE_DATA_EMISSAO, PARA_DATA_EMISSAO),
                new DePara(DE_PAGAMENTO_1_PARCELA, PARA_PAGAMENTO_1_PARCELA),
                new DePara(DE_MF_RECURSOS, PARA_MF_RECURSOS),
                new DePara(DE_MF_EMPRESTIMOS, PARA_MF_EMPRESTIMOS),
                new DePara(DE_MF_OPERACOES_EM_ATRASO, PARA_MF_OPERACOES_EM_ATRASO),
                new DePara(DE_MF_CARTAO_DE_CREDITO, PARA_MF_CARTAO_DE_CREDITO),
                new DePara(DE_MF_SERVICOS, PARA_MF_SERVICOS),
                new DePara(DE_MF_SEGUROS, PARA_MF_SEGUROS),
                new DePara(DE_SUBTOTAL_PRODUTO_BANCARIO, PARA_SUBTOTAL_PRODUTO_BANCARIO),
                new DePara(DE_REM_FOLHA_DE_PAGAMENTO, PARA_REM_FOLHA_DE_PAGAMENTO),
                new DePara(DE_RES_CAPITAL_DE_GIRO, PARA_RES_CAPITAL_DE_GIRO),
                new DePara(DE_PISCOFINSISS, PARA_PISCOFINSISS),
                new DePara(DE_PB_TOTAL, PARA_PB_TOTAL),
                new DePara(DE_PDD_ESPEC, PARA_PDD_ESPEC),
                new DePara(DE_PB_SUBTOTAL_PDD_ESPEC, PARA_PB_SUBTOTAL_PDD_ESPEC),
                new DePara(DE_COR, PARA_COR),
                new DePara(DE_DT_ABERTURA_CONTA, PARA_DT_ABERTURA_CONTA),
                new DePara(DE_DT_ENCERRAMENTO_CONTA, PARA_DT_ENCERRAMENTO_CONTA),
                new DePara(DE_DT_ROLLOUT, PARA_DT_ROLLOUT),
                new DePara(DE_QTD_CONTAS_PERSONNALITE, PARA_QTD_CONTAS_PERSONNALITE),
                new DePara(DE_QTD_CONTAS_CONGLOMERADO, PARA_QTD_CONTAS_CONGLOMERADO),
                new DePara(DE_VOLUME_INVESTIMENTO_GP33, PARA_VOLUME_INVESTIMENTO_GP33),
                new DePara(DE_VOLUME_INVESTIMENTO_TOMBADO, PARA_VOLUME_INVESTIMENTO_TOMBADO),
                new DePara(DE_DATA_DE_ABERTURA, PARA_DATA_DE_ABERTURA),
                new DePara(DE_DATA_DE_LIBERACAO, PARA_DATA_DE_LIBERACAO),
                new DePara(DE_DATA_DO_BLOQUEIO_T, PARA_DATA_DO_BLOQUEIO_T),
                new DePara(DE_DATA_DE_ENCERRAMENTO, PARA_DATA_DE_ENCERRAMENTO),
                new DePara(DE_QTDE_DE_CONTAS_NO_PERSONNALITE, PARA_QTDE_DE_CONTAS_NO_PERSONNALITE),
                new DePara(DE_QTDE_DE_CONTAS_NO_CONGLOMERADO, PARA_QTDE_DE_CONTAS_NO_CONGLOMERADO),
                new DePara(DE_PRODUCAO_AGIR, PARA_PRODUCAO_AGIR)
            };

        }

        public static ProducaoRealizadaAnaliticoPersonnalite ConverterParaModel(int linha, DataRow registro)
        {
            try
            {
                return new ProducaoRealizadaAnaliticoPersonnalite()
                {
                    DataAtualizacao = DateTime.Now,
                    DataCriacao = DateTime.Now,
                    DataReferencia = DateTimeExtension.TryParse(registro[Colunas.PARA_DATAREFERENCIA].ToString()),
                    Data = DateTimeExtension.TryParse(registro[Colunas.PARA_DATA].ToString()),
                    DataDebito = DateTimeExtension.TryParse(registro[Colunas.PARA_DATADEBITO].ToString()),
                    DescricaoProduto = registro[Colunas.PARA_DESCRICAOPRODUTO].ToString(),
                    ClienteAgencia = registro[Colunas.PARA_CLIENTEAGENCIA].ToString(),
                    ClienteConta = registro[Colunas.PARA_CLIENTECONTA].ToString(),
                    DescricaoCanal = registro[Colunas.PARA_DESCRICAOCANAL].ToString(),
                    NomeColaborador = registro[Colunas.PARA_NOMECOLABORADOR].ToString(),
                    ValorProducao = string.IsNullOrWhiteSpace(registro[Colunas.PARA_VALORPRODUCAO].ToString()) ? -1 : DecimalExtension.TryParse(registro[Colunas.PARA_VALORPRODUCAO].ToString().Replace(',', '.')) ,
                    ValorPonderado = DecimalExtension.TryParse(registro[Colunas.PARA_VALORPONDERADO].ToString().Replace(',', '.')),
                    ValorProducaoPonderada = string.IsNullOrWhiteSpace(registro[Colunas.PARA_VALORPRODUCAOPONDERADA].ToString()) ? -1 : DecimalExtension.TryParse(registro[Colunas.PARA_VALORPRODUCAOPONDERADA].ToString().Replace(',', '.')) ,
                    DescricaoStatus = registro[Colunas.PARA_DESCRICAOSTATUS].ToString(),
                    Carteira = registro[Colunas.PARA_CARTEIRA].ToString(),
                    CodigoItem = IntExtension.TryParse(registro[Colunas.PARA_CODIGOITEM].ToString()),
                    IdAgencia = IntExtension.TryParse(registro[Colunas.PARA_IDAGENCIA].ToString()),
                    IdCheckout = IntExtension.TryParse(registro[Colunas.PARA_IDCHECKOUT].ToString()),
                    AgenciaContaDac = (registro[Colunas.PARA_AGENCIA].ToString() + registro[Colunas.PARA_CONTA_DAC].ToString().Replace("-","")).PadLeft(10,'0'),

                    DATA_REF = registro[Colunas.PARA_DATA_REF].ToString(),
                    DICOM = registro[Colunas.PARA_DICOM].ToString(),
                    REGIAO = registro[Colunas.PARA_REGIAO].ToString(),
                    REGIONAL = registro[Colunas.PARA_REGIONAL].ToString(),
                    AGENCIA = registro[Colunas.PARA_AGENCIA].ToString(),
                    PLATAFORMA = registro[Colunas.PARA_PLATAFORMA].ToString(),
                    CONTA_DAC = registro[Colunas.PARA_CONTA_DAC].ToString(),
                    NOME_CLIENTE = registro[Colunas.PARA_NOME_CLIENTE].ToString(),
                    APOLICE = registro[Colunas.PARA_APOLICE].ToString(),
                    DATA_INICIO_VIGENCIA = registro[Colunas.PARA_DATA_INICIO_VIGENCIA].ToString(),
                    DATA_FIM_VIGENCIA = registro[Colunas.PARA_DATA_FIM_VIGENCIA].ToString(),
                    DATA_DEBITO = registro[Colunas.PARA_DATA_DEBITO].ToString(),
                    DATA_CANCELAMENTO = registro[Colunas.PARA_DATA_CANCELAMENTO].ToString(),
                    MOTIVO = registro[Colunas.PARA_MOTIVO].ToString(),
                    STATUS = registro[Colunas.PARA_STATUS].ToString(),
                    PRODUTO = registro[Colunas.PARA_PRODUTO].ToString(),
                    TIPO_PROTECAO = registro[Colunas.PARA_TIPO_PROTECAO].ToString(),
                    VLR_PREMIO = registro[Colunas.PARA_VLR_PREMIO].ToString(),
                    PONDERADOR = registro[Colunas.PARA_PONDERADOR].ToString(),
                    NUM_CARTAO = registro[Colunas.PARA_NUM_CARTAO].ToString(),
                    BANDEIRA = registro[Colunas.PARA_BANDEIRA].ToString(),
                    DATA_VENDA = registro[Colunas.PARA_DATA_VENDA].ToString(),
                    DATA_DESBLOQUEIO = registro[Colunas.PARA_DATA_DESBLOQUEIO].ToString(),
                    TIPO_CARTAO = registro[Colunas.PARA_TIPO_CARTAO].ToString(),
                    TITULAR_ADICIONAL = registro[Colunas.PARA_TITULAR_ADICIONAL].ToString(),
                    ENTRADA = registro[Colunas.PARA_ENTRADA].ToString(),
                    SAIDA = registro[Colunas.PARA_SAIDA].ToString(),
                    STATUS_GESTAO_DE_PATRIMÔNIO = registro[Colunas.PARA_STATUS_GESTAO_DE_PATRIMÔNIO].ToString(),
                    DATA_GESTAO_DE_PATRIMÔNIO = registro[Colunas.PARA_DATA_GESTAO_DE_PATRIMÔNIO].ToString(),
                    STATUS_ASSESSORIA_DEDICADA = registro[Colunas.PARA_STATUS_ASSESSORIA_DEDICADA].ToString(),
                    DATA_ASSESSORIA_DEDICADA = registro[Colunas.PARA_DATA_ASSESSORIA_DEDICADA].ToString(),
                    VALIDO_PARA_O_AGIR = registro[Colunas.PARA_VALIDO_PARA_O_AGIR].ToString(),
                    CONTRATO = registro[Colunas.PARA_CONTRATO].ToString(),
                    VALOR = registro[Colunas.PARA_VALOR].ToString(),
                    DIAS = registro[Colunas.PARA_DIAS].ToString(),
                    REV_PDD_A_VISTA = registro[Colunas.PARA_REV_PDD_A_VISTA].ToString(),
                    REV_PDD_PARCELADO = registro[Colunas.PARA_REV_PDD_PARCELADO].ToString(),
                    CONTRATO_RENEGOCIADO = registro[Colunas.PARA_CONTRATO_RENEGOCIADO].ToString(),
                    A_VISTA = registro[Colunas.PARA_A_VISTA].ToString(),
                    ORIGEM = registro[Colunas.PARA_ORIGEM].ToString(),
                    MES_LIBERACAO_DA_CONTA = registro[Colunas.PARA_MES_LIBERACAO_DA_CONTA].ToString(),
                    BIOMETRIA = registro[Colunas.PARA_BIOMETRIA].ToString(),
                    SENHA = registro[Colunas.PARA_SENHA].ToString(),
                    CARTAO = registro[Colunas.PARA_CARTAO].ToString(),
                    CARTAO_PROVISORIO = registro[Colunas.PARA_CARTAO_PROVISORIO].ToString(),
                    CEP_PLUS = registro[Colunas.PARA_CEP_PLUS].ToString(),
                    CHAVES_VALIDAS = registro[Colunas.PARA_CHAVES_VALIDAS].ToString(),
                    VOLUME_RECURSOS = registro[Colunas.PARA_VOLUME_RECURSOS].ToString(),
                    CAP_M4 = registro[Colunas.PARA_CAP_M4].ToString(),
                    CAP_M3 = registro[Colunas.PARA_CAP_M3].ToString(),
                    CAP_M2 = registro[Colunas.PARA_CAP_M2].ToString(),
                    CAP_M1 = registro[Colunas.PARA_CAP_M1].ToString(),
                    CAP_M0 = registro[Colunas.PARA_CAP_M0].ToString(),
                    CAPLIQ_ACUMULADA = registro[Colunas.PARA_CAPLIQ_ACUMULADA].ToString(),
                    SALDO_EM_CREDITO = registro[Colunas.PARA_SALDO_EM_CREDITO].ToString(),
                    PREMIO_DE_PROTECOES = registro[Colunas.PARA_PREMIO_DE_PROTECOES].ToString(),
                    CREDITO_IMOBILIARIO = registro[Colunas.PARA_CREDITO_IMOBILIARIO].ToString(),
                    CANAL_CREDITO_IMOBILIARIO = registro[Colunas.PARA_CANAL_CREDITO_IMOBILIARIO].ToString(),
                    CPF = registro[Colunas.PARA_CPF].ToString(),
                    NUM_OPERACAO = registro[Colunas.PARA_NUM_OPERACAO].ToString(),
                    DATA_CONTRATACAO = registro[Colunas.PARA_DATA_CONTRATACAO].ToString(),
                    DATA_EMISSAO = registro[Colunas.PARA_DATA_EMISSAO].ToString(),
                    DATA_LIQUIDACAO = registro[Colunas.PARA_DATA_LIQUIDACAO].ToString(),
                    SEGURO_PRESTAMISTA = registro[Colunas.PARA_SEGURO_PRESTAMISTA].ToString(),
                    CONSIGNADO = registro[Colunas.PARA_CONSIGNADO].ToString(),
                    COM_GARANTIA = registro[Colunas.PARA_COM_GARANTIA].ToString(),
                    VALOR_CONTRATACAO = registro[Colunas.PARA_VALOR_CONTRATACAO].ToString(),
                    PONDERADOR_AGIR = registro[Colunas.PARA_PONDERADOR_AGIR].ToString(),
                    COD_PROP = registro[Colunas.PARA_COD_PROP].ToString(),
                    PAGAMENTO_1_PARCELA = registro[Colunas.PARA_PAGAMENTO_1_PARCELA].ToString(),
                    MF_RECURSOS = registro[Colunas.PARA_MF_RECURSOS].ToString(),
                    MF_EMPRESTIMOS = registro[Colunas.PARA_MF_EMPRESTIMOS].ToString(),
                    MF_OPERACOES_EM_ATRASO = registro[Colunas.PARA_MF_OPERACOES_EM_ATRASO].ToString(),
                    MF_CARTAO_DE_CREDITO = registro[Colunas.PARA_MF_CARTAO_DE_CREDITO].ToString(),
                    MF_SERVICOS = registro[Colunas.PARA_MF_SERVICOS].ToString(),
                    MF_SEGUROS = registro[Colunas.PARA_MF_SEGUROS].ToString(),
                    SUBTOTAL_PRODUTO_BANCARIO = registro[Colunas.PARA_SUBTOTAL_PRODUTO_BANCARIO].ToString(),
                    REM_FOLHA_DE_PAGAMENTO = registro[Colunas.PARA_REM_FOLHA_DE_PAGAMENTO].ToString(),
                    RES_CAPITAL_DE_GIRO = registro[Colunas.PARA_RES_CAPITAL_DE_GIRO].ToString(),
                    PISCOFINSISS = registro[Colunas.PARA_PISCOFINSISS].ToString(),
                    PB_TOTAL = registro[Colunas.PARA_PB_TOTAL].ToString(),
                    PDD_ESPEC = registro[Colunas.PARA_PDD_ESPEC].ToString(),
                    PB_SUBTOTAL_PDD_ESPEC = registro[Colunas.PARA_PB_SUBTOTAL_PDD_ESPEC].ToString(),
                    COR = registro[Colunas.PARA_COR].ToString(),
                    DT_ABERTURA_CONTA = registro[Colunas.PARA_DT_ABERTURA_CONTA].ToString(),
                    DT_ENCERRAMENTO_CONTA = registro[Colunas.PARA_DT_ENCERRAMENTO_CONTA].ToString(),
                    DT_ROLLOUT = registro[Colunas.PARA_DT_ROLLOUT].ToString(),
                    QTD_CONTAS_PERSONNALITE = registro[Colunas.PARA_QTD_CONTAS_PERSONNALITE].ToString(),
                    QTD_CONTAS_CONGLOMERADO = registro[Colunas.PARA_QTD_CONTAS_CONGLOMERADO].ToString(),
                    VOLUME_INVESTIMENTO_GP33 = registro[Colunas.PARA_VOLUME_INVESTIMENTO_GP33].ToString(),
                    VOLUME_INVESTIMENTO_TOMBADO = registro[Colunas.PARA_VOLUME_INVESTIMENTO_TOMBADO].ToString(),
                    DATA_DE_ABERTURA = registro[Colunas.PARA_DATA_DE_ABERTURA].ToString(),
                    DATA_DE_LIBERACAO = registro[Colunas.PARA_DATA_DE_LIBERACAO].ToString(),
                    DATA_DO_BLOQUEIO_T = registro[Colunas.PARA_DATA_DO_BLOQUEIO_T].ToString(),
                    DATA_DE_ENCERRAMENTO = registro[Colunas.PARA_DATA_DE_ENCERRAMENTO].ToString(),
                    QTDE_DE_CONTAS_NO_PERSONNALITE = registro[Colunas.PARA_QTDE_DE_CONTAS_NO_PERSONNALITE].ToString(),
                    QTDE_DE_CONTAS_NO_CONGLOMERADO = registro[Colunas.PARA_QTDE_DE_CONTAS_NO_CONGLOMERADO].ToString(),
                    PRODUCAO_AGIR = registro[Colunas.PARA_PRODUCAO_AGIR].ToString(),

                    Linha = linha
                };
            }
            catch
            {
                return null;
            }
        }

        public static List<ProducaoRealizadaAnaliticoPersonnalite> ConverterParaModel(DataTable tb, List<int> linhas)
        {
            var result = new List<ProducaoRealizadaAnaliticoPersonnalite>();
            
            for (var x = 0; x < linhas.Count; x++)
            {
                var model = ConverterParaModel(x, tb.Rows[linhas[x]-2]);

                if (model != null)
                    result.Add(model);
            }

            return result;
        }
    }

}
