﻿using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public abstract class ObjetoModelo
    {
        public int Id { get; set; }

        [NotMapped]
        public int Linha { get; set; }

        protected static T ConverterParaModel<T>(DataRow registro, out List<string> colunasErros)
        {
            T model = Activator.CreateInstance<T>();

            colunasErros = new List<string>();
            foreach (DataColumn item in registro.Table.Columns)
            {
                try
                {
                    var prop = model.GetType().GetProperty(item.ExtendedProperties[Services.ReclamacoesPersonnaliteServices.CONST_COLUNA_PARA].ToString());
                    var valor = Convert.ChangeType(registro[item.ColumnName], prop.PropertyType);
                    prop.SetValue(model, valor);
                }
                catch (Exception ex)
                {
                    colunasErros.Add(item.ColumnName);
                }
            }

            return (T)model;
        }

        protected static int ObterSegmentoId(string sigla)
        {
            if (sigla == "IP")
            {
                return Segmentos.Personnalite.GetHashCode();
            }
            throw new Exception();
        }

        protected static int ObterIdAgencia(List<Agencia> agencias, string codigo)
        {
            var resultado = agencias.Where(s => s.Codigo == codigo);
            if (resultado.Count() == 0)
                throw new Exception("Agência não encontrada: " + codigo);

            return resultado.FirstOrDefault().Id;
        }
    }
}