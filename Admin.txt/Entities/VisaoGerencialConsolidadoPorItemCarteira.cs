﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    /// <summary>
    /// Entidade utilizada para enviar e recuperar valores da tabela VisaoGerencialAgirConsolidadoPorItemCarteira por segmento.
    /// </summary>
    public class VisaoGerencialAgirConsolidadoPorItemCarteira
    {
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public int Id { get; set; }
        public int Dia { get; set; }
        public int Mes { get; set; }
        public int Ano { get; set; }
        public int CodigoItem { get; set; }
        public string NomeItem { get; set; }
        public int DiCom { get; set; }
        public string FuncDICOM { get; set; }
        public int Regiao { get; set; }
        public string FuncSUPT { get; set; }
        public int Regional { get; set; }
        public string FuncGRA { get; set; }
        public int Agencia { get; set; }
        public string Carteira { get; set; }
        public decimal PlanejamentoMensal { get; set; }
        public decimal Meta { get; set; }
        public decimal ProducaoInformada { get; set; }
        public decimal ICMInformado { get; set; }
        public decimal PontosAgir { get; set; }
        public decimal Evolucao { get; set; }
        public int IdSegmento { get; set; }
        public string FuncionalResponsavel { get; set; }
        public string AbreviacaoCargo { get; set; }
    }
}
