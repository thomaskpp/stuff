﻿using System.Net;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class RespostaPadraoAPI<T>
    {
        public T Dados { get; set; }
        public int StatusCodigo { get; set; }
        public string StatusDescricao { get; set; }

        public RespostaPadraoAPI()
        {
            StatusCodigo = (int)HttpStatusCode.OK;
            StatusDescricao = HttpStatusCode.OK.ToString();
        }

        public RespostaPadraoAPI(T dados)
        {
            Dados = dados;
            StatusCodigo = (int)HttpStatusCode.OK;
            StatusDescricao = HttpStatusCode.OK.ToString();
        }

        public RespostaPadraoAPI(T dados, HttpStatusCode statusCodigo, string statusDescricao)
        {
            Dados = dados;
            StatusCodigo = (int)statusCodigo;
            StatusDescricao = statusDescricao;
        }
    }
}
