﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoPlanejamentoPolo : VisaoPlanejamento
    {
        public VisaoPlanejamentoPolo() : base()
        {
        }

        public VisaoPlanejamentoPolo(int id, int codigoPolo, string nome, string segmento, int carteiras, int carteirasPlanejadas) 
            : base(segmento, carteiras, carteirasPlanejadas)
        {
            Id = id;
            CodigoPolo = codigoPolo;
            Nome = nome;
        }

        public int Id { get; set; }
        public int CodigoPolo { get; set; }
        public string Nome { get; set; }
    }
}
