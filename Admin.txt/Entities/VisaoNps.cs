﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoNps
    {
        public string VisaoNPS { get; set; }
        public int IdPolo { get; set; }
        public decimal ValorNPS { get; set; }
        public DateTime DataAtualizacao { get; set; }
    }
}
