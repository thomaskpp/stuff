﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopResposta : ModelBase
    {
        public int IdReposta { get; set; }
        public int IdLigacao { get; set; }
        public int IdPergunta { get; set; }
        public int? IdPerguntaPai { get; set; }
        public string Descricao { get; set; }
        public bool? Tipo { get; set; }
        public string Relatorio { get; set; }

        public InnerLoopLigacao InnerLoopLigacaoNavigation { get; set; }
        public InnerLoopPergunta InnerLoopPerguntaPaiNavigation { get; set; }
    }
}