﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ColaboradorDto
    {
        public int Id { get; set; }

        public string Funcional { get; set; }

        public string Nome { get; set; }

        public int? IdCargo { get; set; }

        public int IdColaboradorGestorDireto { get; set; }

        public IEnumerable<ColaboradorAgir> ColaboradorAgir { get; set; }
    }
}
