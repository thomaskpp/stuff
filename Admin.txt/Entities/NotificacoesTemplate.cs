﻿using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    /// <summary>
    /// Representa a entidade de templates para as notificações.
    /// </summary>
    public class NotificacoesTemplate
    {
        /// <summary>
        /// Código interno do template
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Nome do template
        /// </summary>
        public string Nome { get; set; }

        /// <summary>
        /// Conteúdo (html) do template
        /// </summary>
        public string Html { get; set; }

        /// <summary>
        /// Quantidade de campos variáveis no template
        /// </summary>
        public int QuantidadeCampoVariavel { get; set; }

        /// <summary>
        /// Data da Criação
        /// </summary>
        public DateTime DataCriacao { get; set; }

        /// <summary>
        /// Data de atualização
        /// </summary>
        public DateTime? DataAtualizacao { get; set; }

        /// <summary>
        /// Lista de notificações associadas ao template
        /// </summary>
        public ICollection<Notificacoes> Notificacoes { get; set; }
    }
}
