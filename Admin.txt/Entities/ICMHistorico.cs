﻿
using Itau.SZ7.GPS.Admin.Extensions;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ICMHistorico
    {
        public string Carteira { get; set; }
        public int CodigoItem { get; set; }
        public decimal ICM_Historico { get; set; }

        public short? Mes { get; set; }
        public short? Ano { get; set; }

        public static ICMHistorico ConverteColunas(int linha, string colunas, short? mes, short? ano)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                return new ICMHistorico()
                {
                    Carteira = arrayColunas[0],
                    CodigoItem = IntExtension.TryParse(arrayColunas[1]),
                    ICM_Historico = DecimalExtension.TryParse(arrayColunas[2]),
                    Mes = mes,
                    Ano = ano,
                };
            }
            catch
            {
                return null;
            }
        }
        public static List<ICMHistorico> ConverteColunas(List<int> linhas, List<string> colunas, short? mes, short? ano)
        {
            var result = new List<ICMHistorico>();

            
                for (int x = 0; x < linhas.Count; x++)
                {
                    var model = ConverteColunas(linhas[x], colunas[x], mes, ano);
                    if (model != null)
                        result.Add(model);
                }
            return result;
        }

    }
}
