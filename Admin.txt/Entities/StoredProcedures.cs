﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.VendaAtiva.Data
{
    public static class StoredProcedures
    {
        public static string GetOfertasCliente = "VendaAtiva_Consultar_OfertasCliente";

        public static string GetOfertasReagendadas = "VendaAtiva_Consultar_OfertasReagendadas";

        public static string GetClienteEmail = "VendaAtiva_Consultar_ClienteEmail";

        public static string GetClienteTelefone = "VendaAtiva_Consultar_ClienteTelefone";

        public static string GetCarteirasAndSegmento = "VendaAtiva_Consultar_CarteirasSegmentos";

        public static string PossuiGRAtuandoOfertas = "VendaAtiva_Consultar_PossuiGRAtuandoOfertas";

        public static string PossuiGGAtuandoOfertas = "VendaAtiva_Consultar_PossuiGGAtuandoOfertas";
    }
}
