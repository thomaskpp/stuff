﻿using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class GerenciadorCargaGridConfiguracoes
    {
        public Cargas IdCarga { get; set; }
        public string Nome { get; set; }
        public string NomeResponsavel { get; set; }
        public CargasTipoPeriodo TipoPeriodo { get; set; }
        public bool Ocultar { get; set; }
        public bool TravaSimultanea { get; set; }
        public int IdFuncionalidade { get; set; }

    }
}
