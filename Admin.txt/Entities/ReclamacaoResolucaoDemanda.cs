﻿using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ReclamacaoResolucaoDemanda : ObjetoModelo
    {
        public int IdSegmento { get; set; }
        public byte Mes { get; set; }
        public short Ano { get; set; }
        public string Destino { get; set; }
        public string Tipo { get; set; }
        public decimal IndiceTotal { get; set; }
        public decimal IndiceAtendimento { get; set; }
        public decimal IndiceAgir { get; set; }


        internal static List<ReclamacaoResolucaoDemanda> ConverterParaModel(GerenciadorCarga gerenciador, DataTable tb, List<int> linhas)
        {
            var result = new List<ReclamacaoResolucaoDemanda>();

            foreach (int linha in linhas)
            {
                var model = ConverterParaModel(gerenciador, linha - 2, tb.Rows[linha - 2]);

                if (model != null)
                    result.Add(model);
            }

            return result;
        }

        public static ReclamacaoResolucaoDemanda ConverterParaModel(GerenciadorCarga gerenciador, int linha, DataRow registro)
        {
            List<string> colunasNaoPreenchidas;
            var model = ConverterParaModel<ReclamacaoResolucaoDemanda>(registro, out colunasNaoPreenchidas);

            string dataString = registro["MES"].ToString();

            DateTime dataConvertida = DateTime.Parse(dataString);

            model.Mes = (byte)gerenciador.Mes;

            model.Ano = gerenciador.Ano;

            model.IdSegmento = ObterSegmentoId(registro["SEGMENTO"].ToString());

            model.Linha = linha;

            return model;            
        }
    }
}
