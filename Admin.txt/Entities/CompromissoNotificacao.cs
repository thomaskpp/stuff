﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class CompromissoNotificacao
    {
        public int IdCompromissoColaborador { get; set; }
        public DateTime DataNoticacao { get; set; }

        public CompromissoColaborador CompromissoColaboradorNavigation { get; set; }
    }
}