﻿using Itau.SZ7.GPS.Admin.Enums;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VendaAtivaClientesEmail : ModelBase
    {
        public long NumeroCPFCNPJ { get; set; }
        public string Email { get; set; }
        public AvaliacaoEmail? CodigoAvaliacaoEmail { get; set; }
        public int? OrdemExibicao { get; set; }

        public VendaAtivaClientes VendaAtivaClientesNavigation { get; set; }
    }
}