﻿using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class CompromissoColaborador : ModelBase
    {
        public int Id { get; set; }
        public int? CodigoAgencia { get; set; }
        public string FuncionalCriacao { get; set; }
        public TipoCompromisso CodigoTipoCompromisso { get; set; }
        public StatusCheckCompromisso CodigoStatusCompromisso { get; set; }

        public byte StatusAcao { get; set; }
        public byte CodigoTipoFrequencia { get; set; }

        public string TextoTitulo { get; set; }
        public DateTime DataInicio { get; set; }
        public DateTime DataFim { get; set; }
        public string TextoLocal { get; set; }
        public string TextoComentario { get; set; }
        public string TextoComentarioVisita { get; set; }

        public Agencia AgenciaNavigation { get; set; }
        public Colaborador ColaboradorCriacaoNavigation { get; set; }
        public ICollection<CompromissoNotificacao> CompromissoNotificacao { get; set; }
        public ICollection<CompromissoParticipante> CompromissoParticipante { get; set; }
    }
}
