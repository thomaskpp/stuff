﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PermissoesFuncionalidades : ModelBase
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Funcional { get; set; }
        public int IdFuncionalidade { get; set; }
        public DateTime dataAtualizacao { get; set; }
    }
}
