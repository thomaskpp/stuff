﻿
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Feriado
    {
        public int id { get;set;}
        public int idAgencia { get; set; }
        public DateTime Data { get; set; }


        [NotMapped]
        public int Linha { get; set; }



    }
}
