﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class AgenciaMigracao
    {
        public int Id { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public string Codigo { get; set; }
        public int IdAgenciaCoordenadora { get; set; }
        public bool Ativo { get; set; }
        public string SiglaEstado { get; set; }
        public string NomeCidade { get; set; }
        public string TextoEndereco { get; set; }
        public decimal ValorLongitude { get; set; }
        public decimal ValorLatitude { get; set; }
        public AgenciaEstrutura AgenciaEstrutura { get; set; }
    }
}
