﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopHistorico : ModelBase
    {
        public int Id { get; set; }
        public int IdLigacao { get; set; }  // navigation
        public int IdStatus { get; set; }  // navigation
        public DateTime? DataAgendamento { get; set; }
        public string FuncionalResponsavel { get; set; }

        //Propriedades de Navegação
        public InnerLoopLigacao LigacaoNavigation { get; set; }
        public InnerLoopStatus StatusNavigation { get; set; }
        public Colaborador FuncionalResponsavelNavigation { get; set; }
    }
}