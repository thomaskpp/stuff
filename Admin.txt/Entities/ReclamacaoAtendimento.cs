﻿using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ReclamacaoAtendimento : ObjetoModelo
    {
        public int IdSegmento { get; set; }
        public byte Mes { get; set; }
        public short Ano { get; set; }
        public int IdAgencia { get; set; }
        public int Ocorrencia { get; set; }
        public DateTime DataRegistro { get; set; }
        public int PenalidadeAgir { get; set; }

        internal static List<ReclamacaoAtendimento> ConverterParaModel(GerenciadorCarga gerenciador, DataTable tb, List<int> linhas, List<Agencia> agencias)
        {
            var result = new List<ReclamacaoAtendimento>();

            foreach (int linha in linhas)
            {
                var model = ConverterParaModel(gerenciador, linha - 2, tb.Rows[linha - 2], agencias);

                if (model != null)
                    result.Add(model);
            }

            return result;
        }

        public static ReclamacaoAtendimento ConverterParaModel(GerenciadorCarga gerenciador, int linha, DataRow registro, List<Agencia> agencias)
        {
            List<string> colunasNaoPreenchidas;
            var model = ConverterParaModel<ReclamacaoAtendimento>(registro, out colunasNaoPreenchidas);

            model.Mes = (byte)gerenciador.Mes;
            model.Ano = gerenciador.Ano;

            model.IdSegmento = ObterSegmentoId(registro["SEGMENTO"].ToString());

            model.IdAgencia = ObterIdAgencia(agencias, registro["AGENCIA"].ToString());

            model.Linha = linha;

            return model;
        }        
    }

}
