﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilPermissaoColaborador
    {
        public int Id { get; set; }
        public int IdPerfilPermissao { get; set; }
        public bool Permissao { get; set; }
        public string Funcional { get; set; }
        public int IdColaborador { get; set; }
    }
}
