﻿using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class GerenciadorCargaErro
    {
        public int Id { get; set; }
        public int IdGerenciadorCarga { get; set; }
        public CargasPassos Passo { get; set; }
        public int Linha { get; set; }
        public string Erro { get; set; }

        public string ErroFormatado
        {
            get
            {
                return Erro.IndexOf("<br>") == 0 ? Erro.Substring(4) : Erro;
            }
        }

        public override string ToString()
        {
            return $"{Id};{IdGerenciadorCarga};{Passo};{Linha};{Erro}";
        }

    }
}
