﻿using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Notificacao
    {
        public Int64 Id { get; set; }

        public DateTime DataCriacao { get; set; }

        public DateTime DataAtualizacao { get; set; }

        public long Codigo { get; set; }

        public string Status { get; set; }

        public string Template { get; set; }

        public string ArquivoTemplate { get; set; }

        public string Texto { get; set; }

        public string Img { get; set; }

        public string UrlAtalho { get; set; }

        public string Resumo { get; set; }

        public DateTime DataPublicacao { get; set; }

        public Int32 IdNotificacaoRemetente { get; set; }

        public int TipoExibicao { get; set; }

        public int? Ano { get; set; }

        public int? Mes { get; set; }

        public int IdNotificacaoTemplate { get; set; }
        public int Linha { get; internal set; }
        public long OrdemPag { get; internal set; }
        public long CodigoPai { get;  set; }

        public string EhValido()
        {

            //TEMPLATE INVALIDO
            if ((this.Template.Length > 0 &&
                this.Template.IndexOf("TEXTO") == 0 &&
                this.Template.IndexOf("IMAGE") == 0 &&
                this.Template.IndexOf("ATALHO") == 0) &&
                (((this.Template.IndexOf("TEXTO") != 0 &&
                this.Texto.Length == 0) &&
                 (this.Template.IndexOf("IMAGEM") != 0 &&
                this.Texto.Length == 0) &&
                  (this.Template.IndexOf("ATALHO") != 0 &&
                this.Texto.Length == 0))))
            {
                return "Template Inválido";
            }

            //STATUS INVALIDO
            if (this.Status.Length == 0 || this.Status.Length > 1 || (this.Status != "S" && this.Status != "N"))
            {
                return "Status Inválido";
            }

            //IMAGEM INVALIDA
            if (this.Img.Length != 0 &&
                this.Img.ToUpper().IndexOf("JPG") == 0 &&
                this.Img.ToUpper().IndexOf("JPEG") == 0 &&
                this.Img.ToUpper().IndexOf("PNG") == 0 &&
                this.Img.ToUpper().IndexOf("GIF") == 0)
            {
                return "Imagem Inválida";
            }

            //TIPO EXIBICAO INVALIDO    
            if (this.TipoExibicao == null)
            {
                return "Tipo de exibição Inválido";
            }

            return string.Empty;
        }

        public static Entities.Notificacao ConverteColunas(int linha, string colunas)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                return new Entities.Notificacao()
                {
                    Id = IntExtension.TryParse(arrayColunas[0]),
                    Status = arrayColunas[1],
                    Template = arrayColunas[2],
                    ArquivoTemplate = arrayColunas[3],
                    Texto = arrayColunas[4],
                    Img = arrayColunas[5],
                    UrlAtalho = arrayColunas[6],
                    Resumo = arrayColunas[7],
                    DataPublicacao = DateTimeExtension.TryParse(arrayColunas[8]),
                    IdNotificacaoRemetente = IntExtension.TryParse(arrayColunas[10]),
                    TipoExibicao = IntExtension.TryParse(arrayColunas[11]),
                    IdNotificacaoTemplate = IntExtension.TryParse(arrayColunas[12]),
                    Linha = linha
                };
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
