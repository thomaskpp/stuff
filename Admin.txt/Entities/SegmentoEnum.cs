﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public static class SegmentoEntrieEnum
    {
        public static SegmentoEntrie Agencias = new SegmentoEntrie(1, 1, "Agencias", "IA", new string[3] { "AGENCIAS", "Agências", "IA" });

        public static SegmentoEntrie Uniclass = new SegmentoEntrie(2, 1, "Uniclass", "IU", new string[2] { "UNICLASS", "IU" });

        public static SegmentoEntrie Empresas = new SegmentoEntrie(3, 1, "Empresas", "EMP_4", new string[6] { "EMPRESAS", "EMP4", "EMP 4", "EMP_4", "EMPRESAS 4", "EMPRESAS4" });

        public static SegmentoEntrie OP = new SegmentoEntrie(4, 1, "OP", "OP", new string[2] { "OPERACIONAL", "OP" });

        public static SegmentoEntrie IP = new SegmentoEntrie(5, 2, "IP", "Person", new string[5] { "PERSONNALITE", "PERSONNALITÉ", "PERSON", "IP", "PER" });

        public static SegmentoEntrie OP_IP = new SegmentoEntrie(6, 1, "OP_IP", "Op_Person", new string[0] { });

        public static SegmentoEntrie EMP_2 = new SegmentoEntrie(7, 1, "EMP_2", "EMP_2", new string[0] { });

        public static SegmentoEntrie OP_DIG_IP = new SegmentoEntrie(8, 1, "OP_DIG_IP", "OP_DIG_IP", new string[0] { });

        public static SegmentoEntrie OP_DIG_IU = new SegmentoEntrie(9, 1, "OP_DIG_IU", "OP_DIG_IU", new string[0] { });

        public static SegmentoEntrie EMP_3 = new SegmentoEntrie(10, 1, "EMP_3", "EMP_3", new string[0] { });

        public static SegmentoEntrie OP_DIG_EMP = new SegmentoEntrie(11, 1, "OP_DIG_EMP", "OP_DIG_EMP", new string[0] { });

        public static SegmentoEntrie ADM = new SegmentoEntrie(12, 1, "ADM", "ADM", new string[0] { });


        private static IEnumerable<SegmentoEntrie> Status =>
            new SegmentoEntrie[12]
            {
                Agencias,
                Uniclass,
                Empresas,
                OP,
                IP,
                OP_IP,
                EMP_2,
                OP_DIG_IP,
                OP_DIG_IU,
                EMP_3,
                OP_DIG_EMP,
                ADM
            };

        public static SegmentoEntrie Obter(int id)
        {
            return Status.FirstOrDefault(x => x.Id == id);
        }

        public static SegmentoEntrie Obter(string nome)
        {
            return Status.FirstOrDefault(x =>
                string.Equals(x.Nome, nome, StringComparison.OrdinalIgnoreCase)
                || x.ExisteSinonimo(nome) || string.Equals(x.Sigla, nome, StringComparison.OrdinalIgnoreCase)
            );
        }

        public static SegmentoEntrie ObterPorSigla(string sigla)
        {
            return Status.FirstOrDefault(x =>
                string.Equals(x.Sigla, sigla, StringComparison.OrdinalIgnoreCase)
            );
        }
    }

}
