﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.VendaAtiva.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class SaibaMais : ModelBase
    {
        public SaibaMais()
        {
        }

        public SaibaMais(string nomeProduto, string descricaoProduto, string linkProduto, string codigoArgumento)
        {
            NomeProduto = nomeProduto;
            DescricaoProduto = descricaoProduto;
            LinkProduto = linkProduto;
            CodigoArgumento = codigoArgumento;
        }

        public string CodigoArgumento { get; set; }
        public string NomeSegmento { get; set; }
        public string NomeProduto { get; set; }
        public string DescricaoProduto { get; set; }
        public string LinkProduto { get; set; }

        public static List<SaibaMais> ConverteColunas(List<int> linhas, List<string> colunas, Enums.Segmentos segmento)
        {
            var result = new List<SaibaMais>();
            var dtAtual = DateTime.Now;

            for (var x = 0; x < colunas.Count; x++)
            {
                try
                {
                    var arrayColunas = colunas[x].Split(';');

                    var oferta = new SaibaMais()
                    {
                        CodigoArgumento = arrayColunas[0],
                        NomeSegmento = arrayColunas[1],
                        NomeProduto = arrayColunas[2],
                        DescricaoProduto = arrayColunas[3],
                        LinkProduto = arrayColunas[4],
                        DataCriacao = dtAtual,
                        DataAtualizacao = dtAtual
                    };
                    result.Add(oferta);
                }
                catch
                {
                    //TODO: log
                }
            }

            colunas = null;

            return result;
        }
    }
}
