﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class CarteiraGradeFake
    {
        public short Ano { get; set; }
        public short Mes { get; set; }
        public string Carteira { get; set; }
        public int Grade { get; set; }
        public int Linha { get; set; }
    }
}
