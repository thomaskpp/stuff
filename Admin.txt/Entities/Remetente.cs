﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public partial class Remetente
    {
        public Remetente()
        {
            Notificacoes = new HashSet<Notificacoes>();
        }

        public long Id { get; set; }
        public string Nome { get; set; }
        public string Img { get; set; }

        [NotMapped]
        public int Linha { get; set; }

        public ICollection<Notificacoes> Notificacoes { get; set; }
        public DateTime DataAtualizacao { get; internal set; }
        public DateTime DataCriacao { get; internal set; }
    }
}
