﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Alavanca : ModelBase
    {
        public int Id { get; set; }
        public DateTime DataReferencia { get; set; }
        public int CodigoAgencia { get; set; }
        public string AbreviacaoSegmento { get; set; }
        public string CodigoFamilia { get; set; }
        public string NomeFamilia { get; set; }
        public string CodigoItem { get; set; }
        public string NomeItem { get; set; }
        public decimal ValorICMCiclo { get; set; }
        public decimal ValorPotencial { get; set; }
        public decimal ValorCapturado { get; set; }

        public Agencia AgenciaNavigation { get; set; }

        [NotMapped]
        public int Linha { get; set; }

        #region [Métodos Cargas]
        public static List<Alavanca> ConverteColunasDistinct(List<int> linhas, List<string> colunas, Enums.Segmentos segmento)
        {
            var model = ConverteColunas(linhas, colunas, segmento);
            var result = model.Select(a => new
            {
                a.DataReferencia,
            })
                .Distinct()
                .Select(a => new Alavanca()
                {
                    DataReferencia = a.DataReferencia,
                })
                .ToList();

            return result;
        }
        public static List<Alavanca> ConverteColunas(List<int> linhas, List<string> colunas, Enums.Segmentos segmento)
        {
            var result = new List<Alavanca>();
            var dtAtual = DateTime.Now;

            for (var x = 0; x < colunas.Count; x++)
            {
                try
                {
                    var arrayColunas = colunas[x].Split(';');

                    var alavanca = new Alavanca()
                    {
                        DataCriacao = DateTime.Now,
                        DataAtualizacao = DateTime.Now,
                        DataReferencia = DateTimeExtension.TryParse(arrayColunas[0]),
                        CodigoFamilia = arrayColunas[1],
                        NomeFamilia = arrayColunas[2],
                        CodigoItem = arrayColunas[3],
                        NomeItem = arrayColunas[4],
                        CodigoAgencia = IntExtension.TryParse(arrayColunas[5]),
                        AbreviacaoSegmento = arrayColunas[6],
                        ValorICMCiclo = PorcentDecimalExtension.TryParse(arrayColunas[7]),
                        ValorPotencial = DecimalExtension.TryParse(arrayColunas[8]),
                        ValorCapturado = DecimalExtension.TryParse(arrayColunas[9])
                    };


                    if (alavanca.CodigoAgencia > 0)
                        result.Add(alavanca);
                }
                catch (Exception ex)
                {
                    throw ex;
                    //TODO: log
                }
            }

            colunas = null;

            return result;
        }
        #endregion

        #region [Métodos Auxiliares]

        public const string CODIGO_UNICLASS = "IU";
        public const string CODIGO_EMPRESAS = "EMP4";
        public const string CODIGO_AGENCIAS = "IA";
        public const int VALOR_MAX_ALAVANCA = 200;

        #endregion
    }
}
