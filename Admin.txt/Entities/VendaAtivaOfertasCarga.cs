﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Domain.VendaAtiva.Entities
{
    public class VendaAtivaOfertasCarga : ModelBase
    {
        public long Id { get; set; }
        public string Carteira { get; set; }
        public long NumeroCPFCNPJ { get; set; }
        public string NomeProdutoOferta { get; set; }
        public string NomeSegmento { get; set; }
        public int IdSegmento { get; set; }
        public string CodigoArgumento { get; set; }
        public string DescricaoArgumento { get; set; }
        public int CodigoAgencia { get; set; }
        public int NumeroAgenciaCliente { get; set; }
        public int NumeroContaCliente { get; set; }
        public int? OrdemExibicaoProdutoOferta { get; set; }
        public int? OrdemExibicaoVisaoPorCliente { get; set; }
        public int? OrdemExibicaoVisaoPorProduto { get; set; }
        public string FuncionalAtuandoOferta { get; set; }
        public DateTime DataAtuandoOferta { get; set; }
        public DateTime DataFinalDescanso { get; set; }
        public bool IndicaOfertaFinalizada { get; set; }
        public string CodcahNew { get; set; }
        public string Subsegmento { get; set; }
        public short Liberacao { get; set; }

        public static List<VendaAtivaOfertasCarga> ConverteColunas(List<int> linhas, List<string> colunas, Enums.Segmentos segmento)
        {
            var result = new List<VendaAtivaOfertasCarga>();
            var dtAtual = DateTime.Now;

            for (var x = 0; x < colunas.Count; x++)
            {
                try
                {
                    var arrayColunas = colunas[x].Split(';');

                    var oferta = new VendaAtivaOfertasCarga();
                    SubSegmentoVai subsegmento = (SubSegmentoVai)segmento.Int();

                    oferta = new VendaAtivaOfertasCarga()
                    {
                        Carteira = arrayColunas[5],
                        NumeroCPFCNPJ = Convert.ToInt64(arrayColunas[1]),
                        NomeProdutoOferta = arrayColunas[0],
                        NomeSegmento = arrayColunas[6],
                        CodigoArgumento = arrayColunas[11],
                        DescricaoArgumento = arrayColunas[12],
                        CodigoAgencia = IntExtension.TryParse(arrayColunas[4]),
                        NumeroAgenciaCliente = IntExtension.TryParse(arrayColunas[2]),
                        NumeroContaCliente = IntExtension.TryParse(arrayColunas[3]),
                        OrdemExibicaoProdutoOferta = IntExtension.TryParse(arrayColunas[9]),
                        OrdemExibicaoVisaoPorCliente = IntExtension.TryParse(arrayColunas[8]),
                        OrdemExibicaoVisaoPorProduto = IntExtension.TryParse(arrayColunas[7]),
                        DataAtuandoOferta = DateTime.Now,
                        DataFinalDescanso = DateTimeExtension.TryParse(arrayColunas[10]),
                        IndicaOfertaFinalizada = false,
                        CodcahNew = arrayColunas[13],
                        Subsegmento = subsegmento.Description(),
                        Liberacao = ShortExtension.TryParse(arrayColunas[14])
                    };
                    result.Add(oferta);
                }
                catch(Exception ex)
                {
                    //TODO: log
                }
            }

            colunas = null;

            return result;
        }
    }
}
