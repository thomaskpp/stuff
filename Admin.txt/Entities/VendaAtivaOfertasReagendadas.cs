﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VendaAtivaOfertasReagendadas : ModelBase
    {
        public long Id { get; set; }
        public string Carteira { get; set; }
        public long NumeroCPFCNPJ { get; set; }
        public string NomeProdutoOferta { get; set; }
        public int IdSegmento { get; set; }
        public string NomeSegmento { get; set; }
        public string CodigoArgumento { get; set; }
        public string DescricaoArgumento { get; set; }
        public int CodigoAgencia { get; set; }
        public int NumeroAgenciaCliente { get; set; }
        public int NumeroContaCliente { get; set; }
        public string FuncionalAtuandoOferta { get; set; }
        public DateTime? DataAtuandoOferta { get; set; }
        public bool IndicaOfertaFinalizada { get; set; }
        public DateTime DataReagendamento { get; set; }
        public string CodcahNew { get; set; }
        public string ComentarioReagendamento { get; set; }

        public VendaAtivaClientes VendaAtivaClientesNavigation { get; set; }
    }
}