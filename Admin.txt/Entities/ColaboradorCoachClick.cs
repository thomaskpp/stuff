﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ColaboradorCoachClick : ModelBase
    {
        public string Funcional { get; set; }
        public string NomeTelaAcessada { get; set; }

        public Colaborador ColaboradorNavigation { get; set; }
    }
}