﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Domain.VendaAtiva.Entities
{
    public class VendaAtivaComboAceito
    {

        public int Id { get; set; }

        public DateTime DataCriacao { get; set; }

        public string Valor { get; set; }

        public int Codigo { get; set; }

    }
}
