﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoPlanejado
    {
        public int Id { get; set; }
        public string NomeSegmento { get; set; }
        public decimal ValorPlanejado { get; set; }
    }
}
