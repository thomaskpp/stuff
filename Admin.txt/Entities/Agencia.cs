﻿
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Agencia : ModelBase
    {
        public int Id { get; set; }
        public int CodigoAgencia { get; set; }
        public string Codigo { get; set; }
        public string TextoEndereco { get; set; }
        public string NomeCidade { get; set; }
        public string SiglaEstado { get; set; }
        public decimal? ValorLatitude { get; set; }
        public decimal? ValorLongitude { get; set; }
        public decimal? ValorPesoSegmentoIA { get; set; }
        public decimal? ValorPesoSegmentoIU { get; set; }
        public decimal? ValorPesoSegmentoEmp4 { get; set; }
        public bool IndicadorAtivo { get; set; }
        public int? CodigoAgenciaCoordenadora { get; set; }
        public string NomeTipoAgencia { get; set; }
        public decimal Visita { get; set; }
        public string FuncionalGGC { get; set; }

        public int? IdPoloRegional { get; set; }
        public int? IdPoloRegiao { get; set; }
        public int? IdPoloDICOM { get; set; }


        #region [ Métodos Auxiliares ]


        public static List<Agencia> ConverteColunasAgencias(List<string> linhas)
        {
            var resultado = new List<Agencia>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new Agencia()
                {
                    CodigoAgencia = IntExtension.TryParse(colunas[0]),
                    TextoEndereco = colunas[1],
                    NomeCidade = colunas[2],
                    SiglaEstado = colunas[3],
                    ValorLatitude = DecimalExtension.TryParse(colunas[4].Replace(",", ".")),
                    ValorLongitude = DecimalExtension.TryParse(colunas[5].Replace(",", ".")),

                });
            }

            return resultado;
        }
        public static List<Agencia> ConverteColunasEstruturaAgencias(List<string> linhas)
        {
            var resultado = new List<Agencia>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new Agencia()
                {
                    CodigoAgencia = IntExtension.TryParse(colunas[0]),
                    CodigoAgenciaCoordenadora = IntExtension.TryParse(colunas[1]),
                    IdPoloRegional = IntExtension.TryParse(colunas[2]),
                    IdPoloRegiao = IntExtension.TryParse(colunas[3]),
                    IdPoloDICOM = IntExtension.TryParse(colunas[4]),
                    IndicadorAtivo = BooleanExtension.TryParse(colunas[5]),
                    NomeTipoAgencia = colunas[6],
                    Visita = DecimalExtension.TryParse(colunas[7].Replace(",", "."))
                });
            }

            return resultado;
        }

        #endregion
    }
}
