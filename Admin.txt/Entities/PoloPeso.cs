﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PoloPeso : ModelBase
    {
        public int Id { get; set; }
        public int IdPolo { get; set; }
        public int IdSegmento { get; set; }
        public decimal Peso { get; set; }

        public Polo PoloNavigation { get; set; }
    }
}
