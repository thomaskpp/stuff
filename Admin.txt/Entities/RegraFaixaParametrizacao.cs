﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class RegraFaixaParametrizacao : ModelBase, IEquatable<RegraFaixaParametrizacao>
    {
        public short IdRegra { get; set; }
        public short NumeroFaixa { get; set; }
        public string Condicao { get; set; }
        public int FaixaInicialPonto { get; set; }
        public int FaixaFinalPonto { get; set; }
        public int Valor { get; set; }
        public new DateTime DataCriacao { get; set; }
        public new DateTime DataAtualizacao { get; set; }

        public override bool Equals(object obj)
        {
            return Equals(obj as RegraFaixaParametrizacao);
        }

        public bool Equals(RegraFaixaParametrizacao other)
        {
            return other != null &&
                   IdRegra == other.IdRegra;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(IdRegra);
        }
    }
}