﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilPermissaoCargo : ModelBase
    {
        public int Id { get; set; }
        public int IdPerfilPermissao { get; set; }
        public bool Permissao { get; set; }
        public int IdCargo { get; set; }
        public string AbreviacaoCargo { get; set; }
    }
}
