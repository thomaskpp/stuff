﻿using Newtonsoft.Json;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PapoDeClienteComentario
    {
        public int IdPapoDeClienteComentario { get; set; }
        [JsonIgnore]
        public int IdPapoDeCliente { get; set; }        
        public string Comentario { get; set; }
    }
}
