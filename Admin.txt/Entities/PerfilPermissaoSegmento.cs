﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilPermissaoSegmento : ModelBase
    {
        public int Id { get; set; }
        public int IdPerfilPermissao { get; set; }
        public bool Permissao { get; set; }
        public int IdSegmento { get; set; }
        public string Nome { get; set; }
    }
}
