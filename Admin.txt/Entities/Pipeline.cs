﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Pipeline
    {
        public int Id { get; set; }
        public int VolumeMercado { get; set; }
        public int VolumeItau { get; set; }
        public bool Hot { get; set; }
        public int Valor { get; set; }
        public bool Prospect { get; set; }
        public bool ClienteNovo { get; set; }
        public string SegVgPosse { get; set; }
        public string SegEmpPosse { get; set; }
        public string ConsApto { get; set; }
        public DateTime Data { get; set; }
        public int SavoPorInc { get; set; }
        public int SalvoPorAlt { get; set; }
        public DateTime DataHoraSalvoInc { get; set; }
        public DateTime DataHoraSalvoAlt { get; set; }
        public int IdPipelineProduto { get; set; }
        public int IdVisaoCliente { get; set; }
        public int IdPipelineStatus { get; set; }
        public bool CompraRisco { get; set; }

        public static List<Pipeline> ConverterColunas(int linha, string colunas)
        {
            List<Pipeline> pipelines = new List<Pipeline>(25);

            var arrayColunas = colunas.Split(';');

            //1	Lis
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.Lis, arrayColunas[16], arrayColunas[15], String.Empty, String.Empty, String.Empty, String.Empty));

            //2	Conta Garantida
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.ContaGarantida, arrayColunas[18], arrayColunas[17], String.Empty, String.Empty, String.Empty, String.Empty));

            //3	Giro Aval            
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.GiroAval, arrayColunas[20], arrayColunas[19], String.Empty, String.Empty, String.Empty, String.Empty));

            //4	Giro Garantias
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.GiroGarantias, "0", "0", String.Empty, String.Empty, String.Empty, String.Empty));

            //5	Longo Prazo
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.LongoPrazo, arrayColunas[43], arrayColunas[42], String.Empty, String.Empty, String.Empty, String.Empty));

            //6	Longo Prazo
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.LongoPrazoCDC, arrayColunas[45], arrayColunas[44], String.Empty, String.Empty, String.Empty, String.Empty));

            //7	Trade ACC/ACE
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.TradeACCACE, arrayColunas[36], arrayColunas[38], String.Empty, String.Empty, String.Empty, String.Empty));

            //8	Trade 2770
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.Trade2770, arrayColunas[37], arrayColunas[39], String.Empty, String.Empty, String.Empty, String.Empty));

            //9	Desconto Duplicatas
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.DescontoDuplicatas, arrayColunas[22], arrayColunas[21], String.Empty, String.Empty, String.Empty, String.Empty));

            //10	Desconto Cheque
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.DescontoCheque, "0", "0", String.Empty, String.Empty, String.Empty, String.Empty));

            //11	Antecipação de Cartões
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.AntecipacaoCartoes, arrayColunas[24], arrayColunas[23], String.Empty, String.Empty, String.Empty, String.Empty));

            //12	Câmbio
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.Cambio, arrayColunas[34], arrayColunas[35], String.Empty, String.Empty, String.Empty, String.Empty));

            //13	Cobrança
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.Cobranca, arrayColunas[30], arrayColunas[29], String.Empty, String.Empty, String.Empty, String.Empty));

            //14	Folha de Pagamentos
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.FolhaPagamentos, arrayColunas[28], arrayColunas[27], String.Empty, String.Empty, String.Empty, String.Empty));

            //15	Credenciamento
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.Credenciamento, arrayColunas[10], arrayColunas[9], String.Empty, String.Empty, String.Empty, String.Empty));

            //16	Troca
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.Troca, "0", "0", String.Empty, String.Empty, String.Empty, String.Empty));

            //17	Flex a Vista
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.FlexVista, "0", "0", String.Empty, String.Empty, String.Empty, String.Empty));

            //18	Flex Parcelado
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.FlexParcelado, "0", "0", String.Empty, String.Empty, String.Empty, String.Empty));

            //19	Seguro de Vida Global
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.SeguroVidaGlobal, "0", "0", arrayColunas[31], String.Empty, String.Empty, String.Empty));

            //20	Seguro de Vida Empresarial
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.SeguroVidaEmpresarial, "0", "0", String.Empty, arrayColunas[32], String.Empty, String.Empty));

            //21	Consórcio
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.Consorcio, "0", "0", String.Empty, String.Empty, arrayColunas[33], String.Empty));

            //22	Cartão Business
            pipelines.Add(MontarPipeline(Enums.PipelineProduto.CartaoBusiness, arrayColunas[25], arrayColunas[26], String.Empty, String.Empty, String.Empty, String.Empty));

            //23	Preventivo            
            //24	Renegociação            
            //25	PMT
            if (arrayColunas[48].ToUpper() == "PMT")
            {
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.PMT, "0", "0", String.Empty, String.Empty, String.Empty, arrayColunas[47]));
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.Preventivo, "0", "0", String.Empty, String.Empty, String.Empty, "0"));
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.Renegociacao, "0", "0", String.Empty, String.Empty, String.Empty, "0"));
            }
            else if (arrayColunas[48].ToUpper() == "PREVENTIVO")
            {
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.PMT, "0", "0", String.Empty, String.Empty, String.Empty, "0"));
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.Preventivo, "0", "0", String.Empty, String.Empty, String.Empty, arrayColunas[47]));
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.Renegociacao, "0", "0", String.Empty, String.Empty, String.Empty, "0"));
            }
            else if (arrayColunas[48].ToUpper() == "RENEG")
            {
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.PMT, "0", "0", String.Empty, String.Empty, String.Empty, "0"));
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.Preventivo, "0", "0", String.Empty, String.Empty, String.Empty, "0"));
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.Renegociacao, "0", "0", String.Empty, String.Empty, String.Empty, arrayColunas[47]));
            }
            else
            {                
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.PMT, "0", "0", String.Empty, String.Empty, String.Empty, "0"));
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.Preventivo, "0", "0", String.Empty, String.Empty, String.Empty, "0"));
                pipelines.Add(MontarPipeline(Enums.PipelineProduto.Renegociacao, "0", "0", String.Empty, String.Empty, String.Empty, "0"));
            }


            return pipelines;
        }

        private static Pipeline MontarPipeline(Enums.PipelineProduto pipelineProduto, string volumeMercado, string volumeItau, string segVgPosse, string segEmpPosse, string consApto, string valorGestaoRisco)
        {
            Pipeline pipeline = new Pipeline();

            switch (pipelineProduto)
            {
                case Enums.PipelineProduto.SeguroVidaGlobal:
                    pipeline.SegVgPosse = segVgPosse;
                    break;
                case Enums.PipelineProduto.SeguroVidaEmpresarial:
                    pipeline.SegEmpPosse = segEmpPosse;
                    break;
                case Enums.PipelineProduto.Consorcio:
                    pipeline.ConsApto = consApto;
                    break;
                case Enums.PipelineProduto.PMT:
                case Enums.PipelineProduto.Preventivo:
                case Enums.PipelineProduto.Renegociacao:
                    pipeline.VolumeItau = int.Parse(valorGestaoRisco.Trim());
                    break;
                default:
                    pipeline.VolumeMercado = int.Parse(volumeMercado.Trim());
                    pipeline.VolumeItau = int.Parse(volumeItau.Trim());
                    break;
            }

            pipeline.IdPipelineProduto = pipelineProduto.GetHashCode();

            return pipeline;
        }
    }
}
