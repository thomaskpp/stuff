﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoGerencialAgirConsolidado : ModelBase
    {
        public int? IdPoloDicom { get; set; }
        public int? IdPoloRegiao { get; set; }
        public int? IdPoloRegional { get; set; }
        public int Ano { get; set; }
        public int Mes { get; set; }
        public string FuncionalResponsavel { get; set; }
        public string AbreviacaoCargo { get; set; }
        public decimal ValorInformado { get; set; }
        public decimal ValorRealizado { get; set; }
        public decimal ValorNaoApurado { get; set; }
        public decimal ValorPlanejado { get; set; }
        public decimal ValorMaximo { get; set; }
    }

}
