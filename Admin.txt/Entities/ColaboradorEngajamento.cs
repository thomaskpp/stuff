﻿using Itau.SZ7.GPS.Admin.Enums;
using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ColaboradorEngajamento : ModelBase
    {

        public string Funcional { get; set; }
        public string AbreviacaoCargo { get; set; }
        public int? CodigoAgencia { get; set; }
        public int? IdPoloRegional { get; set; }
        public int? IdPoloRegiao { get; set; }
        public int? IdPoloDICOM { get; set; }
        public string Carteira { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
        public int QuantidadeCheckin { get; set; }
        public int QuantidadeCheckout { get; set; }
        public int QuantidadePlanejamento { get; set; }
        public decimal ValorAderenciaCheckin { get; set; }
        public decimal ValorAderenciaCheckout { get; set; }
        public decimal ValorAderenciaPlanejamento { get; set; }
        public int QuantidadeDiasUteis { get; set; }
        public int QuantidadeDiasIndisponiveis { get; set; }
        public DateTime? DataAtualizacaoCheckin { get; set; }
        public DateTime? DataAtualizacaoCheckout { get; set; }
        public DateTime? DataAtualizacaoPlanejamento { get; set; }
        public ElegivelEngajamento CodigoElegivelEngajamento { get; set; }

        public Agencia AgenciaNavigation { get; set; }
        public Polo PoloRegionalNavigation { get; set; }
        public Polo PoloRegiaoNavigation { get; set; }
        public Polo PoloDICOMNavigation { get; set; }
        public Colaborador ColaboradorNavigation { get; set; }

        //Usado no novo processo de engajamento
        public int DiasIndisponiveis { get; set; }

    }
}
