﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class LogTelaUsuario
    {
        public int Funcional { get; set; }
        public int Altura { get; set; }
        public int Largura { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
    }
}
