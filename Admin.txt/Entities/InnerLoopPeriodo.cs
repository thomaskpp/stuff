﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopPeriodo
    {
        public DateTime Inicio { get; set; }
        public DateTime Fim { get; set; }
    }
}
