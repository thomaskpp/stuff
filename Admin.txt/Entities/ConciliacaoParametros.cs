﻿using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ConciliacaoParametros
    {
        public long Id { get; set; }
        public long IdConfiguracoes { get; set; }
        public DateTime? Data { get; set; }
        public ConciliacaoChaves CodigoChave { get; set; }
        public string ColunaCheckout { get; set; }
        public string ColunaRealizado { get; set; }
        public string Tipo { get; set; }
        public string Criterio { get; set; }
        public string Intervalo { get; set; }
        public string Input { get; set; }
    }
}
