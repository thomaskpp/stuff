﻿using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class NPSTransacional : ModelBase
    {
        public int Id { get; set; }
        public int Agencia { get; set; }
        public short Mes { get; set; }
        public short Ano { get; set; }
        public string Carteira { get; set; }
        public short IdSegmento { get; set; }
        public DateTime DataDisparo { get; set; }
        public string Produto { get; set; }
        public int Detrator { get; set; }
        public int Neutro { get; set; }
        public int Promotor { get; set; }
        public int SatX { get; set; }
        public int GrupoComprometido { get; set; }


        [NotMapped]
        public int Linha { get; set; }

        public static List<NPSTransacional> ConverteColunas(List<int> linhas, List<string> colunas, Enums.Segmentos segmento, short mes, short ano)
        {
            var result = new List<NPSTransacional>();
            var dtAtual = DateTime.Now;

            for (var x = 0; x < colunas.Count; x++)
            {
                try
                {
                    var arrayColunas = colunas[x].Split(';');
                    NPSTransacional NPS = null;

                    NPS = new NPSTransacional()
                    {
                        DataCriacao = dtAtual,
                        DataAtualizacao = dtAtual,
                        Agencia = Convert.ToInt16(arrayColunas[0]),
                        Carteira = Convert.ToString(arrayColunas[1]),
                        IdSegmento = (short)(segmento),
                        DataDisparo = DateTime.Parse(arrayColunas[4]),
                        Produto = arrayColunas[5],
                        Detrator = Convert.ToInt16(arrayColunas[6]),
                        Neutro = Convert.ToInt16(arrayColunas[7]),
                        Promotor = Convert.ToInt16(arrayColunas[8]),
                        SatX = Convert.ToInt16(string.IsNullOrEmpty(arrayColunas[9]) ? "0" : arrayColunas[9]),
                        GrupoComprometido = Convert.ToInt16(arrayColunas[10]),
                        
                        Mes = mes,
                        Ano = ano,
                        Linha = linhas[x]
                    };

                    result.Add(NPS);
                }
                catch
                {
                    //TODO: log
                }
            }

            return result;
        }
    }
}
