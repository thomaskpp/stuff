﻿using Itau.SZ7.GPS.Admin.Enums;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VendaAtivaClientesTelefone : ModelBase
    {
        public long NumeroCPFCNPJ { get; set; }
        public string NumeroTelefone { get; set; }
        public AvaliacaoTelefone? CodigoAvaliacaoTelefone { get; set; }
        public int? OrdemExibicao { get; set; }

        public VendaAtivaClientes VendaAtivaClientesNavigation { get; set; }
    }
}