﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Entities
{
    /// <summary>
    /// Entidade utilizada para enviar e recuperar estrtura de uma carteira
    /// </summary>
    public class VisaoGerencialProducaoCarteiraDM1
    {
        public string Carteira { get; set; }        
        public int CodigoItem { get; set; }        
        public decimal SomaValorProducaoDM1 { get; set; }
    }
}
