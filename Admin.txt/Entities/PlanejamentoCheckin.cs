﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PlanejamentoCheckin : ModelBase
    {
        public int Id { get; set; }
        public int CodigoAgencia { get; set; }
        public int IdAgencia { get; set; }
        public string Carteira { get; set; }
        public short Grade { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
        public int CodigoItem { get; set; }
        public DateTime Data { get; set; }
        public string Funcional { get; set; }
        public decimal ValorPontuacaoPlanejada { get; set; }
        public decimal ValorProducaoPlanejada { get; set; }
        public bool IndicadorRegistroExcluido { get; set; }

        public int IdColaboradorAgir { get; set; }
        public int IdPlanejamento { get; set; }
        public int IdPlanejamentoItem { get; set; }

        public Colaborador ColaboradorNavigation { get; set; }
        public PlanejamentoItemGradeCarteira PlanejamentoItemGradeCarteira { get; set; }
    }
}