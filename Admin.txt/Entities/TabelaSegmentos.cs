﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class TabelaSegmentos
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Sigla { get; set; }
        public int IdEstrutura { get; set; }

    }
}
