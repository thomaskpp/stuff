﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class InnerLoopLigacao
    {

        public const int Periodo_Expurgo = 180;

        public int Id { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public int IdSegmentoColaborador { get; set; }
        public int? IdColaboradorResponsavel { get; set; }
        public int IdAgenciaResponsavel { get; set; }
        public string Responsavel { get; set; }
        public int AgenciaResponsavel { get; set; }
        public string Nome { get; set; }
        public int Nota { get; set; }
        public string Produto { get; set; }
        public int? AgenciaCliente { get; set; }
        public string ContaCliente { get; set; }
        public DateTime? DataContato { get; set; }
        public string Telefone { get; set; }
        public string Cnpj { get; set; }
        public string SegmentoCliente { get; set; }
        public string Ocorrencia { get; set; }
        public string CnpjGrupo { get; set; }
        public string Cidade { get; set; }
        public string Infos { get; set; }
        public string Comentario { get; set; }
        public int? IdColaboradorLigacao { get; set; }
        public string NomeContato { get; set; }
        public string Nps { get; set; }
        public string CpfCnpj { get; set; }
        public string TempoRelac { get; set; }

        [NotMapped]
        public int Linha { get; set; }
    }
}
