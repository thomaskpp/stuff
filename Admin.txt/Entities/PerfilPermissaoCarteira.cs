﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PerfilPermissaoCarteira : ModelBase
    {
        public int Id { get; set; }
        public int IdPerfilPermissao { get; set; }
        public bool Permissao { get; set; }
        public string Carteira { get; set; }
    }
}
