﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class NPS 
    {
        public int Id { get; set; }

        public DateTime DataCriacao { get; set; }

        public DateTime DataAtualizacao { get; set; }

        public int IdAgencia { get; set; }

        public int IdSegmento { get; set; }

        public DateTime DataDisparo { get; set; }

        public string NomeProduto { get; set; }

        public int QuantidadeDetrator { get; set; }

        public int QuantidadeInvalido { get; set; }

        public int QuantidadeNeutro { get; set; }

        public int QuantidadePromotor { get; set; }

        public int QuantidadeValorSAT_X { get; set; }

        public decimal ValorNPS { get; set; }

        public int ValorBench { get; set; }

        public string VisaoNPS { get; set; }

        public int IdEstrutura { get; set; }        

        [NotMapped]
        public int Linha { get; set; }

        public Agencia AgenciaNavigation { get; set; }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int CalcularNota()
        {
            return this.CalcularRespondentes() > 0 ? Convert.ToInt32((Convert.ToDouble(this.QuantidadePromotor - this.QuantidadeDetrator) / this.CalcularRespondentes()) * 100) : 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int CalcularRespondentes()
        {
            return (this.QuantidadeDetrator + this.QuantidadeInvalido + this.QuantidadeNeutro + this.QuantidadePromotor);
        }

        /*

        public static List<NPS> ConverteColunas(List<int> linhas, List<string> colunas, Enums.Segmentos segmento)
        {
            var result = new List<NPS>();
            var dtAtual = DateTime.Now;

            for (var x = 0; x < colunas.Count; x++)
            {
                try
                {
                    var arrayColunas = colunas[x].Split(';');
                    NPS NPS = null;

                    NPS = new NPS()
                    {
                        DataCriacao = dtAtual,
                        DataAtualizacao = dtAtual,
                        CodigoAgencia = IntExtension.TryParse(arrayColunas[0]),
                        NomeSegmento = arrayColunas[1],
                        IdSegmento = (int)(segmento),
                        DataDisparo = DateTime.Parse(arrayColunas[2]),
                        NomeProduto = arrayColunas[3],
                        QuantidadeDetrator = IntExtension.TryParse(arrayColunas[4]),
                        QuantidadeInvalido = IntExtension.TryParse(arrayColunas[5]),
                        QuantidadeNeutro = IntExtension.TryParse(arrayColunas[6]),
                        QuantidadePromotor = IntExtension.TryParse(arrayColunas[7]),
                        QuantidadeValorSAT_X = IntExtension.TryParse(arrayColunas[8]),
                        ValorNPS = IntExtension.TryParse(arrayColunas[9]),
                        ValorBench = IntExtension.TryParse(arrayColunas[10]),
                        VisaoNPS = arrayColunas[11],
                        Linha = linhas[x]
                    };

                    result.Add(NPS);
                }
                catch (Exception ex)
                {
                    //TODO: log
                }
            }

            colunas = null;

            return result;
        }

    */
    }
}
