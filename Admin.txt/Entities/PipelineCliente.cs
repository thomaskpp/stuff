﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PipelineCliente
    {
        public int Id { get; set; }
        public string Cnpj { get; set; }
        public string Descricao { get; set; }
        public string GrupoEconomico { get; set; }
        public string FarolVisita { get; set; }
        public string OfertaCampanha { get; set; }

        public int Linha { get; set; }

        public static List<PipelineCliente> ConverteColunas(List<int> linhas, List<string> colunas)
        {
            var result = new List<PipelineCliente>(linhas.Count);

            for (var x = 0; x < colunas.Count; x++)
            {
                var model = ConverteColunas(linhas[x], colunas[x]);

                if (model != null)
                    result.Add(model);
            }

            return result;
        }

        public static PipelineCliente ConverteColunas(int linha, string colunas)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                return new PipelineCliente()
                {
                    Cnpj = arrayColunas[0],
                    Descricao = arrayColunas[1].Replace("'", string.Empty),
                    GrupoEconomico = arrayColunas[2].Replace("'", string.Empty),
                    FarolVisita = arrayColunas[4].Replace("'", string.Empty),
                    OfertaCampanha = arrayColunas[3].Replace("'", string.Empty),
                    Linha = linha
                };
            }
            catch
            {
                return null;
            }
        }
    }
}
