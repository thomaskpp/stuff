﻿namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VisaoCheckinCheckout
    {
        public int Id { get; set; }
        public string NomeSegmento { get; set; }
        public int Carteiras { get; set; }
        public int DiasUteis { get; set; }
        public int QuantidadeCheckin { get; set; }
        public int QuantidadeCheckout { get; set; }
        public int CheckoutHoje { get; set; }
        public int CheckinHoje { get; set; }

        public string Nome { get; set; }
    }
}
