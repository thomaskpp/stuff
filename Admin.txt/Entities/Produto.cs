﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Produto
    {
        public int Id { get; set; }

        public int Ano { get; set; }

        public int Mes { get; set; }

        public string Codigo { get; set; }

        public string Nome { get; set; }

        public bool Ativo { get; set; }

        public bool ExibeValor { get; set; }

        public decimal ValorICMParam { get; set; }

        public decimal ValorPonderador { get; set; }

        public decimal ValorPonderadorMaximo { get; set; }

        public int IdSegmento { get; set; }

        public int CodigoItem { get; set; }
        public string NomeSegmento { get; internal set; }
    }
}
