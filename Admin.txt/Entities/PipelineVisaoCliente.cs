﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PipelineVisaoCliente
    {

        private int _id;
        public int Id {
            get {
                return _id;
            }
            set {
                _id = value;

                //Adiciona o id visão cliente nos pipelines
                if (Pipelines != null)
                {
                    foreach (Pipeline pipeline in Pipelines)
                    {
                        pipeline.IdVisaoCliente = _id;
                    }
                }
            }
        }
        public int MesCarga { get; set; }
        public int AnoCarga { get; set; }
        public string CodigoGerente { get; set; }
        public int Porte { get; set; }
        public string Matriz { get; set; }
        public string Rating { get; set; }
        public bool VaiVisitar { get; set; }
        public int IdPipelineStatus { get; set; }
        public DateTime DataInicio { get; set; }
        public DateTime DataFim { get; set; }
        public int SalvoPorInc { get; set; }
        public int SalvoPorAlt { get; set; }
        public DateTime DataHoraSalvoInc { get; set; }
        public DateTime DataHoraSalvoAlt { get; set; }
        public int IdAgenciaEstrutura { get; set; }
        public int IdPipelineCliente { get; set; }

        public List<Pipeline> Pipelines { get; set; }
        public string Cnpj { get; set; }
        public string Segmento { get; private set; }
        public string CodigoPlataforma { get; private set; }
        public int Linha { get; private set; }

        public static List<string> ConverteColunas(List<int> linhas, List<string> colunas)
        {
            var result = new List<string>(linhas.Count);

            for (var x = 0; x < colunas.Count; x++)
            {
                var model = ConverteColunas(linhas[x], colunas[x]);

                if (model != null)
                    result.Add(model);
            }

            return result;
        }

        public static string ConverteColunas(int linha, string colunas)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                var sql = $@"
                            INSERT INTO PipelineVisaoClienteSTG (cnpj9
                            ,cod_segmento
                            ,cod_dicom
                            ,cod_regiao
                            ,cod_subregiao
                            ,cod_plataforma
                            ,cod_gerente
                            ,nome_cliente
                            ,grupo_economico
                            ,share_fat_rede_itau
                            ,vol_fat_cartoes
                            ,porte
                            ,matriz
                            ,oferta_campanha
                            ,farol_visita
                            ,lis_bacen_itau
                            ,lis_bacen_total
                            ,cg_bacen_itau
                            ,cg_bacen_total
                            ,giro_bacen_itau
                            ,giro_bacen_total
                            ,desct_bacen_itau
                            ,desct_bacen_total
                            ,antec_bacen_itau
                            ,antec_bacen_total
                            ,cartb_bacen_merc
                            ,cartb_bacen_itau
                            ,pg_vol_itau
                            ,pg_vol_merc
                            ,cobr_vol_itau
                            ,cobr_vol_merc
                            ,seg_vg_posse
                            ,seg_emp_posse
                            ,cons_apto
                            ,cmb_vol_merc
                            ,cmb_vol_itau_real
                            ,trd_bacen_acc_total
                            ,trd_bacen_2770_total
                            ,trd_bacen_acc_itau
                            ,trd_bacen_2770_itau
                            ,trd_bacen_total
                            ,trd_bacen_itau
                            ,lp_bacen_itau
                            ,lp_bacen_total
                            ,lp_cdc_bacen_itau
                            ,lp_cdc_bacen_total
                            ,rating
                            ,potencial_agir
                            ,item)
                            VALUES ({(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[0].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[1].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[2].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[3].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[4].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[5].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[6].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[7].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[8].Replace("'", string.Empty)}'")}
                                    ,{arrayColunas[9]}
                                    ,{arrayColunas[10]}
                                    ,{arrayColunas[11]}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[12].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[13].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[14].Replace("'", string.Empty)}'")}
                                    ,{arrayColunas[15]}
                                    ,{arrayColunas[16]}
                                    ,{arrayColunas[17]}
                                    ,{arrayColunas[18]}
                                    ,{arrayColunas[19]}
                                    ,{arrayColunas[20]}
                                    ,{arrayColunas[21]}
                                    ,{arrayColunas[22]}
                                    ,{arrayColunas[23]}
                                    ,{arrayColunas[24]}
                                    ,{arrayColunas[25]}
                                    ,{arrayColunas[26]}
                                    ,{arrayColunas[27]}
                                    ,{arrayColunas[28]}
                                    ,{arrayColunas[29]}
                                    ,{arrayColunas[30]}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[31].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[32].Replace("'", string.Empty)}'")}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[33].Replace("'", string.Empty)}'")}
                                    ,{arrayColunas[34]}
                                    ,{arrayColunas[35]}
                                    ,{arrayColunas[36]}
                                    ,{arrayColunas[37]}
                                    ,{arrayColunas[38]}
                                    ,{arrayColunas[39]}
                                    ,{arrayColunas[40]}
                                    ,{arrayColunas[41]}
                                    ,{arrayColunas[42]}
                                    ,{arrayColunas[43]}
                                    ,{arrayColunas[44]}
                                    ,{arrayColunas[45]}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[46].Replace("'", string.Empty)}'")}
                                    ,{arrayColunas[47]}
                                    ,{(string.IsNullOrEmpty(arrayColunas[0]) ? "NULL" : $"'{arrayColunas[48].Replace("'", string.Empty)}'")}
                                                        )";

                return sql;
            }
            catch
            {
                return null;
            }
        }
    }
}
