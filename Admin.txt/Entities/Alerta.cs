﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Alerta : ModelBase
    {
        public int Id { get; set; }

        public string TextoMensagem { get; set; }

        public string TextoTitulo { get; set; }

        public string TextoUrlImagemMensagem { get; set; }

        public string FuncionalDestinatario { get; set; }

        public DateTime DataExpiracao { get; set; }
    }
}
