﻿using Itau.SZ7.GPS.Admin.Enums;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class GerenciadorCargaConfiguracao
    {
        public int Id { get; set; }
        public int IdColaborador { get; set; }
        public CargasTipoPeriodo IdTipoPeriodo { get; set; }
        public string ValorPeriodo { get; set; }
        public bool Ocultar { get; set; }
        public bool TravaSimultanea { get; set; }
        public int IdFuncionalidade { get; set; }


        public string Nome { get; set; }
        public string Funcional { get; set; }
        public string NomeResponsavel { get; set; }
        public string Url { get; set; }

    }
}
