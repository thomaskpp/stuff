﻿using Itau.SZ7.GPS.Admin.Enums;
using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class PlanejamentoItemGrade : ModelBase
    {
        public short Grade { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
        public string NomeSegmento { get; set; }
        public int IdSegmento { get; set; }
        public int CodigoItem { get; set; }
        public string NomeItem { get; set; }
        public int? CodigoItemPai { get; set; }
        public decimal ValorPeso { get; set; }
        public decimal ValorMeta { get; set; }
        public bool IndicadorBonus { get; set; }
        public bool IndicadorVocacao { get; set; }
        public decimal ValorICMMaximo { get; set; }
        public decimal? ValorICMHistorico { get; set; }
        public decimal ValorPonderador { get; set; }
        public byte ValorPontuacaoMinima { get; set; }
        public decimal ValorPontuacaoMaxima { get; set; }
        public decimal ValorProducaoMaxima { get; set; }
        public string NomeIconeItem { get; set; }
        public bool IndicadorAlteracao { get; set; }
        public RegraCalculoICMAgrupamento CodigoRegraCalculoICMAgrupamento { get; set; }
        public FrequenciaPlanejamento CodigoFrequenciaPlanejamento { get; set; }

        public override bool Equals(object obj)
        {
            var grade = obj as PlanejamentoItemGrade;
            return grade != null &&
                   Grade == grade.Grade &&
                   Ano == grade.Ano &&
                   Mes == grade.Mes &&
                   NomeSegmento == grade.NomeSegmento &&
                   CodigoItem == grade.CodigoItem;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Grade, Ano, Mes, NomeSegmento, CodigoItem);
        }
    }
}
