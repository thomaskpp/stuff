﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class GerenciadorCargaConfiguracaoMigracao
    {
        public bool Ocultar { get; set; }
        public string ValorPeriodo { get; set; }
        public int IdTipoPeriodo { get; set; }
        public int IdColaborador { get; set; }
        public int Id { get; set; }
        public bool TravaSimultanea { get; set; }
        public int IdFuncionalidade { get; set; }
    }
}
