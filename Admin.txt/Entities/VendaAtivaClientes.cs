﻿using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VendaAtivaClientes : ModelBase, IEquatable<VendaAtivaClientes>
    {
        public long NumeroCPFCNPJ { get; set; }
        public string NomeCliente { get; set; }
        public DateTime DataNascimento { get; set; }
        public string AbreviaturaGenero { get; set; }
        public string SociosPJ { get; set; }
        public string Emails { get; set; }
        public string Telefones { get; set; }

        public ICollection<VendaAtivaClientesEmail> VendaAtivaClientesEmail { get; set; }
        public ICollection<VendaAtivaClientesTelefone> VendaAtivaClientesTelefone { get; set; }
        public ICollection<VendaAtivaOfertas> VendaAtivaOfertas { get; set; }
        public ICollection<VendaAtivaResultadoOfertas> VendaAtivaResultadoOfertas { get; set; }
        public ICollection<VendaAtivaOfertasReagendadas> VendaAtivaOfertasReagendadas { get; set; }

        public bool Equals(VendaAtivaClientes other)
        {
            if (NumeroCPFCNPJ == other.NumeroCPFCNPJ)
                return true;
            return false;
        }


    }
}