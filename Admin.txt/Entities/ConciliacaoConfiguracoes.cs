﻿using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ConciliacaoConfiguracoes
    {
        public long Id { get; set; }
        public int CodigoItem { get; set; }
        public int IdSegmento { get; set; }
        public short Mes { get; set; }
        public short Ano { get; set; }
        public bool IndicadorAtivo { get; set; }

        public List<ConciliacaoParametros> parametros { get; set; }

        [NotMapped]
        public bool FlagConfiguracoes { 
            get 
            {
                return parametros?.Any() ?? false;
            }
        }
    }
}
