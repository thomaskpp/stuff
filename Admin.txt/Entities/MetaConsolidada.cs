﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class MetaConsolidada
    {
        public int codigoItem { get; set; }
        public int mes { get; set; }
        public string nomeSegmento { get; set; }
        public string nomeItem { get; set; }
        public int count { get; set; }
        public decimal sumValorMeta { get; set; }
        public string dataReferencia { get; set; }
        public string dataEnvio { get; set; }
    }
}
