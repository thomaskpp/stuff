﻿using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class VendaAtivaOfertas : ModelBase
    {
        public long Id { get; set; }
        public string Carteira { get; set; }
        public long NumeroCPFCNPJ { get; set; }
        public string NomeProdutoOferta { get; set; }
        public int IdSegmento { get; set; }
        public string NomeSegmento { get; set; }
        public string CodigoArgumento { get; set; }
        public string DescricaoArgumento { get; set; }
        public int CodigoAgencia { get; set; }
        public int NumeroAgenciaCliente { get; set; }
        public int NumeroContaCliente { get; set; }
        public int? OrdemExibicaoProdutoOferta { get; set; }
        public int? OrdemExibicaoVisaoPorCliente { get; set; }
        public int? OrdemExibicaoVisaoPorProduto { get; set; }
        public string FuncionalAtuandoOferta { get; set; }
        public DateTime? DataAtuandoOferta { get; set; }
        public DateTime? DataFinalDescanso { get; set; }
        public bool IndicaOfertaFinalizada { get; set; }
        public string CodcahNew { get; set; }
        public bool GGAtuando { get; set; }

        public VendaAtivaClientes VendaAtivaClientesNavigation { get; set; }
        public ICollection<VendaAtivaResultadoOfertas> VendaAtivaResultadoOfertas { get; set; }

    }
}