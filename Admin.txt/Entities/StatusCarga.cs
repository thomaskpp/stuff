﻿using Itau.SZ7.GPS.Admin.Domain.Carga.Enums;
using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class StatusCarga
    {
        public string Nome { get; set; }
        public Funcionalidade.Enum Funcionalidade { get; set; }
        public DateTime? UltimaAtualizacao { get; set; }
        public StatusEnum Status { get; set; }
        public string Proxima { get; set; }
        public string DsUrl { get; set; }
        public string BaseUrl { get; set; }
        public int IdFuncionalidade { get; set; }

        public string UltimaAtualizacaoString
        {
            get
            {
                return UltimaAtualizacao.HasValue ? UltimaAtualizacao.Value.ToString("dd/MM/yyyy") : "---";
            }
        }
    }
}
