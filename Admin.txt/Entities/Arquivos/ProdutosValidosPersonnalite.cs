﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Models.Arquivos
{
    public class ProdutosValidosPersonnalite
    {
        public string Segmento { get; set; }
        public string CodigoItem { get; set; }
        public string NomeProduto { get; set; }
        public string Status { get; set; }
        public string CodigoProduto { get; set; }
        public string ICM_PARAM { get; set; }
        public string PONDERADOR { get; set; }
        public string PONDERADOR_MAX { get; set; }

        public static List<ProdutosValidosPersonnalite> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<ProdutosValidosPersonnalite>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new ProdutosValidosPersonnalite()
                {
                    Segmento = colunas[0],
                    CodigoItem = colunas[1],
                    NomeProduto = colunas[2],
                    Status = colunas[3],
                    CodigoProduto = colunas[4],
                    ICM_PARAM = colunas[5],
                    PONDERADOR = colunas[6],
                    PONDERADOR_MAX = colunas[7],
                });
            }

            return resultado;
        }
    }
}
