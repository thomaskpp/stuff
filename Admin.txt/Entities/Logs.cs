﻿using System;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class Logs
    {
        public int Id { get; set; }
        public string Guid { get; set; }
        public DateTime DataCriacao { get; set; }
        public int? IdColaborador { get; set; }
        public string Carteira { get; set; }
        public int? IdAgencia { get; set; }
        public string Racf { get; set; }
        public string StackTrace { get; set; }
        public string Descricao { get; set; }
        public string MetodoOrigem { get; set; }
        public string Versao { get; set; }
        public string Servidor { get; set; }

        public int IdLogTipo { get; set; }
        public int? IdSegmento { get; set; }
        public int IdPlataforma { get; set; }
        public int IdFuncionalidade { get; set; }

        public Logs()
        {
            this.DataCriacao = DateTime.Now;
        }
    }
}
