﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Entities
{
    public class ConciliacaoTabelas
    {
        public int CodigoTabela { get; set; }
        public string NomeColuna { get; set; }
        public string NomeTabela { get; set; }
        public string Tipo { get; set; }
    }
}
