﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Exceptions;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Extensions
{
    public class GPSExceptionHandler
    {
        private readonly RequestDelegate _next;
        private readonly ILogApplication _logApplication;

        /// <summary>
        /// Create new instance of GPSExceptionHandler
        /// </summary>
        /// <param name="next"></param>
        /// <param name="logger"></param>
        public GPSExceptionHandler(RequestDelegate next, ILogApplication logApplication)
        {
            _next = next;
            _logApplication = logApplication;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception exception)
            {
                await HandleExceptionAsync(httpContext, exception);
            }
        }

        private Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            var errorMessage = "error";
            int statusCode = (int)HttpStatusCode.BadRequest;
            var exceptionType = exception.GetType();

            switch (exception)
            {
                case Exception e when exceptionType == typeof(UnauthorizedAccessException):
                    statusCode = (int)HttpStatusCode.Unauthorized;
                    break;

                case GPSApplicationException e when exceptionType == typeof(GPSApplicationException) || exceptionType.BaseType == typeof(GPSApplicationException):
                    int.TryParse(e.Code, out statusCode);
                    errorMessage = e.Message;
                    break;

                default:
                    statusCode = (int)HttpStatusCode.InternalServerError;
                    errorMessage = exception.Message;
                    break;
            }

            var response = new { message = errorMessage };
            var payload = JsonConvert.SerializeObject(response);
            context.Response.StatusCode = statusCode;

            var logId = _logApplication.RegistrarLog(tipo: LogTipo.Critico,
                                        plataforma: Plataforma.Enum.Admin,
                                        funcionalidade: Funcionalidade.Enum.Desconhecido,
                                        stackTrace: ExceptionExtension.RetornaStackTrace(exception),
                                        descricao: ExceptionExtension.RetornaInnerException(exception)?.Message ?? string.Empty,
                                        metodoOrigem: "HandleExceptionAsync");


            if (!string.IsNullOrWhiteSpace(context.Request.ContentType)
                    && context.Request.ContentType.ToLower().Contains("json"))
            {
                context.Response.ContentType = "application/json";
                return context.Response.WriteAsync(payload);
            }
            else
            {
                context.Response.Redirect($"/Error?id={logId}");
                return Task.CompletedTask;
            }

        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    /// <summary>
    /// GPSExceptionHandler Extensions Methods
    /// </summary>
    public static class GPSExceptionHandlerExtensions
    {
        /// <summary>
        /// Add GPSExceptionHandler to the application request pipeline
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseGPSExceptionHandler(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<GPSExceptionHandler>();
        }
    }
}
