﻿using System.Text.RegularExpressions;

namespace Itau.SZ7.GPS.Admin.Extensions
{
    public static class StringExtensions
    {
        public static string RemoveSpecialCharacters(this string str)
        {
            return Regex.Replace(str, "[^a-zA-Z0-9_.]+", "", RegexOptions.Compiled);
        }

        public static string ToBase64(this string str)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(str);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string FromBase64(this string str)
        {
            byte[] data = System.Convert.FromBase64String(str);
            return System.Text.Encoding.ASCII.GetString(data);
        }
    }
}
