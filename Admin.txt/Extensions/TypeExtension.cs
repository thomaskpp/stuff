﻿using Itau.SZ7.GPS.Admin.Attributes;
using System;
using System.Linq;
using System.Reflection;

namespace Itau.SZ7.GPS.Admin.Extensions
{
    public static class TypeExtensions
    {
        public static PropertyInfo[] GetFilteredProperties(this Type type)
        {
            return type.GetProperties()
              .Where(pi => !Attribute.IsDefined(pi, typeof(ReflectionSkipAttribute)))
              .ToArray();
        }
    }
}
