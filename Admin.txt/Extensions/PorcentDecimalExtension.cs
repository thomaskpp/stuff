﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Extensions
{
    public static class PorcentDecimalExtension
    {
        public static decimal TryParse(this string value)
        {
            decimal.TryParse(value.Replace("%", ""), NumberStyles.Float, CultureInfo.CreateSpecificCulture("en-US"), out decimal result);
            return result;
        }
    }
}
