﻿using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Configuration;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Data.Sql;
using Itau.SZ7.GPS.Admin.Domain.Carga.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Domain.Home.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Domain.Notificacao.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Domain.PermissaoAcesso.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Domain.Security.Interfaces;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Repositories;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using Itau.SZ7.GPS.Admin.Services;
using Itau.SZ7.GPS.Admin.Services.Conciliacao;
using Itau.SZ7.GPS.Admin.Services.Conciliacao.Interfaces;
using Itau.SZ7.GPS.Admin.Services.EditorParametros.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Home;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Notificacao;
using Itau.SZ7.GPS.Admin.Services.Notificacao.Interfaces;
using Itau.SZ7.GPS.Admin.VendaAtiva.Data.Interfaces;
using Itau.SZ7.GPS.Admin.VendaAtiva.Data.Repositories;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Itau.SZ7.GPS.Admin.Extensions
{
    public static class StartupExtensions
    {
        public static void GPSDependencyInjectionMap(this IServiceCollection services, IHostingEnvironment hostingEnvironment, IConfiguration Configuration)
        {
            services.AddMemoryCache();

            #region [ serviços ]

            services.AddTransient<HttpRequestHeaderHandler>()
                .AddHttpClient<IGpsHttpClient, GpsHttpClient>()
                .AddHttpMessageHandler<HttpRequestHeaderHandler>();

            services.AddTransient<IAgenciasServices, AgenciasServices>();
            services.AddTransient<IAlavancaServices, AlavancaServices>();
            services.AddSingleton<IAppConfiguration, AppConfiguration>();
            services.AddTransient<IBaixaAderencia, BaixaAderenciaServices>();
            services.AddTransient<ICargaEditarConfiguracoesRepository, CargaEditarConfiguracoesRepository>();
            services.AddTransient<ICargoServices, CargoServices>();
            services.AddTransient<IColaboradorAgirServices, ColaboradorAgirServices>();
            services.AddTransient<IColaboradorServices, ColaboradorServices>();
            services.AddTransient<IConcluidasServices, ConcluidasServices>();
            services.AddTransient<IConfiguracoesStatusServices, ConfiguracoesStatusServices>();
            services.AddSingleton<ICookies, Cookies>();
            services.AddSingleton<IConfigurationBuilder, ConfigurationBuilder>();
            services.AddTransient<IEditarConfiguracoesServices, EditarConfiguracoesServices>();
            services.AddTransient<IEditorParametrosServices, EditorParametrosServices>();
            services.AddTransient<IFeriado, FeriadoServices>();
            services.AddTransient<IFuncionalidadeServices, FuncionalidadeServices>();
            services.AddTransient<INPSServices, NPSServices>();
            services.AddTransient<INPSComentarioServices, NPSComentarioServices>();
            services.AddTransient<INPSRespostaClienteServices, NPSRespostaClienteServices>();

            services.AddTransient<IGerenciadorCargaServices, GerenciadorCargaServices>();
            services.AddTransient<IGradeServices, GradeServices>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddTransient<IHomeTemplateService, HomeTemplateService>();
            services.AddTransient<IInnerLoopLigacoes, InnerLoopLigacoes>();
            services.AddTransient<IInnerLoopArvoreDecisoes, InnerLoopArvoreDecisoes>();
            services.AddTransient<IInnerLoopLiberacaoService, InnerLoopLiberacaoService>();
            services.AddTransient<IICMHistoricoServices, ICMHistoricoServices>();
            services.AddTransient<ILimpaCacheApiServico, LimpaCacheApiServico>();
            services.AddTransient<IMemoryCacheConfiguration, MemoryCacheConfiguration>();
            services.AddTransient<IMetaPersonnaliteServices, MetaPersonnaliteServices>();
            services.AddTransient<IMetaServices, MetaServices>();
            services.AddTransient<INotificacaoServices, NotificacaoServices>();
            services.AddTransient<INPSGlobalPersonnaliteServices, NPSGlobalPersonnaliteServices>();
            services.AddTransient<INPSAgendaPersonnalite, NPSAgendaPersonnaliteServices>();
            services.AddTransient<INPSTransacionalServices, NPSTransacionalServices>();
            services.AddTransient<PermissaoAttribute>();
            services.AddTransient<IPerfilServices, PerfilServices>();
            services.AddTransient<IReclamacoesServices, ReclamacoesServices>();
            services.AddTransient<ISegmentoServices, SegmentoServices>();
            services.AddTransient<ISecurityServices, SecurityServices>();
            services.AddTransient<ISqlFactory, SqlFactory>();
            services.AddSingleton<ISqlDataContext, SqlDataContext>();
            services.AddTransient<ITemplateServices, TemplateServices>();
            services.AddTransient<IVendaAtiva, VendaAtivaServices>();
            services.AddTransient<IVerificaoDados, VerificacaoDados>();
            services.AddTransient<IVisualizarArquivo, VisualizarArquivoServices>();
            services.AddTransient<IVerificadorProducaoAnalitico, VerificadorProducaoAnaliticoServices>();
            services.AddTransient<IVerificadorProducaoRealizado, VerificacaoProducaoRealizadoServices>();
            services.AddTransient<IUserValidationService, UserValidationService>();
            services.AddTransient<IConciliacaoServices, ConciliacaoServices>();
            services.AddTransient<IVerificadorProducaoAnaliticoPersonnaliteServices, VerificadorProducaoAnaliticoPersonnaliteServices>();            
            services.AddTransient<IContratoMetasPersonnaliteServices, ContratoMetasPersonnaliteServices>();
            services.AddTransient<IAcompanhamentoRelatorioServico, AcompanhamentoRelatorioServico>();
            services.AddTransient<IAcompanhamentoRepositorio, AcompanhamentoRepositorio>();

            services.AddTransient<IDiasSemReclamacoesService, DiasSemReclamacoesService>();

            #endregion
            services.AddTransient<IPipelineClienteServices, PipelineClienteServices>();
            services.AddTransient<IPipelineServices, PipelineServices>();
            services.AddTransient<IReclamacoesPersonnaliteServices, ReclamacoesPersonnaliteServices>();
            services.AddTransient<IConfiguracaoVPAnaliticoPersonnnaliteServices, ConfiguracaoVPAnaliticoPersonnnaliteServices>();
            services.AddTransient<IRelatorioCheckoutPendenteServico, RelatorioCheckoutPendenteServico>();
            services.AddTransient<ITemplateSecaoServico, TemplateSecaoServico>();



            #region [ repositorio ]

            services.AddTransient<IAgenciaRepository, AgenciaRepository>();
            services.AddTransient<IAlavancaRepository, AlavancaRepository>();
            services.AddTransient<ICargoRepository, CargoRepository>();
            services.AddTransient<ICarteiraGradeFakeRepository, CarteiraGradeFakeRepository>();
            services.AddTransient<IColaboradorRepository, ColaboradorRepository>();
            services.AddTransient<IColaboradorAgirRepository, ColaboradorAgirRepository>();
            services.AddTransient<IColaboradorPerfilAcessoRepository, ColaboradorPerfilAcessoRepository>();
            services.AddTransient<INPSRepository, NPSRepository>();
            services.AddTransient<INPSComentarioRepository, NPSComentarioRepository>();
            services.AddTransient<INPSRespostaClienteRepository, NPSRespostaClienteRepository>();


            services.AddTransient<IGerenciadorCargaPassoRepository, GerenciadorCargaPassoRepository>();
            services.AddTransient<INotificacoesRepository, NotificacoesRepository>();
            services.AddTransient<IRemetenteRepository, RemetenteRepository>();
            services.AddTransient<IDestinatarioRepository, DestinatarioRepository>();
            services.AddTransient<IReclamacaoRepository, ReclamacaoRepository>();
            services.AddTransient<IVendaAtivaRepository, VendaAtivaRepository>();
            services.AddTransient<IPoloRepository, PoloRepository>();
            services.AddTransient<IPlanejamentoItemGradeRepository, PlanejamentoItemGradeRepository>();
            services.AddTransient<IPlanejamentoCarteiraRepository, PlanejamentoCarteiraRepository>();
            services.AddTransient<IProdutoGradeItemRepository, ProdutoGradeItemRepository>();
            services.AddTransient<IInnerLoopLigacaoRepository, InnerLoopLigacaoRepository>();
            services.AddTransient<IInnerLoopHistoricoRepository, InnerLoopHistoricoRepository>();
            services.AddTransient<IInnerLoopRespostaRepository, InnerLoopRespostaRepository>();
            services.AddTransient<IInnerLoopPerguntaRepository, InnerLoopPerguntaRepository>();
            services.AddTransient<ISegmentoRepository, SegmentoRepository>();
            services.AddTransient<IInnerLoopLiberacaoFuncionalidadeRepository, InnerLoopLiberacaoFuncionalidadeRepository>();
            services.AddTransient<IConfiguracoesStatusRepository, ConfiguracoesStatusRepository>();
            services.AddTransient<ICheckinRepository, CheckinRepository>();
            services.AddTransient<ICheckoutRepository, CheckoutRepository>();
            services.AddTransient<IDelegacaoAcessoRepository, DelegacaoAcessoRepository>();
            services.AddTransient<IFeriadoRepository, FeriadoRepository>();
            services.AddTransient<IFuncionalidadeRepository, FuncionalidadeRepository>();
            services.AddTransient<IGerenciadorCargaConfiguracaoRepository, GerenciadorCargaConfiguracaoRepository>();
            services.AddTransient<IGerenciadorCargaErroRepository, GerenciadorCargaErroRepository>();
            services.AddTransient<IGerenciadorCargaRepository, GerenciadorCargaRepository>();
            services.AddTransient<IGradeCarteiraRepository, GradeCarteiraRepository>();
            services.AddTransient<IHomeTemplateRepository, HomeTemplateRepository>();
            services.AddTransient<ILogApplication, LogApplication>();
            services.AddTransient<ILogRepository, LogRepository>();
            services.AddTransient<INPSTransacionalRepository, NPSTransacionalRepositorio>();
            services.AddTransient<INotificacoesTemplateRepository, NotificacoesTemplateRepository>();
            services.AddTransient<IPerfilPermissaoRepository, PerfilPermissaoRepository>();
            services.AddTransient<IPerfilPermissaoAgenciaRepository, PerfilPermissaoAgenciaRepository>();
            services.AddTransient<IPerfilPermissaoCargoRepository, PerfilPermissaoCargoRepository>();
            services.AddTransient<IPerfilPermissaoCarteiraRepository, PerfilPermissaoCarteiraRepository>();
            services.AddTransient<IPerfilPermissaoColaboradorRepository, PerfilPermissaoColaboradorRepository>();
            services.AddTransient<IPerfilPermissaoSegmentoRepository, PerfilPermissaoSegmentoRepository>();
            services.AddSingleton<IPerfilRepository, PerfilRepository>();
            services.AddTransient<IPlanejamentoItemGradeCarteiraRepository, PlanejamentoItemGradeCarteiraRepository>();
            services.AddTransient<IProducaoRealizadaRepository, ProducaoRealizadaRepository>();
            services.AddTransient<ISecurityRepository, SecurityRepository>();
            services.AddTransient<ISimulaColabRepository, SimulaColabRepository>();
            services.AddTransient<IVerificadorProducaoRepository, VerificadorProducaoRepository>();
            services.AddTransient<IVisaoGerencialAgirConsolidadoRepository, VisaoGerencialAgirConsolidadoRepository>();
            services.AddTransient<IVerificadorProducaoPersonnaliteRepository, VerificadorProducaoPersonnaliteRepository>();
            services.AddTransient<IEstruturaRepository, EstruturaRepository>();
            services.AddTransient<IContratoMetasPersonnaliteRepository, ContratoMetasPersonnaliteRepository>();
            services.AddTransient<IPipelineClienteRepository, PipelineClienteRepository>();
            services.AddTransient<IPipelineRepository, PipelineRepository>();
            services.AddTransient<IReclamacoesPersonnaliteRepository, ReclamacoesPersonnaliteRepository>();
            services.AddTransient<IConfguracaoVPAPersonaliteRepository, ConfguracaoVPAPersonaliteRepository>();
            services.AddTransient<IConciliacaoPersonnaliteRepository, ConciliacaoPersonnaliteRepository>();

            services.AddTransient<IDiasSemReclamacoesRepository, DiasSemReclamacoesRepository>();
            services.AddTransient<IVisaoGerencialRelatorioCheckoutPendenteRepositorio, VisaoGerencialRelatorioCheckoutPendenteRepositorio>();
            services.AddTransient<IVisaoGerencialRelatorioPlanejamentoRepositorio, VisaoGerencialRelatorioPlanejamentoRepositorio>();

            services.AddTransient<ITemplateSecaoRepositorio, TemplateSecaoRepositorio>();

            #endregion
        }
    }
}
