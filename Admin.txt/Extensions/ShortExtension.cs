﻿namespace Itau.SZ7.GPS.Admin.Extensions
{
    public static class ShortExtension
    {
        public static short TryParse(this string value)
        {
            short.TryParse(value, out short result);

            return result;
        }
    }
}
