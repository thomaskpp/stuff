﻿using System;
using System.Globalization;

namespace Itau.SZ7.GPS.Admin.Extensions
{
    public static class DecimalExtension
    {
        public static decimal TryParse(this string value, string culture = "pt-BR")
        {
            decimal.TryParse(value, NumberStyles.Float, CultureInfo.CreateSpecificCulture(culture), out decimal result);
            return result;
        }

        public static decimal Round(this decimal valor, int decimals)
        {
            return Math.Round(valor, decimals);
        }

        public static decimal Round(this decimal valor)
        {
            return Round(valor, 2);
        }

        public static string ToSql(this decimal value)
        {
            return value.ToString(CultureInfo.CreateSpecificCulture("en-us"));
        }
    }
}
