﻿namespace Itau.SZ7.GPS.Admin.Extensions
{
    public static class IntExtension
    {
        public static int TryParse(this string value)
        {
            int.TryParse(value, out int result);

            return result;
        }

        public static int TryParse(this double value)
        {
            int.TryParse(value.ToString(), out int result);

            return result;
        }
    }
}
