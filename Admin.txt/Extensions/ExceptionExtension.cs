﻿using System;

namespace Itau.SZ7.GPS.Admin.Extensions
{
    public static class ExceptionExtension
    {
        public static Exception RetornaInnerException(AggregateException exception)
        {
            if (exception == null)
                return null;
            else if (exception.InnerException == null)
                return exception;
            else
                return RetornaInnerException(exception.InnerException);
        }

        public static Exception RetornaInnerException(Exception exception)
        {
            if (exception == null)
                return null;
            else if (exception.InnerException == null)
                return exception;
            else
                return RetornaInnerException(exception.InnerException);
        }

        public static string RetornaStackTrace(AggregateException exception)
        {
            if (exception == null)
                return string.Empty;
            else if (exception.InnerException == null)
                return exception.StackTrace;
            else
                return RetornaStackTrace(exception.InnerException);
        }

        public static string RetornaStackTrace(Exception exception)
        {
            if (exception == null)
                return string.Empty;
            else if (exception.InnerException == null)
                return exception.StackTrace;
            else
                return RetornaStackTrace(exception.InnerException);
        }
    }
}
