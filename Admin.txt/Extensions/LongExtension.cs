﻿namespace Itau.SZ7.GPS.Admin.Extensions
{
    public static class LongExtension
    {
        public static long TryParse(this string value)
        {
            long.TryParse(value, out long result);

            return result;
        }
    }
}
