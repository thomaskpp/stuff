﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Middlewares
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;

        public ExceptionMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                if ((!string.IsNullOrWhiteSpace(httpContext.Request.ContentType) && httpContext.Request.ContentType.ToLower().Contains("json"))
                    && httpContext.Request.Headers["api-client"].Count > 0)
                {
                    await HandleExceptionAsync(httpContext, ex);
                }
                else
                {
                    await _next(httpContext);
                }
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            var result = JsonConvert.SerializeObject(new { erro = exception.Message });

            return context.Response.WriteAsync(result);
        }
    }
}
