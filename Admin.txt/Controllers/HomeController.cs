﻿using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Itau.SZ7.GPS.Admin.Entities;

namespace Itau.SZ7.GPS.Admin.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.HomeAdmin })]
    public class HomeController : BaseController
    {
        public HomeController(ICookies cookies,
           IConfiguration configuration,
           ISecurityServices securityServices)
           : base(cookies, configuration, securityServices)
        { }

        [Authentication]
        public IActionResult Index()
        {
            SetViewBag();

            return View();
        }
    }
}
