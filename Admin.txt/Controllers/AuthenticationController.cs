﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace Itau.SZ7.GPS.Admin.Controllers
{
    public class AuthenticationController : Controller
    {
        private readonly string _authCookieName;
        private readonly string _funcionalCookieName;
        private string _colaboradorCookieName => "colaborador";
        private readonly ICookies _cookies;
        private readonly string _portalUrl;

        public AuthenticationController(ICookies cookies, IConfiguration configuration)
        {
            _cookies = cookies;
            _authCookieName = configuration.GetSection("AppSettings")["AuthCookieName"];
            _funcionalCookieName = configuration.GetSection("AppSettings")["FuncionalCookieName"];
            _portalUrl = configuration.GetSection("AppSettings")["PortalUrl"];
        }

        [HttpPost]
        public IActionResult Login([FromBody] ColaboradorDto colaborador)
        {
            _cookies.Remove(_authCookieName);

            if (!Request.Headers.ContainsKey("Access-Control-Expose-Headers") ||
                !Request.Headers["Access-Control-Expose-Headers"].ToString().Equals("X-fdad_token"))
            {
                return BadRequest();
            }

            if (!Request.Headers.ContainsKey("fdad_key") ||
                string.IsNullOrEmpty(Request.Headers["fdad_key"].ToString()))
            {
                return BadRequest("Chave não presente");
            }

            _cookies.Gravar(_authCookieName, Request.Headers["fdad_key"].ToString());

            CriarCookieColaborador(colaborador);

            return Ok();
        }

        public IActionResult Logout()
        {
            _cookies.Remove(_authCookieName);
            _cookies.Remove(_funcionalCookieName);
            _cookies.Remove(_colaboradorCookieName);

            return Redirect($"{_portalUrl}logout");
        }

        private void CriarCookieColaborador(ColaboradorDto colaborador)
        {
            if (colaborador == null)
            {
                _cookies.Remove(_colaboradorCookieName);
                return;
            }

            _cookies.Remove(_colaboradorCookieName);
            
            var json = JsonConvert.SerializeObject(colaborador);

            _cookies.Gravar(_colaboradorCookieName, json);
        }
    }
}