﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace Itau.SZ7.GPS.Admin.Controllers
{
    public class ErrorController : BaseController
    {
        public ErrorController(ICookies cookies,
             IConfiguration configuration,
             ISecurityServices securityServices)
             : base(cookies, configuration, securityServices)
        { }

        public IActionResult Index(int? id)
        {
            SetViewBag();

            return View();
        }

        public IActionResult FalhaAcesso([FromServices] ICookies cookies)
        {
            ViewBag.Nomecolaborador = "Colaborador";

            var cookieColaborador = cookies.Ler("colaborador");

            if (!string.IsNullOrWhiteSpace(cookieColaborador))
            {
                var colaborador = JsonConvert.DeserializeObject<ColaboradorDto>(cookieColaborador);
                if (colaborador == null) ViewBag.Nomecolaborador = string.Empty;
                else ViewBag.Nomecolaborador = colaborador.Nome;
            }

            return View("FalhaAcesso");
        }
    }
}