﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Itau.SZ7.GPS.Admin.Controllers
{
    public class BaseController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly ICookies _cookies;
        private readonly ISecurityServices _securityServices;

        private ColaboradorDto _colaboradorLogado;

        public ColaboradorDto Colaborador
        {
            get
            {
                if (_colaboradorLogado is null)
                {
                    string cookieColaborador = _cookies.Ler("colaborador");

                    if (!string.IsNullOrEmpty(cookieColaborador))
                    {
                        _colaboradorLogado = JsonConvert.DeserializeObject<ColaboradorDto>(cookieColaborador);
                    }
                }

                return _colaboradorLogado ?? new ColaboradorDto();
            }
        }

        public GerenciadorCarga GerenciadorCargaAtual { get; set; }

        public BaseController(ICookies cookies,
            IConfiguration configuration,
            ISecurityServices securityServices)
        {
            _configuration = configuration;
            _cookies = cookies;
            _securityServices = securityServices;

            ViewBag.FileVersion = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version;
        }

        /// <summary>
        /// Define Viewbag a ser usada nas Views.
        /// Precisa ser chamada em todas as Actions
        /// </summary>
        public virtual void SetViewBag()
        {
            var funcionalidades = ObterMenu();

            ViewBag.ColaboradorNome = Colaborador.Nome;
            ViewBag.Menu = funcionalidades.Where(x => x.Id != (int)Funcionalidade.Enum.Portal);
            ViewBag.UrlPortal = funcionalidades.FirstOrDefault(x => x.Id == (int)Funcionalidade.Enum.Portal)?.Url ?? string.Empty;
            ViewBag.BaseUrl = Url.Action("Index", "Home", new { area = "" }).TrimEnd('/');
            ViewBag.FileVersion = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version;
        }

        private IEnumerable<PerfilPermissaoResposta> ObterMenu()
        {
            return _securityServices.ObterFuncionalidadesMenu().Result;
        }
    }
}