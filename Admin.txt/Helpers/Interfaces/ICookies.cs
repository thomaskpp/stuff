﻿namespace Itau.SZ7.GPS.Admin.Helpers.Interfaces
{
    public interface ICookies
    {
        void Gravar(string chave, string valor);
        string Ler(string chave);
        void Remove(string chave);
    }
}
