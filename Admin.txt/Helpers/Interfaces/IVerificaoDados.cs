﻿

using Itau.SZ7.GPS.Admin.Enums;

namespace Itau.SZ7.GPS.Admin.Helpers.Interfaces
{
    public interface IVerificaoDados
    {
        bool Validar(string value, Campos campo, bool nulo = false);
        string RetornaErroNuloOuInvalido(string valorColuna);
        void LimpaCache();
    }
}
