﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Entities;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.Net.Http.Headers;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Helpers
{
    public class ExcelOutputFormatter : OutputFormatter
    {
        public ExcelOutputFormatter()
        {
            SupportedMediaTypes.Add(MediaTypeHeaderValue.Parse("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        }

        public bool CanWriteType(OutputFormatterCanWriteContext context) { return typeof(IEnumerable<object>).IsAssignableFrom(context.ObjectType); }

        public override Task WriteResponseBodyAsync(OutputFormatterWriteContext context)
        {
            if (context == null) { throw new ArgumentNullException(nameof(context)); }
            var excelStream = CreateExcelFile(context.Object as BaseUploadViewModel);
            var response = context.HttpContext.Response;
            response.ContentLength = excelStream.Length; return response.Body.WriteAsync(excelStream.ToArray()).AsTask();
        }

        public override void WriteResponseHeaders(OutputFormatterWriteContext context)
        {
            if (context == null) { throw new ArgumentNullException(nameof(context)); }
            var fileName = (context.Object as IEnumerable<object>).GetType().GetGenericArguments()[0].Name;
            context.HttpContext.Response.Headers["Content-Disposition"] = new ContentDispositionHeaderValue("attachment") { FileName = fileName + ".xlsx" }.ToString(); context.HttpContext.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        }

        public MemoryStream CreateExcelFile(BaseUploadViewModel model)
        {
            using (var package = new ExcelPackage())
            {
                var linha = 2;
                var wsValidacao = package.Workbook.Worksheets.Add("Validação");
                var wsRemocao = package.Workbook.Worksheets.Add("Remoção");
                var wsInsercao = package.Workbook.Worksheets.Add("Inserção");

                wsValidacao.Cells["A1"].Value = "Linha";
                wsValidacao.Cells["B1"].Value = "Erro";

                wsRemocao.Cells["A1"].Value = "Linha";
                wsRemocao.Cells["B1"].Value = "Erro";

                wsInsercao.Cells["A1"].Value = "Linha";
                wsInsercao.Cells["B1"].Value = "Erro";


                //foreach (var erroValidacao in model.ErrosValidacao)
                //{
                //    foreach (var erroLinha in erroValidacao.UploadRetornoLista)
                //    {
                //        foreach (var erroColuna in erroLinha.Colunas)
                //        {
                //            wsValidacao.Cells[$"A{linha}"].Value = erroLinha.Linha;
                //            wsValidacao.Cells[$"B{linha}"].Value = erroColuna.Coluna;
                //            wsValidacao.Cells[$"C{linha}"].Value = erroColuna.Descricao;
                //            wsValidacao.Cells[$"D{linha}"].Value = erroColuna.Detalhe;
                //        }
                //    }

                //    linha++;
                //}

                //linha = 2;

                //foreach (var erroRemocao in model.ErrosRemocao)
                //{
                //    foreach (var erroLinha in erroRemocao.UploadRetornoLista)
                //    {
                //        foreach (var erroColuna in erroLinha.Colunas)
                //        {
                //            wsRemocao.Cells[$"A{linha}"].Value = erroLinha.Linha;
                //            wsRemocao.Cells[$"B{linha}"].Value = erroColuna.Coluna;
                //            wsRemocao.Cells[$"C{linha}"].Value = erroColuna.Descricao;
                //            wsRemocao.Cells[$"D{linha}"].Value = erroColuna.Detalhe;
                //        }
                //    }

                //    linha++;
                //}

                //linha = 2;

                //foreach (var erroInsercao in model.ErrosInsercao)
                //{
                //    foreach (var erroLinha in erroInsercao.UploadRetornoLista)
                //    {
                //        foreach (var erroColuna in erroLinha.Colunas)
                //        {
                //            wsInsercao.Cells[$"A{linha}"].Value = erroLinha.Linha;
                //            wsInsercao.Cells[$"B{linha}"].Value = erroColuna.Coluna;
                //            wsInsercao.Cells[$"C{linha}"].Value = erroColuna.Descricao;
                //            wsInsercao.Cells[$"D{linha}"].Value = erroColuna.Detalhe;
                //        }
                //    }

                //    linha++;
                //}


                return new MemoryStream(package.GetAsByteArray());
            }
        }

        public byte[] CreateExcelFileAsByte(BaseUploadViewModel model)
        {
            using (var package = new ExcelPackage())
            {
                var linha = 2;
                var wsValidacao = package.Workbook.Worksheets.Add("Validação");
                var wsRemocao = package.Workbook.Worksheets.Add("Remoção");
                var wsInsercao = package.Workbook.Worksheets.Add("Inserção");

                wsValidacao.Cells["A1"].Value = "Linha";
                wsValidacao.Cells["B1"].Value = "Erro";

                wsRemocao.Cells["A1"].Value = "Linha";
                wsRemocao.Cells["B1"].Value = "Erro";

                wsInsercao.Cells["A1"].Value = "Linha";
                wsInsercao.Cells["B1"].Value = "Erro";


                //foreach (var erroValidacao in model.ErrosValidacao)
                //{
                //    foreach (var erroLinha in erroValidacao.UploadRetornoLista)
                //    {
                //        foreach (var erroColuna in erroLinha.Colunas)
                //        {
                //            wsValidacao.Cells[$"A{linha}"].Value = erroLinha.Linha;
                //            wsValidacao.Cells[$"B{linha}"].Value = erroColuna.Coluna;
                //            wsValidacao.Cells[$"C{linha}"].Value = erroColuna.Descricao;
                //            wsValidacao.Cells[$"D{linha}"].Value = erroColuna.Detalhe;
                //        }
                //    }

                //    linha++;
                //}

                //linha = 2;

                //foreach (var erroRemocao in model.ErrosRemocao)
                //{
                //    foreach (var erroLinha in erroRemocao.UploadRetornoLista)
                //    {
                //        foreach (var erroColuna in erroLinha.Colunas)
                //        {
                //            wsRemocao.Cells[$"A{linha}"].Value = erroLinha.Linha;
                //            wsRemocao.Cells[$"B{linha}"].Value = erroColuna.Descricao;
                //            wsRemocao.Cells[$"C{linha}"].Value = erroColuna.Detalhe;
                //        }
                //    }

                //    linha++;
                //}

                //linha = 2;

                //foreach (var erroInsercao in model.ErrosInsercao)
                //{
                //    foreach (var erroLinha in erroInsercao.UploadRetornoLista)
                //    {
                //        foreach (var erroColuna in erroLinha.Colunas)
                //        {
                //            wsInsercao.Cells[$"A{linha}"].Value = erroLinha.Linha;
                //            wsInsercao.Cells[$"B{linha}"].Value = erroColuna.Descricao;
                //            wsInsercao.Cells[$"C{linha}"].Value = erroColuna.Detalhe;
                //        }
                //    }

                //    linha++;
                //}


                return package.GetAsByteArray();
            }
        }

    }
}
