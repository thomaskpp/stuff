﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

public static class MultiThreadingHelper
{
    
    public static List<Task<T2>> GerarTasks<T, T2>(List<T> lista, Func<List<T>, T2> funcaoChamar, int maximoThreads = 5) where T : class where T2: class
    {
        int pegar = lista.Count / maximoThreads;
        int pegos = 0;
        int ultimoIndex = (lista.Count - 1);
        List<Task<T2>> listaTasks = new List<Task<T2>>();

        while (pegos < ultimoIndex)
        {
            Task<T2> t = null;
            int pegosAgora = 0;

            if ((pegos + pegar) > ultimoIndex)
            {
                var listaAtual = lista.GetRange(pegos, (ultimoIndex - pegos));

                t = new Task<T2>(() => funcaoChamar(listaAtual));
                pegosAgora = (ultimoIndex - pegos);
            }
            else if ((pegos + pegar) < ultimoIndex)
            {
                var listaAtual = lista.GetRange(pegos, pegar);

                t = new Task<T2>(() => funcaoChamar(listaAtual));
                pegosAgora = pegar;
            }
            else
            {
                break;
            }
            pegos += pegosAgora;

            t.Start();

            listaTasks.Add(t);
        }

        return listaTasks;

    }

    public static List<Task<T2>> GerarTasksNotNull<T, T2>(List<T> lista, Func<List<T>, T2> funcaoChamar, int maximoThreads = 5) where T : class where T2 : struct
    {
        int pegar = lista.Count / maximoThreads;
        int pegos = 0;
        int ultimoIndex = (lista.Count - 1);
        List<Task<T2>> listaTasks = new List<Task<T2>>();

        while (pegos < ultimoIndex)
        {
            Task<T2> t = null;
            int pegosAgora = 0;

            if ((pegos + pegar) > ultimoIndex)
            {
                var listaAtual = lista.GetRange(pegos, (ultimoIndex - pegos));

                t = new Task<T2>(() => funcaoChamar(listaAtual));
                pegosAgora = (ultimoIndex - pegos);
            }
            else if ((pegos + pegar) < ultimoIndex)
            {
                var listaAtual = lista.GetRange(pegos, pegar);

                t = new Task<T2>(() => funcaoChamar(listaAtual));
                pegosAgora = pegar;
            }
            else
            {
                break;
            }
            pegos += pegosAgora;

            listaTasks.Add(t);
        }

        return listaTasks;

    }

}
