﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Helpers
{
    public static class SqlDataReaderExtension
    {
        public static string SafeGetString(this SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
            {
                return reader.GetString(colIndex);
            }

            return string.Empty;
        }

        public static int SafeGetByte(this SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
            {
                return reader.GetByte(colIndex);
            }

            return 0;
        }

        public static Int16 SafeGetInt16(this SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
            {
                return reader.GetInt16(colIndex);
            }

            return 0;
        }

        public static int SafeGetInt32(this SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
            {
                return reader.GetInt32(colIndex);
            }

            return 0;
        }

        public static decimal SafeGetDecimal(this SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
            {
                return reader.GetDecimal(colIndex);
            }

            return 0M;
        }

        public static Int64 SafeGetInt64(this SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
            {
                return reader.GetInt64(colIndex);
            }

            return 0;
        }

        public static DateTime? SafeGetDateTime(this SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
            {
                return reader.GetDateTime(colIndex);
            }

            return null;
        }

        public static DateTime SafeGetDateTimeNotNull(this SqlDataReader reader, int colIndex)
        {
            var result = new DateTime();

            if (!reader.IsDBNull(colIndex))
            {
                return reader.GetDateTime(colIndex);
            }

            return result;
        }

        public static TimeSpan SafeGetTimeSpan(this SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
            {
                return reader.GetTimeSpan(colIndex);
            }

            return new TimeSpan();
        }

        public static bool SafeGetBoolean(this SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
            {
                return reader.GetBoolean(colIndex);
            }

            return false;
        }
    }
}
