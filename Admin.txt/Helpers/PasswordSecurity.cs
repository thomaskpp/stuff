﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Helpers
{
    internal static class PasswordSecurity
    {
        private static string userOpen = "abrirsenha";
        private static string hashOpen = "pwsd1390%%%%3aas";

        internal static void GetUserAndPassword(string base64Key, out string usuarioServico, out string senhaServico)
        {
            byte[] bufUserKeys = Convert.FromBase64String(base64Key);
            string userkey = UTF8Encoding.UTF8.GetString(bufUserKeys);
            string[] infos = userkey.Split(':');
            usuarioServico = infos[0];
            senhaServico = infos[1];
        }

        internal static bool ValidateToken(string tokenKey, out string funcional)
        {
            bool isValid = false;
            funcional = string.Empty;

            if (string.IsNullOrEmpty(tokenKey) || tokenKey == "null")
                return false;

            string[] tokens = tokenKey.Split(new char[] { ']', ':', '[' }, StringSplitOptions.RemoveEmptyEntries);
            string tokenSecret = Encrypt.DecryptString(tokens[1], string.Format("{0}:{1}", userOpen, hashOpen));
            string[] secures = tokenSecret.Split(':');
            string token = Encrypt.DecryptString(tokens[0], string.Format("{0}:{1}", secures[0], secures[1]));
            string[] infos = token.Split(';');

            long ticks;
            long.TryParse(infos[0].Replace("d:", ""), out ticks);

            bool.TryParse(infos[1].Replace("a:", ""), out isValid);

            if (isValid)
            {
                DateTime d = new DateTime(ticks);
                var dif = d - DateTime.Now;
                if (dif.TotalSeconds < 0)
                    isValid = false;
            }

            if (isValid)
            {
                string user = infos[2].Replace("k:", "");
                funcional = user.Split(new char[] { ']', ':', '[' }, StringSplitOptions.RemoveEmptyEntries)[0];
            }

            return isValid;
        }

        internal static string CreateTokenAuthentication(bool isAuthorized, string u, string username, string password)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("d:{0};", DateTime.Today.AddDays(1d).Ticks);
            sb.AppendFormat("a:{0};", isAuthorized);
            sb.AppendFormat("k:{0};", u);
            string token = Encrypt.EncryptString(sb.ToString(), string.Format("{0}:{1}", username, password));
            string tokenSecret = Encrypt.EncryptString(string.Format("{0}:{1}", username, password), string.Format("{0}:{1}", userOpen, hashOpen));
            return string.Concat(token, ":", tokenSecret);
        }
    }
}
