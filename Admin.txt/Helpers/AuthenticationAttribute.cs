﻿using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using System;

namespace Itau.SZ7.GPS.Admin.Helpers
{
    [AttributeUsage(AttributeTargets.Method)]
    public class AuthenticationAttribute : TypeFilterAttribute
    {
        public AuthenticationAttribute() : base(typeof(AuthenticationAttributeImpl))
        {

        }

        public class AuthenticationAttributeImpl : IActionFilter
        {
            private readonly string _authCookieName;
            private readonly string _funcionalCookieName;
            private readonly string _portalUrl;
            private readonly ICookies _cookies;
            private readonly IUserValidationService _userValidationService;
            private readonly string _environment;
            private readonly IConfiguration _configuration;

            public AuthenticationAttributeImpl(ICookies cookies, IConfiguration configuration, IUserValidationService userValidationService, IHostingEnvironment env)
            {
                _configuration = configuration;
                _cookies = cookies;
                _authCookieName = configuration.GetSection("AppSettings")["AuthCookieName"];
                _funcionalCookieName = configuration.GetSection("AppSettings")["FuncionalCookieName"];
                _portalUrl = configuration.GetSection("AppSettings")["PortalUrl"];
                _userValidationService = userValidationService;

                var environmentVariableName = configuration.GetSection("AppSettings")["EnviromentVariableName"];
                _environment = Environment.GetEnvironmentVariable(environmentVariableName, EnvironmentVariableTarget.Machine);

                if (string.IsNullOrEmpty(_environment))
                    _environment = Environment.GetEnvironmentVariable(environmentVariableName);

                if (string.IsNullOrEmpty(_environment))
                    _environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            }

            public void OnActionExecuted(ActionExecutedContext context)
            {
                
            }

            public void OnActionExecuting(ActionExecutingContext context)
            {
                var simulaAutenticacao = _configuration.GetValue("AppSettings:SimulaAutenticacao:Ativo", false);
                var simulaAutenticacaoFuncional = _configuration.GetValue("AppSettings:SimulaAutenticacao:Funcional", "007577711");

                //para não precisar logar em ambiente local
                if (simulaAutenticacao)//|| _environment.Equals("Development")
                {
                    _cookies.Gravar(_funcionalCookieName, simulaAutenticacaoFuncional);
                    return;
                }

                var token = _cookies.Ler(_authCookieName);
                var isValid = _userValidationService.IsValidToken(token, out string funcional);

                if (!isValid)
                {
                    _cookies.Remove(_authCookieName);
                    context.Result = new RedirectResult($"{_portalUrl}login");
                }
            }
        }
        
    }
}
