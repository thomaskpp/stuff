﻿using System.Collections.Generic;
using System.Data;

namespace Itau.SZ7.GPS.Admin.Helpers
{
    public class Tabela
    {
        public static DataTable CriaTabelaDeInteiros(IEnumerable<int> inteiros)
        {
            return CriaTabelaDeInteiros(inteiros, "Id");
        }

        public static DataTable CriaTabelaDeInteiros(IEnumerable<int> inteiros, string nomeColuna)
        {
            return CriaTabela(inteiros, nomeColuna);
        }

        public static DataTable CriaTabelaDeInteiros(IEnumerable<long> inteiros, string nomeColuna)
        {
            return CriaTabela(inteiros, nomeColuna);
        }

        public static DataTable CriaTabelaDeVarchar(IEnumerable<string> valores, string nomeColuna)
        {
            return CriaTabela(valores, nomeColuna);
        }

        private static DataTable CriaTabela<T>(IEnumerable<T> valores, string nomeColuna)
        {
            var tabela = new DataTable();
            tabela.Columns.Add(nomeColuna, typeof(T));

            foreach (var valor in valores)
                tabela.Rows.Add(valor);

            return tabela;
        }
    }
}
