﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Itau.SZ7.GPS.Admin.Helpers
{
    public class Misc
    {

        public static List<string> LerFileStreamComoTexto(MemoryStream fileStream, bool pulaHeader)
        {
            var resultado = new List<string>();

            fileStream.Position = 0;
            var reader = new StreamReader(fileStream, Encoding.GetEncoding("iso-8859-1"));

            if (pulaHeader)
                reader.ReadLine();

            while (!reader.EndOfStream)
            {
                resultado.Add(reader.ReadLine());
            }

            return resultado;
        }

        public static ExcelPackage LerFileStreamComoExcel(MemoryStream fileStream)
        {
            return new ExcelPackage(fileStream);
        }

        public static string ExtraiHtmlBody(string html)
        {
            RegexOptions options = RegexOptions.IgnoreCase | RegexOptions.Singleline;
            Regex regx = new Regex("<body>(?<tagBody>.*)</body>", options);
            Match match = regx.Match(html);

            if (match.Success)
                return match.Groups["tagBody"].Value;

            return string.Empty;
        }
    }

    public static class EnhancedMath
    {
        private delegate decimal RoundingFunction(decimal value);

        private enum RoundingDirection { Up, Down }

        public static decimal RoundUp(decimal value, int precision)
        {
            return Round(value, precision, RoundingDirection.Up);
        }

        public static decimal RoundDown(decimal value, int precision)
        {
            return Round(value, precision, RoundingDirection.Down);
        }

        private static decimal Round(decimal value, int precision,
                    RoundingDirection roundingDirection)
        {
            RoundingFunction roundingFunction;
            if (roundingDirection == RoundingDirection.Up)
                roundingFunction = Math.Ceiling;
            else
                roundingFunction = Math.Floor;
            value *= Convert.ToDecimal(Math.Pow(10, precision));
            value = roundingFunction(value);
            return value * Convert.ToDecimal(Math.Pow(10, -1 * precision));
        }
    }
}