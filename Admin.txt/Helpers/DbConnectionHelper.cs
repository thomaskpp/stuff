﻿using Itau.ST.Data;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Helpers
{
    public static class DbConnectionHelper
    {
        public static string GetSqlConnection(string itauDbConnection)
        {

            DbProviderFactory factory = Itau.ST.Data.SqlClient.ItauSqlClientFactory.Instance;
            ItauDbConnection connection = (ItauDbConnection)factory.CreateConnection();
            connection.ConnectionString = itauDbConnection;
            var sqlConnection = connection.GetTypedConnection<System.Data.SqlClient.SqlConnection>();
            return sqlConnection.ConnectionString;
        }
    }
}
