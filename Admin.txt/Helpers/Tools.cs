﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Repositories;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Helpers
{
    public static class Tools
    {
        public static List<string> LerLinhasArquivo(List<GerenciadorCarga> gerenciadorCargas, bool contemCabecalho = true)
        {
            var registros = new List<string>();

            foreach (var gerenciador in gerenciadorCargas)
            {
                StreamReader reader;
                int linha = 0;
                var linhas = new List<int>();

                var dtUltimaGravacaoGerenciador = DateTime.Now;
                var arquivoExtensao = "";

                gerenciador.FileStream.Position = 0;
                reader = new StreamReader(gerenciador.FileStream, Encoding.GetEncoding("iso-8859-1"));

                linha = 1;
                linhas = new List<int>();
                registros = new List<string>();
                arquivoExtensao = Path.GetExtension(gerenciador.Arquivo);

                if (arquivoExtensao.Equals(".csv"))
                {
                    while (!reader.EndOfStream)
                    {
                        //pula cabeçalho
                        if (contemCabecalho && linha.Equals(1))
                        {
                            linha++;
                            reader.ReadLine();
                            continue;
                        }

                        linhas.Add(linha);
                        registros.Add(reader.ReadLine());
                    }
                }
            }

            return registros;
        }
        public static TipoEstrutura TiposDeEstrutura(List<string> registros, int coluna)
        {
            List<string> estruturas = new List<string>();

            foreach (var itemRegistro in registros)
            {
                var arrayColunas = itemRegistro.Split(';');

                if (!string.IsNullOrEmpty(arrayColunas[coluna]))
                {
                    estruturas.Add(arrayColunas[coluna].ToUpper().Trim());

                }
            }

            estruturas = estruturas.Distinct().ToList();

            if (estruturas.Count == 1)
            {
                if (estruturas.First() == "COMERCIAL")
                {
                    return TipoEstrutura.Comercial;

                }
                else
                {
                    return TipoEstrutura.Operacional;

                }
            }
            else
            {
                return TipoEstrutura.Todos;
            }
        }
    }
}
