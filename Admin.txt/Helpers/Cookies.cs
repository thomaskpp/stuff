﻿using Microsoft.AspNetCore.Http;
using System;

namespace Itau.SZ7.GPS.Admin.Helpers
{
    public class Cookies : Interfaces.ICookies
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public Cookies(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public void Gravar(string chave, string valor)
        {
            CookieOptions option = new CookieOptions();
            option.Expires = DateTime.Now.AddDays(1);
            option.Path = "/";
            option.SameSite = SameSiteMode.None;
            option.Secure = false;

            _httpContextAccessor?.HttpContext?.Response?.Cookies?.Append(chave, valor, option);
        }

        public string Ler(string chave)
        {
            return _httpContextAccessor?.HttpContext?.Request?.Cookies[chave] ?? "";
        }

        public void Remove(string chave)
        {
            _httpContextAccessor?.HttpContext?.Response?.Cookies?.Delete(chave);
        }
    }
}
