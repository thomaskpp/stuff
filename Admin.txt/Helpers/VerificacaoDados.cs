﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;

using Itau.SZ7.GPS.Admin.Repositories;
using Itau.SZ7.GPS.Admin.Domain.Notificacao.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Helpers
{
    public class VerificacaoDados : IVerificaoDados
    {
        private readonly string[] _Segmentos = new string[] { "IA", "IU", "EMP4", "AGENCIAS", "UNICLASS", "EMPRESAS", "EMP 4", "IP" };
        private readonly IPlanejamentoItemGradeCarteiraRepository _planejamentoItemGradeCarteiraRepository;
        private readonly IAgenciaRepository _agenciaRepository;
        private readonly IRemetenteRepository _remetenteRepository;
        private readonly INotificacoesRepository _notificacaoRepository;
        private readonly IColaboradorRepository _colaboradorRepository;
        private List<Agencia> _agenciasValidas = new List<Agencia>();
        private List<Notificacao> notificacoesDB;

        public VerificacaoDados(IPlanejamentoItemGradeCarteiraRepository planejamentoItemGradeCarteiraRepository,
            IAgenciaRepository agenciaRepository,
            IColaboradorRepository colaboradorRepository,
            IRemetenteRepository remetenteRepository,
            INotificacoesRepository notificacaoRepository
            )
        {
            _planejamentoItemGradeCarteiraRepository = planejamentoItemGradeCarteiraRepository;
            _agenciaRepository = agenciaRepository;
            _colaboradorRepository = colaboradorRepository;
            _remetenteRepository = remetenteRepository;
            _notificacaoRepository = notificacaoRepository;
        }

        /// <summary>
        /// Valida os valores fornecidos de acordo com o nome do campo
        /// </summary>
        /// <param name="value"></param>
        /// <param name="campo"></param>
        /// <returns></returns>
        public bool Validar(string value, Campos campo, bool nulo = false)
        {
            //As validações ocorrem sempre na negativa
            //Se o campo não estiver mapeado, ele é valido

            var result = true;
            int intValue;
            long longValue;
            decimal decimalValue;
            DateTime dateTimeValue;

            try
            {
                switch (campo)
                {
                    case Campos.Long:
                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !long.TryParse(value, out longValue)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.Integer:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !int.TryParse(value, out intValue)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.Decimal:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !decimal.TryParse(value, out decimalValue)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.Agencia:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !int.TryParse(value, out intValue)
                            || intValue <= 0
                            || intValue > 99999
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.AgenciaComPlanejamento:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !int.TryParse(value, out intValue)
                            || intValue <= 0
                            || intValue > 99999
                            || !AgenciaExistePlanejamento(intValue)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.Funcional:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !int.TryParse(value, out intValue)
                            || !FuncionalExiste(value.PadLeft(9, '0'))
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.Canal:

                        if (!nulo && string.IsNullOrWhiteSpace(value))
                        {
                            return false;
                        }

                        break;

                    case Campos.Carteira:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !int.TryParse(value, out intValue)
                            || intValue <= 0
                            || intValue > 999
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.CarteiraColaborador:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            //|| !CarteiraExisteColaborador(value)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.CodigoItem:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !int.TryParse(value, out intValue)
                            || intValue <= 0
                            || intValue > 9999
                            || !ItemExiste(intValue)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.ClienteAgencia:

                        if (!string.IsNullOrWhiteSpace(value)
                            && (!int.TryParse(value, out intValue)
                                || intValue <= 0
                                || intValue > 99999)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.DataContabilizacao:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !DateTime.TryParse(value, out dateTimeValue)
                            || dateTimeValue.Equals(DateTime.MinValue))
                        {
                            return false;
                        }

                        break;

                    case Campos.DataReferencia:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !DateTime.TryParse(value, out dateTimeValue)
                            || dateTimeValue.Equals(DateTime.MinValue))
                        {
                            return false;
                        }

                        break;

                    case Campos.NomeProduto:

                        if (!nulo && string.IsNullOrWhiteSpace(value))
                        {
                            return false;
                        }

                        break;

                    case Campos.Segmento:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !_Segmentos.Contains(value))
                        {
                            return false;
                        }

                        break;

                    case Campos.Status:

                        if (!nulo && string.IsNullOrWhiteSpace(value))
                        {
                            return false;
                        }

                        break;

                    case Campos.ValorPonderado:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !decimal.TryParse(value, out decimalValue)
                            || decimalValue <= 0
                            || decimalValue >= 100)
                        {
                            return false;
                        }

                        break;

                    case Campos.ValorProducao:

                        if (!string.IsNullOrWhiteSpace(value) &&
                            (!decimal.TryParse(value, out decimalValue)
                            || decimalValue < 0
                            || decimalValue >= 10000000))
                        {
                            return false;
                        }

                        break;

                    case Campos.ValorProducaoPonderada:

                        if (!string.IsNullOrWhiteSpace(value) &&
                            (!decimal.TryParse(value, out decimalValue)
                            || decimalValue < 0
                            || decimalValue >= 100000000))
                        {
                            return false;
                        }

                        break;

                    case Campos.ICM:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !decimal.TryParse(value, out decimalValue)
                            || decimalValue < 0)
                        {
                            return false;
                        }

                        break;

                    case Campos.ValorPontuacao:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !decimal.TryParse(value, out decimalValue)
                            || decimalValue < 0)
                        {
                            return false;
                        }

                        break;

                    case Campos.Regiao:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !int.TryParse(value, out intValue)
                            || intValue < 0
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.Platger:

                        if (!string.IsNullOrWhiteSpace(value)
                            && (!int.TryParse(value, out intValue)
                                || intValue <= 0)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.Alavancas:

                        if (!nulo && string.IsNullOrWhiteSpace(value))
                        {
                            return false;
                        }

                        break;

                    case Campos.ICMCiclo:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !decimal.TryParse(value.Replace("%", ""), out decimalValue)
                            || decimalValue < 0
                            || decimalValue > 100)
                        {
                            return false;
                        }

                        break;

                    case Campos.QuantidadeInvalido:

                        if (!string.IsNullOrWhiteSpace(value)
                            && (!int.TryParse(value, out intValue)
                                || intValue <= 0
                                || intValue > 99999)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.QuantidadeNeutro:

                        if (!string.IsNullOrWhiteSpace(value)
                          && (!int.TryParse(value, out intValue)
                              || intValue < 0
                              || intValue > 99999)
                          )
                        {
                            return false;
                        }

                        break;

                    case Campos.QuantidadePromotor:

                        if (!string.IsNullOrWhiteSpace(value)
                            && (!int.TryParse(value, out intValue)
                                || intValue < 0
                                || intValue > 99999)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.ValoresAlavancas:

                        if (!string.IsNullOrWhiteSpace(value) &&
                            (!decimal.TryParse(value, out decimalValue)
                            || decimalValue < 0
                            || decimalValue >= 100000000))
                        {
                            return false;
                        }

                        break;

                    case Campos.RemetenteID:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !long.TryParse(value, out longValue)
                            || longValue <= 0
                            || !RemetenteExiste(longValue)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.NotificacaoCodigoExibicao:

                        var tipoNotificacao = new TipoExibicaoNotificacao();
                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !Enum.TryParse(value.Trim(), true, out tipoNotificacao))
                        {
                            return false;
                        }

                        break;

                    case Campos.NotificacaoTipoExibicao:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !long.TryParse(value, out longValue)
                            || longValue <= 0
                            || !NotificacaoTipoExibicaoValido(longValue)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.NotificacaoCodigo:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !long.TryParse(value, out longValue)
                            || longValue <= 0
                            || !NotificacaoExiste(longValue)
                            )
                        {
                            return false;
                        }

                        break;

                    case Campos.String:

                        if (!nulo && string.IsNullOrWhiteSpace(value))
                        {
                            return false;
                        }

                        break;

                    case Campos.VendaAtiva:

                        if (!nulo && string.IsNullOrWhiteSpace(value))
                        {
                            return false;
                        }

                        break;

                    case Campos.Genero:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                             || !GeneroExiste(value))
                        {
                            return false;
                        }

                        break;

                    case Campos.DataNascimento:

                        if ((!nulo && string.IsNullOrWhiteSpace(value))
                            || !DateTime.TryParse(value, out dateTimeValue)
                            || !DataNascimentoExiste(dateTimeValue))
                        {
                            return false;
                        }

                        break;
                    case Campos.Porcentagem:

                        if (!nulo && string.IsNullOrWhiteSpace(value))
                        {

                        }
                        else if(!nulo)
                        {
                            value = value.Replace("%", "");
                            if (!decimal.TryParse(value, out decimalValue))
                            {
                                return false;
                            }
                        }
                        
                        break;

                }
            }
            catch
            {
                result = false;
            }

            return result;

        }

        public string RetornaErroNuloOuInvalido(string valorColuna)
        {
            if (string.IsNullOrWhiteSpace(valorColuna))
            {
                return "Valor não informado";
            }
            else
            {
                return $"O valor \"{valorColuna}\" não é válido";
            }
        }

        public bool DataNascimentoExiste(DateTime date)
        {
            var valida = date.Year;

            if (valida >= 1900)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void LimpaCache()
        {
            _agenciasValidas = new List<Agencia>();
            notificacoesDB = null;
        }

        //private bool AgenciaExiste(int codigoAgencia)
        //{
        //    if (!_agenciasValidas.Any())
        //    {
        //        _agenciasValidas = _agenciaRepository.GetAgencias().ToList();
        //    }

        //    return _agenciasValidas.Any(x => x.CodigoAgencia.Equals(codigoAgencia));
        //}

        private bool AgenciaExistePlanejamento(int codigoAgencia)
        {
            return _planejamentoItemGradeCarteiraRepository.AgenciaExisteFromCache(codigoAgencia);
        }

        private bool FuncionalExiste(string funcional)
        {
            return _planejamentoItemGradeCarteiraRepository.FuncionalExistenteFromCache(funcional);
        }

        private bool CarteiraExistePlanejamento(string carteira)
        {
            return _planejamentoItemGradeCarteiraRepository.CarteiraExisteFromCache(carteira);
        }

        //private bool CarteiraExisteColaborador(string carteira)
        //{
        //    return _colaboradorRepository.ExisteCarteira(carteira);
        //}

        private bool ItemExiste(int codigoItem)
        {
            return _planejamentoItemGradeCarteiraRepository.ItemExisteFromCache(codigoItem);
        }

        private bool GeneroExiste(string genero)
        {
            if (genero == "M" || genero == "F")
            {

                return true;
            }
            else
            {
                return false;
            }
        }

        private bool RemetenteExiste(long idRemetente)
        {
            return _remetenteRepository.RemetenteExisteFromCache(idRemetente);
        }

        private bool NotificacaoTipoExibicaoValido(long codigoNotificacao)
        {
            return _notificacaoRepository.NotificacaoTipoExibicao(codigoNotificacao) != null;
        }

        private bool NotificacaoExiste(long codigoNotificacao)
        {
            if (notificacoesDB == null)
                notificacoesDB = _notificacaoRepository.GetNotificacoes();

            return notificacoesDB.Any(x => x.Codigo.Equals(codigoNotificacao));
        }

    }
}
