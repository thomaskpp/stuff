﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Helpers;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;

namespace Itau.SZ7.GPS.Admin.Configuration
{
    public class AppConfiguration : IAppConfiguration
    {
        private IConfigurationSection appSetting;
        private IConfigurationSection connectionString;
        private IConfigurationSection ldapSettings;


        public AppConfiguration(IConfiguration configuration, IConfigurationBuilder configurationBuilder)
        {
            var environmentVariableName = configuration.GetSection("AppSettings")["EnviromentVariableName"];
            var environment = Environment.GetEnvironmentVariable(environmentVariableName, EnvironmentVariableTarget.Machine);

            if (string.IsNullOrEmpty(environment))
                environment = Environment.GetEnvironmentVariable(environmentVariableName);

            if (string.IsNullOrEmpty(environment))
                environment = configuration[environmentVariableName];

            if (string.IsNullOrEmpty(environment))
                environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            if (string.IsNullOrEmpty(environment))
                environment = configuration["ASPNETCORE_ENVIRONMENT"];


            CreateConfiguration(configurationBuilder, configuration, environment);
        }

        private void CreateConfiguration(IConfigurationBuilder configurationBuilder, IConfiguration config, string environmentName)
        {
            configurationBuilder.AddConfiguration(config);
            configurationBuilder.SetBasePath(Directory.GetCurrentDirectory());
            configurationBuilder
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{environmentName}.json", optional: true, reloadOnChange: true);


            var root = configurationBuilder.Build();

            connectionString = root.GetSection("ConnectionStrings");
            appSetting = root.GetSection("AppSettings");
            ldapSettings = root.GetSection("LDAPSettings");

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GetApplicationSettings(string key)
        {
            return appSetting[key];
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GetConnectionStrings(string key)
        {
            var sqlConnection = connectionString[key];
           sqlConnection = DbConnectionHelper.GetSqlConnection(sqlConnection);

            return sqlConnection;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GetLDAPSettings(string key)
        {
            return ldapSettings[key];
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string GetContentRootPath()
        {
            return string.Empty;
        }
    }
}
