﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Configuration
{
    public class MemoryCacheConfiguration : IMemoryCacheConfiguration
    {
        private readonly IAppConfiguration _appConfiguration;
        private const string DefaultCacheExpiration = "DefaultCacheExpiration";

        public MemoryCacheConfiguration(IAppConfiguration appConfiguration)
        {
            _appConfiguration = appConfiguration;
        }

        public MemoryCacheEntryOptions GetConfiguracaoCache(string cacheKey)
        {
            double cacheExpiration = 0;

            double.TryParse(_appConfiguration.GetApplicationSettings(cacheKey), out cacheExpiration);

            if (cacheExpiration == 0)
                double.TryParse(_appConfiguration.GetApplicationSettings(DefaultCacheExpiration), out cacheExpiration);

            MemoryCacheEntryOptions memoryCacheEntryOptions = new MemoryCacheEntryOptions { SlidingExpiration = TimeSpan.FromMinutes(cacheExpiration) };
            return memoryCacheEntryOptions;
        }
    }
}
