﻿namespace Itau.SZ7.GPS.Admin.Configuration.Interface
{
    public interface IAppConfiguration
    {
        string GetApplicationSettings(string key);

        string GetConnectionStrings(string key);

        string GetLDAPSettings(string key);

        string GetContentRootPath();
    }
}