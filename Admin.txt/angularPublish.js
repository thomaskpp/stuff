const fs = require('fs');
const path = require('path');

const jsonPath = process.env.PWD + '/angular.json';
const angularJSON = require(jsonPath);
const proj = angularJSON.defaultProject;
const { index } = angularJSON.projects[proj].architect.build.options;
const folderPath = path.resolve(process.env.PWD, `../../`);

const folder = folderPath.split(path.sep).pop();

if (process.argv[2] === 'pre') {

  const srcIndex = path.resolve(process.env.PWD, index);

  fs.readFile(srcIndex, 'utf8', replaceLangAndFavIcon(writeIndex));

  writeJSON(JSON.stringify(mergeDeep(angularJSON, {
    projects: {
      [proj]: {
        architect: {
          build: {
            options: {
              "outputPath": `../../../../wwwroot/dist/${proj}`,
              "baseHref": `/${folder}/${proj}/Index/`,
              "deployUrl": `/dist/${proj}/`
            }
          }
        }
      }
    }
  }), null, 2));

  function replaceLangAndFavIcon(callback) {
    return (err, data) => callback(data
      .replace(/\<html lang\=\"(.+)?"\>/i, '<html lang="pt-BR">')
      .replace(/\<link rel=\"icon\" type=\"image\/x-icon\" href=\"(.+)?\"\>/i, '<link rel="icon" type="image/x-icon" href="/favicon.ico">'));
  }

  function writeIndex(data) {
    fs.writeFile(srcIndex, data, () => {
      console.log('substituições na index finalizadas');
    });
  }
  function writeJSON(data) {
    fs.writeFile(jsonPath, data, () => {
      console.log('substituições no json finalizadas');
    });
  }

} else if (process.argv[2] === 'post') {

  const indexHtml = index.slice(index.lastIndexOf('/') + 1);

  const { outputPath } = angularJSON.projects[proj].architect.build.options;
  const buildIndex = path.resolve(process.env.PWD, outputPath, indexHtml);
  fs.readFile(buildIndex, 'utf8', extractSegments(replaceCSHTML(writeCSHTML)));

  replaceController(writeController);

  function extractSegments(callback) {
    return function (err, data) {

      data = data.replace(/>(\s+)?</g, '><');

      const head = /\<head\>(.+)?\<\/head\>/.exec(data)[1];
      const body = /\<body\>(.+)?\<\/body\>/.exec(data)[1];


      return callback(head, body)
    }
  }

  function replaceCSHTML(callback) {
    return function (head, body) {
      return callback(`
      @{
        Layout = null;
      }
      <!doctype html>
      <html lang="pt-BR">
        <head>
          <!--Head-->
          ${head}
          <!--/Head-->
          @Html.Partial("../../../../Views/Shared/_EstilosMenu")
        </head>
        <body>
          @Html.Partial("../../../../Views/Shared/_Menu")
          <div class="wrapper" style="padding-top: 85px">
            <!--Body-->
            ${body}
            <!--/Body-->
          </div>
        </body>
      </html> 
      `)
    }
  }

  function writeCSHTML(file) {
    const cshtmlPath = path.resolve(process.env.PWD, `../../Views/${proj}`);

    fs.promises.mkdir(cshtmlPath, { recursive: true }).then(() => {
      fs.writeFile(path.resolve(cshtmlPath + '/Index.cshtml'), file, function () {
        console.log('cshtml gerado com sucesso');
      });
    });
  }

  function replaceController(callback) {
    return callback(`
using Itau.SZ7.GPS.Admin.Controllers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Itau.SZ7.GPS.Admin.Areas.${proj}.Controllers
{
  [Area("${proj}")]
  public class ${proj}Controller : BaseController
  {
    public ${proj}Controller(ICookies a, IConfiguration b, ISecurityServices c) : base(a, b, c)
    {

    }
    public IActionResult Index()
    {
      this.SetViewBag();

      return View();
    }
  }
}`);
  }

  function writeController(file) {
    const controllerPath = path.resolve(process.env.PWD, `../../Controllers/`);

    fs.promises.mkdir(controllerPath, { recursive: true }).then(() => {
      fs.writeFile(path.resolve(`${controllerPath}/${proj}Controller.cs`), file, function () {
        console.log('controller gerada com sucesso');
      });
    });
  }
}

function isObject(item) {
  return (item && typeof item === 'object' && !Array.isArray(item));
}

function mergeDeep(target, ...sources) {
  if (!sources.length) return target;
  const source = sources.shift();

  if (isObject(target) && isObject(source)) {
    for (const key in source) {
      if (isObject(source[key])) {
        if (!target[key]) Object.assign(target, { [key]: {} });
        mergeDeep(target[key], source[key]);
      } else {
        Object.assign(target, { [key]: source[key] });
      }
    }
  }

  return mergeDeep(target, ...sources);
}