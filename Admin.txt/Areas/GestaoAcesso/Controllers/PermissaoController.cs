﻿using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Controllers;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Controllers
{
    [Area("GestaoAcesso")]
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.GestaoAcessoAdmin })]
    public class PermissaoController : BaseController
    {
        public PermissaoController(
            ICookies cookies,
            IConfiguration configuration,
            ISecurityServices securityServices) : base(cookies, configuration, securityServices)
        { }

        public IActionResult Index()
        {
            SetViewBag();

            return View();
        }
    }
}
