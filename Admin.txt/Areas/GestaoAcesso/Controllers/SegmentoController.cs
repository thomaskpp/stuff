﻿using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Controllers
{
    [Area("GestaoAcesso")]
    public class SegmentoController : Controller
    {
        private readonly ISegmentoServices _segmentoServices;

        public SegmentoController(ISegmentoServices segmentoServices)
        {
            _segmentoServices = segmentoServices;
        }

        [HttpGet]
        public IActionResult ListarSegmento()
        {
            var lista = _segmentoServices.ListarSegmento();

            if (lista == null)
                return NoContent();

            return Ok(lista);
        }
    }
}