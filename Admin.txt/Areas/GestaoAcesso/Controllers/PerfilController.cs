﻿using Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Models;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Controllers
{
    [Area("GestaoAcesso")]
    public class PerfilController : Controller
    {
        private readonly IPerfilServices _perfilServices;

        public PerfilController(IPerfilServices perfilServices)
        {
            _perfilServices = perfilServices;
        }

        [HttpGet]
        public async Task<IActionResult> ListarAsync(string nome)
        {
            var perfis = await _perfilServices.BuscarAsync(nome);

            if (!perfis.Any())
            {
                return NoContent();
            }

            return Ok(perfis);
        }

        [HttpDelete]
        public async Task<IActionResult> ExcluirAsync(int id)
        {
            if (await _perfilServices.ExcluirAsync(id))
            {
                return Ok("Perfil excluído cm sucesso");
            }

            return BadRequest("Não foi possível remover o perfil.");
        }

        [HttpGet]
        public async Task<IActionResult> ObterPorIdAsync(int id)
        {
            var perfil = await _perfilServices.ObterPorIdAsync(id);

            if (perfil.Id == 0)
            {
                return NoContent();
            }

            return Ok(perfil);
        }

        [HttpPost]
        public async Task<IActionResult> InserirAsync([FromBody]PerfilViewModel perfil)
        {
            if (perfil is null)
            {
                return BadRequest("Não foi possível criar o perfil");
            }

            var erros = _perfilServices.Validar(perfil);

            if (erros.Any())
            {
                return BadRequest(erros);
            }

            var verificaExistencia = await _perfilServices.VerificaExistenciaPerfil(perfil);
            
            if(verificaExistencia > 0)
            {
                return BadRequest("Perfil Já existente!");
            }

            if (await _perfilServices.InserirAsync(perfil))
            {
                #region metodo comentado
                //    if(perfil.PerfilPermissoes == null)
                //    {
                //        var idPerfil = perfil.Id;

                //       var afetado = await _perfilServices.InserePerfilPadrao(idPerfil);

                //        if (afetado)
                //            return Ok(perfil);
                //    }

                #endregion

                return Ok(perfil);
            }

            return BadRequest("Não foi possível atualziar o perfil");
        }

        [HttpPut]
        public async Task<IActionResult> EditarAsync([FromBody]PerfilViewModel perfil, [FromRoute] int id)
        {
            if(perfil is null)
            {
                return BadRequest("Não foi possível atualizar o perfil");
            }

            perfil.Id = id;

            var erros = _perfilServices.Validar(perfil);

            if (erros.Any())
            {
                return BadRequest(erros);
            }

            if (await _perfilServices.AtualizarAsync(perfil))
            {
                return Ok(perfil);
            }

            return BadRequest("Não foi possível atualizar o perfil");
        }

        [HttpGet]
        public async Task<IActionResult> ListaPermissoesPorFuncional(string funcional)
        {
            if (funcional == null && string.IsNullOrWhiteSpace(funcional))
            {
                return BadRequest("Digite uma funcional para pesquisa");
            }

            var permissoes = await _perfilServices.ObterFuncionalidadesPerfilPorFuncional(funcional);

            var dto = new
            {
                FuncionalidadesPortal = permissoes.FuncionalidadesPortal.Select(x => new { x.Home, x.Nome }),
                FuncionalidadesAdmin = permissoes.FuncionalidadesAdmin.Select(x => new { x.Home, x.Nome }),
                permissoes.Perfis

            };

            if (!permissoes.Perfis.Any())
            {
                return NoContent();
            }

            return Ok(dto);
        }

        [HttpPost]
        public async Task<IActionResult> ImportarCSV([FromForm] IFormFile arquivoCSV)
        {
            if (arquivoCSV.Length <= 0)
            {
                return NoContent();
            }
            else
            {
                var csv = await _perfilServices.ImportarCSV(arquivoCSV);

                if (csv.Any())
                {
                    return Ok(csv);
                }
                else
                {
                    return NoContent();
                }
            }
        }

        [HttpGet]
        public async Task<IActionResult> DownloadFuncionalCSV(int id)
        {
            var csv = await _perfilServices.CriarCsvFuncional(id);
            var filename = $"arquivoFuncional_" + DateTime.Now.ToString("dd/MM/yyyy") + ".csv";

            if (string.IsNullOrEmpty(csv))
            {
                return NoContent();
            }

            return File(new System.Text.UTF8Encoding().GetBytes(csv), "text/csv", filename);
        }

        [HttpGet]
        public async Task<IActionResult> DownloadCogidoAgenciaCSV(int id)
        {
            var csv = await _perfilServices.CriarCsvCodigoAgencia(id);
            var filename = $"arquivoCodigoAgencia_" + DateTime.Now.ToString("dd/MM/yyyy") + ".csv";

            if (string.IsNullOrEmpty(csv))
            {
                return NoContent();
            }

            return File(new System.Text.UTF8Encoding().GetBytes(csv), "text/csv", filename);
        }

        [HttpGet]
        public async Task<IActionResult> DownloadCarteiraCSV(int id)
        {
            var csv = await _perfilServices.CriarCsvCarteira(id);
            var filename = $"arquivoCarteira_" + DateTime.Now.ToString("dd/MM/yyyy") + ".csv";

            if (string.IsNullOrEmpty(csv))
            {
                return NoContent();
            }

            return File(new System.Text.UTF8Encoding().GetBytes(csv), "text/csv", filename);
        }
    }
}