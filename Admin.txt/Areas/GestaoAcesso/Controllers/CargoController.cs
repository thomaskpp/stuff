﻿using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Controllers
{
    [Area("GestaoAcesso")]
    public class CargoController : Controller
    {
        private readonly ICargoServices _cargoServices;

        public CargoController(ICargoServices cargoServices)
        {
            _cargoServices = cargoServices;
        }

        [HttpGet]
        public async Task<IActionResult> ListarCargo()
        {
            var cargo = await _cargoServices.ListarCargoAsync();

            if (cargo == null)
            {
                return NoContent();
            }

            return Ok(cargo);
        }
    }
}