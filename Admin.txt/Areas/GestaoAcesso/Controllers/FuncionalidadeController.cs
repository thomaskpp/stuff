﻿using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Controllers
{
    [Area("GestaoAcesso")]
    public class FuncionalidadeController : Controller
    {
        private readonly IFuncionalidadeServices _funcionalidadeServices;

        public FuncionalidadeController(IFuncionalidadeServices funcionalidadeServices)
        {
            _funcionalidadeServices = funcionalidadeServices;
        }

        [HttpGet]
        public async Task<IActionResult> ListarAsync()
        {
            var funcionalidades = await _funcionalidadeServices.ListarAsync();

            if (!funcionalidades.Any())
            {
                return NoContent();
            }

            return Ok(funcionalidades);
        }
    }
}