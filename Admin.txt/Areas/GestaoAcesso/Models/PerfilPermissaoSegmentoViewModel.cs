﻿namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Models
{
    public class PerfilPermissaoSegmentoViewModel
    {
        public bool Permissao { get; set; }
        public int IdSegmento { get; set; }
        public string NomeSegmento { get; set; }
    }
}
