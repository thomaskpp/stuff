﻿namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Models
{
    public class PerfilPermissaoColaboradorViewModel
    {
        public bool Permissao { get; set; }
        public string Funcional { get; set; }
        public int IdColaborador { get; set; }
    }
}
