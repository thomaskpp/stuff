﻿using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Models
{
    public class PerfilViewModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int? idColaborador { get; set; }
        public IEnumerable<PerfilPermissaoViewModel> PerfilPermissoes { get; set; }
    }
}
