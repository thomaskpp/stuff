﻿namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Models
{
    public class PerfilPermissaoCarteiraViewModel
    {
        public bool Permissao { get; set; }
        public string Carteira { get; set; }
    }
}
