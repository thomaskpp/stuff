﻿namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Models
{
    public class PerfilPermissaoCargoViewModel
    {
        public bool Permissao { get; set; }
        public int IdCargo { get; set; }
        public string AbreviacaoCargo { get; set; }
    }
}
