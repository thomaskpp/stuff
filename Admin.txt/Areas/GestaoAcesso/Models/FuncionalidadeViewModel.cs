﻿using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Models
{
    public class FuncionalidadeViewModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public IEnumerable<PerfilPermissaoAgenciaViewModel> PermissaoAgencias { get; set; }
        public IEnumerable<PerfilPermissaoCarteiraViewModel> PermissaoCarteiras { get; set; }
        public IEnumerable<PerfilPermissaoCargoViewModel> PermissaoCargos { get; set; }
        public IEnumerable<PerfilPermissaoColaboradorViewModel> PermissaoColaboradores { get; set; }
        public IEnumerable<PerfilPermissaoSegmentoViewModel> PermissaoSegmentos { get; set; }

        public static FuncionalidadeViewModel Convert(Entities.Funcionalidade funcionalidade)
        {
            if (funcionalidade is null)
            {
                return new FuncionalidadeViewModel
                {
                    Nome = string.Empty,
                    PermissaoAgencias = Enumerable.Empty<PerfilPermissaoAgenciaViewModel>(),
                    PermissaoCargos = Enumerable.Empty<PerfilPermissaoCargoViewModel>(),
                    PermissaoCarteiras = Enumerable.Empty<PerfilPermissaoCarteiraViewModel>(),
                    PermissaoColaboradores = Enumerable.Empty<PerfilPermissaoColaboradorViewModel>(),
                    PermissaoSegmentos = Enumerable.Empty<PerfilPermissaoSegmentoViewModel>(),
                };
            }

            return new FuncionalidadeViewModel
            {
                Id = funcionalidade.Id,
                Nome = $"{ObterPlataforma(funcionalidade.IdPlataforma)} {funcionalidade.Nome}",
                PermissaoAgencias = (funcionalidade.PerfilPermissaoAgencias?
                    .Select(y => new PerfilPermissaoAgenciaViewModel { Codigo = y.Codigo, IdAgenica = y.IdAgencia, Permissao = y.Permissao }))
                    ?? Enumerable.Empty<PerfilPermissaoAgenciaViewModel>(),
                PermissaoCargos = (funcionalidade.PerfilPermissaoCargos?
                    .Select(y => new PerfilPermissaoCargoViewModel { AbreviacaoCargo = y.AbreviacaoCargo, IdCargo = y.IdCargo, Permissao = y.Permissao }))
                    ?? Enumerable.Empty<PerfilPermissaoCargoViewModel>(),
                PermissaoCarteiras = (funcionalidade.PerfilPermissaoCarteiras?
                   .Select(y => new PerfilPermissaoCarteiraViewModel { Carteira = y.Carteira, Permissao = y.Permissao }))
                    ?? Enumerable.Empty<PerfilPermissaoCarteiraViewModel>(),
                PermissaoColaboradores = (funcionalidade.PerfilPermissaocolaborador?
                   .Select(y => new PerfilPermissaoColaboradorViewModel { Funcional = y.Funcional, Permissao = y.Permissao}))
                   ?? Enumerable.Empty<PerfilPermissaoColaboradorViewModel>(),
                PermissaoSegmentos = (funcionalidade.PerfilPermissaoSegmentos?
                   .Select(y => new PerfilPermissaoSegmentoViewModel { NomeSegmento = y.Nome, IdSegmento = y.IdSegmento, Permissao = y.Permissao }))
                   ?? Enumerable.Empty<PerfilPermissaoSegmentoViewModel>(),
            };
        }

        private static string ObterPlataforma(int idPlataforma)
        {
            switch (idPlataforma)
            {
                case (int)Plataforma.Enum.Admin:
                    return "[Admin]";
                case (int)Plataforma.Enum.Web:
                    return "[Portal]";
                default:
                    return string.Empty;
            }
        }
    }
}
