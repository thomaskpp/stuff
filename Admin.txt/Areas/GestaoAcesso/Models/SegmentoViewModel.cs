﻿namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Models
{
    public class SegmentoViewModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
