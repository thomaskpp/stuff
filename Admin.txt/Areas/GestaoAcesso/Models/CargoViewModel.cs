﻿namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Models
{
    public class CargoViewModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
