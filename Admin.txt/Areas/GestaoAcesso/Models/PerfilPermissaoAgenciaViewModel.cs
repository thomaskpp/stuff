﻿namespace Itau.SZ7.GPS.Admin.Areas.GestaoAcesso.Models
{
    public class PerfilPermissaoAgenciaViewModel
    {
        public bool Permissao { get; set; }
        public int IdAgenica { get; set; }
        public string Codigo { get; set; }
    }
}
