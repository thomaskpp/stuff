﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Areas.Home.Models.Template;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Controllers;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.TemplateHome.Controllers
{
    [Area("Home")]
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.HomeTemplateAdmin })]
    public class HomeTemplateController : BaseController
    {
        private readonly IHomeTemplateService _homeTemplateServices;

        public HomeTemplateController(
            ICookies cookies,
            IConfiguration configuration,
            IHomeTemplateService homeTemplateServices,
            ISecurityServices securityServices) : base(cookies, configuration, securityServices)
        {
            _homeTemplateServices = homeTemplateServices;
        }

        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var templates = await _homeTemplateServices.ListarAsync();

            var listaTemplate = new ListaTemplate()
            {
                Templates = templates
            };

            return View(listaTemplate);
        }

        public async Task<IActionResult> Novo([FromQuery] ModeloTemplate modelo)
        {
            var model = new HomeTemplateModel
            {
                PopupConfirmacao = new PopupConfirmacaoModel
                {
                    Mensagem = "Confirma a inclusão do novo template? ",
                    TituloBotaoCancelar = "Não",
                    TituloBotaoOk = "Sim"
                }
            };

            CriarViewBags();

            return await Task.FromResult(ObterModeloTemplate(modelo, model));
        }

        public async Task<IActionResult> Editar([FromQuery] ModeloTemplate modelo, int id)
        {
            var model = await _homeTemplateServices.ObterPorIdAsync(id);

            model.PopupConfirmacao = new PopupConfirmacaoModel
            {
                Mensagem = "Confirma a edição do template? ",
                TituloBotaoCancelar = "Não",
                TituloBotaoOk = "Sim"
            };

            CriarViewBags();

            return ObterModeloTemplate(modelo, model);
        }

        [HttpPost]
        public async Task<IActionResult> InserirAsync([FromForm]HomeTemplateModel homeTemplateModel, [FromForm]IFormFile arquivo)
        {
            return await SalvarAsync(homeTemplateModel, arquivo);
        }

        [HttpPut]
        public async Task<IActionResult> EditarAsync([FromForm]HomeTemplateModel homeTemplateModel, [FromRoute]int id, [FromForm]IFormFile arquivo)
        {
            return await SalvarAsync(homeTemplateModel, arquivo, id);
        }

        [HttpDelete]
        public async Task<IActionResult> ExcluirAsync([FromRoute]int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }

            int linhasAfetadas = await _homeTemplateServices.ExcluirAsync(id);

            if (linhasAfetadas > 0)
            {
                return NoContent();
            }
            else
            {
                return BadRequest("Não foi possível remover o template");
            }
        }

        [HttpGet]
        public async Task<IActionResult> ExisteTemplatePadrao([FromRoute]int id)
        {
            var existeTemplatePadrao = await _homeTemplateServices.ExisteTemplatePadrao(id);

            return Ok(new { status = existeTemplatePadrao });
        }

        [HttpGet]
        public async Task<IActionResult> DownloadExcelAsync([FromRoute]int id)
        {
            var streamExcel = await _homeTemplateServices.CriarExcelFuncionais(id);
            var filename = $"LiberacaoHome_{DateTime.Now.ToString("yyyyMMddHHmmssffff")}.xlsx";

            Response.Headers.Add("fileName", filename);

            return File(streamExcel, "application/download", filename);
        }

        private async Task<IActionResult> SalvarAsync(HomeTemplateModel homeTemplateModel, IFormFile arquivo, int? id = null)
        {
            var funcionais = _homeTemplateServices.ObterFuncionaisExcel(arquivo?.OpenReadStream());

            if (!funcionais.Any() && id != null && homeTemplateModel.Status == StatusPublicacao.PublicadoAlgunsUsuario)
            {
                funcionais = await _homeTemplateServices.ListarFuncionaisPorIdTemplateAsync(id.Value);
            }

            homeTemplateModel.Funcionais = funcionais;

            var erros = _homeTemplateServices.Validar(homeTemplateModel);

            if (erros.Any())
            {
                return BadRequest(erros);
            }

            int linhasAfetadas;

            if (id == null)
            {
                linhasAfetadas = await _homeTemplateServices.InserirAsync(homeTemplateModel);
            }
            else
            {
                homeTemplateModel.Id = id.Value;

                linhasAfetadas = await _homeTemplateServices.EditarAsync(homeTemplateModel);
            }

            if (linhasAfetadas > 0)
            {
                return NoContent();
            }
            else
            {
                return BadRequest(id != null ? "Não foi possível editar o template" : "Não foi possível criar o template");
            }
        }

        private IActionResult ObterModeloTemplate(ModeloTemplate modelo, HomeTemplateModel homeTemplateModel)
        {
            return View(modelo.ToString(), homeTemplateModel);
        }

        private void CriarViewBags()
        {
            SetViewBag();

            ViewBag.Action = RouteData.Values["action"].ToString().ToLower();
        }
    }
}