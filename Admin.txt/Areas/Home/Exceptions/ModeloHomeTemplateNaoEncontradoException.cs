﻿using System;

namespace Itau.SZ7.GPS.Admin.Areas.Home.Exceptions
{
    public class ModeloHomeTemplateNaoEncontradoException : Exception
    {
        public ModeloHomeTemplateNaoEncontradoException() : base("O modelo do template não existe") { }
    }
}
