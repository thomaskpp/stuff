﻿using Itau.SZ7.GPS.Admin.Areas.Notificacao.Models;
using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Home.Models.Template
{
    public class HomeTemplateModel : BaseModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Html { get; set; }
        public string ModeloTemplate { get; set; }
        public StatusPublicacao Status { get; set; }
        public string StatusCss { get; set; }
        public string Resumo { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime? DataAtualizacao { get; set; }
        public IEnumerable<string> Funcionais { get; set; }
    }
}
