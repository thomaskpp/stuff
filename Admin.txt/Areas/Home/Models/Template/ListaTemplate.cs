﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Models;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Areas.Home.Models.Template
{
    public class ListaTemplate : BaseViewModel
    {
        public IEnumerable<HomeTemplateModel> Templates { get; set; }
        public int Count => Templates?.Count() ?? 0;
    }
}
