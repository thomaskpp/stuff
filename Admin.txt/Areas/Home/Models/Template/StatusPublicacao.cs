﻿namespace Itau.SZ7.GPS.Admin.Areas.Home.Models.Template
{
    public enum StatusPublicacao
    {
        NaoPublicado = 1,
        PublicadoTodos = 2,
        PublicadoAlgunsUsuario = 3
    }
}
