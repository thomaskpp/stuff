﻿namespace Itau.SZ7.GPS.Admin.Areas.Home.Models.Template
{
    public enum ModeloTemplate
    {
        ModeloA = 1,
        ModeloB = 2,
        ModeloC = 3
    }
}
