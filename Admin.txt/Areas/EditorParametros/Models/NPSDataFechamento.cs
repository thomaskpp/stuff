﻿using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.EditorParametros.Models
{
    public class NPSDataFechamento
    {
        public DateTime DataReferencia { get; set; }
        public DateTime DataFechamento { get; set; }
    }

    public class NPSListaFechamento : NPSDataFechamento
    { 
        public List<NPSDataFechamento> Fechamentos { get; set; }
    }
}
