﻿using Itau.SZ7.GPS.Admin.Areas.EditorParametros.Models;
using Itau.SZ7.GPS.Admin.Controllers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.EditorParametros.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.EditorParametros.Controllers
{
    [Area("EditorParametros")]
    public class EditorParametrosController : BaseController
    {
        private readonly IEditorParametrosServices _editorParametrosServices;

        public EditorParametrosController(IEditorParametrosServices editorParametrosServices, ICookies cookies,
            IConfiguration configuration, ISecurityServices securityServices)
            : base(cookies, configuration, securityServices)
        {
            _editorParametrosServices = editorParametrosServices;
        }

        public async Task<IActionResult> IndexAsync()
        {
            SetViewBag();

            NPSListaFechamento fechamentos = await _editorParametrosServices.GetFechamentos();

            return View(fechamentos);
        }

        [HttpPost]
        public IActionResult Inserir(NPSListaFechamento model)
        {
            SetViewBag();
            _editorParametrosServices.InsertDataFechamento(model);

            return RedirectToAction("Index");
        }
    }
}

