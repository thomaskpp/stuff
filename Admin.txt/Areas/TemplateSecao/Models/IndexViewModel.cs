﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.TemplateSecao.Models
{
    public class IndexViewModel
    {
        public IEnumerable<Entities.DTO.TemplateSecao> Secoes { get; set; }

        public int IdSecao { get; set; }

        public int IdTemplateHtml { get; set; }

        public string Html { get; set; }

    }
}
