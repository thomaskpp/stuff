﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Areas.Home.Models.Template;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Controllers;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Entities.DTO;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.TemplateSecao.Controllers
{
    [Area("TemplateSecao")]
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.TemplateSecao })]
    public class TemplateSecaoController : BaseController
    {
        private readonly ITemplateSecaoServico _templateSecaoServico;

        public TemplateSecaoController(
            ICookies cookies,
            IConfiguration configuration,
            ITemplateSecaoServico templateSecaoServico,
            ISecurityServices securityServices) : base(cookies, configuration, securityServices)
        {
            _templateSecaoServico = templateSecaoServico;
        }

        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var secoes = await _templateSecaoServico.ObterSecoes();

            var viewModel = new Models.IndexViewModel();

            viewModel.Secoes = secoes;

            return View(viewModel);
        }

        [HttpGet]
        public async Task<IActionResult> ObterHtml([FromQuery] string nomeTemplateSecao)
        {
            if (string.IsNullOrEmpty(nomeTemplateSecao))
                return BadRequest();

            var html = await _templateSecaoServico.ObterTemplateSecaoHtml(nomeTemplateSecao);

            if (html == null)
                return NoContent();

            return Json(html);
        }

        public class CorpoHtml
        {
            public string Html { get; set; }
        }


        [HttpPost]
        public async Task<IActionResult> Gravar([FromQuery] int idTemplateSecao, [FromQuery] int idTemplateHtml, [FromBody] CorpoHtml html)
        {

            if (idTemplateSecao <= 0)
                return BadRequest();

            TemplateSecaoHtml htmlRetorno = null;

            if (idTemplateHtml > 0)
            {
                htmlRetorno = await _templateSecaoServico.AtualizarTemplateSecaoHtml(idTemplateSecao, idTemplateHtml, html.Html);
            }
            else
            {
                htmlRetorno = await _templateSecaoServico.InserirTemplateSecaoHtml(idTemplateSecao, html.Html);
            }

            if (htmlRetorno == null)
                return StatusCode(500, "Não foi possível gravar o html.");

            return Json(htmlRetorno);
        }

    }
}