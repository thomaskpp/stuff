import React from 'react';
import ReactDOM from 'react-dom';
import ConfigAgir from './components/config-agir';

ReactDOM.render(
  <ConfigAgir></ConfigAgir>
  ,
  document.getElementById('react-root')
);