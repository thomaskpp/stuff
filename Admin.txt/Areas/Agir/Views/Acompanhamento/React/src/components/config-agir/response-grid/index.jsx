import React, { Component } from 'react';
import styled, { css } from 'styled-components';

const Table = styled.table`
  width: 100%;
  background-color: #fff;
  text-align: center;
  td, th {
    padding: 3px;
  }
  th { 
    text-align: center;
  }
  tbody tr { 
    border-bottom: 1px solid  #ADADAD;
  }
`;

const TotalRow = styled.tr`
 background: #7F7F7F;
 color: #fff
`;

const BorderCell = styled.td`
  border-right: 1px solid  #ADADAD;
`;

const THBorder = styled.th`
  border-right: 1px solid  #ADADAD;
`;

const Farol = styled.div`
    width: 15px;
    height: 15px;
    border-radius: 4px;
    border: 1px solid;
    display: inline-block;
    margin-right: 5px;
    ${props => css`
      color: ${props.cor};
      background-color: ${props.cor};
    ` }
`;

class ResponseGrid extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }
  renderRow(val, sumario) {
    return (sumario ?
      <TotalRow>
        <td>{val.codigoItem}</td>
        <td>{val.nomeProduto || '-'}</td>
        <td>{val.nomeSegmento}</td>
        <td>{val.dataAtualizacao || '-'}</td>
        <BorderCell>{val.dataReferencia || '-'}</BorderCell>
        <td>{val.quantidade}</td>
        <td>{val.aprovado} ({val.aprovadoPorcentagem})</td>
        <td>{val.similar} ({val.similarPorcentagem})</td>
        <td>{val.invalido} ({val.invalidoPorcentagem})</td>
        <td>{val.pendente} ({val.pendentePorcentagem})</td>
      </TotalRow> :
      <tr>
        <td>{val.codigoItem}</td>
        <td>{val.nomeProduto || '-'}</td>
        <td>{val.nomeSegmento}</td>
        <td>{val.dataAtualizacao || '-'}</td>
        <BorderCell>{val.dataReferencia || '-'}</BorderCell>
        <td>{val.quantidade}</td>
        <td>{val.aprovado} ({val.aprovadoPorcentagem})</td>
        <td>{val.similar} ({val.similarPorcentagem})</td>
        <td>{val.invalido} ({val.invalidoPorcentagem})</td>
        <td>{val.pendente} ({val.pendentePorcentagem})</td>
      </tr>
    )
  }
  render() {
    return (
      <Table>
        <thead>
          <tr>
            <THBorder colSpan="5"></THBorder>
            <th colSpan="5"> Check-Out </th>
          </tr>
          <tr>
            <th>Cód.Item</th>
            <th>Item</th>
            <th>Segmento</th>
            <th>Último Processamento</th>
            <THBorder>Data VP</THBorder>
            <th>Total</th>
            <th><Farol cor={'#06B050'}></Farol>Apurado</th>
            <th><Farol cor={'#92D051'}></Farol>Similaridade</th>
            <th><Farol cor={'#C00000'}></Farol>Inválido</th>
            <th><Farol ></Farol>Pendente</th>
          </tr>
        </thead>
        <tbody>
          {this.renderRow(this.props.gridData.sumario, true)}
          {
            this.props.gridData.linhas.map((linha) => this.renderRow(linha))
          }
        </tbody>
      </Table>
    )
  }
}

export default ResponseGrid;