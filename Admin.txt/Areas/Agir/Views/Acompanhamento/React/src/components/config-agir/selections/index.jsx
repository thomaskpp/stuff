import React, { Component } from 'react';
import styled from "styled-components";
const Arrow = styled.i`
  position: absolute;
  display: block;
  width: 15px;
  height: 15px;
  background: url("/icons/down-arrow.svg") center center no-repeat;
  background-size: auto;
  background-size: contain;
  right: 10px;  
  bottom: 10px;
`;
const SelectionsWrapper = styled.section`
  display: flex;
  margin: 5px 0;
`;
const DropdownWrapper = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  margin-right: 10px
`;

const GPSSelect = styled.select`
  padding: 6px 25px 7px 24px;
  height: 36px;
  width: 150px;
  font-size: 14px;
  font-weight: 400;
  color: #605751;
  max-height: 37px;
  cursor: pointer;
  background:#fff;
  border: 1px solid #ec7000;
  border-radius: 20px;
  outline: 0;
  -moz-appearance: none;
  -webkit-appearance: none;
  line-height: normal;
`;
class Selections extends Component {
  constructor(props) {
    super(props);
    let dataAtual = new Date();
    this.state = {
      datas: Array(12).fill(1).map((val, idx) => {
        const formatado = `${(dataAtual.getMonth() + 1)}`.padStart(2, '0') + '/' + dataAtual.getFullYear();
        dataAtual.setMonth(dataAtual.getMonth() - 1);
        return formatado;
      }),
      segmentos: [
        { title: 'EMP2E3', id: 3 },
        { title: 'AGENCIAS', id: 1 },
        { title: 'UNICLASS', id: 2 },
        { title: 'TODOS', id: -1 }
      ]
    };
  }

  componentDidMount() {
    this.setState({
      segmento: this.state.segmentos[3].id,
      data: this.state.datas[0]
    });
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.state.data && this.state.segmento && (prevState.data !== this.state.data || prevState.segmento !== this.state.segmento)) {
      this.props.onSelect((({ data, segmento }) => ({ data, segmento }))(this.state));
    }
  }

  handleInputChange(event) {
    const target = event.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;

    this.setState({
      [name]: value
    });
  }

  render() {
    return (
      <SelectionsWrapper>
        <DropdownWrapper>
          <label for="data">Data Referência</label>
          <GPSSelect id="data" name="data" value={this.state.data} onChange={(e) => this.handleInputChange(e)}>
            {this.state.datas.map(data => <option key={data} value={data}>{data}</option>)}
          </GPSSelect>
          <Arrow class="seta-baixo"></Arrow>
        </DropdownWrapper>
        <DropdownWrapper>
          <label for="segmento">Segmento</label>
          <GPSSelect id="segmento" name="segmento" value={this.state.segmento} onChange={(e) => this.handleInputChange(e)}>
            {this.state.segmentos.map(seg => <option key={seg.id} value={seg.id} selected={seg.id === 4}>{seg.title}</option>)}
          </GPSSelect>
          <Arrow class="seta-baixo"></Arrow>

        </DropdownWrapper>
      </SelectionsWrapper>
    )
  }
}

export default Selections;