import React, { Component } from 'react';
import styled from "styled-components";
import ResponseGrid from './response-grid';
import Selections from './selections';

const Wrapper = styled.main`
  background-color: #F3F2F4;
  padding: 15px;
`;

class ConfigAgir extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: {
        linhas: [],
        sumario: {}
      }
    };
  }

  render() {
    return (
      <Wrapper>
        <Selections onSelect={(params) => this.getNewData(params)}></Selections>
        <ResponseGrid gridData={this.state.data}></ResponseGrid>
      </Wrapper>
    )
  }


  getNewData(params) {
    const loading = document.querySelector('.loading');
    loading.style.display = 'block';
    console.log(params);
    const dateParts = params.data.split('/');
    fetch(defaultUrl + `Agir/Acompanhamento/relatorio?mes=${dateParts[0]}&ano=${dateParts[1]}&idsegmento=${params.segmento}`)
      .then(response => {
        return response.json()
          .then(json => {
            this.setState({
              data: json
            });
            loading.removeAttribute('style');
          })
      });

  }
}

export default ConfigAgir;