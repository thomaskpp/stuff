﻿using Itau.SZ7.GPS.Admin.Areas.Agir.Models.DTO;
using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models
{
    public class ConciliacaoViewModel : ConciliacaoTela
    {
        public ConciliacaoConfiguracoes listConfiguracoes { get; set; }
        public ConciliacaoTabelas Selecionado { get; set; }
        public bool FlagFiltro { get; set; }
    }
}
