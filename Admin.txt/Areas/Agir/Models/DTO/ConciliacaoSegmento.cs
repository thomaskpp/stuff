﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models
{
    public class ConciliacaoSegmento
    {
        public int IdSegmento { get; set; }
        public string Segmento { get; set; }
    }
}
