﻿namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models.DTO
{
  public class AcompanhamanetoRelatorioSumarioDto
  {
    public AcompanhamanetoRelatorioSumarioDto()
    {
      this.CodigoItem = "Total";
    }
    public string CodigoItem { get; set; }

    public string Total { get; set; }

    public string TotalApurado { get; set; }

    public string AprovadoPorcentagem { get; set; }

    public string TotalSimilar { get; set; }

    public string SimilarPorcentagem { get; set; }

    public string TotalInvalido { get; set; }

    public string InvalidoPorcentagem { get; set; }

    public string TotalPendente { get; set; }

    public string PendentePorcentagem { get; set; }
  }
}