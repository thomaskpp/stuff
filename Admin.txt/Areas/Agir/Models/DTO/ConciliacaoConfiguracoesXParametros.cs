﻿using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models.DTO
{
    public class ConciliacaoConfiguracoesXParametros
    {
        public long Id { get; set; }
        public int CodigoItem { get; set; }
        public int IdSegmento { get; set; }
        public short Mes { get; set; }
        public short Ano { get; set; }
        public ConciliacaoChaves CodigoChave { get; set; }
        public string ColunaCheckout { get; set; }
        public string ColunaRealizado { get; set; }
        public string Tipo { get; set; }
        public string Criterio { get; set; }
        public string Intervalo { get; set; }
        public string Input { get; set; }
        public bool IndicadorAtivo { get; set; }
    }
}
