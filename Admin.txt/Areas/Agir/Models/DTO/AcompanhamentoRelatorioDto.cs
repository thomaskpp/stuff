﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models.DTO
{
    public class AcompanhamentoRelatorioDto
    {
        public IEnumerable<AcompanhamanetoRelatorioLinhaDto> Linhas { get; set; }

        public AcompanhamanetoRelatorioSumarioDto Sumario { get; set; }
    }
}
