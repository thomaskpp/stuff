﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models
{
    public class ConciliacaoComboItens
    {
        public int CodigoItem { get; set; }
        public string NomeItem { get; set; }

        public List<SelectListItem> listItens { get; set; }
        public string NomeSegmento { get; set; }

        [NotMapped]
        public bool FlagConfiguracoes { get; set; }
    }
}
