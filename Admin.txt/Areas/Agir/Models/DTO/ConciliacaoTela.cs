﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models
{
    public class ConciliacaoTela
    {
        public ConciliacaoPeriodo periodos { get; set; }
        public ConciliacaoComboItens item { get; set; }
        public ConciliacaoChaves Chaves { get; set; }
        public ConciliacaoComboTabela tabela { get; set; }
        public List<ConciliacaoComboItens> DTOitem { get; set; }
        public List<ConciliacaoItens> Itens { get; set; }
        public List<ConciliacaoSegmento> segmentos { get; set; }
        public List<ConciliacaoTabelas> DTOlistTabelas { get; set; }
        public string periodoSelecionado { get; set; }
        public string ItemSelecionado { get; set; }
        public string SegmentoSelecionado { get; set; }
        public string Input { get; set; }
        public bool IndicadorAtivo { get; set; }

    }
}
