﻿namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models.DTO
{
    public class AcompanhamanetoRelatorioLinhaDto
    {
        public string Pendente { get; set; }

        public string PendentePorcentagem { get; set; }

        public string Aprovado { get; set; }

        public string AprovadoPorcentagem { get; set; }

        public string Similar { get; set; }

        public string SimilarPorcentagem { get; set; }

        public string Invalido { get; set; }

        public string InvalidoPorcentagem { get; set; }

        public int CodigoItem { get; set; }

        public string Quantidade { get; set; }

        public string DataAtualizacao { get; set; }

        public string DataReferencia { get; set; }

        public string NomeSegmento { get; set; }

        public string NomeProduto { get; set; }
    }
}
