﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models
{
    public class ConciliacaoComboTabela
    {
        public ConciliacaoComboTabela()
        {
            List<SelectListItem> ColunasTipo = new List<SelectListItem>();
            List<SelectListItem> ColunasCheckout = new List<SelectListItem>();
            List<SelectListItem> ColunasRealizado = new List<SelectListItem>();
            List<SelectListItem> Criterios = new List<SelectListItem>();
            List<SelectListItem> Intervalos = new List<SelectListItem>();
        }
        public long IdConfiguracoes { get; set; }
        public int CodigoTabela { get; set; }
        public DateTime Data { get; set; }
        public string NomeColuna { get; set; }
        public string ColunaCheckout { get; set; }
        public string ColunaRealizado { get; set; }
        public string NomeTabela { get; set; }
        public string Tipo { get; set; }
        public string Criterio { get; set; }
        public string Intervalo { get; set; }
        public string IntervaloData { get; set; }
        public List<SelectListItem> ColunasTipo { get; set; }

        public List<SelectListItem> ColunasCheckout { get; set; }
        public List<SelectListItem> ColunasRealizado { get; set; }

        [NotMapped]
        public List<SelectListItem> Criterios { get; set; }

        [NotMapped]
        public List<SelectListItem> Intervalos { get; set; }
    }
}
