﻿using Itau.SZ7.GPS.Admin.Areas.Agir.Models.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models.Enum
{
    public enum SegmentoEnum
    {
        [Description("Agencias")]
        Agencias = 1,
        [Description("Uniclass")]
        Uniclass = 2,
        [Description("Empresas 4")]
        Empresas4 = 3
    }
}
