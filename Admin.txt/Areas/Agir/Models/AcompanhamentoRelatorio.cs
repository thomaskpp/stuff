﻿using System;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Models
{
    public class AcompanhamentoRelatorio
    {
        public int Pendente { get; set; }

        public decimal PendentePorcentagem { get; set; }

        public int Aprovado { get; set; }

        public decimal AprovadoPorcentagem { get; set; }

        public int Similar { get; set; }

        public decimal SimilarPorcentagem { get; set; }

        public int Invalido { get; set; }

        public decimal InvalidoPorcentagem { get; set; }

        public int CodigoItem { get; set; }

        public int Quantidade { get; set; }

        public DateTime? DataAtualizacao { get; set; }

        public DateTime? DataReferencia { get; set; }

        public string NomeSegmento { get; set; }

        public string NomeProduto { get; set; }
    }
}
