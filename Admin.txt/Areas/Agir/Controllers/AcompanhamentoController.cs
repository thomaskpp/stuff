﻿using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Controllers;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Conciliacao.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Controllers
{

    [Area("Agir")]
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.ConfiguracoesConciliacaoAutomaticaVP })]
    public class AcompanhamentoController : BaseController
    {
        private readonly IAcompanhamentoRelatorioServico _acompanhamentoRelatorioServico;

        public AcompanhamentoController(
            ICookies cookies,
            IConfiguration configuration,
            ISecurityServices securityServices,
            IAcompanhamentoRelatorioServico acompanhamentoRelatorioServico) : base(cookies, configuration, securityServices)
        {
            _acompanhamentoRelatorioServico = acompanhamentoRelatorioServico;
        }

        public IActionResult Index()
        {
            SetViewBag();

            return View();
        }

        [ActionName("Relatorio")]
        public async Task<IActionResult> ObterRelatorio(int mes, int ano, int idSegmento)
        {
            var relatorio = await _acompanhamentoRelatorioServico.ObterRelatorio(mes, ano, idSegmento);

            return Ok(relatorio);
        }
    }
}