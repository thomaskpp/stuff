﻿using Itau.SZ7.GPS.Admin.Areas.Agir.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Controllers;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Conciliacao.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;

namespace Itau.SZ7.GPS.Admin.Areas.Agir.Controllers
{
    [Area("Agir")]
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.ConfiguracoesConciliacaoAutomaticaVP })]
    public class ConciliacaoController : BaseController
    {
        private readonly IConciliacaoServices _conciliacaoServices;

        public ConciliacaoController(IConciliacaoServices conciliacaoServices,
            ICookies cookies,
            IConfiguration configuration,
            ISecurityServices securityServices) : base(cookies, configuration, securityServices)
        {
            _conciliacaoServices = conciliacaoServices;
        }

        [HttpGet]
        public IActionResult Index(ConciliacaoViewModel model)
        {
            SetViewBag();

            var retorno = _conciliacaoServices.Carregar(model);
            return View(retorno);

        }

        [HttpPost]
        public IActionResult Filtros(ConciliacaoViewModel model)
        {
            model.FlagFiltro = true;

            return Index(model);

        }

        [HttpPost]
        public IActionResult AtualizarFlagExibir(string data, string produto, string segmento, string ativo)
        {
            _conciliacaoServices.AtualizaIndicadorAtivo(produto, segmento, data, Convert.ToBoolean(ativo));
            return Ok();
        }

        [HttpPost]
        public IActionResult Salvar(ConciliacaoViewModel model)
        {
            try
            {

                _conciliacaoServices.Salvar(model);
                model.FlagFiltro = true;
                return RedirectToAction("Index", model);
            }
            catch (Exception ex)
            {
                // Implementar Retorno da Falha
                ex.Message.ToString();
                return RedirectToAction("Index");

            }

        }
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            _conciliacaoServices.DeletarPorId(id);
            return Ok();
        }
    }
}
