﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Areas.VisaoGerencial.Models
{
    public class Periodo
    {
        private Periodo() { }

        public static Periodo Novo(DateTime dataAtual)
        {
            var periodo = new Periodo
            {
                Ano = dataAtual.Year,
                Mes = dataAtual.Month,
                Dias = ObterDias(dataAtual).OrderByDescending(x => x)
            };

            return periodo;
        }

        public int Ano { get; private set; }

        public int Mes { get; private set; }

        public IEnumerable<int> Dias { get; private set; }

        private static IEnumerable<int> ObterDias(DateTime dataAtual)
        {
            var i = 0;
            var mesAtual = DateTime.Now.Month == dataAtual.Month
                    && DateTime.Now.Year == dataAtual.Year;

            while (i < DateTime.DaysInMonth(dataAtual.Year, dataAtual.Month))
            {
                var diaAtual = i + 1;

                if (mesAtual && DateTime.Now.Day == diaAtual)
                {
                    i = DateTime.DaysInMonth(dataAtual.Year, dataAtual.Month);
                }

                i++;

                yield return diaAtual;
            }
        }
    }
}
