﻿using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Controllers;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.VisaoGerencial.Controllers
{
    [Area("VisaoGerencial")]
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CheckoutsPendentes })]

    public class RelatorioCheckoutPendenteController : BaseController
    {
        private readonly IRelatorioCheckoutPendenteServico _relatorioCheckoutPendenteServico;

        public RelatorioCheckoutPendenteController(ICookies cookies,
            IConfiguration configuration,
            ISecurityServices securityServices,
            IRelatorioCheckoutPendenteServico relatorioCheckoutPendenteServico) : base(cookies, configuration, securityServices)
        {
            _relatorioCheckoutPendenteServico = relatorioCheckoutPendenteServico;
        }

        public IActionResult Index()
        {
            SetViewBag();

            return View();
        }

        [HttpGet]
        public IActionResult ObterDatas()
        {
            return Ok(_relatorioCheckoutPendenteServico.ObterPeriodos());
        }

        [HttpGet]
        public async Task<IActionResult> DownloadCsvCheckoutPendente([FromQuery]DateTime dataCriacao)
        {
            var stringCsv = await _relatorioCheckoutPendenteServico.ObterRelatorioCheckoutPendentePorData(dataCriacao);
            var nomeArquivo = $"planejamentos_{dataCriacao.Year}_{dataCriacao.Month}_{dataCriacao.Day}.csv";

            if (string.IsNullOrEmpty(stringCsv))
            {
                return NoContent();
            }

            return File(new UTF8Encoding().GetBytes(stringCsv), "text/csv", nomeArquivo);
        }

        [HttpGet]
        public async Task<IActionResult> DownloadCsvPlanejamento([FromQuery]DateTime dataCriacao)
        {
            var stringCsv = await _relatorioCheckoutPendenteServico.ObterRelatorioPlanejamentoPorData(dataCriacao);
            var nomeArquivo = $"planejamentos_{dataCriacao.Year}_{dataCriacao.Month}_{dataCriacao.Day}.csv";

            if (string.IsNullOrEmpty(stringCsv))
            {
                return NoContent();
            }

            return File(new UTF8Encoding().GetBytes(stringCsv), "text/csv", nomeArquivo);
        }

        [HttpGet]
        public async Task<IActionResult> CriarRelatoriosPorData([FromQuery]DateTime dataCriacao)
        {
            try
            {
                await _relatorioCheckoutPendenteServico.CriarRelatorios(dataCriacao);

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}