﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class NPSGlobalPersonnaliteViewModel : BaseUploadViewModel
    {
        public NPSGlobalPersonnaliteViewModel()
        {
            Ano = (short)DateTime.Now.Year;
        }

        public Enums.Segmentos Segmento { get; set; }
        public short Ano { get; set; }
    }
}
