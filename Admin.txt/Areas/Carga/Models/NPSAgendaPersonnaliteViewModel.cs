﻿using Itau.SZ7.GPS.Admin.Enums;
using System;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class NPSAgendaPersonnaliteViewModel : BaseUploadViewModel
    {
        public NPSAgendaPersonnaliteViewModel()
        {
            Ano = (short)DateTime.Now.Year;
            Mes = (short)DateTime.Now.Month;
        }

        public Segmentos Segmento { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
    }
}
