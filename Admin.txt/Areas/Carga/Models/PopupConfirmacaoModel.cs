﻿namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class PopupConfirmacaoModel
    {
        public string Mensagem { get; set; }
        public string TituloBotaoOk { get; set; }
        public string TituloBotaoCancelar { get; set; }
    }
}
