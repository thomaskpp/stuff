﻿
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class ConfiguracoesStatusViewModel : BaseUploadViewModel
    {
        public CargasTipoPeriodo PeriodoTipo { get; set; }

        public List<DateTime> ListaDatas { get; set; }

        public IEnumerable<GerenciadorCargaGridConfiguracoes> ListCargas { get; set; }
    }
}
