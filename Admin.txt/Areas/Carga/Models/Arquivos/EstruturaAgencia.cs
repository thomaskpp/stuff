﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class EstruturaAgencia
    {
        public string Agencia { get; set; }
        public string Coordenadora { get; set; }
        public string Regional { get; set; }
        public string Regiao { get; set; }
        public string Dicom { get; set; }
        public string Ativo { get; set; }
        public string Tipo { get; set; }
        public string Visita { get; set; }

        public static List<EstruturaAgencia> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<EstruturaAgencia>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new EstruturaAgencia()
                {
                    Agencia = colunas[0],
                    Coordenadora = colunas[1],
                    Regional = colunas[2],
                    Regiao = colunas[3],
                    Dicom = colunas[4],
                    Ativo = colunas[5],
                    Tipo = colunas[6],
                    Visita = colunas[7]
                });
            }

            return resultado;
        }
    }
}
