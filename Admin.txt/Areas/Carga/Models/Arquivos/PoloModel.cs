﻿using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class PoloModel
    {
        public string Polo { get; set; }
        public string Tipo { get; set; }
        public string Funcional { get; set; }
        public string Racf { get; set; }
        public int IdEstrutura { get; set; }

        public static List<PoloModel> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<PoloModel>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new PoloModel()
                {
                    Polo = colunas[0],
                    Tipo = colunas[1],
                    Funcional = colunas[2],
                    Racf = colunas[3],
                    IdEstrutura = Convert.ToInt32(colunas[4])
                });
            }
            return resultado;
        }
    }
}
