﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class Meta
    {
        public string Data { get; set; }
        public string CodigoItem { get; set; }
        public string ValorMeta { get; set; }
        public string CodigoSegmento { get; set; }
        public string Carteira { get; set; }
        public int Grade { get; set; }

        public DateTime DataConvertida
        {
            get
            {
                return new DateTime(
                    Convert.ToInt32(Data.Substring(4, 4)),
                    Convert.ToInt32(Data.Substring(2, 2)),
                    1);
            }
        }

        public static List<Meta> ConverteColunas(ExcelWorksheet excelWorksheet)
        {
            var resultado = new List<Meta>();

            for (var x = 1; x <= excelWorksheet.Dimension.Rows; x++)
            {
                resultado.Add(new Meta()
                {
                    Data = excelWorksheet.Cells[x, 2].Text,
                    CodigoItem = excelWorksheet.Cells[x, 3].Text,
                    ValorMeta = excelWorksheet.Cells[x, 4].Text,
                    CodigoSegmento = excelWorksheet.Cells[x, 5].Text,
                    Carteira = excelWorksheet.Cells[x, 6].Text
                });
            }

            return resultado;
        }
    }
}
