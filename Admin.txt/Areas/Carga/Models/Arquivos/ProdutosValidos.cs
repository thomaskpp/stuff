﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class ProdutosValidos
    {
        public string Segmento { get; set; }
        public string CodigoItem { get; set; }
        public string NomeProduto { get; set; }
        public string Status { get; set; }
        public string CodigoProduto { get; set; }

        public static List<ProdutosValidos> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<ProdutosValidos>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new ProdutosValidos()
                {
                    Segmento = colunas[0],
                    CodigoItem = colunas[1],
                    NomeProduto = colunas[2],
                    Status = colunas[3],
                    CodigoProduto = colunas[4]
                });
            }

            return resultado;
        }
    }
}
