﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class Vocacoes
    {
        public string Grade { get; set; }
        public string CodVocacao { get; set; }

        public static List<Vocacoes> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<Vocacoes>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new Vocacoes()
                {
                    Grade = colunas[0],
                    CodVocacao = colunas[1]
                });
            }

            return resultado;
        }
    }
}
