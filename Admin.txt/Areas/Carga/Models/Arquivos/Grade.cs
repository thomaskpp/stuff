﻿using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class Grade
    {
        public string Segmento { get; set; }
        public string CodigoItem { get; set; }
        public string Bonus { get; set; }
        public string NomeItem { get; set; }
        public string GradeId { get; set; }
        public string Vinculo { get; set; }
        public string Peso { get; set; }
        public string IcmMaximo { get; set; }
        public string Agrupamento { get; set; }
        public string Ponderador { get; set; }
        public string Periodo { get; set; }
        public string ValorNoCheckout { get; set; }
        public string Icone { get; set; }
        public bool ExibicaoPlanejamento { get; private set; }
        public short ExibicaoPerformance { get; private set; }

        public static List<Grade> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<Grade>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new Grade()
                {
                    Segmento = colunas[0],
                    CodigoItem = colunas[1],
                    Bonus = colunas[2],
                    NomeItem = colunas[3],
                    GradeId = colunas[4],
                    Vinculo = colunas[5],
                    Peso = colunas[6],
                    IcmMaximo = colunas[7],
                    Agrupamento = colunas[8],
                    Ponderador = colunas[9],
                    Periodo = colunas[10],
                    ValorNoCheckout = colunas[11],
                    Icone = colunas[12],
                    ExibicaoPlanejamento = ConverteColuna(colunas[14]),
                    ExibicaoPerformance = ConverteColunaExibicaoPerformance(colunas[15])
                });
            }

            return resultado;
        }

        private static short ConverteColunaExibicaoPerformance(string valor)
        {
            short retorno = 0;
            if(short.TryParse(valor, out retorno))
            {
                return retorno;
            }
            return 3;
        }

        private static bool ConverteColuna(string valor)
        {
            return string.IsNullOrEmpty(valor) || valor.ToUpper() == "S";
        }
    }
}
