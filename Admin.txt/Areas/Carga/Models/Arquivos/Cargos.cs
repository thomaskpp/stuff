﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class Cargos
    {
        public string COD_CARGO_RH { get; set; }
        public string NOME_CARGO_RH { get; set; }
        public string SEGMENTO { get; set; }
        public string NOME_CARGO_GPS { get; set; }
        public string TRAT_AG { get; set; }

        public static List<Cargos> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<Cargos>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new Cargos()
                {
                    COD_CARGO_RH = colunas[0],
                    NOME_CARGO_RH = colunas[1],
                    SEGMENTO = colunas[2],
                    NOME_CARGO_GPS = colunas[3],
                    TRAT_AG = colunas[4]
                });
            }
            return resultado;
        }
    }
}
