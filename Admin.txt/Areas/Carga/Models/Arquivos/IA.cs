﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class IA
    {
        public string DataPrg { get; set; }
        public string Par_Agir { get; set; }
        public string Agencia { get; set; }
        public string Nome_Agencia { get; set; }
        public string Porte { get; set; }
        public string Dicom { get; set; }
        public string Regiao { get; set; }
        public string Coord_AGIR { get; set; }
        public string Data_Ab { get; set; }
        public string Vocacao_Grade { get; set; }
        public string NR_UNICLASS_MENOR_NIVEL { get; set; }
        public string Nucleo_EMP4 { get; set; }
        public string Regiao_GRA { get; set; }
        public string Subregiao_GRA { get; set; }
        public string TIPO { get; set; }
        public string GRADE { get; set; }

        public static List<IA> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<IA>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new IA()
                {
                    DataPrg = colunas[0],
                    Par_Agir = colunas[1],
                    Agencia = colunas[2],
                    Nome_Agencia = colunas[3],
                    Porte = colunas[4],
                    Dicom = colunas[5],
                    Regiao = colunas[6],
                    Coord_AGIR = colunas[7],
                    Data_Ab = colunas[8],
                    Vocacao_Grade = colunas[9],
                    NR_UNICLASS_MENOR_NIVEL = colunas[10],
                    Nucleo_EMP4 = colunas[11],
                    Regiao_GRA = colunas[12],
                    Subregiao_GRA = colunas[13],
                    TIPO = colunas[14],
                    GRADE = colunas[15]
                });
            }
            return resultado;
        }
    }
}
