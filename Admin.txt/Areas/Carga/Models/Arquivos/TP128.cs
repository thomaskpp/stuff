﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class TP128
    {
        public string NUMFUNC { get; set; }
        public string NOMFUNC { get; set; }
        public string QUADRO { get; set; }
        public string EMAIL { get; set; }
        public string NIVELCRG { get; set; }
        public string DESCNIVELCRG { get; set; }
        public string CDCRGP { get; set; }
        public string NOMECRGP { get; set; }
        public string DTACRGP { get; set; }
        public string DTAORG { get; set; }
        public string DTADMF { get; set; }
        public string NUMFUNC_GESTOR { get; set; }
        public string NOMFUNC_GESTOR { get; set; }
        public string NOMEORG_GESTOR { get; set; }
        public string DEPTID_GESTOR { get; set; }
        public string NOMECRGP_GESTOR { get; set; }
        public string DESCNIVELCRG_GESTOR { get; set; }
        public string CDSEQORG { get; set; }
        public string CLASSDEPTID { get; set; }
        public string CARACTDEPTID { get; set; }
        public string SIGLADEPT { get; set; }
        public string DESCDEPT { get; set; }
        public string HIERARQUIA_00_DEPTDESC { get; set; }
        public string HIERARQUIA_01_DEPTDESC { get; set; }
        public string HIERARQUIA_01_DEPTID { get; set; }
        public string HIERARQUIA_01_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_01_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_02_DEPTDESC { get; set; }
        public string HIERARQUIA_02_DEPTID { get; set; }
        public string HIERARQUIA_02_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_02_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_03_DEPTDESC { get; set; }
        public string HIERARQUIA_03_DEPTID { get; set; }
        public string HIERARQUIA_03_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_03_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_04_DEPTDESC { get; set; }
        public string HIERARQUIA_04_DEPTID { get; set; }
        public string HIERARQUIA_04_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_04_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_05_DEPTDESC { get; set; }
        public string HIERARQUIA_05_DEPTID { get; set; }
        public string HIERARQUIA_05_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_05_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_06_DEPTDESC { get; set; }
        public string HIERARQUIA_06_DEPTID { get; set; }
        public string HIERARQUIA_06_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_06_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_07_DEPTDESC { get; set; }
        public string HIERARQUIA_07_DEPTID { get; set; }
        public string HIERARQUIA_07_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_07_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_08_DEPTDESC { get; set; }
        public string HIERARQUIA_08_DEPTID { get; set; }
        public string HIERARQUIA_08_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_08_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_09_DEPTDESC { get; set; }
        public string HIERARQUIA_09_DEPTID { get; set; }
        public string HIERARQUIA_09_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_09_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_10_DEPTDESC { get; set; }
        public string HIERARQUIA_10_DEPTID { get; set; }
        public string HIERARQUIA_10_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_10_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_11_DEPTDESC { get; set; }
        public string HIERARQUIA_11_DEPTID { get; set; }
        public string HIERARQUIA_11_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_11_NUMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_12_DEPTDESC { get; set; }
        public string HIERARQUIA_12_DEPTID { get; set; }
        public string HIERARQUIA_12_NOMFUNC_TITULAR { get; set; }
        public string HIERARQUIA_12_NUMFUNC_TITULAR { get; set; }
        public string CODEMPI { get; set; }
        public string NOMEMR { get; set; }
        public string NOMEORG { get; set; }
        public string AGENFIL { get; set; }
        public string DESCPOLO { get; set; }
        public string LOGRAD { get; set; }
        public string NUMERLT { get; set; }
        public string COMPL { get; set; }
        public string COMPL2 { get; set; }
        public string ANDAR { get; set; }
        public string N_EDIFICIO { get; set; }
        public string BAIRRO { get; set; }
        public string CIDADE { get; set; }
        public string ESTADO { get; set; }
        public string REGIAO_BRASIL { get; set; }
        public string SEXOFUNC { get; set; }
        public string CDREABIL { get; set; }
        public string DESCPNE { get; set; }
        public string IDADE { get; set; }
        public string ESCOLARIDADE { get; set; }
        public string INICIO_FERIAS1 { get; set; }
        public string FIM_FERIAS1 { get; set; }
        public string INICIO_FERIAS2 { get; set; }
        public string FIM_FERIAS2 { get; set; }
        public string INICIO_FERIAS3 { get; set; }
        public string FIM_FERIAS3 { get; set; }
        public string DTINLIC { get; set; }
        public string LIC_DESC { get; set; }
        public string DTFILIC { get; set; }
        public string DT_AUSENCIA { get; set; }
        public string JUST_AUSENCIA { get; set; }
        public string IDGESTP_DESC { get; set; }
        public string NUMTITEL { get; set; }
        public string DIRIGENTE_SINDICAL	{ get; set; }
        public string DT_INICIO_MANDATO { get; set; }
        public string DT_FIM_MANDATO { get; set; }
        public string FREQUENCIA_LIVRE { get; set; }
        public string MEMBRO_CIPA_DESC { get; set; }
        public string MANDATO_INI_DT { get; set; }
        public string MANDATO_FIM_DT { get; set; }
        public string ESTABILIDADE { get; set; }
        public string COMENTARIOS { get; set; }
        public string TIPO_DE_ESTABILIDADE { get; set; }
        public string INICIO_DA_ESTABILIDADE { get; set; }
        public string FIM_DA_ESTABILIDADE { get; set; }
        public string SEG_DEPT { get; set; }
        public string DATABASE { get; set; }
        public string CBODE { get; set; }
        public string DESC_PREDIO { get; set; }
        public string HENHT { get; set; }
        public string IRNHT { get; set; }
        public string FRNHT { get; set; }
        public string HSNHT { get; set; }
        public string TELEFONCOML { get; set; }
        public string NOME_INSTITUICAO { get; set; }
        public string NOME_CURSO { get; set; }
        public string DT_INIC_CUR { get; set; }
        public string DT_FIM_CUR { get; set; }
        public string EMAIL_CORPORATIVO { get; set; }

        public static List<TP128> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<TP128>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new TP128()
                {
                    NUMFUNC = colunas[0],
                    NOMFUNC = colunas[1],
                    QUADRO = colunas[2],
                    EMAIL = colunas[3],
                    NIVELCRG = colunas[4],
                    DESCNIVELCRG = colunas[5],
                    CDCRGP = colunas[6],
                    NOMECRGP = colunas[7],
                    DTACRGP = colunas[8],
                    DTAORG = colunas[9],
                    DTADMF = colunas[10],
                    NUMFUNC_GESTOR = colunas[11],
                    NOMFUNC_GESTOR = colunas[12],
                    NOMEORG_GESTOR = colunas[13],
                    DEPTID_GESTOR = colunas[14],
                    NOMECRGP_GESTOR = colunas[15],
                    DESCNIVELCRG_GESTOR = colunas[16],
                    CDSEQORG = colunas[17],
                    CLASSDEPTID = colunas[18],
                    CARACTDEPTID = colunas[19],
                    SIGLADEPT = colunas[20],
                    DESCDEPT = colunas[21],
                    HIERARQUIA_00_DEPTDESC = colunas[22],
                    HIERARQUIA_01_DEPTDESC = colunas[23],
                    HIERARQUIA_01_DEPTID = colunas[24],
                    HIERARQUIA_01_NOMFUNC_TITULAR = colunas[25],
                    HIERARQUIA_01_NUMFUNC_TITULAR = colunas[26],
                    HIERARQUIA_02_DEPTDESC = colunas[27],
                    HIERARQUIA_02_DEPTID = colunas[28],
                    HIERARQUIA_02_NOMFUNC_TITULAR = colunas[29],
                    HIERARQUIA_02_NUMFUNC_TITULAR = colunas[30],
                    HIERARQUIA_03_DEPTDESC = colunas[31],
                    HIERARQUIA_03_DEPTID = colunas[32],
                    HIERARQUIA_03_NOMFUNC_TITULAR = colunas[33],
                    HIERARQUIA_03_NUMFUNC_TITULAR = colunas[34],
                    HIERARQUIA_04_DEPTDESC = colunas[35],
                    HIERARQUIA_04_DEPTID = colunas[36],
                    HIERARQUIA_04_NOMFUNC_TITULAR = colunas[37],
                    HIERARQUIA_04_NUMFUNC_TITULAR = colunas[38],
                    HIERARQUIA_05_DEPTDESC = colunas[39],
                    HIERARQUIA_05_DEPTID = colunas[40],
                    HIERARQUIA_05_NOMFUNC_TITULAR = colunas[41],
                    HIERARQUIA_05_NUMFUNC_TITULAR = colunas[42],
                    HIERARQUIA_06_DEPTDESC = colunas[43],
                    HIERARQUIA_06_DEPTID = colunas[44],
                    HIERARQUIA_06_NOMFUNC_TITULAR = colunas[45],
                    HIERARQUIA_06_NUMFUNC_TITULAR = colunas[46],
                    HIERARQUIA_07_DEPTDESC = colunas[47],
                    HIERARQUIA_07_DEPTID = colunas[48],
                    HIERARQUIA_07_NOMFUNC_TITULAR = colunas[49],
                    HIERARQUIA_07_NUMFUNC_TITULAR = colunas[50],
                    HIERARQUIA_08_DEPTDESC = colunas[51],
                    HIERARQUIA_08_DEPTID = colunas[52],
                    HIERARQUIA_08_NOMFUNC_TITULAR = colunas[53],
                    HIERARQUIA_08_NUMFUNC_TITULAR = colunas[54],
                    HIERARQUIA_09_DEPTDESC = colunas[55],
                    HIERARQUIA_09_DEPTID = colunas[56],
                    HIERARQUIA_09_NOMFUNC_TITULAR = colunas[57],
                    HIERARQUIA_09_NUMFUNC_TITULAR = colunas[58],
                    HIERARQUIA_10_DEPTDESC = colunas[59],
                    HIERARQUIA_10_DEPTID = colunas[60],
                    HIERARQUIA_10_NOMFUNC_TITULAR = colunas[61],
                    HIERARQUIA_10_NUMFUNC_TITULAR = colunas[62],
                    HIERARQUIA_11_DEPTDESC = colunas[63],
                    HIERARQUIA_11_DEPTID = colunas[64],
                    HIERARQUIA_11_NOMFUNC_TITULAR = colunas[65],
                    HIERARQUIA_11_NUMFUNC_TITULAR = colunas[66],
                    HIERARQUIA_12_DEPTDESC = colunas[67],
                    HIERARQUIA_12_DEPTID = colunas[68],
                    HIERARQUIA_12_NOMFUNC_TITULAR = colunas[69],
                    HIERARQUIA_12_NUMFUNC_TITULAR = colunas[70],
                    CODEMPI = colunas[71],
                    NOMEMR = colunas[72],
                    NOMEORG = colunas[73],
                    AGENFIL = colunas[74],
                    DESCPOLO = colunas[75],
                    LOGRAD = colunas[76],
                    NUMERLT = colunas[77],
                    COMPL = colunas[78],
                    COMPL2 = colunas[79],
                    ANDAR = colunas[80],
                    N_EDIFICIO = colunas[81],
                    BAIRRO = colunas[82],
                    CIDADE = colunas[83],
                    ESTADO = colunas[84],
                    REGIAO_BRASIL = colunas[85],
                    SEXOFUNC = colunas[86],
                    CDREABIL = colunas[87],
                    DESCPNE = colunas[88],
                    IDADE = colunas[89],
                    ESCOLARIDADE = colunas[90],
                    INICIO_FERIAS1 = colunas[91],
                    FIM_FERIAS1 = colunas[92],
                    INICIO_FERIAS2 = colunas[93],
                    FIM_FERIAS2 = colunas[94],
                    INICIO_FERIAS3 = colunas[95],
                    FIM_FERIAS3 = colunas[96],
                    DTINLIC = colunas[97],
                    LIC_DESC = colunas[98],
                    DTFILIC = colunas[99],
                    DT_AUSENCIA = colunas[100],
                    JUST_AUSENCIA = colunas[101],
                    IDGESTP_DESC = colunas[102],
                    NUMTITEL = colunas[103],
                    DIRIGENTE_SINDICAL = colunas[104],
                    DT_INICIO_MANDATO = colunas[105],
                    DT_FIM_MANDATO = colunas[106],
                    FREQUENCIA_LIVRE = colunas[107],
                    MEMBRO_CIPA_DESC = colunas[108],
                    MANDATO_INI_DT = colunas[109],
                    MANDATO_FIM_DT = colunas[110],
                    ESTABILIDADE = colunas[111],
                    COMENTARIOS = colunas[112],
                    TIPO_DE_ESTABILIDADE = colunas[113],
                    INICIO_DA_ESTABILIDADE = colunas[114],
                    FIM_DA_ESTABILIDADE = colunas[115],
                    SEG_DEPT = colunas[116],
                    DATABASE = colunas[117],
                    CBODE = colunas[118],
                    DESC_PREDIO = colunas[119],
                    HENHT = colunas[120],
                    IRNHT = colunas[121],
                    FRNHT = colunas[122],
                    HSNHT = colunas[123],
                    TELEFONCOML = colunas[124],
                    NOME_INSTITUICAO = colunas[125],
                    NOME_CURSO = colunas[126],
                    DT_INIC_CUR = colunas[127],
                    DT_FIM_CUR = colunas[128],
                    EMAIL_CORPORATIVO = colunas[129]
                });
            }
            return resultado;
        }
    }
}
