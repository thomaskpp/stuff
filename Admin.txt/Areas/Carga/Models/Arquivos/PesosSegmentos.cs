﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class PesosSegmentos
    {
        public string ChavePeso { get; set; }
        public string ValorPesoIA { get; set; }
        public string ValorPesoIU { get; set; }
        public string ValorPesoEMP4 { get; set; }

        public static List<PesosSegmentos> ListaPesosSegmentos()
        {
            List<PesosSegmentos> pesosSegmentos = new List<PesosSegmentos>();

            pesosSegmentos.Add(new PesosSegmentos
            {
                ChavePeso = "111",
                ValorPesoIA = "0.3",
                ValorPesoIU = "0.4",
                ValorPesoEMP4 = "0.3"

            });
            pesosSegmentos.Add(new PesosSegmentos
            {
                ChavePeso = "110",
                ValorPesoIA = "0.4",
                ValorPesoIU = "0.6",
                ValorPesoEMP4 = "0"
            });
            pesosSegmentos.Add(new PesosSegmentos
            {
                ChavePeso = "100",
                ValorPesoIA = "1",
                ValorPesoIU = "0",
                ValorPesoEMP4 = "0"

            });
            pesosSegmentos.Add(new PesosSegmentos
            {
                ChavePeso = "010",
                ValorPesoIA = "0",
                ValorPesoIU = "1",
                ValorPesoEMP4 = "0"

            });
            pesosSegmentos.Add(new PesosSegmentos
            {
                ChavePeso = "001",
                ValorPesoIA = "0",
                ValorPesoIU = "0",
                ValorPesoEMP4 = "1"

            });
            pesosSegmentos.Add(new PesosSegmentos
            {
                ChavePeso = "101",
                ValorPesoIA = "0.4",
                ValorPesoIU = "0",
                ValorPesoEMP4 = "0.6"

            });
            return pesosSegmentos;
        }

    }
}
