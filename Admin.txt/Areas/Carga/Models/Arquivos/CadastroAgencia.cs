﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class CadastroAgencia
    {
        public string FUNCIONAL { get; set; }
        public string RACF { get; set; }
        public string NOME { get; set; }
        public string NOME_COMPLETO { get; set; }
        public string AGENCIA { get; set; }
        public string CARTEIRA { get; set; }
        public string CARGO { get; set; }
        public string SEGMENTO { get; set; }
        public string ATIVO { get; set; }
        public string INICIO_FERIAS1 { get; set; }
        public string FIM_FERIAS1 { get; set; }
        public string INICIO_FERIAS2 { get; set; }
        public string FIM_FERIAS2 { get; set; }
        public string INICIO_FERIAS3 { get; set; }
        public string FIM_FERIAS3 { get; set; }
        public string DATABASE { get; set; }
        public string ELEGIVEL_ENGAJAMENTO { get; set; }
        public string DIAS_INDISPONIVEIS { get; set; }
        public string NUMFUNC_GESTOR { get; set; }

        public static List<CadastroAgencia> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<CadastroAgencia>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new CadastroAgencia()
                {
                    FUNCIONAL = colunas[0],
                    RACF = colunas[1],
                    NOME = colunas[2],
                    NOME_COMPLETO = colunas[3],
                    AGENCIA = colunas[4],
                    CARTEIRA = colunas[5],
                    CARGO = colunas[6],
                    SEGMENTO = colunas[7],
                    ATIVO = colunas[8],
                    INICIO_FERIAS1 = colunas[9],
                    FIM_FERIAS1 = colunas[10],
                    INICIO_FERIAS2 = colunas[11],
                    FIM_FERIAS2 = colunas[12],
                    INICIO_FERIAS3 = colunas[13],
                    FIM_FERIAS3 = colunas[14],
                    DATABASE = colunas[15],
                    ELEGIVEL_ENGAJAMENTO = colunas[16],
                    DIAS_INDISPONIVEIS = colunas[17],
                    NUMFUNC_GESTOR = colunas[18]
                });
            }
            return resultado;
        }
    }
}
