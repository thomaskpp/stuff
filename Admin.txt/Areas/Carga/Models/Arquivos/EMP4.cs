﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class EMP4
    {
        public string DATA_REF { get; set; }
        public string CARTEIRA_MENOR { get; set; }
        public string CARTEIRA_MAIOR { get; set; }
        public string DICOM { get; set; }
        public string REGIAO { get; set; }
        public string SUBREGIAO { get; set; }
        public string NOME_GRA { get; set; }
        public string NOME_GGN { get; set; }
        public string SEGMENTO { get; set; }
        public string CARTEIRA_COORDENADORA { get; set; }
        public string AGENCIA_COORDENADORA { get; set; }
        public string CARTEIRA_COORDENADORA2 { get; set; }
        public string CARTEIRA { get; set; }
        public string AGENCIA { get; set; }
        public string GERENTE { get; set; }
        public string FUNCIONAL_GR { get; set; }
        public string NOME_GR { get; set; }
        public string TIPO_CARTEIRA { get; set; }
        public string CLIENTES { get; set; }
        public string VOCACAO { get; set; }
        public string MAIOR_NIVEL { get; set; }
        public string FERIAS { get; set; }
        public string PORTE_SEMESTRAL { get; set; }
        public string porte_codigo { get; set; }
        public string Grade { get; set; }

        public static List<EMP4> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<EMP4>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new EMP4()
                {
                    DATA_REF = colunas[0],
                    CARTEIRA_MENOR = colunas[1],
                    CARTEIRA_MAIOR = colunas[2],
                    DICOM = colunas[3],
                    REGIAO = colunas[4],
                    SUBREGIAO = colunas[5],
                    NOME_GRA = colunas[6],
                    NOME_GGN = colunas[7],
                    SEGMENTO = colunas[8],
                    CARTEIRA_COORDENADORA = colunas[9],
                    AGENCIA_COORDENADORA = colunas[10],
                    CARTEIRA_COORDENADORA2 = colunas[11],
                    CARTEIRA = colunas[12],
                    AGENCIA = colunas[13],
                    GERENTE = colunas[14],
                    FUNCIONAL_GR = colunas[15],
                    NOME_GR = colunas[16],
                    TIPO_CARTEIRA = colunas[17],
                    CLIENTES = colunas[18],
                    VOCACAO = colunas[19],
                    MAIOR_NIVEL = colunas[20],
                    FERIAS = colunas[21],
                    PORTE_SEMESTRAL = colunas[22],
                    porte_codigo = colunas[23],
                    Grade = colunas[24]
                });
            }
            return resultado;
        }
    }
}
