﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models.Arquivos
{
    public class Uniclass
    {
        public string DataPrg { get; set; }
        public string DICOM { get; set; }
        public string REGIAO { get; set; }
        public string SUBREGIAO { get; set; }
        public string NOME_GRA { get; set; }
        public string GGN { get; set; }
        public string SEGMENTO { get; set; }
        public string CARTEIRA_COORDENADORA { get; set; }
        public string AGENCIA_COORDENADORA { get; set; }
        public string CARTEIRA_COORDENADORA2 { get; set; }
        public string CARTEIRA { get; set; }
        public string AGENCIA { get; set; }
        public string GERENTE { get; set; }
        public string FUNCIONAL_GR { get; set; }
        public string NOME_GR { get; set; }
        public string TIPO_CARTEIRA { get; set; }
        public string Qtde_Clientes { get; set; }
        public string Vocacao { get; set; }
        public string GRADE { get; set; }

        public static List<Uniclass> ConverteColunas(List<string> linhas)
        {
            var resultado = new List<Uniclass>();

            foreach (var linha in linhas)
            {
                var colunas = linha.Split(";");

                resultado.Add(new Uniclass()
                {
                    DataPrg = colunas[0],
                    DICOM = colunas[1],
                    REGIAO = colunas[2],
                    SUBREGIAO = colunas[3],
                    NOME_GRA = colunas[4],
                    GGN = colunas[5],
                    SEGMENTO = colunas[6],
                    CARTEIRA_COORDENADORA = colunas[7],
                    AGENCIA_COORDENADORA = colunas[8],
                    CARTEIRA_COORDENADORA2 = colunas[9],
                    CARTEIRA = colunas[10],
                    AGENCIA = colunas[11],
                    GERENTE = colunas[12],
                    FUNCIONAL_GR = colunas[13],
                    NOME_GR = colunas[14],
                    TIPO_CARTEIRA = colunas[15],
                    Qtde_Clientes = colunas[16],
                    Vocacao = colunas[17],
                    GRADE = colunas[18]
                });
            }
            return resultado;
        }
    }
}
