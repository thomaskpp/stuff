﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Models;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class BaseUploadViewModel : BaseViewModel
    {
        public BaseUploadViewModel()
        {
            Cargas = new List<GerenciadorCarga>();
            ItensAbertos = new List<int>();
        }

        public IEnumerable<GerenciadorCarga> Cargas { get; set; }

        public IEnumerable<GerenciadorCarga> CargasAtivas
        {
            get
            {
                return Cargas?.Where(x => !x.Finalizado) ?? Enumerable.Empty<GerenciadorCarga>();
            }
        }

        public IEnumerable<GerenciadorCarga> CargasFinalizadas
        {
            get
            {
                return Cargas?.Where(x => x.Finalizado) ?? Enumerable.Empty<GerenciadorCarga>();
            }
        }

        public Entities.Funcionalidade.Enum CargaTipo { get; set; }

        public bool CargaEmAndamento { get; set; }

        public bool MostrarCargasEmAndamento { get; set; }

        public List<int> ItensAbertos { get; set; }

        public IEnumerable<GerenciadorCarga> MostrarPopup
        {
            get
            {
                return Cargas?.Where(x => x.PopupConclusao) ?? Enumerable.Empty<GerenciadorCarga>();
            }
        }

    }
}
