﻿
using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class EditarConfiguracoesViewModel: BaseUploadViewModel
    {
        public EditarConfiguracoesViewModel()
        {
            DiasDoMes = string.Empty;
            DiasExato = string.Empty;
            ListaDias = new List<int>();
        }

        public Cargas CargaTipo { get; set; }

        public CargasTipoPeriodo PeriodoTipo { get; set; }

        public string DiasDoMes { get; set; }
        public string DiasExato { get; set; }

        public List<int> ListaDias { get; set; }

        public MultiSelectList ValoresDiasdaSemana { get; set; }
        public MultiSelectList Funcionalidades { get; set; }

        public bool PrimeiroDiaUtil { get; set; }
        public bool UtimoDiaUtil { get; set; }
        public bool TravaSimultanea { get; set; }

        public int IdFuncionalidade { get; set; }
    }
}
