﻿namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class InnerLoopViewModel : BaseUploadViewModel
    {
        public int Segmento { get; set; }
    }
}
