﻿using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class GerenciadorCargaErrosViewModel : BaseUploadViewModel
    {
        public GerenciadorCarga Carga { get; set; }
        public List<GerenciadorCargaErro> CargaErros { get; set; }
    }
}
