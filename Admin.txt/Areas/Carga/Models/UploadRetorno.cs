﻿using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class UploadRetorno
    {
        public UploadRetorno()
        {
            Colunas = new List<UploadRetornoColuna>();
        }

        public UploadRetorno(int linha, List<UploadRetornoColuna> colunas)
        {
            Linha = linha;
            Colunas = colunas;
        }

        public int Linha { get; set; }
        public List<UploadRetornoColuna> Colunas { get; set; }

        public override string ToString()
        {
            return $"{string.Concat(Colunas.Select(x => x.ToString()))}";
        }
    }

    public class UploadRetornoColuna
    {
        public UploadRetornoColuna(string coluna, string descricao)
        {
            Coluna = coluna;
            Descricao = descricao;
        }

        public UploadRetornoColuna(string coluna, string descricao, string detalhe)
        {
            Coluna = coluna;
            Descricao = descricao;
            Detalhe = detalhe;
        }

        public string Coluna { get; set; }
        public string Descricao { get; set; }
        public string Detalhe { get; set; }

        public override string ToString()
        {
            return $"<br>{Coluna}: {Descricao}";
        }
    }
}
