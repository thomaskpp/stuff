﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class CoachClickViewModel
    {
        public string Teste { get; set; }
    }
}
