﻿using Itau.SZ7.GPS.Admin.Entities;
using System;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class GradePersonnaliteViewModel : BaseUploadViewModel
    {
        public GradePersonnaliteViewModel()
        {
            Ano = (short)DateTime.Now.Year;
            Mes = (short)DateTime.Now.Month;
        }

        public Enums.Segmentos Segmento { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
    }
}
