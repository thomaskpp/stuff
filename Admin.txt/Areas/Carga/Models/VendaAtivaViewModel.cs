﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class VendaAtivaViewModel : BaseUploadViewModel
    {
        public int Segmento { get; set; }
        public SelectList Segmentos { get; set; }
    }
}
