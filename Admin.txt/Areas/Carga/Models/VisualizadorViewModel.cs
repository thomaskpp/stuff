﻿
using Itau.SZ7.GPS.Admin.Enums;
using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class VisualizarViewModel : BaseUploadViewModel
    {

        public VisualizarViewModel() : base()
        {
            this.CurrentList = new List<Entities.MetaConsolidada>();
            this.Agencias = new List<Entities.MetaConsolidada>();
            this.Uniclass = new List<Entities.MetaConsolidada>();
            this.Empresas = new List<Entities.MetaConsolidada>();
            this.MesSelecionado = DateTime.Now.Month;
            this.AnoSelecionado = DateTime.Now.Year;
            this.FiltroSelecionado = "TODOS";
        }

        public VisualizarArquivoVisao Visao { get; set; }

        public int MesSelecionado { get; set; }

        public int AnoSelecionado { get; set; }

        public string FiltroSelecionado { get; set; }

        public List<Entities.MetaConsolidada> CurrentList { get; set; }

        public List<Entities.MetaConsolidada> Agencias { get; set; }

        public List<Entities.MetaConsolidada> Uniclass { get; set; }

        public List<Entities.MetaConsolidada> Empresas { get; set; }
    }
}
