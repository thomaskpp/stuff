﻿using Itau.SZ7.GPS.Admin.Enums;
using System;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class VendaAtivaDadosStage
    {
        public DateTime Data { get; set; }
        public string IdControleCarga { get; set; }
        public long Clientes { get; set; }
        public long Ofertas { get; set; }
        public bool PodeExecutar { get; set; }
        public bool EmExecucao { get; set; }
        public bool Finalizado { get; set; }
        public Segmentos IdSegmento { get; set; }


    }
}
