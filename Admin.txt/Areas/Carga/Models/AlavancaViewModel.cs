﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class AlavancaViewModel : BaseUploadViewModel
    {
        public int Id { get; set; }
        public DateTime DataReferencia { get; set; }
        public int CodigoAgencia { get; set; }
        public string AbreviacaoSegmento { get; set; }
        public string CodigoFamilia { get; set; }
        public string NomeFamilia { get; set; }
        public string CodigoItem { get; set; }
        public string NomeItem { get; set; }
        public decimal ValorICMCiclo { get; set; }
        public decimal ValorPotencial { get; set; }
        public decimal ValorCapturado { get; set; }
    }
}
