﻿using Itau.SZ7.GPS.Admin.Entities;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class VerificadorProducaoViewModel : BaseUploadViewModel
    {
        public Enums.Segmentos Segmento { get; set; }

    }
}
