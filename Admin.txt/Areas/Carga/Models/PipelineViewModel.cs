﻿namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class PipelineViewModel : BaseUploadViewModel
    {
        public Enums.Segmentos Segmento { get; set; }
    }
}
