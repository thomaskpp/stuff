﻿using Itau.SZ7.GPS.Admin.Entities;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class NPSRespostaClienteViewModel : BaseUploadViewModel
    {
        public Enums.Segmentos Segmento { get; set; }
    }
}
