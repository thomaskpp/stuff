﻿
using Itau.SZ7.GPS.Admin.Enums;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class BaseViewModel
    {
        public BaseViewModel()
        {
            Erros = new List<string>();
        }

        public List<string> Erros { get; set; }
        public AdminAbaAtiva AbaAtiva { get; set; }
        public PopupConfirmacaoModel PopupConfirmacao { get; set; }
    }
}
