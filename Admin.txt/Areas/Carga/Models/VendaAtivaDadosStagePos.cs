﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class VendaAtivaDadosStagePos
    {
        public DateTime DataExecucao { get; set; }
        public string IdControleCarga { get; set; }
        public int OfertasPreExc { get; set; }
        public int ClientesPreExc { get; set; }
        public int OfertasPosExc { get; set; }
        public int ClientesPosExc { get; set; }
        public int OfertasAtualizadas { get; set; }
        public int ClientesAtualizados { get; set; }
    }
}
