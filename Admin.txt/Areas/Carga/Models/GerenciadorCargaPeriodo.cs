﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class GerenciadorCargaPeriodo
    {
        public GerenciadorCargaPeriodo()
        {
            DiasDaSemana = new List<int>();
            DiasExato = new List<string>();
            DiasDoMes = new List<int>();
        }

        public List<int> DiasDaSemana { get; set; }
        public List<int> DiasDoMes { get; set; }
        public List<string> DiasExato { get; set; }
        public bool PrimeiroDiaUtil { get; set; }
        public bool UltimoDiaUtil { get; set; }

        [JsonIgnore]
        public List<DateTime> DiasExatoToDate
        {
            get
            {
                var result = new List<DateTime>();

                if (DiasExato == null)
                    return result;

                foreach (var item in DiasExato)
                    result.Add(new DateTime(DateTime.Now.Year, Convert.ToInt32(item.Split("/")[1]), Convert.ToInt32(item.Split("/")[0])));

                return result;
            }
        }
    }
}
