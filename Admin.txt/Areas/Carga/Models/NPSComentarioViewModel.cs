﻿using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class NPSComentarioViewModel : BaseUploadViewModel
    {
        public NPSComentarioViewModel()
        {
            Ano = (short)DateTime.Now.Year;
            Mes = (short)DateTime.Now.Month;
        }

        public Enums.Segmentos Segmento { get; set; }
        public short Ano { get; set; }
        public short Mes { get; set; }
    }
}
