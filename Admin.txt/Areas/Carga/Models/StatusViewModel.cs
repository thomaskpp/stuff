﻿using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class StatusViewModel : BaseUploadViewModel
    {
        public StatusViewModel()
        {
            StatusCargas = new List<StatusCarga>();
        }

        public List<StatusCarga> StatusCargas { get; set; }
    }
}
