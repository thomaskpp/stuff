﻿namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class ReclamacoesViewModel : BaseUploadViewModel
    {
    }
}
