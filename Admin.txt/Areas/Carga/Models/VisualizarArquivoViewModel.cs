﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class VisualizarArquivoViewModel
    {
        public List<MetaConsolidada> Agencias { get; set; }

        public List<MetaConsolidada> Uniclass { get; set; }

        public List<MetaConsolidada> Empresas { get; set; }
    }
}
