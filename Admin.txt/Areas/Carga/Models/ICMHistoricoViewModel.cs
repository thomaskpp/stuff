﻿using System;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class ICMHistoricoViewModel : BaseUploadViewModel
    {
        public ICMHistoricoViewModel()
        {
            Ano = (short)DateTime.Now.Year;
        }

        public short Ano { get; set; }
        public short Mes { get; set; }
    }
}
