﻿
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Models
{
    public class BaixaAderenciaViewModel: BaseUploadViewModel
    {
        //public ColaboradorPerfilAcesso colaboradorPerfilAcesso { get; set; }
        public int CodigoPerfilAcesso { get; set; }
        public string Funcional { get; set; }

        public static BaixaAderenciaViewModel ConverteColunas(int linha, string colunas)
        {
            try
            {
                var arrayColunas = colunas.Split(';');

                return new BaixaAderenciaViewModel()
                {
                    CodigoPerfilAcesso = IntExtension.TryParse(arrayColunas[0]),
                    Funcional = arrayColunas[1]

                };
            }
            catch
            {
                return null;
            }
        }
        public static List<BaixaAderenciaViewModel> ConverteColunas(List<int> linhas, List<string> colunas)
        {
            var result = new List<BaixaAderenciaViewModel>();

            for (var x = 0; x < colunas.Count; x++)
            {
                var model = ConverteColunas(linhas[x], colunas[x]);

                if (model != null)
                    result.Add(model);
            }

            return result;
        }
    }
}
