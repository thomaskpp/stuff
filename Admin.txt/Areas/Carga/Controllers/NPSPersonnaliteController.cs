﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaNPSPersonnaliteAdmin })]
    public class NPSPersonnaliteController : BaseCargaController
    {
        private readonly INPSTransacionalServices _npsServices;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private readonly string[] _extensoesAceitas = new string[] { ".csv" };
        private readonly int _batchSize;

        public NPSPersonnaliteController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            INPSTransacionalServices npsServices,
            ISecurityServices securityServices) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _batchSize = configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

            _npsServices = npsServices;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new NPSTransacionalViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaNPSPersonnaliteAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();
            model.Segmento = Segmentos.Personnalite;

            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Index(NPSTransacionalViewModel model)
        {
            SetViewBag();
            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida Arquivos

            model.Erros.Clear();

            if (!Request.Form.Files.Any())
                model.Erros.Add("Por Favor, selecione o arquivo de carga");

            #region Carrega Arquivos

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");

                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaNPSPersonnaliteAdmin,
                    Mes = model.Mes,
                    Ano = model.Ano,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome
                };

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);
            }
            #endregion

            if (model.Erros.Any())
                return View(model);

            #endregion

            var task = new Task(() =>
            {
                var cargaSelecionada = gerenciadorCargas[0];

                #region Verifica Dados

                _npsServices.LimpaCache();

                VerificaUpload(gerenciadorCargas, model.Segmento, _npsServices.VerificaLinhaArquivo);

                #endregion

                #region Deleta todos os registros

                _npsServices.RemoveTodosItens(model.Mes, model.Ano);

                #endregion

                #region Valida se as agências na planilha existem e insere os registros

                UpsertUpload(gerenciadorCargas, model.Segmento, _npsServices.Insert, null);

                #endregion

                #region grava gerenciador
                cargaSelecionada.Fim = DateTime.Now;
                _gerenciadorCargaServices.GravarGerenciador(cargaSelecionada);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
    }
}