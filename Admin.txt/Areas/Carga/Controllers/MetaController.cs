﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;

using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Extensions;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaMetaAdmin })]
    public class MetaController : BaseCargaController
    {
        private readonly IMetaServices _metaServices;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private readonly string[] _extensoesAceitas = new string[] { ".xlsx" };
        private readonly int _batchSize;

        public MetaController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            IMetaServices metaServices,
            ISecurityServices securityServices) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _batchSize = configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

            _metaServices = metaServices;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new MetaViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaMetaAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Index(MetaViewModel model)
        {
            SetViewBag();
            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida arquivos

            model.Erros.Clear();

            if (!Request.Form.Files.Any())
            {
                model.Erros.Add("Por favor, selecione o arquivo de carga.");
            }

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                {
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");
                }

                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaMetaAdmin,
                    Ano = model.Ano,
                    Mes = model.Mes,
                    IdColaborador = Colaborador.Id,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdSegmento = 200,
                    GravaCarga = false
                };

                //var carga = new GerenciadorCarga()
                //{
                //    Arquivo = arquivo.FileName,
                //    IdFuncionalidade = Funcionalidade.Enum.CargaMetaAdmin,
                //    Ano = model.Ano,
                //    Mes = model.Mes,
                //    Funcional = Colaborador?.Funcional,
                //    NomeFuncional = Colaborador?.Nome,
                //    Segmento = model.Segmento,
                //    GravaCarga = false
                //};

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);
            }

            if (model.Erros.Any())
            {
                return View(model);
            }

            #endregion

            var task = new Task(() =>
            {
                #region grava gerenciador

                var cargaMetas = new GerenciadorCarga()
                {
                    IdFuncionalidade = Funcionalidade.Enum.CargaMetaAdmin,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    Inicio = DateTime.Now,
                    IdColaborador = Colaborador.Id
                };

                _gerenciadorCargaServices.GravarGerenciador(cargaMetas);

                var passoVerificacao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Validacao,
                    Nome = CargasPassos.Validacao.ToString(),
                    Atualizado = DateTime.Now
                };

                cargaMetas.Passos.Add(passoVerificacao);


                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Agências Fake",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Colaboradores Fake",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Metas GG",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Itens Metas GG",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Metas GRA",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Itens Metas GRA",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Metas Supt",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Itens Metas Supt",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Metas Dicom",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Itens Metas Dicom",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Metas Fake",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Itens Metas Fake",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Recalcular Checkin",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Recalcular Checkout",
                    Atualizado = DateTime.Now
                });
                cargaMetas.Passos.Add(new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaMetas.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = "Recalcular Desafio",
                    Atualizado = DateTime.Now
                });


                _gerenciadorCargaServices.GravarGerenciador(cargaMetas);

                GerenciadorCargaAtual = cargaMetas;

                #endregion

                #region Verifica dados

                _metaServices.LimpaCache();

                VerificaUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _metaServices.VerificaLinhaArquivoNovo, false);

                #endregion

                #region grava gerenciador

                cargaMetas.TotalLinhas = gerenciadorCargas.Sum(x => x.TotalLinhas);
                passoVerificacao.LinhasProcessadas = 1;
                passoVerificacao.Fim = DateTime.Now;

                _gerenciadorCargaServices.GravarGerenciador(cargaMetas);

                #endregion

                #region Insere dados

                _metaServices.InsertUpdate(gerenciadorCargas, _batchSize, cargaMetas);

                #endregion

                //#region grava gerenciador

                //var passoLimpeza = new GerenciadorCargaPasso()
                //{
                //    IdGerenciadorCarga = cargaMetas.Id,
                //    Passo = CargasPassos.PosExecucao,
                //    Nome = CargasPassos.PosExecucao.Description(),
                //    Atualizado = DateTime.Now
                //};

                //cargaMetas.Passos.Add(passoLimpeza);
                //_gerenciadorCargaServices.GravarGerenciador(cargaMetas);

                //#endregion

                //#region Limpa itens obsoletos

                //_metaServices.RemoveItensObsoletos(cargaMetas);

                //#endregion

                #region grava gerenciador

                //passoLimpeza.Fim = DateTime.Now;

                cargaMetas.Fim = DateTime.Now;
                _gerenciadorCargaServices.GravarGerenciador(cargaMetas);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
    }
}