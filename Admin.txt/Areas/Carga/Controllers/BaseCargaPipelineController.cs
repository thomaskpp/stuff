﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    public class BaseCargaPipelineController : BaseCargaController
    {
        private readonly IConfiguration _configuration;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private IEnumerable<GerenciadorCarga> cargasRecentes = Enumerable.Empty<GerenciadorCarga>();

        public BaseCargaPipelineController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            ISecurityServices securityServices
            ) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _configuration = configuration;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        public void Executar(List<GerenciadorCarga> gerenciadorCargas, Segmentos segmento, Action<List<int>, List<string>, int, Segmentos, GerenciadorCarga, Action<GerenciadorCarga>, Action<GerenciadorCargaErro>> insertFunc, Action<GerenciadorCarga, Action<GerenciadorCarga>, Action<GerenciadorCargaErro>> postAction, bool contemCabecalho = true)
        {
            var batchSize = 1000;

            foreach (var gerenciador in gerenciadorCargas)
            {
                StreamReader reader;
                int linha = 0;
                var linhas = new List<int>();
                var registros = new List<string>();
                var dtUltimaGravacaoGerenciador = DateTime.Now;
                var arquivoExtensao = "";


                #region adiciona registros

                var passoValidacao = gerenciador.Passos.FirstOrDefault(x => x.Passo == CargasPassos.Validacao);

                var passoInsercao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = gerenciador.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = CargasPassos.Insercao.Description(),
                    Atualizado = DateTime.Now
                };

                gerenciador.Passos.Add(passoInsercao);
                _gerenciadorCargaServices.GravarGerenciador(gerenciador);

                gerenciador.FileStream.Position = 0;
                reader = new StreamReader(gerenciador.FileStream, Encoding.GetEncoding("iso-8859-1"));

                linha = 1;
                linhas = new List<int>();
                registros = new List<string>();
                dtUltimaGravacaoGerenciador = DateTime.Now;
                arquivoExtensao = Path.GetExtension(gerenciador.Arquivo);

                if (arquivoExtensao.Equals(".csv") || arquivoExtensao.Equals(".txt"))
                {
                    while (!reader.EndOfStream)
                    {
                        string conteudoLinha = string.Empty;
                        //pula cabeçalho
                        //pula linhas com erro de validação
                        if ((contemCabecalho && linha.Equals(1)) ||
                            (passoValidacao?.ErroLinhas?.Contains(linha) ?? false))
                        {
                            linha++;
                            conteudoLinha = reader.ReadLine();

                            if (!reader.EndOfStream)
                            {
                                continue;
                            }
                        }

                        if (!reader.EndOfStream)
                        {
                            conteudoLinha = reader.ReadLine();
                            if (!(string.IsNullOrEmpty(conteudoLinha) ||
                                  (conteudoLinha.Contains('\t') && string.IsNullOrWhiteSpace(string.Join("", conteudoLinha.Split('\t'))))))
                            {
                                linhas.Add(linha);
                                registros.Add(conteudoLinha);
                            }
                        }

                        if (registros.Count.Equals(batchSize) || reader.EndOfStream)
                        {
                            insertFunc(linhas, registros, batchSize, segmento, gerenciador, _gerenciadorCargaServices.GravarGerenciador, _gerenciadorCargaServices.GravarErro);

                            linhas = new List<int>();
                            registros = new List<string>();
                        }

                        if (dtUltimaGravacaoGerenciador.AddSeconds(10) < DateTime.Now)
                        {
                            _gerenciadorCargaServices.GravarGerenciador(gerenciador);
                            dtUltimaGravacaoGerenciador = DateTime.Now;
                        }

                        linha++;
                    }
                }
                else if (arquivoExtensao.Equals(".xlsx"))
                {
                    var package = new OfficeOpenXml.ExcelPackage(gerenciador.FileStream);
                    var workSheet = package.Workbook.Worksheets[0];

                    for (var x = (contemCabecalho ? 2 : 1); x <= workSheet.Dimension.End.Row; x++)
                    {
                        if (passoValidacao?.ErroLinhas?.Contains(linha) ?? false)
                            continue;

                        var colunas = "";

                        for (int j = workSheet.Dimension.Start.Column; j <= workSheet.Dimension.End.Column; j++)
                            colunas += $"{workSheet.Cells[x, j].Value};";

                        linhas.Add(x);
                        registros.Add(colunas.TrimEnd(';'));

                        if (registros.Count.Equals(batchSize) || x.Equals(workSheet.Dimension.End.Row))
                        {
                            insertFunc(linhas, registros, batchSize, segmento, gerenciador, _gerenciadorCargaServices.GravarGerenciador, _gerenciadorCargaServices.GravarErro);

                            linhas = new List<int>();
                            registros = new List<string>();
                        }

                        if (dtUltimaGravacaoGerenciador.AddSeconds(10) < DateTime.Now)
                        {
                            _gerenciadorCargaServices.GravarGerenciador(gerenciador);
                            dtUltimaGravacaoGerenciador = DateTime.Now;
                        }

                    }
                }


                #endregion

                postAction?.Invoke(gerenciador, _gerenciadorCargaServices.GravarGerenciador, _gerenciadorCargaServices.GravarErro);

                passoInsercao.Fim = DateTime.Now;
                gerenciador.Fim = DateTime.Now;
                gerenciador.PopupConclusao = true;
                _gerenciadorCargaServices.GravarGerenciador(gerenciador);
            }
        }


    }
}
