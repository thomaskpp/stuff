﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    public class InnerLoopController : BaseCargaController
    {
        private readonly IInnerLoopLigacoes _ligacoesInnerLoop;
        private readonly IInnerLoopArvoreDecisoes _arvoreDecisoes;
        private readonly IInnerLoopLiberacaoService _liberacaoService;
        private readonly string[] _extensoesAceitas = new string[] { ".csv" };
        private readonly IConfiguration _configuration;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;

        public InnerLoopController(
            ICookies cookies,
            IConfiguration configuration,
            IInnerLoopLigacoes ligacoesInnerLoop,
            IInnerLoopArvoreDecisoes arvoreDecisoes,
            IGerenciadorCargaServices gerenciadorCargaServices,
            IInnerLoopLiberacaoService liberacaoService,
            ISecurityServices securityServices)
            : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _ligacoesInnerLoop = ligacoesInnerLoop;
            _arvoreDecisoes = arvoreDecisoes;
            _configuration = configuration;
            _gerenciadorCargaServices = gerenciadorCargaServices;
            _liberacaoService = liberacaoService;
        }

        #region InnerLoop - Ligacoes
        [Authentication]
        [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaInnerLoopLigacoesAdmin })]
        public async Task<IActionResult> Ligacoes()
        {
            SetViewBag();

            var model = new InnerLoopViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaInnerLoopLigacoesAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [HttpPost]
        [Authentication]
        public IActionResult Ligacoes(InnerLoopViewModel model)
        {
            SetViewBag();
            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida arquivos

            model.Erros.Clear();

            if (!Request.Form.Files.Any())
                model.Erros.Add("Por favor, selecione o arquivo de carga.");

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo.ToLower()))
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");

                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaInnerLoopLigacoesAdmin,
                    IdColaborador = Colaborador.Id,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdSegmento = 200
                };

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);

            }

            if (model.Erros.Any())
                return View(model);

            #endregion

            var task = new Task(() =>
            {
                #region Verifica dados

                VerificaUploadInner(gerenciadorCargas, model.Segmento, _ligacoesInnerLoop.VerificaLinhaArquivoInner);

                #endregion

                #region Remove Ligações com mais de três meses

                _ligacoesInnerLoop.RemoveLigacoesExpurgo();

                #endregion

                #region Insere Dados Ligações

                UpsertUploadInner(gerenciadorCargas, model.Segmento, _ligacoesInnerLoop.InsertAsyncInner, null);

                #endregion

            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }

        #endregion

        #region InnerLoop - Perguntas e Respostas

        [Authentication]
        [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaInnerLoopArvoreDecisoesAdmin })]
        public async Task<IActionResult> ArvoreDecisoes()
        {
            SetViewBag();

            var model = new InnerLoopViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaInnerLoopArvoreDecisoesAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();


            var segmentos = _arvoreDecisoes.RetornaSegmentos();

            ViewBag.Segmentos = new SelectList(segmentos, "Id", "Nome");

            return View(model);
        }

        [HttpPost]
        [Authentication]
        public IActionResult ArvoreDecisoes(InnerLoopViewModel model)
        {
            SetViewBag();
            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida arquivos
            model.Erros.Clear();

            if (model.Segmento == 0)
                model.Erros.Add("Por favor, selecione o segmento.");

            if (!Request.Form.Files.Any())
                model.Erros.Add("Por favor, selecione o arquivo de carga.");

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");

                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaInnerLoopArvoreDecisoesAdmin,
                    IdColaborador = Colaborador.Id,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdSegmento = model.Segmento
                };

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);
            }

            if (model.Erros.Any())
                return View(model);

            #endregion

            var task = new Task(() =>
            {
                #region Verifica dados

                VerificaUploadInner(gerenciadorCargas, model.Segmento, _arvoreDecisoes.VerificaLinhaArquivoInner);

                #endregion

                #region Insere Dados da Arvore de Decisões

                UpsertUploadInner(gerenciadorCargas, model.Segmento, _arvoreDecisoes.InsertAsyncInner, _arvoreDecisoes.RemoveExistentesPorItemInner);

                #endregion

            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }

        #endregion

        #region InnerLoop - Liberação da funcionalidade
        [Authentication]
        [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaLiberacaoFuncionalidadeAdmin })]
        public async Task<IActionResult> LiberacaoFuncionalidade()
        {
            SetViewBag();

            var model = new InnerLoopViewModel();
            //model.CargaTipo = Funcionalidade.Enum.InnerLoopLiberacaoFuncionalidade;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [HttpPost]
        [Authentication]
        public IActionResult LiberacaoFuncionalidade(InnerLoopViewModel model)
        {
            SetViewBag();
            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida arquivos
            model.Erros.Clear();

            if (!Request.Form.Files.Any())
                model.Erros.Add("Por favor, selecione o arquivo de carga.");

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");

                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    //IdFuncionalidade = Funcionalidade.Enum.InnerLoopLiberacaoFuncionalidade,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdColaborador = Colaborador.Id
                };

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);

            }

            if (model.Erros.Any())
                return View(model);

            #endregion

            var task = new Task(() =>
            {
                #region Verifica dados

                VerificaUploadInner(gerenciadorCargas, model.Segmento, _liberacaoService.VerificaLinhaArquivoInner);

                #endregion

                #region Remove todos os registros

                _liberacaoService.RemoveRegistros();

                #endregion

                #region Insere Dados

                UpsertUploadInner(gerenciadorCargas, model.Segmento, _liberacaoService.InsertAsyncInner, null);

                #endregion

            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
        #endregion

        /// <summary>
        /// Método genérico para remoção e inserção de registros provenientes de arquivos de carga
        /// </summary>
        /// <param name="files">Lista de arquivos do Form</param>
        /// <param name="segmento">Nome do Segmento. Será repassado ao método delegado</param>
        /// <param name="carga">Tipo de carga. Será repassado ao método delegado</param>
        /// <param name="insertFunc">Método delegado responsável pela inserção dos registros no DB</param>
        /// <param name="removeFunc">Método delegado responsável pela remoção dos registros no DB</param>
        /// <returns>Lista de erros por linha x coluna</returns>
        public void UpsertUploadInner(List<GerenciadorCarga> gerenciadorCargas, int segmento, Action<List<int>, List<string>, int, int, GerenciadorCarga, Action<GerenciadorCarga>, Action<GerenciadorCargaErro>, bool> insertFunc, Action<List<int>, List<string>, int, int, GerenciadorCarga, Action<GerenciadorCarga>, Action<GerenciadorCargaErro>> removeAction)
        {
            try
            {
                var batchSize = _configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

                foreach (var gerenciador in gerenciadorCargas)
                {
                    StreamReader reader;
                    int linha = 0;
                    var linhas = new List<int>();
                    var registros = new List<string>();

                    #region remove registros

                    if (removeAction != null)
                    {
                        var passoRemocao = new GerenciadorCargaPasso()
                        {
                            IdGerenciadorCarga = gerenciador.Id,
                            Passo = CargasPassos.Remocao,
                            Nome = CargasPassos.Remocao.Description(),
                            Atualizado = DateTime.Now
                        };

                        gerenciador.Passos.Add(passoRemocao);
                        _gerenciadorCargaServices.GravarGerenciador(gerenciador);


                        gerenciador.FileStream.Position = 0;
                        reader = new StreamReader(gerenciador.FileStream, Encoding.GetEncoding("iso-8859-1"));

                        linha = 1;
                        linhas = new List<int>();
                        registros = new List<string>();

                        while (!reader.EndOfStream)
                        {
                            //pula cabeçalho
                            if (linha.Equals(1))
                            {
                                linha++;
                                reader.ReadLine();
                                continue;
                            }

                            linhas.Add(linha);
                            registros.Add(reader.ReadLine());
                        }

                        gerenciador.TotalLinhas = linhas.Count;

                    removeAction(linhas, registros, batchSize, segmento, gerenciador, _gerenciadorCargaServices.GravarGerenciador, _gerenciadorCargaServices.GravarErro);

                        if (passoRemocao.Erro)
                            return;
                    }

                    #endregion

                    #region adiciona registros

                    var passoValidacao = gerenciador.Passos.FirstOrDefault(x => x.Passo == CargasPassos.Validacao);

                    var passoInsercao = new GerenciadorCargaPasso()
                    {
                        IdGerenciadorCarga = gerenciador.Id,
                        Passo = CargasPassos.Insercao,
                        Nome = CargasPassos.Insercao.Description(),
                        Atualizado = DateTime.Now
                    };

                    gerenciador.Passos.Add(passoInsercao);
                    _gerenciadorCargaServices.GravarGerenciador(gerenciador);

                    gerenciador.FileStream.Position = 0;
                    reader = new StreamReader(gerenciador.FileStream, Encoding.GetEncoding("iso-8859-1"));

                    linha = 1;
                    linhas = new List<int>();
                    registros = new List<string>();

                    while (!reader.EndOfStream)
                    {
                        //pula cabeçalho
                        //pula linhas com erro de validação
                        if (linha.Equals(1) ||
                            (passoValidacao?.ErroLinhas?.Contains(linha) ?? false))
                        {
                            linha++;
                            reader.ReadLine();

                            if (!reader.EndOfStream)
                                continue;
                        }

                        if (!reader.EndOfStream)
                        {
                            linhas.Add(linha);
                            registros.Add(reader.ReadLine());
                        }

                        if (registros.Count.Equals(gerenciador.TotalLinhas) || reader.EndOfStream)
                        {
                            insertFunc(linhas, registros, batchSize, segmento, gerenciador, _gerenciadorCargaServices.GravarGerenciador, _gerenciadorCargaServices.GravarErro, false);

                            linhas = new List<int>();
                            registros = new List<string>();
                        }

                        if (linha % 1000 == 0)
                            _gerenciadorCargaServices.GravarGerenciador(gerenciador);

                        linha++;
                    }

                    #endregion

                    gerenciador.Fim = DateTime.Now;
                    _gerenciadorCargaServices.GravarGerenciador(gerenciador);
                }
            }
            catch(Exception ex)
            {
                GerenciadorCargaErro cargaErro = new GerenciadorCargaErro();
                cargaErro.IdGerenciadorCarga = gerenciadorCargas[0].Id;
                cargaErro.Erro = ex.Message;
                cargaErro.Passo = CargasPassos.Insercao;
                _gerenciadorCargaServices.GravarErro(cargaErro);
            }
        }

        /// <summary>
        /// Método genérico para verificação de um arquivo de carga
        /// </summary>
        /// <param name="gerenciadorCarga">Objeto com dados dos arquivos e status</param>
        /// <param name="segmento">Nome do Segmento. Será repassado ao método delegado</param>
        /// <param name="verificacaoFunc">Método delegado a ser chamado para verificar o arquivo</param>
        /// <returns>Lista de erros por linha x coluna</returns>
        public void VerificaUploadInner(List<GerenciadorCarga> gerenciadorCargas, int segmento, Func<int, string, int, GerenciadorCarga, Models.UploadRetorno> verificacaoFunc)
        {
            try
            {
                foreach (var gerenciador in gerenciadorCargas)
                {
                    var passoAtual = new GerenciadorCargaPasso()
                    {
                        IdGerenciadorCarga = gerenciador.Id,
                        Passo = CargasPassos.Validacao,
                        Nome = CargasPassos.Validacao.Description(),
                        Atualizado = DateTime.Now
                    };

                    gerenciador.Passos.Add(passoAtual);
                    gerenciador.Inicio = DateTime.Now;
                    _gerenciadorCargaServices.GravarGerenciador(gerenciador);

                    int errosCont = 0;
                    gerenciador.FileStream.Position = 0;
                    var reader = new StreamReader(gerenciador.FileStream, Encoding.GetEncoding("iso-8859-1"));

                    int linha = 1;

                    while (!reader.EndOfStream)
                    {
                        //pula cabeçalho
                        if (linha.Equals(1))
                        {
                            linha++;
                            reader.ReadLine();
                            continue;
                        }

                        var verificacao = verificacaoFunc(linha, reader.ReadLine(), segmento, gerenciador);

                        if (verificacao != null)
                        {
                            errosCont++;

                            gerenciador.Passos.First(x => x.Passo == CargasPassos.Validacao)
                                .ErroLinhas.Add(linha);

                            _gerenciadorCargaServices.GravarErro(new GerenciadorCargaErro()
                            {
                                IdGerenciadorCarga = gerenciador.Id,
                                Passo = CargasPassos.Validacao,
                                Linha = linha,
                                Erro = verificacao.ToString()
                            });
                        }

                        passoAtual.Atualizado = DateTime.Now;
                        passoAtual.LinhasProcessadas = linha - 1;
                        gerenciador.TotalLinhas = passoAtual.LinhasProcessadas;
                        linha++;
                    }

                    passoAtual.Erro = passoAtual.ErroLinhas?.Count > 0;
                    _gerenciadorCargaServices.GravarGerenciador(gerenciador);
                }
            }
            catch(Exception ex)
            {
                GerenciadorCargaErro cargaErro = new GerenciadorCargaErro();
                cargaErro.IdGerenciadorCarga = gerenciadorCargas[0].Id;
                cargaErro.Erro = ex.Message;
                cargaErro.Passo = CargasPassos.Validacao;
                _gerenciadorCargaServices.GravarErro(cargaErro);
            }
        }
    }

}