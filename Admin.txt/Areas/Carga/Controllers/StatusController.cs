﻿using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;

using Itau.SZ7.GPS.Admin.Enums;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Entities;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargasAdmin })]
    public class StatusController : BaseCargaController
    {
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;

        public StatusController(ICookies cookies, 
            IConfiguration configuration, 
            IGerenciadorCargaServices gerenciadorCargaServices,
            ISecurityServices securityServices)
            : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = await _gerenciadorCargaServices.GetStatusCargas();
            model.AbaAtiva = AdminAbaAtiva.Status;

            return View(model);
        }
    }
}
