﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;

using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaNPSComentarioPersonnaliteAdmin })]
    public class NPSComentarioPersonnaliteController : BaseCargaController
    {
        private readonly INPSComentarioServices _npsServices;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private readonly string[] _extensoesAceitas = new string[] { ".csv" };
        private readonly int _batchSize;

        public NPSComentarioPersonnaliteController(ICookies cookies,
            IConfiguration configuration,
            IColaboradorServices colaboradorRepository,
            IGerenciadorCargaServices gerenciadorCargaServices,
            INPSComentarioServices npsServices,
            ISecurityServices securityServices) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _batchSize = configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

            _npsServices = npsServices;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        public IActionResult Index()
        {
            SetViewBag();

            var model = new NPSComentarioViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaNPSComentarioPersonnaliteAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = RetornaCargasRecentesAsync().Result;
            model.Segmento = Enums.Segmentos.Personnalite;

            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Index(NPSComentarioViewModel model)
        {
            SetViewBag();
            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida Arquivos

            model.Erros.Clear();

            if (!Request.Form.Files.Any())
                model.Erros.Add("Por Favor, selecione o arquivo de carga");

            #region Carrega Arquivos

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");

                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaNPSComentarioPersonnaliteAdmin,
                    Mes = model.Mes,
                    Ano = model.Ano,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdColaborador = Colaborador.Id
                };

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);
            }

            #endregion


            if (model.Erros.Any())
                return View(model);

            #endregion

            var task = new Task(() =>
            {
                #region Verifica Dados

                _npsServices.LimpaCache();

                VerificaUpload(gerenciadorCargas, model.Segmento, _npsServices.VerificaLinhaArquivo);

                #endregion

                #region Deleta todos os registros

                _npsServices.RemoveTodosItens();

                #endregion

                #region Valida se as agências na planilha existem e insere os registros

                UpsertUpload(gerenciadorCargas, model.Segmento, _npsServices.Insert, null);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
    }
}