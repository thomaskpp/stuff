﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;

using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaBaixaAderenciaAdmin })]
    public class BaixaAderenciaController : BaseCargaController
    {
        private readonly IBaixaAderencia _baixaAderencia;
        private readonly IConfiguration _configuration;
        private readonly string[] _extensoesAceitas = new string[] { ".csv" };

        public BaixaAderenciaController(
            ICookies cookies,
            IConfiguration configuration,
            IBaixaAderencia baixaAderencia,
            IGerenciadorCargaServices gerenciadorCargaServices,
            ISecurityServices securityServices
            ) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _configuration = configuration;
            _baixaAderencia = baixaAderencia;

        }
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new BaixaAderenciaViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaBaixaAderenciaAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [HttpPost]
        [Authentication]
        public IActionResult Index(BaixaAderenciaViewModel model)
        {
            SetViewBag();

            model.CargaTipo = Funcionalidade.Enum.CargaBaixaAderenciaAdmin;
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = RetornaCargasRecentesAsync().Result;

            var gerenciadorCargas = new List<GerenciadorCarga>();

            if (!Request.Form.Files.Any())
                model.Erros.Add("Por favor, selecione o arquivo de carga.");

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");


                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaBaixaAderenciaAdmin,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdColaborador = Colaborador.Id
                };

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);
            }

            if (model.Erros.Any())
                return View(model);

            var task = new Task(() =>
            {
                #region Verifica dados

                VerificaUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _baixaAderencia.VerificaLinhaArquivo);

                #endregion

                #region Insere dados

                UpsertUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _baixaAderencia.Insert, null);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
    }
}