﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Entities.DTO;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargasAdmin })]
    public class CarregarController : BaseCargaController
    {
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;

        public CarregarController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            ISecurityServices securityServices)
            : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _gerenciadorCargaServices = gerenciadorCargaServices;

        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new BaseUploadViewModel();
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [Authentication]
        public async Task<IActionResult> Erros(int id)
        {
            SetViewBag();

            var model = _gerenciadorCargaServices.ListaCargaErros(id).Result;

            return View(model);
        }

        public async Task<IActionResult> DownloadCargaErroCSV(int id)
        {
            if (id == 0)
            {
                return NoContent();
            }

            var CargaErrocsv = await _gerenciadorCargaServices.CargaErroxlsx(id);
            var NomeArquivo = await _gerenciadorCargaServices.ListaGerenciadorCargaPorId(id);
            var filename = $"{NomeArquivo.Arquivo.Replace(".csv", "")}_" + DateTime.Now.ToString("yyyy/MM/dd") + ".xlsx";

            if (CargaErrocsv.Length <= 0)
            {
                return NoContent();
            }

            Response.Headers.Add("fileName", filename);

            return File(CargaErrocsv, "application/download", filename);

            //return File(new System.Text.UTF8Encoding().GetBytes(CargaErrocsv.ToString()), "application/vnd.ms-excel", filename);
        }

        public async Task<PartialViewResult> RetornaCargasEmAndamento(bool mostrarAberto, string idsAbertos)
        {
            var model = new BaseUploadViewModel();
            model.Cargas = await RetornaCargasRecentesAsync();
            model.MostrarCargasEmAndamento = mostrarAberto;

            if (!string.IsNullOrEmpty(idsAbertos))
            {
                var ids = idsAbertos.Split(',');

                foreach (var id in ids)
                    model.ItensAbertos.Add(IntExtension.TryParse(id));
            }

            return PartialView("_CargasEmAndamentoPartial", model);
        }

        public async Task<IActionResult> VizualizouPopupConcluidas(string model)
        {
            var concluida = new GerenciadorCarga();
            concluida.Id = Convert.ToInt32(model);
            var teste = _gerenciadorCargaServices.GravaPopUpConclusao(concluida);
            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }

        [HttpPut]
        public async Task<IActionResult> AtualizaCargaAgendadaAsync([FromQuery] DateTime dataInicio, int id)
        {
            if (id == 0)
            {
                return BadRequest("Parametro de entrada invalido!");
            }

            var CargaAfetada = await _gerenciadorCargaServices.AtualizarPorIdAsync(dataInicio, id);

            if (CargaAfetada > 0)
            {
                TempData["CargaAtualizada"] = "Carga editada com sucesso!";
                return Ok("Index");
            }

            TempData["ErroEditarCarga"] = "Erro ao editar!";
            return View("Index");
        }

        [HttpDelete]
        public async Task<IActionResult> DeletaCargaAgendadaAsync(int id)
        {
            if (id == 0)
            {
                return BadRequest("Parametro de entrada invalido!");
            }

            var CargaAfetada = await _gerenciadorCargaServices.DeletaPorIdAsync(id);

            if (CargaAfetada > 0)
            {
                TempData["CargaExcluida"] = "Carga excluida com sucesso!";
                return View("Index");
            }

            TempData["ErroExcluirCarga"] = "Erro ao tentar excluir!";
            return View("Index");
        }

        public async Task<IEnumerable<GerenciadorCargaAgendada>> RetornaCargasAgendadas()
        {
            return await _gerenciadorCargaServices.RetornaCargasAgendadas();
        }
    }
}
