﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;

using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaVPRealizadoAdmin })]
    public class VerificadorProducaoAnaliticoPersonnaliteController : BaseCargaController
    {
        private static string URLBASE = "ApiUrl";

        private readonly IVerificadorProducaoAnaliticoPersonnaliteServices _verificadorProducaoAnaliticoPersonnalite;
        private readonly IVerificadorProducaoRealizado _verificadorProducaoRealizado;
         
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private readonly IConfiguration _configuration;

        private readonly string[] _extensoesAceitas = new string[] { ".txt" };

        public VerificadorProducaoAnaliticoPersonnaliteController(
            ICookies cookies,
            IConfiguration configuration,
            IVerificadorProducaoAnaliticoPersonnaliteServices verificadorProducaoAnaliticoPersonnalite,
            IVerificadorProducaoRealizado verificadorProducaoRealizado,
            IGerenciadorCargaServices gerenciadorCargaServices,
            ISecurityServices securityServices
           )
            : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _verificadorProducaoAnaliticoPersonnalite = verificadorProducaoAnaliticoPersonnalite;
            _verificadorProducaoRealizado = verificadorProducaoRealizado;
            _configuration = configuration;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        #region Analitico

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new VerificadorProducaoViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaVPAnaliticoPersonnaliteAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [HttpPost]
        [Authentication]
        public IActionResult Index(VerificadorProducaoViewModel model)
        {
            SetViewBag();
            var gerenciadorCargas = new List<GerenciadorCarga>();
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = RetornaCargasRecentesAsync().Result;

            #region Valida arquivos

            model.Erros.Clear();

            if (!Request.Form.Files.Any())
                model.Erros.Add("Por favor, selecione o arquivo de carga.");

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!arquivo.FileName.Contains("_P1_"))
                    continue;

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");


                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaVPAnaliticoPersonnaliteAdmin,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdSegmento = 200,
                    IdColaborador = Colaborador.Id
                };

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);
            }

            if (model.Erros.Any())
                return View(model);

            #endregion

            var task = new Task(() =>
            {
                #region Verifica dados

                _verificadorProducaoAnaliticoPersonnalite.CriarTabelas(gerenciadorCargas);

                VerificaUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _verificadorProducaoAnaliticoPersonnalite.VerificaLinhaArquivo);

                #endregion

                #region Insere dados

                UpsertUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _verificadorProducaoAnaliticoPersonnalite.Insert, _verificadorProducaoAnaliticoPersonnalite.RemoveExistentesPorItem);

                #endregion

                #region Atualiza indicador PlanejamentoItemGradeCarteira

                var batchSize = _configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

                foreach (var gerenciador in gerenciadorCargas)
                {
                    //#region grava gerenciador
                    //gerenciador.Fim = DateTime.Now;
                    //_gerenciadorCargaServices.GravarGerenciador(gerenciador);

                    //#endregion
                    //using (var reader = new StreamReader(gerenciador.FileStream))
                    //{
                    //    int linha = 1;
                    //    var linhas = new List<int>();
                    //    var registros = new List<string>();

                    //    while (!reader.EndOfStream)
                    //    {
                    //        //pula cabeçalho
                    //        if (linha.Equals(1))
                    //        {
                    //            linha++;
                    //            reader.ReadLine();
                    //            continue;
                    //        }

                    //        linhas.Add(linha);
                    //        registros.Add(reader.ReadLine());
                    //    }

                    //    _verificadorProducaoRealizado.AtualizaIndicadorPlanejamentoItemGradeCarteira(linhas, registros, model.Segmento, batchSize);
                    //}
                }

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }

        #endregion
    }
}