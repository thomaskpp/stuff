﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Attributes;
using Microsoft.Extensions.Configuration;


using Itau.SZ7.GPS.Admin.Helpers.Interfaces;

using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Extensions;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaColaboradorAdmin })]
    public class ColaboradorController : BaseCargaController
    {
        private readonly IColaboradorServices _colaboradorServices;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private readonly ILogApplication _logApplication;
        private readonly string[] _extensoesAceitas = new string[] { ".csv", ".xlsx" };
        private readonly Dictionary<string, string> _headerNecessarios = new Dictionary<string, string>();
        private readonly int _batchSize;

        public ColaboradorController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            IColaboradorServices colaboradorServices,
            ILogApplication logApplication,
            ISecurityServices securityServices) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _headerNecessarios.Add("Colaborador Fake", "FUNCIONAL;RACF;NOME;NOME_COMPLETO;AGENCIA;CARTEIRA;CARGO;SEGMENTO;ATIVO;INICIO_FERIAS1;FIM_FERIAS1;INICIO_FERIAS2;FIM_FERIAS2;INICIO_FERIAS3;FIM_FERIAS3;DATABASE;ELEGIVEL_ENGAJAMENTO;DIAS_INDISPONIVEIS;NUMFUNC_GESTOR");
            _headerNecessarios.Add("Cargos", "COD_CARGO_RH;NOME_CARGO_RH;SEGMENTO;NOME_CARGO_GPS;TRAT_AG");
            _headerNecessarios.Add("Cadastro Itau IA", "DATAPRG;PAR AGIR;AGÊNCIA;NOME AGÊNCIA;PORTE;DICOM;REGIAO;COORD AGIR;DATA AB.;VOCAÇÃO/GRADE;NR UNICLASS MENOR NÍVEL?;NÚCLEO EMP4;REGIÃO GRA;SUBREGIÃO GRA;TIPO;GRADE");
            _headerNecessarios.Add("Cadastro Itau Uniclass", "DATAPRG;DICOM;REGIAO;SUBREGIAO;NOME GRA;GGN;SEGMENTO;CARTEIRA COORDENADORA;AGENCIA_COORDENADORA;CARTEIRA_COORDENADORA;CARTEIRA;AGENCIA;GERENTE;FUNCIONAL GR;NOME GR;TIPO CARTEIRA;QTDE_CLIENTES;VOCAÇÃO;GRADE");
            _headerNecessarios.Add("Cadastro Itau EMP4", "DATA_REF;CARTEIRA MENOR;CARTEIRA MAIOR;DICOM;REGIAO;SUBREGIAO;NOME GRA;NOME GGN;SEGMENTO;CARTEIRA COORDENADORA;AGENCIA_COORDENADORA;CARTEIRA_COORDENADORA;CARTEIRA;AGENCIA;GERENTE;FUNCIONAL GR;NOME GR;TIPO CARTEIRA;#CLIENTES;VOCAÇÃO;MAIOR NIVEL;FÉRIAS;PORTE SEMESTRAL;PORTE CODIGO;GRADE");
            _headerNecessarios.Add("Polo", "POLO;TIPO;FUNCIONAL;RACF;ESTRUTURA");
            _headerNecessarios.Add("TP128", "NUMFUNC;NOMFUNC;QUADRO;EMAIL;NIVELCRG;DESCNIVELCRG;CDCRGP;NOMECRGP;DTACRGP;DTAORG;DTADMF;NUMFUNC_GESTOR;NOMFUNC_GESTOR;NOMEORG_GESTOR;DEPTID_GESTOR;NOMECRGP_GESTOR;DESCNIVELCRG_GESTOR;CDSEQORG;CLASSDEPTID;CARACTDEPTID;SIGLADEPT;DESCDEPT;HIERARQUIA_00_DEPTDESC;HIERARQUIA_01_DEPTDESC;HIERARQUIA_01_DEPTID;HIERARQUIA_01_NOMFUNC_TITULAR;HIERARQUIA_01_NUMFUNC_TITULAR;HIERARQUIA_02_DEPTDESC;HIERARQUIA_02_DEPTID;HIERARQUIA_02_NOMFUNC_TITULAR;HIERARQUIA_02_NUMFUNC_TITULAR;HIERARQUIA_03_DEPTDESC;HIERARQUIA_03_DEPTID;HIERARQUIA_03_NOMFUNC_TITULAR;HIERARQUIA_03_NUMFUNC_TITULAR;HIERARQUIA_04_DEPTDESC;HIERARQUIA_04_DEPTID;HIERARQUIA_04_NOMFUNC_TITULAR;HIERARQUIA_04_NUMFUNC_TITULAR;HIERARQUIA_05_DEPTDESC;HIERARQUIA_05_DEPTID;HIERARQUIA_05_NOMFUNC_TITULAR;HIERARQUIA_05_NUMFUNC_TITULAR;HIERARQUIA_06_DEPTDESC;HIERARQUIA_06_DEPTID;HIERARQUIA_06_NOMFUNC_TITULAR;HIERARQUIA_06_NUMFUNC_TITULAR;HIERARQUIA_07_DEPTDESC;HIERARQUIA_07_DEPTID;HIERARQUIA_07_NOMFUNC_TITULAR;HIERARQUIA_07_NUMFUNC_TITULAR;HIERARQUIA_08_DEPTDESC;HIERARQUIA_08_DEPTID;HIERARQUIA_08_NOMFUNC_TITULAR;HIERARQUIA_08_NUMFUNC_TITULAR;HIERARQUIA_09_DEPTDESC;HIERARQUIA_09_DEPTID;HIERARQUIA_09_NOMFUNC_TITULAR;HIERARQUIA_09_NUMFUNC_TITULAR;HIERARQUIA_10_DEPTDESC;HIERARQUIA_10_DEPTID;HIERARQUIA_10_NOMFUNC_TITULAR;HIERARQUIA_10_NUMFUNC_TITULAR;HIERARQUIA_11_DEPTDESC;HIERARQUIA_11_DEPTID;HIERARQUIA_11_NOMFUNC_TITULAR;HIERARQUIA_11_NUMFUNC_TITULAR;HIERARQUIA_12_DEPTDESC;HIERARQUIA_12_DEPTID;HIERARQUIA_12_NOMFUNC_TITULAR;HIERARQUIA_12_NUMFUNC_TITULAR;CODEMPI;NOMEMR;NOMEORG;AGENFIL;DESCPOLO;LOGRAD;NUMERLT;COMPL;COMPL2;ANDAR;N_EDIFICIO;BAIRRO;CIDADE;ESTADO;REGIAO_BRASIL;SEXOFUNC;CDREABIL;DESCPNE;IDADE;ESCOLARIDADE;INICIO_FERIAS1;FIM_FERIAS1;INICIO_FERIAS2;FIM_FERIAS2;INICIO_FERIAS3;FIM_FERIAS3;DTINLIC;LIC_DESC;DTFILIC;DT_AUSENCIA;JUST_AUSENCIA;IDGESTP_DESC;NUMTITEL;DIRIGENTE SINDICAL;DT INICIO MANDATO;DT FIM MANDATO;FREQUÊNCIA_LIVRE;MEMBRO_CIPA_DESC;MANDATO_INI_DT;MANDATO_FIM_DT;ESTABILIDADE;COMENTARIOS;TIPO DE ESTABILIDADE;INICIO DA ESTABILIDADE;FIM DA ESTABILIDADE;SEG_DEPT;DATABASE;CBODE;DESC_PREDIO;HENHT;IRNHT;FRNHT;HSNHT;TELEFONCOML;NOME_INSTITUICAO;NOME_CURSO;DT_INIC_CUR;DT_FIM_CUR;EMAIL_CORPORATIVO");

            _batchSize = configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

            _colaboradorServices = colaboradorServices;
            _gerenciadorCargaServices = gerenciadorCargaServices;
            _logApplication = logApplication;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new ColaboradorViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaColaboradorAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Index(ColaboradorViewModel model)
        {
            SetViewBag();

            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida arquivos
            model.Erros.Clear();

            if (model.Ano < 1 || model.Mes < 1)
            {
                model.Erros.Add("Selecione Mês e Ano para prosseguir");
                return View(model);
            }

            if (!Request.Form.Files.Any() || Request.Form.Files.Count != 5)
            {
                model.Erros.Add("Para executar esta carga são necessários 5 arquivos físicos: Cadastro Agência, Cargos, Cadastro Agir (esse com 3 planilhas (IA, Uniclass e EMP4)), Polo e TP128");
                return View(model);
            }

            //validar todos arquivos necessários para carga Agir
            Dictionary<string, string> headersEncontrados = new Dictionary<string, string>();
            string header = "";

            try
            {
                foreach (var arquivo in Request.Form.Files)
                {
                    string extensao = Path.GetExtension(arquivo.FileName);
                    if (extensao == ".csv")
                    {
                        using (StreamReader reader = new StreamReader(arquivo.OpenReadStream()))
                        {
                            header = reader.ReadLine();

                            if (_headerNecessarios.Any(x => x.Value.ToUpper().Equals(header.ToUpper())) && !headersEncontrados.Any(x => x.Value.ToUpper().Equals(header.ToUpper())))
                            {
                                var headerDict = _headerNecessarios.First(x => x.Value.ToUpper().Equals(header.ToUpper()));
                                headersEncontrados.Add(headerDict.Key, headerDict.Value);

                                var carga = new GerenciadorCarga()
                                {
                                    Arquivo = arquivo.FileName,
                                    ArquivoApelido = headerDict.Key,
                                    IdFuncionalidade = Funcionalidade.Enum.CargaColaboradorAdmin,
                                    GravaCarga = false,
                                    IdColaborador = Colaborador.Id,
                                    Funcional = Colaborador?.Funcional,
                                    NomeFuncional = Colaborador?.Nome,
                                    IdSegmento = 200
                                };

                                arquivo.CopyTo(carga.FileStream);
                                gerenciadorCargas.Add(carga);
                            }
                        }
                    }
                    else if (extensao == ".xlsx")
                    {
                        var package = new OfficeOpenXml.ExcelPackage(arquivo.OpenReadStream());
                        for (int i = 0; i < package.Workbook.Worksheets.Count; i++)
                        {
                            header = "";
                            OfficeOpenXml.ExcelWorksheet workSheet = package.Workbook.Worksheets[i];

                            for (int j = workSheet.Dimension.Start.Column; j <= workSheet.Dimension.End.Column; j++)
                            {
                                if (header == "")
                                    header += workSheet.Cells[1, j].Value.ToString().Trim();
                                else
                                    header += ";" + workSheet.Cells[1, j].Value.ToString().Trim();
                            }

                            if (_headerNecessarios.Any(x => x.Value.ToUpper().Equals(header.ToUpper())) && !headersEncontrados.Any(x => x.Value.ToUpper().Equals(header.ToUpper())))
                            {
                                var headerDict = _headerNecessarios.First(x => x.Value.Equals(header.ToUpper()));
                                headersEncontrados.Add(headerDict.Key, headerDict.Value);

                                var carga = new GerenciadorCarga()
                                {
                                    Arquivo = workSheet.Name + ".csv",
                                    ArquivoApelido = headerDict.Key,
                                    IdFuncionalidade = Funcionalidade.Enum.CargaColaboradorAdmin,
                                    GravaCarga = false,
                                    IdColaborador = Colaborador.Id,
                                    Funcional = Colaborador?.Funcional,
                                    NomeFuncional = Colaborador?.Nome,
                                    IdSegmento = 200
                                };

                                var planilha = EpplusCsvConverter.ConvertToCsv(workSheet);
                                Stream stream = new MemoryStream(planilha);
                                stream.CopyTo(carga.FileStream);
                                gerenciadorCargas.Add(carga);
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                _logApplication.RegistrarLog(tipo: LogTipo.Critico,
                                        plataforma: Plataforma.Enum.Web,
                                        funcionalidade: Funcionalidade.Enum.Desconhecido,
                                        stackTrace: ExceptionExtension.RetornaStackTrace(exception),
                                        descricao: ExceptionExtension.RetornaInnerException(exception)?.Message ?? string.Empty,
                                        metodoOrigem: "ColaboradorController / Index");
            }

            if (headersEncontrados.Count != _headerNecessarios.Count)
            {
                var arquivosFaltantes = new List<string>();

                foreach (var item in _headerNecessarios)
                    if (!headersEncontrados.Contains(item))
                        arquivosFaltantes.Add(item.Key);

                model.Erros.Add($"Para executar esta carga são necessários 5 arquivos (um deles com 3 planilhas). Não recebemos os seguintes arquivos: {string.Join(", ", arquivosFaltantes.ToArray())}");
                return View(model);
            }

            foreach (var gerenciador in gerenciadorCargas)
            {
                var extensaoArquivo = Path.GetExtension(gerenciador.Arquivo);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {gerenciador.Arquivo} não é suportado.");
            }

            if (model.Erros.Any())
                return View(model);
            #endregion

            var task = new Task(async () =>
            {
                #region Grava gerenciador

                var cargaAgir = new GerenciadorCarga()
                {
                    IdFuncionalidade = Funcionalidade.Enum.CargaColaboradorAdmin,
                    Ano = model.Ano,
                    Mes = model.Mes,
                    GravaCarga = true,
                    IdColaborador = Colaborador.Id,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdSegmento = 200
                };

                var passoVerificacao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaAgir.Id,
                    Passo = CargasPassos.Validacao,
                    Nome = CargasPassos.Validacao.Description(),
                    Atualizado = DateTime.Now,
                    Inicio = DateTime.Now
                };

                cargaAgir.Passos.Add(passoVerificacao);
                cargaAgir.Inicio = DateTime.Now;
                _gerenciadorCargaServices.GravarGerenciador(cargaAgir);

                GerenciadorCargaAtual = cargaAgir;

                foreach (var gerenciador in gerenciadorCargas)
                    gerenciador.Id = cargaAgir.Id;

                #endregion

                #region Verifica dados

                VerificaUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _colaboradorServices.VerificaLinhaArquivo);

                #endregion

                #region Grava gerenciador

                GerenciadorCargaAtual = cargaAgir;

                var passoRemocao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaAgir.Id,
                    Passo = CargasPassos.Remocao,
                    Nome = CargasPassos.Remocao.Description(),
                    Atualizado = DateTime.Now,
                    Inicio = DateTime.Now
                };

                cargaAgir.Passos.Add(passoRemocao);
                cargaAgir.TotalLinhas = gerenciadorCargas.Sum(x => x.TotalLinhas);
                passoVerificacao.LinhasProcessadas = cargaAgir.TotalLinhas;
                passoVerificacao.Erro = gerenciadorCargas.Any(x => x.ContemErro);
                passoVerificacao.Fim = DateTime.Now;
                _gerenciadorCargaServices.GravarGerenciador(cargaAgir);

                #endregion

                #region Remove GradeColaborador

                _colaboradorServices.ExcluiGradeColaborador(cargaAgir, _gerenciadorCargaServices.GravarGerenciador, _gerenciadorCargaServices.GravarErro);

                #endregion

                #region Grava gerenciador

                var passoInsercao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaAgir.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = CargasPassos.Insercao.Description(),
                    Atualizado = DateTime.Now,
                    Inicio = DateTime.Now
                };

                cargaAgir.Passos.Add(passoInsercao);
                cargaAgir.TotalLinhas = gerenciadorCargas.Sum(x => x.TotalLinhas);
                passoRemocao.LinhasProcessadas = cargaAgir.TotalLinhas;
                passoRemocao.Fim = DateTime.Now;
                _gerenciadorCargaServices.GravarGerenciador(cargaAgir);

                #endregion

                #region Insere dados

                _colaboradorServices.CarregarColaboradorAsync(gerenciadorCargas, _batchSize, cargaAgir, _gerenciadorCargaServices.GravarGerenciador, _gerenciadorCargaServices.GravarErro);

                #endregion

                #region Grava gerenciador

                passoInsercao.Fim = DateTime.Now;
                cargaAgir.Fim = DateTime.Now;
                cargaAgir.PopupConclusao = true;
                _gerenciadorCargaServices.GravarGerenciador(cargaAgir);
                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
    }
}