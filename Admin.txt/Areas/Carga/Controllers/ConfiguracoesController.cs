﻿using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Entities;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargasAdmin })]
    public class ConfiguracoesController : BaseCargaController
    {
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        public ConfiguracoesController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            ISecurityServices securityServices)
            : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new ConfiguracoesStatusViewModel();

            model.ListCargas = await _gerenciadorCargaServices.GetGridAllCargasAsync();
            model.AbaAtiva = AdminAbaAtiva.Configuracao;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Index(ConfiguracoesStatusViewModel model)
        {
            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }

        [Authentication]
        [HttpPost]
        public async Task<JsonResult> AtualizaOcultar(int idFuncionalidade, bool ocultar)
        {
            var resultado = _gerenciadorCargaServices.GravaOcultar(idFuncionalidade, !ocultar);

            return new JsonResult(resultado);
        }
    }
}
