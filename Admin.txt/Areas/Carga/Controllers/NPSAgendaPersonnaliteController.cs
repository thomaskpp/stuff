﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.MetasPersonnaliteAdmin })]
    public class NPSAgendaPersonnaliteController : BaseCargaController
    {
        private readonly INPSAgendaPersonnalite _service;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private readonly string[] _extensoesAceitas = new string[] { ".csv" };
        private readonly int _batchSize;

        public NPSAgendaPersonnaliteController(ICookies cookies,
            IConfiguration configuration,
            IColaboradorRepository colaboradorRepository,
            IGerenciadorCargaServices gerenciadorCargaServices,
            INPSAgendaPersonnalite service,
            ISecurityServices securityServices) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _batchSize = configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

            _service = service;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new NPSAgendaPersonnaliteViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaNPSAgendaPersonnaliteAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Index(NPSAgendaPersonnaliteViewModel model)
        {
            SetViewBag();
            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida arquivos

            model.Erros.Clear();

            if (!Request.Form.Files.Any())
            {
                model.Erros.Add("Por favor, selecione o arquivo de carga.");
            }

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                {
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");
                }

                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaNPSAgendaPersonnaliteAdmin,
                    Ano = model.Ano,
                    Mes = model.Mes,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    Inicio = DateTime.Now
                };

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);
            }

            if (model.Erros.Any())
            {
                return View(model);
            }

            #endregion

            var task = new Task(() =>
            {
                var cargaSelecionada = gerenciadorCargas[0];

                #region grava gerenciador

                var passoInsercao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaSelecionada.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = CargasPassos.Insercao.Description(),
                    Atualizado = DateTime.Now
                };

                cargaSelecionada.Passos.Add(passoInsercao);
                _gerenciadorCargaServices.GravarGerenciador(cargaSelecionada);

                GerenciadorCargaAtual = cargaSelecionada;

                #endregion

                #region Verifica dados

                VerificaUpload(gerenciadorCargas, Segmentos.Personnalite, _service.VerificaLinhaArquivo);

                #endregion

                #region Insere dados
                cargaSelecionada.TotalLinhas--;
                _service.CarregarAgendaMes(gerenciadorCargas, _batchSize, cargaSelecionada).Wait();

                #endregion

                #region grava gerenciador
                cargaSelecionada.Fim = DateTime.Now;                
                _gerenciadorCargaServices.GravarGerenciador(cargaSelecionada);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
    }
}
