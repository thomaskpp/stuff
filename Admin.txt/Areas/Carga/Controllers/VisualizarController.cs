﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;

using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml;
using System;
using Itau.SZ7.GPS.Admin.Entities;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaVisualizarArquivoAdmin })]
    public class VisualizarController : BaseCargaController
    {
        private readonly IVisualizarArquivo _VisualizarArquivosServices;

        public VisualizarController(ICookies cookies, 
            IConfiguration configuration, 
            IGerenciadorCargaServices gerenciadorCargaServices,
            IVisualizarArquivo visualizarArquivosServices,
            ISecurityServices securityServices)
            : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _VisualizarArquivosServices = visualizarArquivosServices;
        }

        [Authentication]
        public IActionResult Index()
        {
            return RedirectToAction("Metas");
        }

        [Authentication]
        public IActionResult Grade()
        {
            SetViewBag();

            var model = new VisualizarViewModel();
            model.AbaAtiva = AdminAbaAtiva.Visualizar;
            model.Visao = VisualizarArquivoVisao.Grade;
            return View(model);
        }

        [Authentication]
        public IActionResult Metas(string filtroMeta, int mes, int ano)
        {
            SetViewBag();

            filtroMeta = String.IsNullOrEmpty(filtroMeta) ? "TODOS" : filtroMeta;
            mes = mes == 0 ? DateTime.Now.Month : mes;
            ano = ano == 0 ? DateTime.Now.Year : ano;

            var model = new VisualizarViewModel();

            model = _VisualizarArquivosServices.GetMetasConsolidades(mes, ano);

            model.AbaAtiva = AdminAbaAtiva.Visualizar;
            model.Visao = VisualizarArquivoVisao.Metas;
            model.MesSelecionado = mes;
            model.AnoSelecionado = ano;
            model.FiltroSelecionado = filtroMeta;

            switch (filtroMeta)
            {
                case "":
                case "TODOS":
                default:
                    model.CurrentList.AddRange(model.Uniclass);
                    model.CurrentList.AddRange(model.Empresas);
                    model.CurrentList.AddRange(model.Agencias);
                    break;
                case "UNICLASS":
                    model.CurrentList.Clear();
                    model.CurrentList.AddRange(model.Uniclass);
                    break;
                case "AGENCIAS":
                    model.CurrentList.Clear();
                    model.CurrentList.AddRange(model.Agencias);
                    break;
                case "EMPRESAS":
                    model.CurrentList.Clear();
                    model.CurrentList.AddRange(model.Empresas);
                    break;
            }
            return View(model);
        }

        [Authentication]
        public ActionResult Export(string filtroMeta, int mes, int ano)
        {
            SetViewBag();

            filtroMeta = String.IsNullOrEmpty(filtroMeta) ? "TODOS" : filtroMeta;
            mes = mes == 0 ? DateTime.Now.Month : mes;
            ano = ano == 0 ? DateTime.Now.Year : ano;

            var model = new VisualizarViewModel();

            model = _VisualizarArquivosServices.GetMetasConsolidades(mes, ano);

            model.AbaAtiva = AdminAbaAtiva.Visualizar;
            model.Visao = VisualizarArquivoVisao.Metas;
            model.MesSelecionado = mes;
            model.AnoSelecionado = ano;
            model.FiltroSelecionado = filtroMeta;

            switch (filtroMeta)
            {
                case "":
                case "TODOS":
                default:
                    model.CurrentList.AddRange(model.Uniclass);
                    model.CurrentList.AddRange(model.Empresas);
                    model.CurrentList.AddRange(model.Agencias);
                    break;
                case "UNICLASS":
                    model.CurrentList.Clear();
                    model.CurrentList.AddRange(model.Uniclass);
                    break;
                case "AGENCIAS":
                    model.CurrentList.Clear();
                    model.CurrentList.AddRange(model.Agencias);
                    break;
                case "EMPRESAS":
                    model.CurrentList.Clear();
                    model.CurrentList.AddRange(model.Empresas);
                    break;
            }

            if (model.CurrentList.Count > 0)
            {
                int linha = 1;

                using (var package = new ExcelPackage())
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Metas - " + filtroMeta + " - " + mes + "-" + ano);

                    worksheet.Cells[1, 1].Value = "Segmento";
                    worksheet.Cells[1, 2].Value = "Data Referência";
                    worksheet.Cells[1, 3].Value = "Cód. Item";
                    worksheet.Cells[1, 4].Value = "Nome do Produto";
                    worksheet.Cells[1, 5].Value = "Data Envio";
                    worksheet.Cells[1, 6].Value = "Soma Meta";
                    worksheet.Cells[1, 7].Value = "Funcional";
                    worksheet.Cells[1, 8].Value = "Quant. Linhas";

                    foreach (var item in model.CurrentList)
                    {
                        linha = linha + 1;
                        worksheet.Cells[linha, 1].Value = item.nomeSegmento;
                        worksheet.Cells[linha, 2].Value = item.dataReferencia;
                        worksheet.Cells[linha, 3].Value = item.codigoItem;
                        worksheet.Cells[linha, 4].Value = item.nomeItem;
                        worksheet.Cells[linha, 5].Value = item.dataEnvio;
                        worksheet.Cells[linha, 6].Value = item.sumValorMeta;
                        worksheet.Cells[linha, 7].Value = "-";
                        worksheet.Cells[linha, 8].Value = item.count;
                    }

                    worksheet.Column(1).AutoFit();
                    worksheet.Column(2).AutoFit();
                    worksheet.Column(3).AutoFit();
                    worksheet.Column(4).AutoFit();
                    worksheet.Column(5).AutoFit();
                    worksheet.Column(6).AutoFit();
                    worksheet.Column(7).AutoFit();
                    worksheet.Column(8).AutoFit();

                    package.Save();

                    byte[] reportBytes;
                    reportBytes = package.GetAsByteArray();

                    return File(reportBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Metas_" + mes + "-" + ano + "_" + filtroMeta + "_" + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") + ".xlsx");
                }
            }
            else
                return RedirectToAction("Metas", new { filtroMeta, mes, ano });
        }
    }
}
