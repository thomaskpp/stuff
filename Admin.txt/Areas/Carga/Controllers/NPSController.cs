﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;

using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaNPSAdmin })]
    public class NPSController : BaseCargaController
    {
        private readonly INPSServices _NPSServices;
        private readonly IConfiguration _configuration;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private readonly string[] _extensoesAceitas = new string[] { ".csv" };

        public NPSController(
            ICookies cookies,
            IConfiguration configuration,
            INPSServices NPSServices,
            IGerenciadorCargaServices gerenciadorCargaServices,
            ISecurityServices securityServices)
            : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _NPSServices = NPSServices;
            _configuration = configuration;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();
            
            var model = new NPSViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaNPSAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Index(NPSViewModel model)
        {
            SetViewBag();
            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida Arquivos

            model.Erros.Clear();

            if (!Request.Form.Files.Any())
                model.Erros.Add("Por Favor, selecione o arquivo de carga");

            #region Carrega Arquivos
            
            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");

                //ponto
                /* var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaNPSAdmin,
                    Funcional = Colaborador?.Funcional ?? string.Empty,
                    NomeFuncional = Colaborador?.Nome ?? string.Empty
                };*/
                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaNPSAdmin,
                    IdColaborador = Colaborador.Id,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdSegmento = 200
                };



                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);
            }

            #endregion


            if (model.Erros.Any())
                return View(model);

            #endregion

            var task = new Task(() =>
            {
                #region Verifica Dados

                _NPSServices.LimpaCache();

                VerificaUpload(gerenciadorCargas, model.Segmento, _NPSServices.VerificaLinhaArquivo);

                #endregion

                if (gerenciadorCargas.Any(x => x.ContemErro))
                {
                    var passoAtual = gerenciadorCargas.First().Passos.First(x => x.Passo == CargasPassos.Validacao);

                    passoAtual.Fim = DateTime.Now;
                    _gerenciadorCargaServices.GravarGerenciador(gerenciadorCargas.First());

                    return;
                }

                #region Deleta todos os registros

                _NPSServices.ExpurgoNPS(gerenciadorCargas);

                _NPSServices.ExcluirMeses(gerenciadorCargas);
                #endregion

                #region Valida se as agências na planilha existem e insere os registros

                UpsertUpload(gerenciadorCargas, model.Segmento, _NPSServices.Insert, null);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
    }
}