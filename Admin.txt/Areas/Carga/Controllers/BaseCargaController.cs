﻿using Itau.SZ7.GPS.Admin.Controllers;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Exceptions;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [Area("Carga")]
    public class BaseCargaController : BaseController
    {
        private readonly IConfiguration _configuration;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private IEnumerable<GerenciadorCarga> cargasRecentes = Enumerable.Empty<GerenciadorCarga>();

        public BaseCargaController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            ISecurityServices securityServices
            ) : base(cookies, configuration, securityServices)
        {
            _configuration = configuration;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        /// <summary>
        /// Define Viewbag a ser usada nas Views.
        /// Precisa ser chamada em todas as Actions
        /// </summary>
        public override void SetViewBag()
        {
            base.SetViewBag();

            var meses = new List<SelectListItem>();
            meses.Add(new SelectListItem("01", "1"));
            meses.Add(new SelectListItem("02", "2"));
            meses.Add(new SelectListItem("03", "3"));
            meses.Add(new SelectListItem("04", "4"));
            meses.Add(new SelectListItem("05", "5"));
            meses.Add(new SelectListItem("06", "6"));
            meses.Add(new SelectListItem("07", "7"));
            meses.Add(new SelectListItem("08", "8"));
            meses.Add(new SelectListItem("09", "9"));
            meses.Add(new SelectListItem("10", "10"));
            meses.Add(new SelectListItem("11", "11"));
            meses.Add(new SelectListItem("12", "12"));

            var anos = new List<SelectListItem>();
            anos.Add(new SelectListItem(Convert.ToString(DateTime.Now.Year - 1), Convert.ToString(DateTime.Now.Year - 1)));
            anos.Add(new SelectListItem(Convert.ToString(DateTime.Now.Year), Convert.ToString(DateTime.Now.Year), true));
            anos.Add(new SelectListItem(Convert.ToString(DateTime.Now.Year + 1), Convert.ToString(DateTime.Now.Year + 1)));

            ViewBag.Meses = meses;
            ViewBag.Anos = anos;

            ViewBag.StatusCargas = _gerenciadorCargaServices.RetornaListaCargasUltimaAtualizacao().Result.StatusCargas;

            var cargasRecentes = _gerenciadorCargaServices.ListaGerenciadoresRecentes().Result;
            ViewBag.CargasFinalizadas = cargasRecentes?.Where(x => x.Finalizado)?.ToList() ?? new List<GerenciadorCarga>();

            ViewBag.FileVersion = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version;
        }

        public async Task<IEnumerable<GerenciadorCarga>> RetornaCargasRecentesAsync()
        {
            if (!cargasRecentes.Any())
            {
                cargasRecentes = await _gerenciadorCargaServices.ListaGerenciadoresRecentes();
            }

            return cargasRecentes;
        }

        /// <summary>
        /// Método genérico para verificação de um arquivo de carga
        /// </summary>
        /// <param name="gerenciadorCarga">Objeto com dados dos arquivos e status</param>
        /// <param name="segmento">Nome do Segmento. Será repassado ao método delegado</param>
        /// <param name="verificacaoFunc">Método delegado a ser chamado para verificar o arquivo</param>
        /// <returns>Lista de erros por linha x coluna</returns>
        public void VerificaUpload(List<GerenciadorCarga> gerenciadorCargas, Segmentos segmento, Func<int, string, Segmentos, GerenciadorCarga, Models.UploadRetorno> verificacaoFunc, bool contemCabecalho = true)
        {
            foreach (var gerenciador in gerenciadorCargas)
            {
                var passoAtual = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = gerenciador.Id,
                    Passo = CargasPassos.Validacao,
                    Nome = CargasPassos.Validacao.Description(),
                    Atualizado = DateTime.Now
                };

                gerenciador.Passos.Add(passoAtual);
                gerenciador.Inicio = DateTime.Now;
                _gerenciadorCargaServices.GravarGerenciador(gerenciador);

                if (gerenciador.GravaCarga)
                    GerenciadorCargaAtual = gerenciador;

                gerenciador.FileStream.Position = 0;
                var reader = new StreamReader(gerenciador.FileStream, Encoding.GetEncoding("iso-8859-1"));
                var dtUltimaGravacaoGerenciador = DateTime.Now;

                int linha = 1;

                #region conta total de linhas

                while (!reader.EndOfStream)
                {
                    //pula cabeçalho
                    if (contemCabecalho && linha.Equals(1))
                    {
                        linha++;
                        reader.ReadLine();
                        continue;
                    }

                    linha++;
                    reader.ReadLine();
                }

                gerenciador.TotalLinhas = linha - (contemCabecalho ? 1 : 0);
                _gerenciadorCargaServices.GravarGerenciador(gerenciador);

                #endregion

                linha = 1;
                gerenciador.FileStream.Position = 0;

                var arquivoExtensao = Path.GetExtension(gerenciador.Arquivo);

                if (arquivoExtensao.Equals(".csv") || arquivoExtensao.Equals(".txt"))
                {
                    while (!reader.EndOfStream)
                    {
                        //pula cabeçalho
                        if (contemCabecalho && linha.Equals(1))
                        {
                            linha++;
                            reader.ReadLine();
                            continue;
                        }

                        VerificaUploadInterno(ref linha, reader.ReadLine(), segmento, gerenciador, passoAtual, ref dtUltimaGravacaoGerenciador, verificacaoFunc);
                    }
                }
                else if (arquivoExtensao.Equals(".xlsx"))
                {
                    var package = new OfficeOpenXml.ExcelPackage(gerenciador.FileStream);
                    var workSheet = package.Workbook.Worksheets[0];

                    for (var x = (contemCabecalho ? 2 : 1); x <= workSheet.Dimension.End.Row; x++)
                    {
                        var colunas = "";

                        for (int j = workSheet.Dimension.Start.Column; j <= workSheet.Dimension.End.Column; j++)
                            colunas += $"{workSheet.Cells[x, j].Value};";

                        VerificaUploadInterno(ref x, colunas.TrimEnd(';'), segmento, gerenciador, passoAtual, ref dtUltimaGravacaoGerenciador, verificacaoFunc);
                    }
                }

                passoAtual.Erro = passoAtual.ErroLinhas?.Count > 0;
                passoAtual.Fim = DateTime.Now;
                gerenciador.TotalLinhas = gerenciador.Passos.Sum(x => x.LinhasProcessadas);
                _gerenciadorCargaServices.GravarGerenciador(gerenciador);
            }
        }

        public void VerificaUploadInterno(ref int linha, string colunas, Segmentos segmento, GerenciadorCarga gerenciador, GerenciadorCargaPasso passoAtual, ref DateTime dtUltimaGravacaoGerenciador, Func<int, string, Segmentos, GerenciadorCarga, Models.UploadRetorno> verificacaoFunc, bool contemCabecalho = true)
        {
            var verificacao = verificacaoFunc(linha, colunas, segmento, gerenciador);

            if (verificacao != null)
            {
                gerenciador.Passos.First(x => x.Passo == CargasPassos.Validacao)
                    .ErroLinhas.Add(linha);

                _gerenciadorCargaServices.GravarErro(new GerenciadorCargaErro()
                {
                    IdGerenciadorCarga = gerenciador.Id,
                    Passo = CargasPassos.Validacao,
                    Linha = linha,
                    Erro = verificacao.ToString()
                });
            }

            passoAtual.Atualizado = DateTime.Now;
            passoAtual.LinhasProcessadas = linha - (contemCabecalho ? 1 : 0);
            linha++;

            if (dtUltimaGravacaoGerenciador.AddSeconds(10) < DateTime.Now)
            {
                _gerenciadorCargaServices.GravarGerenciador(gerenciador);
                dtUltimaGravacaoGerenciador = DateTime.Now;
            }
        }

        /// <summary>
        /// Método genérico para remoção e inserção de registros provenientes de arquivos de carga
        /// </summary>
        /// <param name="files">Lista de arquivos do Form</param>
        /// <param name="segmento">Nome do Segmento. Será repassado ao método delegado</param>
        /// <param name="carga">Tipo de carga. Será repassado ao método delegado</param>
        /// <param name="insertFunc">Método delegado responsável pela inserção dos registros no DB</param>
        /// <param name="removeFunc">Método delegado responsável pela remoção dos registros no DB</param>
        /// <returns>Lista de erros por linha x coluna</returns>
        public void UpsertUpload(List<GerenciadorCarga> gerenciadorCargas, Segmentos segmento, Action<List<int>, List<string>, int, Segmentos, GerenciadorCarga, Action<GerenciadorCarga>, Action<GerenciadorCargaErro>, bool> insertFunc, Action<List<int>, List<string>, int, Segmentos, GerenciadorCarga, Action<GerenciadorCarga>, Action<GerenciadorCargaErro>> removeAction, bool contemCabecalho = true)
        {
            var batchSize = _configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

            foreach (var gerenciador in gerenciadorCargas)
            {
                StreamReader reader;
                int linha = 0;
                var linhas = new List<int>();
                var registros = new List<string>();
                var dtUltimaGravacaoGerenciador = DateTime.Now;
                var arquivoExtensao = "";

                #region remove registros

                if (removeAction != null)
                {
                    var passoRemocao = new GerenciadorCargaPasso()
                    {
                        IdGerenciadorCarga = gerenciador.Id,
                        Passo = CargasPassos.Remocao,
                        Nome = CargasPassos.Remocao.Description(),
                        Atualizado = DateTime.Now
                    };

                    gerenciador.Passos.Add(passoRemocao);
                    _gerenciadorCargaServices.GravarGerenciador(gerenciador);

                    if (gerenciador.GravaCarga)
                        GerenciadorCargaAtual = gerenciador;

                    gerenciador.FileStream.Position = 0;
                    reader = new StreamReader(gerenciador.FileStream, Encoding.GetEncoding("iso-8859-1"));

                    linha = 1;
                    linhas = new List<int>();
                    registros = new List<string>();
                    arquivoExtensao = Path.GetExtension(gerenciador.Arquivo);

                    if (arquivoExtensao.Equals(".csv"))
                    {
                        while (!reader.EndOfStream)
                        {
                            //pula cabeçalho
                            if (contemCabecalho && linha.Equals(1))
                            {
                                linha++;
                                reader.ReadLine();
                                continue;
                            }

                            linhas.Add(linha);
                            registros.Add(reader.ReadLine());
                        }
                    }
                    else if (arquivoExtensao.Equals(".xlsx"))
                    {
                        var package = new OfficeOpenXml.ExcelPackage(gerenciador.FileStream);
                        var workSheet = package.Workbook.Worksheets[0];

                        for (var x = (contemCabecalho ? 2 : 1); x <= workSheet.Dimension.End.Row; x++)
                        {
                            var colunas = "";

                            for (int j = workSheet.Dimension.Start.Column; j <= workSheet.Dimension.End.Column; j++)
                                colunas += $"{workSheet.Cells[x, j].Value};";

                            linhas.Add(x);
                            registros.Add(colunas.TrimEnd(';'));
                        }
                    }

                    gerenciador.TotalLinhas = linhas.Count;

                    removeAction(linhas, registros, batchSize, segmento, gerenciador, _gerenciadorCargaServices.GravarGerenciador, _gerenciadorCargaServices.GravarErro);

                    passoRemocao.Fim = DateTime.Now;

                    if (passoRemocao.Erro)
                    {
                        gerenciador.Fim = DateTime.Now;
                        gerenciador.PopupConclusao = true;
                        _gerenciadorCargaServices.GravarGerenciador(gerenciador);
                        continue;
                    }
                }

                #endregion

                #region adiciona registros

                var passoValidacao = gerenciador.Passos.FirstOrDefault(x => x.Passo == CargasPassos.Validacao);

                var passoInsercao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = gerenciador.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = CargasPassos.Insercao.Description(),
                    Atualizado = DateTime.Now
                };

                gerenciador.Passos.Add(passoInsercao);
                _gerenciadorCargaServices.GravarGerenciador(gerenciador);

                gerenciador.FileStream.Position = 0;
                reader = new StreamReader(gerenciador.FileStream, Encoding.GetEncoding("iso-8859-1"));

                linha = 1;
                linhas = new List<int>();
                registros = new List<string>();
                dtUltimaGravacaoGerenciador = DateTime.Now;
                arquivoExtensao = Path.GetExtension(gerenciador.Arquivo);

                if (arquivoExtensao.Equals(".csv") || arquivoExtensao.Equals(".txt"))
                {
                    while (!reader.EndOfStream)
                    {
                        string conteudoLinha = string.Empty;
                        //pula cabeçalho
                        //pula linhas com erro de validação
                        if ((contemCabecalho && linha.Equals(1)) ||
                            (passoValidacao?.ErroLinhas?.Contains(linha) ?? false))
                        {
                            linha++;
                            conteudoLinha = reader.ReadLine();

                            if (!reader.EndOfStream)
                            {
                                continue;
                            }
                        }

                        if (!reader.EndOfStream)
                        {
                            conteudoLinha = reader.ReadLine();
                            if (!(string.IsNullOrEmpty(conteudoLinha) ||
                                  (conteudoLinha.Contains('\t') && string.IsNullOrWhiteSpace(string.Join("", conteudoLinha.Split('\t'))))))
                            {
                                linhas.Add(linha);
                                registros.Add(conteudoLinha);
                            }
                        }

                        if (registros.Count.Equals(batchSize) || reader.EndOfStream)
                        {
                            insertFunc(linhas, registros, batchSize, segmento, gerenciador, _gerenciadorCargaServices.GravarGerenciador, _gerenciadorCargaServices.GravarErro, false);

                            linhas = new List<int>();
                            registros = new List<string>();
                        }

                        if (dtUltimaGravacaoGerenciador.AddSeconds(10) < DateTime.Now)
                        {
                            _gerenciadorCargaServices.GravarGerenciador(gerenciador);
                            dtUltimaGravacaoGerenciador = DateTime.Now;
                        }

                        linha++;
                    }
                }
                else if (arquivoExtensao.Equals(".xlsx"))
                {
                    var package = new OfficeOpenXml.ExcelPackage(gerenciador.FileStream);
                    var workSheet = package.Workbook.Worksheets[0];

                    for (var x = (contemCabecalho ? 2 : 1); x <= workSheet.Dimension.End.Row; x++)
                    {
                        if (passoValidacao?.ErroLinhas?.Contains(linha) ?? false)
                            continue;

                        var colunas = "";

                        for (int j = workSheet.Dimension.Start.Column; j <= workSheet.Dimension.End.Column; j++)
                            colunas += $"{workSheet.Cells[x, j].Value};";

                        linhas.Add(x);
                        registros.Add(colunas.TrimEnd(';'));

                        if (registros.Count.Equals(batchSize) || x.Equals(workSheet.Dimension.End.Row))
                        {
                            insertFunc(linhas, registros, batchSize, segmento, gerenciador, _gerenciadorCargaServices.GravarGerenciador, _gerenciadorCargaServices.GravarErro, false);

                            linhas = new List<int>();
                            registros = new List<string>();
                        }

                        if (dtUltimaGravacaoGerenciador.AddSeconds(10) < DateTime.Now)
                        {
                            _gerenciadorCargaServices.GravarGerenciador(gerenciador);
                            dtUltimaGravacaoGerenciador = DateTime.Now;
                        }

                    }
                }


                #endregion

                passoInsercao.Fim = DateTime.Now;
                gerenciador.Fim = DateTime.Now;
                gerenciador.PopupConclusao = true;
                _gerenciadorCargaServices.GravarGerenciador(gerenciador);
            }
        }

        public bool CargasEmAndamento(int TipoCarga)
        {
            var result = false;

            var cargasNaoSimultaneas = _gerenciadorCargaServices.GetGridAllCargasAsync().Result.Where(x => x.TravaSimultanea.Equals(true) && x.IdCarga == (Cargas)TipoCarga).ToList();

            if (cargasNaoSimultaneas.Count() > 0)
            {
                if (!cargasRecentes.Any())
                {
                    cargasRecentes = _gerenciadorCargaServices.ListaGerenciadoresRecentes().Result;

                }
                var ExisteCargaAtiva = cargasRecentes?.Where(x => !x.Finalizado && x.IdFuncionalidade == (Funcionalidade.Enum)TipoCarga)?.ToList() ?? new List<GerenciadorCarga>();

                if (ExisteCargaAtiva.Count > 0)
                {
                    result = true;
                }
            }

            return result;
        }

        public async Task CarregarFiltroCargasFinalizadasAsync()
        {
            var cargasRecentes = await _gerenciadorCargaServices.ListaGerenciadoresRecentes();

            ViewBag.FiltroProcessos = cargasRecentes?.Where(x => x.Finalizado)?.GroupBy(x => x.NomeFuncional).Select(group => group.First());
            ViewBag.FiltroResponsavel = cargasRecentes?.Where(x => x.Finalizado)?.GroupBy(x => x.NomeFuncional).Select(group => group.First());
            ViewBag.FiltroTempo = cargasRecentes?.Where(x => x.Finalizado)?.GroupBy(x => x.TempoTermino).Select(group => group.First());
            ViewBag.FiltroData = cargasRecentes?.Where(x => x.Finalizado)?.GroupBy(x => x.FimDataFormatado).Select(group => group.First());
            ViewBag.FiltroHoras = cargasRecentes?.Where(x => x.Finalizado)?.GroupBy(x => x.FimHoraFormatado).Select(group => group.First());
            ViewBag.FiltroLinhas = cargasRecentes?.Where(x => x.Finalizado)?.GroupBy(x => x.TotalLinhasInseridas).Select(group => group.First());
        }

        private string FormatarNomeCarga(GerenciadorCarga gerenciadorCarga)
        {
            if ((int)gerenciadorCarga.IdFuncionalidade != 57)
            {
                return gerenciadorCarga.IdFuncionalidade.ToString();
            }

            return $"{gerenciadorCarga.IdFuncionalidade.ToString()} ({gerenciadorCarga.Arquivo.Replace(".csv", string.Empty)})";
        }

        public void GerenciadorCargaExceptionHandler(Task task)
        {
            var passoAtual = GerenciadorCargaAtual?.Passos?.Last();

            _gerenciadorCargaServices.GravarErro(new GerenciadorCargaErro()
            {
                IdGerenciadorCarga = GerenciadorCargaAtual.Id,
                Passo = passoAtual?.Passo ?? CargasPassos.Validacao,
                Linha = 0,
                Erro = $"{ExceptionExtension.RetornaInnerException(task.Exception)?.Message} <br> {ExceptionExtension.RetornaInnerException(task.Exception)?.StackTrace}"
            });

            if (passoAtual != null)
                passoAtual.Erro = true;

            GerenciadorCargaAtual.Fim = DateTime.Now;
            _gerenciadorCargaServices.GravarGerenciador(GerenciadorCargaAtual);
        }
    }
}