﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaGradeAdmin })]
    public class GradeController : BaseCargaController
    {
        private readonly IGradeServices _gradeServices;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private readonly string[] _extensoesAceitas = new string[] { ".csv" };
        private readonly Dictionary<string, string> _headerNecessarios = new Dictionary<string, string>();
        private readonly int _batchSize;

        public GradeController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            IGradeServices gradeServices,
            ISecurityServices securityServices) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _headerNecessarios.Add("Grades", "SEGMENTO;CODIGO_ITEM;BONUS;NOME_ITEM;GRADE;VINCULO;PESO;ICM_MAXIMO;AGRUPAMENTO;PONDERADOR;PERIODO;VALOR_NO_CHECK_OUT;ICONE;ICM_MINIMO;EXIBICAO_PLANEJAMENTO;EXIBICAO_PERFORMANCE");
            _headerNecessarios.Add("Produtos Válidos", "SEGMENTO;CODIGO_ITEM;NOME_PRODUTO;STATUS;CODIGO_PRODUTO");
            _headerNecessarios.Add("Vocações", "GRADE;COD_VOCACAO");

            _batchSize = configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

            _gradeServices = gradeServices;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new GradeViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaGradeAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Index(GradeViewModel model)
        {
            SetViewBag();
            model.CargaTipo = Funcionalidade.Enum.CargaGradeAdmin;
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = RetornaCargasRecentesAsync().Result;

            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida arquivos

            model.Erros.Clear();

            if (model.Ano < 1 || model.Mes < 1)
            {
                model.Erros.Add("Selecione Mês e Ano para prosseguir");
                return View(model);
            }

            if (!Request.Form.Files.Any() || Request.Form.Files.Count != _headerNecessarios.Count)
            {
                model.Erros.Add($"Para executar esta carga são necessários {_headerNecessarios.Count} arquivos: {string.Join(", ", _headerNecessarios.Keys.ToArray())}");
                return View(model);
            }

            //validar todos arquivos necessários para carga
            Dictionary<string, string> headersEncontrados = new Dictionary<string, string>();

            foreach (var arquivo in Request.Form.Files)
            {
                using (StreamReader reader = new StreamReader(arquivo.OpenReadStream()))
                {
                    var header = reader.ReadLine();

                    if (_headerNecessarios.Any(x => x.Value.Equals(header)) &&
                        !headersEncontrados.Any(x => x.Value.Equals(header)))
                    {
                        var headerDict = _headerNecessarios.First(x => x.Value.Equals(header));
                        headersEncontrados.Add(headerDict.Key, headerDict.Value);

                        var carga = new GerenciadorCarga()
                        {
                            Arquivo = arquivo.FileName,
                            ArquivoApelido = headerDict.Key,
                            IdFuncionalidade = Funcionalidade.Enum.CargaGradeAdmin,
                            GravaCarga = false,
                            Funcional = Colaborador?.Funcional,
                            NomeFuncional = Colaborador?.Nome,
                            IdColaborador = Colaborador.Id
                        };

                        arquivo.CopyTo(carga.FileStream);
                        gerenciadorCargas.Add(carga);
                    }
                }
            }

            if (headersEncontrados.Count != _headerNecessarios.Count)
            {
                var arquivosFaltantes = _headerNecessarios.Keys.Where(x => !headersEncontrados.Keys.Contains(x)).ToArray();

                model.Erros.Add($"Para executar esta carga são necessários {_headerNecessarios.Count} arquivos. Não recebemos os seguintes arquivos: {string.Join(", ", arquivosFaltantes)}");
                return View(model);
            }


            foreach (var gerenciador in gerenciadorCargas)
            {
                var extensaoArquivo = Path.GetExtension(gerenciador.Arquivo);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {gerenciador.Arquivo} não é suportado.");
            }

            if (model.Erros.Any())
                return View(model);

            #endregion

            var task = new Task(() =>
            {
                #region grava gerenciador

                var cargaGrade = new GerenciadorCarga()
                {
                    IdFuncionalidade = Funcionalidade.Enum.CargaGradeAdmin,
                    Ano = model.Ano,
                    Mes = model.Mes,
                    IdColaborador = Colaborador.Id,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdSegmento = 200
                };

                var passoVerificacao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaGrade.Id,
                    Passo = CargasPassos.Validacao,
                    Nome = CargasPassos.Validacao.Description(),
                    Atualizado = DateTime.Now
                };

                cargaGrade.Passos.Add(passoVerificacao);
                cargaGrade.Inicio = DateTime.Now;
                _gerenciadorCargaServices.GravarGerenciador(cargaGrade);

                GerenciadorCargaAtual = cargaGrade;

                foreach (var gerenciador in gerenciadorCargas)
                    gerenciador.Id = cargaGrade.Id;

                #endregion

                #region Verifica dados

                VerificaUpload(gerenciadorCargas, model.Segmento, _gradeServices.VerificaLinhaArquivo);

                //não continua se houver erro de validação
                if (gerenciadorCargas.Any(x => x.ContemErro))
                {
                    cargaGrade.Fim = DateTime.Now;
                    _gerenciadorCargaServices.GravarGerenciador(cargaGrade);

                    return;
                }

                #endregion

                #region grava gerenciador

                var passoInsercao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaGrade.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = CargasPassos.Insercao.Description(),
                    Atualizado = DateTime.Now
                };

                cargaGrade.Passos.Add(passoInsercao);
                cargaGrade.TotalLinhas = gerenciadorCargas.Sum(x => x.TotalLinhas);
                passoVerificacao.LinhasProcessadas = cargaGrade.TotalLinhas;
                passoVerificacao.Erro = gerenciadorCargas.Any(x => x.ContemErro);
                passoVerificacao.Fim = DateTime.Now;

                _gerenciadorCargaServices.GravarGerenciador(cargaGrade);

                #endregion

                #region Insere dados

                _gradeServices.CarregarProdutoItem(gerenciadorCargas, _batchSize, cargaGrade).Wait();
                _gradeServices.CarregarPlanejamentoItemGrade(gerenciadorCargas, _batchSize, cargaGrade).Wait();
                var res =_gradeServices.RemoverPlanejamentoItemGrade(gerenciadorCargas, _batchSize, cargaGrade).Result;

                // Todo Carlos - limpar cache em:
                //PRODUTO / GRADE ITEM 
                // #delete: planejamento simulação / planejamento Item / checkout / colaborador Agir / Grade Item # 

                #endregion

                #region grava gerenciador

                passoInsercao.Fim = DateTime.Now;
                cargaGrade.Fim = DateTime.Now;
                cargaGrade.PopupConclusao = true;
                _gerenciadorCargaServices.GravarGerenciador(cargaGrade);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }

        [Authentication]
        public async Task<IActionResult> Fake()
        {
            SetViewBag();

            var model = new GradeViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaGradeCarteiraFakeAdmin;
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Fake(GradeViewModel model)
        {
            SetViewBag();
            model.CargaTipo = Funcionalidade.Enum.CargaGradeCarteiraFakeAdmin;
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = RetornaCargasRecentesAsync().Result;

            var gerenciadorCargas = new List<GerenciadorCarga>();
            var headerNecessarios = new Dictionary<string, string>();

            #region Valida arquivos

            headerNecessarios.Add("Grade Fake", "CARTEIRA;GRADE");

            model.Erros.Clear();

            if (model.Ano < 1 || model.Mes < 1)
            {
                model.Erros.Add("Selecione Mês e Ano para prosseguir");
                return View(model);
            }

            if (!Request.Form.Files.Any() || Request.Form.Files.Count != headerNecessarios.Count)
            {
                model.Erros.Add($"Para executar esta carga são necessários {headerNecessarios.Count} arquivos: {string.Join(", ", _headerNecessarios.Keys.ToArray())}");
                return View(model);
            }

            //validar todos arquivos necessários para carga
            Dictionary<string, string> headersEncontrados = new Dictionary<string, string>();

            foreach (var arquivo in Request.Form.Files)
            {
                if (Path.GetExtension(arquivo.FileName) != ".xlsx")
                {
                    model.Erros.Add($"O formato arquivo {arquivo.FileName} não é suportado");
                    return View(model);
                }

                var package = new OfficeOpenXml.ExcelPackage(arquivo.OpenReadStream());

                if (!package.Workbook.Worksheets.Any())
                {
                    model.Erros.Add("O arquivo informado está vazio");
                    return View(model);
                }

                var workSheet = package.Workbook.Worksheets[0];
                var header = "";

                for (int j = workSheet.Dimension.Start.Column; j <= workSheet.Dimension.End.Column; j++)
                    header += $"{workSheet.Cells[1, j].Value};";

                if (header.TrimEnd(';').ToUpper() != "CARTEIRA;GRADE")
                {
                    model.Erros.Add("O arquivo informado está vazio");
                    return View(model);
                }

                var carga = new GerenciadorCarga()
                {
                    Arquivo = Path.GetFileName(arquivo.FileName),
                    IdFuncionalidade = Funcionalidade.Enum.CargaGradeCarteiraFakeAdmin,
                    GravaCarga = true,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    Ano = model.Ano,
                    Mes = model.Mes,
                    IdColaborador = Colaborador.Id,
                    IdSegmento = 200
                };

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);
            }

            #endregion

            var task = new Task(() =>
            {
                #region Verifica dados

                VerificaUpload(gerenciadorCargas, model.Segmento, _gradeServices.VerificaLinhaArquivo);

                #endregion

                #region Insere dados

                UpsertUpload(gerenciadorCargas, model.Segmento, _gradeServices.InsertGradeFake, _gradeServices.RemoveItemGradeFake);

                #endregion

            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
    }
}