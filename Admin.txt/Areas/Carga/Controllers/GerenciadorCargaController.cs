﻿using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargasAdmin })]
    public class GerenciadorCargaController : BaseCargaController
    {
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;

        public GerenciadorCargaController(
            IGerenciadorCargaServices gerenciadorCargaServices,
            ICookies cookies,
            IConfiguration configuration,
            ISecurityServices securityServices)
            : base(cookies, configuration, gerenciadorCargaServices,securityServices)
        {
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new Models.GerenciadorCargaViewModel();

            model.Cargas = await _gerenciadorCargaServices.ListaGerenciadoresRecentes();

            return View(model);
        }

        [Authentication]
        public async Task<IActionResult> Erros(int id)
        {
            SetViewBag();

            var model = await _gerenciadorCargaServices.ListaCargaErros(id);

            return View(model);
        }

        [HttpPost]
        public JsonResult RetornaListaCargasExecucao()
        {
            var cargas = _gerenciadorCargaServices.ListaGerenciadoresRecentes().Result;
            var cargasAtivas = cargas?.Where(x => !x.Finalizado)?.OrderBy(x => x.ProgressoAtual).ToList() ?? new List<GerenciadorCarga>();

            return Json(cargasAtivas);
        }
    }
}