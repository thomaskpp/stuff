﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;

using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaNotificacaoAdmin })]
    public class NotificacaoController : BaseCargaController
    {
        private readonly string[] _extensoesAceitas = new string[] { ".csv" };
        private readonly Dictionary<string, string> _headerNecessarios = new Dictionary<string, string>();
        private readonly INotificacaoServices _notificacaoServices;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;

        private readonly int _batchSize;


        public NotificacaoController(ICookies cookies,
                                     IConfiguration configuration,
                                     IGerenciadorCargaServices gerenciadorCargaServices,
                                     INotificacaoServices notificacaoServices,
            ISecurityServices securityServices) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _headerNecessarios.Add("1_Notificacao_Remetente", "ID_REMETENTE;REMETENTE;IMG_REMETENTE");
            _headerNecessarios.Add("2_Notificacao", "ID_NOTIFICACAO;STATUS;TEMPLATE;ARQUIVO_TEMPLATE;TEXTO;IMG;URLATALHO;RESUMO;DATAPUBLICACAO;HORA;ID_REMETENTE;CODIGOTIPO_EXIBICAO;ID_TEMPLATE;ORDEM_PAG;CODIGOPAI");
            _headerNecessarios.Add("3_Notificacao_Destinatario", "FUNCIONAL;ID_NOTIFICACAO;DADOS_VARIAVEIS;STATUS");

            _batchSize = configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

            _gerenciadorCargaServices = gerenciadorCargaServices;
            _notificacaoServices = notificacaoServices;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new NotificacaoProcessamentoViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaNotificacaoAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [HttpPost]
        public IActionResult Index(NotificacaoProcessamentoViewModel model)
        {
            SetViewBag();

            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida arquivos

            model.Erros.Clear();

            if (!Request.Form.Files.Any() || Request.Form.Files.Count != _headerNecessarios.Count)
            {
                model.Erros.Add($"Para executar esta carga são necessários {_headerNecessarios.Count} arquivos: {string.Join(", ", _headerNecessarios.Keys.ToArray())}");
                return View(model);
            }

            //validar todos arquivos necessários para carga
            Dictionary<string, string> headersEncontrados = new Dictionary<string, string>();

            foreach (var arquivo in Request.Form.Files)
            {
                using (StreamReader reader = new StreamReader(arquivo.OpenReadStream()))
                {
                    var header = reader.ReadLine();

                    if (_headerNecessarios.Any(x => x.Value.Equals(header)) &&
                        !headersEncontrados.Any(x => x.Value.Equals(header)))
                    {
                        var headerDict = _headerNecessarios.First(x => x.Value.Equals(header));
                        headersEncontrados.Add(headerDict.Key, headerDict.Value);

                        var carga = new GerenciadorCarga()
                        {
                            Arquivo = arquivo.FileName,
                            ArquivoApelido = headerDict.Key,
                            IdFuncionalidade = Funcionalidade.Enum.CargaNotificacaoAdmin,
                            GravaCarga = false,
                            Funcional = Colaborador?.Funcional,
                            NomeFuncional = Colaborador?.Nome,
                            IdColaborador = Colaborador.Id
                        };

                        arquivo.CopyTo(carga.FileStream);
                        gerenciadorCargas.Add(carga);
                    }
                }
            }

            if (headersEncontrados.Count != _headerNecessarios.Count)
            {
                var arquivosFaltantes = _headerNecessarios.Keys.Where(x => !headersEncontrados.Keys.Contains(x)).ToArray();

                model.Erros.Add($"Para executar esta carga são necessários {_headerNecessarios.Count} arquivos. Não recebemos os seguintes arquivos: {string.Join(", ", arquivosFaltantes)}");
                return View(model);
            }


            foreach (var gerenciador in gerenciadorCargas)
            {
                var extensaoArquivo = Path.GetExtension(gerenciador.Arquivo);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {gerenciador.Arquivo} não é suportado.");
            }

            if (model.Erros.Any())
                return View(model);

            #endregion

            var task = new Task(() =>
            {
                #region Limpa Cache

                _notificacaoServices.LimpaCache();

                #endregion

                #region grava gerenciador

                var cargaNotificacoes = new GerenciadorCarga()
                {
                    IdFuncionalidade = Funcionalidade.Enum.CargaNotificacaoAdmin,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdSegmento = 200,
                    IdColaborador = Colaborador.Id
                };

                var passoVerificacao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaNotificacoes.Id,
                    Passo = CargasPassos.Validacao,
                    Nome = CargasPassos.Validacao.ToString(),
                    Atualizado = DateTime.Now
                };

                cargaNotificacoes.Passos.Add(passoVerificacao);
                cargaNotificacoes.Inicio = DateTime.Now;
                _gerenciadorCargaServices.GravarGerenciador(cargaNotificacoes);

                GerenciadorCargaAtual = cargaNotificacoes;

                foreach (var arquivo in gerenciadorCargas)
                    arquivo.Id = cargaNotificacoes.Id;

                #endregion

                #region Verifica dados

                _notificacaoServices.SalvaNotificacoesCsv(gerenciadorCargas.First(x => x.ArquivoApelido.Equals("2_Notificacao")).FileStream);

                VerificaUpload(gerenciadorCargas.OrderBy(x => x.ArquivoApelido).ToList(), Enums.Segmentos.Agencias, _notificacaoServices.VerificaLinhaArquivo);

                //não continua se houver erro de validação
                //Ver com o murilo se isso vai continuar para essa carga 
                //    if (gerenciadorCargas.Any(x => x.ContemErro))
                //{
                //    cargaAgencias.Fim = DateTime.Now;
                //    _gerenciadorCargaServices.GravarGerenciador(cargaAgencias);

                //    return;
                //}

                #endregion

                #region grava gerenciador

                var passoInsercao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaNotificacoes.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = CargasPassos.Insercao.ToString(),
                    Atualizado = DateTime.Now
                };

                cargaNotificacoes.Passos.Add(passoInsercao);
                cargaNotificacoes.TotalLinhas = gerenciadorCargas.Sum(x => x.TotalLinhas);
                passoVerificacao.LinhasProcessadas = cargaNotificacoes.TotalLinhas;
                passoVerificacao.Erro = gerenciadorCargas.Any(x => x.ContemErro);
                passoVerificacao.Fim = DateTime.Now;

                _gerenciadorCargaServices.GravarGerenciador(cargaNotificacoes);

                #endregion

                #region Insere dados

                UpsertUpload(gerenciadorCargas.OrderBy(x => x.ArquivoApelido).ToList(), Enums.Segmentos.Agencias, _notificacaoServices.InsertUpdate, null);

                cargaNotificacoes.TotalLinhas = gerenciadorCargas.Sum(x => x.TotalLinhas);
                passoInsercao.LinhasProcessadas = gerenciadorCargas.Sum(x => x.Passos.First(y => y.Passo == CargasPassos.Insercao).LinhasProcessadas);
                _gerenciadorCargaServices.GravarGerenciador(cargaNotificacoes);

                #region Processar Historico

                if (gerenciadorCargas.Any(x => x.ArquivoApelido == "2_Notificacao") ||
                    gerenciadorCargas.Any(x => x.ArquivoApelido == "3_Notificacao_Destinatario"))
                {
                    _notificacaoServices.MoverNotificacoesHistorico().Wait();
                }

                #endregion

                #endregion

                #region grava gerenciador

                if (gerenciadorCargas.Where(x => x.ContemErro).Any())
                {
                    cargaNotificacoes.Passos.First(x => x.Passo == CargasPassos.Insercao).Erro = true;
                }

                passoInsercao.Fim = DateTime.Now;
                cargaNotificacoes.Fim = DateTime.Now;
                cargaNotificacoes.PopupConclusao = true;
                _gerenciadorCargaServices.GravarGerenciador(cargaNotificacoes);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }

    }
}