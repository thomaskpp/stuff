﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.GradePersonnaliteAdmin })]
    public class GradePersonnaliteController : BaseCargaController
    {
        private readonly IGradeServices _gradeServices;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;
        private readonly string[] _extensoesAceitas = new string[] { ".csv" };
        private readonly Dictionary<string, string> _headerNecessarios = new Dictionary<string, string>();
        private readonly int _batchSize;

        public GradePersonnaliteController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            IGradeServices gradeServices,
            ISecurityServices securityService) : base(cookies, configuration, gerenciadorCargaServices, securityService)
        {
            _headerNecessarios.Add("Grades", "SEGMENTO;CODIGO_ITEM;BONUS;NOME_ITEM;GRADE;VINCULO;PESO;ICM_MAXIMO;AGRUPAMENTO;PONDERADOR;PERIODO;VALOR_NO_CHECK_OUT;ICONE;ICM_MINIMO;EXIBICAO_PLANEJAMENTO;EXIBICAO_PERFORMANCE");
            _headerNecessarios.Add("Produtos Válidos", "SEGMENTO;CODIGO_ITEM;NOME_PRODUTO;STATUS;CODIGO_PRODUTO;ICM_PARAM;PONDERADOR;PONDERADOR_MAX");
            _headerNecessarios.Add("Vocações", "GRADE;COD_VOCACAO");

            _batchSize = configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

            _gradeServices = gradeServices;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new GradePersonnaliteViewModel();
            model.CargaTipo = Funcionalidade.Enum.GradePersonnaliteAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Index(GradePersonnaliteViewModel model)
        {
            SetViewBag();
            model.CargaTipo = Funcionalidade.Enum.GradePersonnaliteAdmin;
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = RetornaCargasRecentesAsync().Result;

            var gerenciadorCargas = new List<GerenciadorCarga>();

            #region Valida arquivos

            model.Erros.Clear();

            if (model.Ano < 1 || model.Mes < 1)
            {
                model.Erros.Add("Selecione Mês e Ano para prosseguir");
                return View(model);
            }

            if (!Request.Form.Files.Any() || Request.Form.Files.Count != _headerNecessarios.Count)
            {
                model.Erros.Add($"Para executar esta carga são necessários {_headerNecessarios.Count} arquivos: {string.Join(", ", _headerNecessarios.Keys.ToArray())}");
                return View(model);
            }

            //validar todos arquivos necessários para carga
            Dictionary<string, string> headersEncontrados = new Dictionary<string, string>();

            foreach (var arquivo in Request.Form.Files)
            {
                using (StreamReader reader = new StreamReader(arquivo.OpenReadStream()))
                {
                    var header = reader.ReadLine();

                    if (_headerNecessarios.Any(x => x.Value.Equals(header)) &&
                        !headersEncontrados.Any(x => x.Value.Equals(header)))
                    {
                        var headerDict = _headerNecessarios.First(x => x.Value.Equals(header));
                        headersEncontrados.Add(headerDict.Key, headerDict.Value);

                        var carga = new GerenciadorCarga()
                        {
                            Arquivo = arquivo.FileName,
                            ArquivoApelido = headerDict.Key,
                            IdFuncionalidade = Funcionalidade.Enum.GradePersonnaliteAdmin,
                            GravaCarga = false,
                            Funcional = Colaborador?.Funcional,
                            NomeFuncional = Colaborador?.Nome,
                            IdColaborador = Colaborador.Id
                        };

                        arquivo.CopyTo(carga.FileStream);
                        gerenciadorCargas.Add(carga);
                    }
                }
            }

            if (headersEncontrados.Count != _headerNecessarios.Count)
            {
                var arquivosFaltantes = _headerNecessarios.Keys.Where(x => !headersEncontrados.Keys.Contains(x)).ToArray();

                model.Erros.Add($"Para executar esta carga são necessários {_headerNecessarios.Count} arquivos. Não recebemos os seguintes arquivos: {string.Join(", ", arquivosFaltantes)}");
                return View(model);
            }


            foreach (var gerenciador in gerenciadorCargas)
            {
                var extensaoArquivo = Path.GetExtension(gerenciador.Arquivo);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {gerenciador.Arquivo} não é suportado.");
            }

            if (model.Erros.Any())
                return View(model);

            #endregion

            var task = new Task(() =>
            {
                #region grava gerenciador

                var cargaGrade = new GerenciadorCarga()
                {
                    IdFuncionalidade = Funcionalidade.Enum.GradePersonnaliteAdmin,
                    Ano = model.Ano,
                    Mes = model.Mes,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdSegmento = 5,
                    IdColaborador = Colaborador.Id
                };

                var passoVerificacao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaGrade.Id,
                    Passo = CargasPassos.Validacao,
                    Nome = CargasPassos.Validacao.Description(),
                    Atualizado = DateTime.Now
                };

                cargaGrade.Passos.Add(passoVerificacao);
                cargaGrade.Inicio = DateTime.Now;
                _gerenciadorCargaServices.GravarGerenciador(cargaGrade);

                GerenciadorCargaAtual = cargaGrade;

                #endregion

                #region Verifica dados

                //VerificaUpload(gerenciadorCargas, model.Segmento, _gradeServices.VerificaLinhaArquivo);

                //não continua se houver erro de validação
                if (gerenciadorCargas.Any(x => x.ContemErro))
                {
                    cargaGrade.Fim = DateTime.Now;
                    _gerenciadorCargaServices.GravarGerenciador(cargaGrade);

                    return;
                }

                #endregion

                #region grava gerenciador

                var passoInsercao = new GerenciadorCargaPasso()
                {
                    IdGerenciadorCarga = cargaGrade.Id,
                    Passo = CargasPassos.Insercao,
                    Nome = CargasPassos.Insercao.Description(),
                    Atualizado = DateTime.Now                    
                };

                cargaGrade.Passos.Add(passoInsercao);
                cargaGrade.TotalLinhas = gerenciadorCargas.Sum(x => x.TotalLinhas);
                passoVerificacao.LinhasProcessadas = cargaGrade.TotalLinhas;
                passoVerificacao.Erro = gerenciadorCargas.Any(x => x.ContemErro);
                passoVerificacao.Fim = DateTime.Now;

                _gerenciadorCargaServices.GravarGerenciador(cargaGrade);

                #endregion

                #region Insere dados
                
                _gradeServices.CarregarProdutoItemPersonnalite(gerenciadorCargas, _batchSize, cargaGrade).Wait();
                _gradeServices.CarregarPlanejamentoItemGrade(gerenciadorCargas, _batchSize, cargaGrade).Wait();
                _gradeServices.RemoverPlanejamentoItemGradePersonnalite(gerenciadorCargas, _batchSize, cargaGrade).Wait();

                #endregion

                #region grava gerenciador

                passoInsercao.Fim = DateTime.Now;
                cargaGrade.Fim = DateTime.Now;
                cargaGrade.PopupConclusao = true;
                _gerenciadorCargaServices.GravarGerenciador(cargaGrade);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
    }
}