﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargasAdmin })]
    public class EditarConfiguracoesController : BaseCargaController
    {
        private readonly IEditarConfiguracoesServices _editarConfiguracoesServices;

        public EditarConfiguracoesController(ICookies cookies,
           IConfiguration configuration,
           IGerenciadorCargaServices gerenciadorCargaServices,
           IEditarConfiguracoesServices editarConfiguracoesServices,
           ISecurityServices securityServices
            )
           : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _editarConfiguracoesServices = editarConfiguracoesServices;
        }

        [Authentication]
        [HttpGet]
        public async Task<IActionResult> Index(int Funcionalidade)
        {
            SetViewBag();

            string urlAnterior = Request.QueryString.ToString().Replace("?Funcionalidade=", "");
            var model = new EditarConfiguracoesViewModel();

            if (!string.IsNullOrWhiteSpace(urlAnterior))
            {
                //model.CargaTipo = (Cargas)Convert.ToInt32(urlAnterior);
                model.IdFuncionalidade = Convert.ToInt32(urlAnterior);

                var editarCarga = _editarConfiguracoesServices.GetActiveCargas(model.IdFuncionalidade).Result;

                model.PeriodoTipo = editarCarga.PeriodoTipo;
                model.ListaDias = editarCarga.ListaDias;
                model.DiasDoMes = editarCarga.DiasDoMes;
                model.DiasExato = editarCarga.DiasExato;
                model.PrimeiroDiaUtil = editarCarga.PrimeiroDiaUtil;
                model.UtimoDiaUtil = editarCarga.UtimoDiaUtil;
                model.TravaSimultanea = editarCarga.TravaSimultanea;
            }

            model.AbaAtiva = AdminAbaAtiva.Configuracao;

            var list = CargaEditarConfiguracoes.GetAllDiasSemanais();
            model.ValoresDiasdaSemana = new MultiSelectList(list, "Value", "Dia");
            return View(model);
        }

        [Authentication]
        [HttpPost]
        public IActionResult Index(EditarConfiguracoesViewModel model)
        {
            if (model.PeriodoTipo.Equals(CargasTipoPeriodo.Diario))
            {
                _editarConfiguracoesServices.InsereDiario(model);
            }
            else
            if (model.PeriodoTipo.Equals(CargasTipoPeriodo.Semanal))
            {
                _editarConfiguracoesServices.InsereSemanais(model);
            }
            else
            if (model.PeriodoTipo.Equals(CargasTipoPeriodo.Mensal))
            {
                _editarConfiguracoesServices.InsereMensal(model);
            }
            else
            if (model.PeriodoTipo.Equals(CargasTipoPeriodo.Anual))
            {
                _editarConfiguracoesServices.InsereAnual(model);
            }

            return Redirect("~/Carga/Configuracoes");
        }


    }
}