﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using ReflectionIT.Mvc.Paging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    public class VendaAtivaController : BaseCargaController
    {
        private readonly IVendaAtiva _vendaAtiva;
        private readonly IConfiguration _configuration;
        private readonly IGerenciadorCargaServices _gerenciadorCargaServices;

        private readonly string[] _extensoesAceitas = new string[] { ".csv" };
        //private readonly Dictionary<string, string> _headerNecessarios = new Dictionary<string, string>();
        public VendaAtivaController(
            ICookies cookies,
            IConfiguration configuration,
            IVendaAtiva vendaAtiva,
            IGerenciadorCargaServices gerenciadorCargaServices,
            ISecurityServices securityServices
            ) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _configuration = configuration;
            _vendaAtiva = vendaAtiva;
            _gerenciadorCargaServices = gerenciadorCargaServices;
        }

        #region VendaAtiva
        [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaVendaAtivaAdmin })]
        public async Task<IActionResult> Index()
        {

            SetViewBag();

            var model = new VendaAtivaViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaVendaAtivaAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();
            model.Segmentos = _vendaAtiva.RetornarSelectSegmentos();

            return View(model);

        }

        [HttpPost]
        [Authentication]
        public IActionResult Index(VendaAtivaViewModel model)
        {
            SetViewBag();

            model.CargaTipo = Funcionalidade.Enum.CargaVendaAtivaAdmin;
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = RetornaCargasRecentesAsync().Result;

            var gerenciadorCargas = new List<GerenciadorCarga>();

            if (model.Segmento == 0)
            {
                model.Erros.Add("Por favor, selecione o segmento.");
                model.Segmentos = _vendaAtiva.RetornarSelectSegmentos();
                return View(model);
            }


            if (!Request.Form.Files.Any())
            {
                model.Erros.Add("Por favor, selecione o arquivo de carga.");
                model.Segmentos = _vendaAtiva.RetornarSelectSegmentos();
                return View(model);
            }

            #region Valida arquivos

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                {
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");
                }

                var cargaVendaAtiva = new GerenciadorCarga()
                {
                    Arquivo = $"VAI - { arquivo.FileName }",
                    IdFuncionalidade = Funcionalidade.Enum.CargaVendaAtivaAdmin,
                    IdColaborador = Colaborador.Id,
                    Funcional = "",
                    NomeFuncional = "",
                    IdSegmento = 200,
                    GravaCarga = false,
                    ArquivoApelido = arquivo.FileName.Split('.')[0]
                };

                arquivo.CopyTo(cargaVendaAtiva.FileStream);
                gerenciadorCargas.Add(cargaVendaAtiva);
            }

            if (model.Erros.Any())
            {
                model.Segmentos = _vendaAtiva.RetornarSelectSegmentos();
                return View(model);
            }
            #endregion

            var task = new Task(() =>
            {
                #region grava gerenciador

                var cargaVendaAtiva = new GerenciadorCarga()
                {
                    Arquivo = "VAI",
                    IdFuncionalidade = Funcionalidade.Enum.CargaVendaAtivaAdmin,
                    IdColaborador = Colaborador.Id,
                    Funcional = "",
                    NomeFuncional = "",
                    IdSegmento = 200
                };
                gerenciadorCargas.Add(cargaVendaAtiva);
                cargaVendaAtiva.Inicio = DateTime.Now;
                cargaVendaAtiva.TotalLinhas = gerenciadorCargas.Sum(x => x.TotalLinhas);
                _gerenciadorCargaServices.GravarGerenciador(cargaVendaAtiva);

                GerenciadorCargaAtual = cargaVendaAtiva;

                foreach (var arquivo in gerenciadorCargas)
                    arquivo.Id = cargaVendaAtiva.Id;

                #endregion

                #region Verifica dados

                //VerificaUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _vendaAtiva.VerificaLinhaArquivo);

                #endregion

                #region Insere dados

                string _idControle = "PA-" + DateTime.Now.ToString("yyyyMMddHHmmss");

                _vendaAtiva.InsertControleCarga(_idControle);

                foreach (var g in gerenciadorCargas)
                {
                    g.IdControleCarga = _idControle;
                }

                UpsertUpload(gerenciadorCargas, (Enums.Segmentos)model.Segmento, _vendaAtiva.Insert, _vendaAtiva.RemoveExistentesPorItem);

                _vendaAtiva.AtualizaControleCarga(_idControle);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }
        #endregion

        #region SaibaMais
        [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaVendaAtivaSaibaMaisAdmin })]
        public async Task<IActionResult> SaibaMais()
        {
            SetViewBag();

            var model = new VendaAtivaViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaVendaAtivaSaibaMaisAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [HttpPost]
        [Authentication]
        public IActionResult SaibaMais(VendaAtivaViewModel model)
        {
            SetViewBag();

            model.CargaTipo = Funcionalidade.Enum.CargaVendaAtivaSaibaMaisAdmin;
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = RetornaCargasRecentesAsync().Result;

            var gerenciadorCargas = new List<GerenciadorCarga>();

            if (!Request.Form.Files.Any())
                model.Erros.Add("Por favor, selecione o arquivo de carga.");

            #region Valida arquivos

            model.Erros.Clear();

            if (!Request.Form.Files.Any())
            {
                model.Erros.Add("Por favor, selecione o arquivo de carga.");
            }

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                {
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");
                }

                var cargaVendaAtiva = new GerenciadorCarga()
                {
                    Arquivo = "VAI",
                    IdFuncionalidade = Funcionalidade.Enum.CargaVendaAtivaSaibaMaisAdmin,
                    IdColaborador = Colaborador.Id,
                    GravaCarga = false,
                    Funcional = "",
                    NomeFuncional = "",
                    IdSegmento = 200,
                    ArquivoApelido = arquivo.FileName.Split('.')[0]
                };

                arquivo.CopyTo(cargaVendaAtiva.FileStream);
                gerenciadorCargas.Add(cargaVendaAtiva);
            }

            if (model.Erros.Any())
            {
                return View(model);
            }

            #endregion

            if (model.Erros.Any())
                return View(model);


            var task = new Task(() =>
            {
                #region grava gerenciador

                var cargaVendaAtiva = new GerenciadorCarga()
                {
                    Arquivo = "VAI",
                    IdFuncionalidade = Funcionalidade.Enum.CargaVendaAtivaAdmin,
                    IdColaborador = Colaborador.Id,
                    Funcional = "",
                    NomeFuncional = "",
                    IdSegmento = 200
                };

                //var passoVerificacao = new GerenciadorCargaPasso()
                //{
                //    IdGerenciadorCarga = cargaVendaAtiva.Id,
                //    Passo = CargasPassos.Validacao,
                //    Nome = CargasPassos.Validacao.ToString(),
                //    Atualizado = DateTime.Now
                //};
                //
                //cargaVendaAtiva.Passos.Add(passoVerificacao);
                cargaVendaAtiva.Inicio = DateTime.Now;
                _gerenciadorCargaServices.GravarGerenciador(cargaVendaAtiva);

                GerenciadorCargaAtual = cargaVendaAtiva;

                foreach (var arquivo in gerenciadorCargas)
                    arquivo.Id = cargaVendaAtiva.Id;

                #endregion

                #region Verifica dados

                VerificaUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _vendaAtiva.VerificaLinhaArquivo);

                #endregion

                #region grava gerenciador

                //var passoInsercao = new GerenciadorCargaPasso()
                //{
                //    IdGerenciadorCarga = cargaVendaAtiva.Id,
                //    Passo = CargasPassos.Insercao,
                //    Nome = CargasPassos.Insercao.ToString(),
                //    Atualizado = DateTime.Now
                //};
                //
                //cargaVendaAtiva.Passos.Add(passoInsercao);
                cargaVendaAtiva.TotalLinhas = gerenciadorCargas.Sum(x => x.TotalLinhas);
                //passoVerificacao.LinhasProcessadas = cargaVendaAtiva.TotalLinhas;
                _gerenciadorCargaServices.GravarGerenciador(cargaVendaAtiva);

                #endregion

                #region Insere dados

                UpsertUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _vendaAtiva.Insert, _vendaAtiva.RemoveExistentesPorItem);

                #endregion

                #region grava gerenciador
                //if (gerenciadorCargas.Where(x => x.ContemErro).Any())
                //{
                //    cargaVendaAtiva.Passos.First(x => x.Passo == CargasPassos.Insercao).Erro = true;
                //}
                cargaVendaAtiva.Fim = DateTime.Now;
                //cargaVendaAtiva.PopupConclusao = true;
                //passoInsercao.LinhasProcessadas = gerenciadorCargas
                //    .Where(p => p.Passos.Any(o => o.Passo == CargasPassos.Insercao))
                //    .Sum(x => x.Passos.First(y => y.Passo == CargasPassos.Insercao).LinhasProcessadas);
                _gerenciadorCargaServices.GravarGerenciador(cargaVendaAtiva);

                #endregion
            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect("~/Carregar?open=1");
        }
        #endregion

        [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaVendaAtivaAdmin })]
        public async Task<IActionResult> RelatorioStage(int pageindex = 1)
        {
            var model = new VendaAtivaViewModel();

            var dadosStage = _vendaAtiva.RetornarRelatorioStage().Result;
            ViewBag.DadosStage = PagingList.Create(dadosStage.AsQueryable().OrderByDescending(x => x.Data), 40, pageindex);

            return View(model);
        }

        [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaVendaAtivaAdmin })]
        public async Task<IActionResult> RelatorioStagePos(int pageindex = 1)
        {
            var model = new VendaAtivaViewModel();

            var dadosStage = _vendaAtiva.RetornarRelatorioStagePos().Result;
            ViewBag.DadosStage = PagingList.Create(dadosStage.AsQueryable().OrderByDescending(x => x.DataExecucao), 40, pageindex);

            return View(model);
        }



    }
}