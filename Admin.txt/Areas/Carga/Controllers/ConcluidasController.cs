﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargasAdmin })]
    public class ConcluidasController : BaseCargaController
    {
        private readonly IConcluidasServices _concluidasServices;

        public ConcluidasController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            IConcluidasServices concluidasServices,
            ISecurityServices securityServices)
            : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _concluidasServices = concluidasServices;
        }

        [Authentication]
        public async Task<IActionResult> Index(string sortOrder, string filtering, string id)
        {
            SetViewBag();
            await CarregarFiltroCargasFinalizadasAsync();

            var model = new ConcluidasViewModel
            {
                Cargas = await RetornaCargasRecentesAsync()
            };

            if (!string.IsNullOrWhiteSpace(filtering))
            {
                if (!string.IsNullOrWhiteSpace(sortOrder))
                {
                    model = _concluidasServices.CarregarOrdenadasFiltradas(model, sortOrder, filtering, id);
                }
                else
                {
                    model = _concluidasServices.FilteringCargasFinalizadas(model, filtering, id);
                }
            }
            else
            {
                model = _concluidasServices.SortCargasFinalizadas(model, sortOrder);
            }

            model.AbaAtiva = AdminAbaAtiva.Concluidas;

            return View(model);
        }
    }
}
