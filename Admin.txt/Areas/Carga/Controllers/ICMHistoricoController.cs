﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;

using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Carga.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.CargaICMHistoricoAdmin })]
    public class ICMHistoricoController : BaseCargaController
    {
        private readonly IICMHistoricoServices _iCMHistorico;
        private readonly string[] _extensoesAceitas = new string[] { ".csv" };
        private readonly int _batchSize;

        public ICMHistoricoController(ICookies cookies,
            IConfiguration configuration,
            IGerenciadorCargaServices gerenciadorCargaServices,
            IICMHistoricoServices iCMHistorico,
            ISecurityServices securityServices) : base(cookies, configuration, gerenciadorCargaServices, securityServices)
        {
            _batchSize = configuration.GetValue("AppSettings:Cargas:SQLBatchSize", 30);

            _iCMHistorico = iCMHistorico;
        }

        [Authentication]
        public async Task<IActionResult> Index()
        {
            SetViewBag();

            var model = new ICMHistoricoViewModel();
            model.CargaTipo = Funcionalidade.Enum.CargaICMHistoricoAdmin;
            model.CargaEmAndamento = CargasEmAndamento(model.CargaTipo.GetHashCode());
            model.AbaAtiva = AdminAbaAtiva.Carregar;
            model.Cargas = await RetornaCargasRecentesAsync();

            return View(model);
        }

        [HttpPost]
        [Authentication]
        public IActionResult Index(ICMHistoricoViewModel model)
        {
            SetViewBag();

            var gerenciadorCargas = new List<GerenciadorCarga>();

            if (!Request.Form.Files.Any())
                model.Erros.Add("Por favor, selecione o arquivo de carga.");

            foreach (var arquivo in Request.Form.Files)
            {
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (!_extensoesAceitas.Contains(extensaoArquivo))
                    model.Erros.Add($"O arquivo {arquivo.FileName} não é suportado.");


                var carga = new GerenciadorCarga()
                {
                    Arquivo = arquivo.FileName,
                    IdFuncionalidade = Funcionalidade.Enum.CargaICMHistoricoAdmin,
                    Ano = model.Ano,
                    Mes = model.Mes,
                    Funcional = Colaborador?.Funcional,
                    NomeFuncional = Colaborador?.Nome,
                    IdColaborador = Colaborador.Id,
                    IdSegmento = 200
                };

                arquivo.CopyTo(carga.FileStream);
                gerenciadorCargas.Add(carga);
            }

            if (model.Erros.Any())
                return View(model);

            var task = new Task(() =>
            {
                #region Verifica dados

                VerificaUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _iCMHistorico.VerificaLinhaArquivo);

                #endregion

                #region Insere dados

                UpsertUpload(gerenciadorCargas, Enums.Segmentos.Agencias, _iCMHistorico.Insert, null);

                #endregion

            });

            task.ContinueWith(GerenciadorCargaExceptionHandler, TaskContinuationOptions.OnlyOnFaulted);
            task.Start();

            return Redirect($"{Url.Action("Index", "Carregar", new { area = "Carga" })}?open=1");
        }

    }
}