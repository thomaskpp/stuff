﻿namespace Itau.SZ7.GPS.Admin.Areas.Notificacao.Models.Enum
{
    public enum AbaAtiva
    {
        Lista,
        Edicao
    }
}
