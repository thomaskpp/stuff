﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Areas.Notificacao.Models
{
    public class ListaTemplate : BaseModel
    {
        public IEnumerable<Template> Templates { get; set; }
        public string FiltroAtivo { get; set; }
    }
}
