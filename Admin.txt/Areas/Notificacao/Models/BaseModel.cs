﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Models;

namespace Itau.SZ7.GPS.Admin.Areas.Notificacao.Models
{
    public class BaseModel : BaseViewModel
    {
        public new Enum.AbaAtiva AbaAtiva { get; set; }
        public string TituloAbaTemplate { get; set; }
    }
}
