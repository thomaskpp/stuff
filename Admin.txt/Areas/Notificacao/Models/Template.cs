﻿using System;

namespace Itau.SZ7.GPS.Admin.Areas.Notificacao.Models
{
    public class Template : BaseModel
    {
        public int? Id { get; set; }
        public string Nome { get; set; }
        public string Html { get; set; }
        public int? QuantidadeCampoVariavel { get; set; }

        internal object Where(Func<object, object> p)
        {
            throw new NotImplementedException();
        }
    }
}
