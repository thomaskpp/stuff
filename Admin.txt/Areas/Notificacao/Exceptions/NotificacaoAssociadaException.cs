﻿using System;

namespace Itau.SZ7.GPS.Admin.Areas.Notificacao.Exceptions
{
    public class NotificacaoAssociadaException : Exception
    {
        public NotificacaoAssociadaException() : base("Este template está associado com uma ou mais notificações e não poderá ser excluído.") { }
    }
}
