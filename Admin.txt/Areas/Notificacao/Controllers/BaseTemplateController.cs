﻿using Itau.SZ7.GPS.Admin.Controllers;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Itau.SZ7.GPS.Admin.Areas.Notificacao.Controllers
{
    [Area("Notificacao")]
    public class BaseTemplateController : BaseController
    {
        public BaseTemplateController(ICookies cookies,
            IConfiguration configuration,
            ISecurityServices securityServices)
            : base(cookies, configuration, securityServices)
        {

        }
    }
}