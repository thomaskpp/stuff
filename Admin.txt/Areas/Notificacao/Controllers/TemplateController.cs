﻿using Itau.SZ7.GPS.Admin.Areas.Carga.Models;
using Itau.SZ7.GPS.Admin.Areas.Notificacao.Exceptions;
using Itau.SZ7.GPS.Admin.Attributes;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Notificacao.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Areas.Notificacao.Controllers
{
    [TypeFilter(typeof(PermissaoAttribute), Arguments = new object[] { Funcionalidade.Enum.TemplateNotificaçãoAdmin })]
    public class TemplateController : BaseTemplateController
    {
        private readonly ITemplateServices _templateServices;

        public TemplateController(
            ITemplateServices templateServices,
            ICookies cookies,
            IConfiguration configuration,
            ISecurityServices securityServices) : base(cookies, configuration, securityServices)
        {
            _templateServices = templateServices;
        }

        public async Task<IActionResult> Index(string sortOrder, string filtering, string id)
        {
            SetViewBag();

            var model = await _templateServices.ListarTemplatesAsync(sortOrder, filtering, id);
            model.AbaAtiva = Models.Enum.AbaAtiva.Lista;

            model.TituloAbaTemplate = "Novo";

            model.PopupConfirmacao = new PopupConfirmacaoModel
            {
                Mensagem = "Confirma a exclusão do template? ",
                TituloBotaoCancelar = "Não",
                TituloBotaoOk = "Sim"
            };

            return View(model);
        }

        public async Task<IActionResult> Editar(int? id)
        {
            SetViewBag();

            var model = new Models.Template();

            if (id.HasValue)
            {
                model = await _templateServices.CarregaTemplateAsync(id.Value);

                model.TituloAbaTemplate = "Editar";

                model.PopupConfirmacao = new PopupConfirmacaoModel
                {
                    Mensagem = "Confirma a edição do template? ",
                    TituloBotaoCancelar = "Não",
                    TituloBotaoOk = "Sim"
                };
            }
            else
            {
                model.TituloAbaTemplate = "Novo";

                model.PopupConfirmacao = new PopupConfirmacaoModel
                {
                    Mensagem = "Confirma a inclusão do novo template? ",
                    TituloBotaoCancelar = "Não",
                    TituloBotaoOk = "Sim"
                };
            }

            model.AbaAtiva = Models.Enum.AbaAtiva.Edicao;

            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> Editar(Models.Template model)
        {
            SetViewBag();

            model.Erros.Clear();

            #region novo arquivo html

            if (Request.Form.Files.Any())
            {
                var arquivo = Request.Form.Files[0];
                var extensaoArquivo = Path.GetExtension(arquivo.FileName);

                if (extensaoArquivo.ToLower().Equals(".html"))
                {
                    using (StreamReader reader = new StreamReader(arquivo.OpenReadStream()))
                    {
                        var html = await reader.ReadToEndAsync();
                        var body = Helpers.Misc.ExtraiHtmlBody(html).Trim();

                        if (string.IsNullOrWhiteSpace(body))
                            model.Erros.Add("Não foi encontrado um elemento Body ou está vazio");
                        else
                        {
                            ModelState.Remove("Html");
                            model.Html = body;
                            return View(model);
                        }
                    }
                }
                else
                    model.Erros.Add("Por favor selecione um arquivo no formato .html");

                if (model.Erros.Any())
                    return View(model);
            }

            #endregion

            #region validação

            if (string.IsNullOrWhiteSpace(model.Nome))
                model.Erros.Add("Favor informar um nome para o template");

            //if (!model.QuantidadeCampoVariavel.HasValue ||
            //    model.QuantidadeCampoVariavel.Value < 0)
            //    model.Erros.Add("Favor informar a quantidade de variáveis");

            if (string.IsNullOrWhiteSpace(model.Html))
                model.Erros.Add("Favor informar o HTML do template");

            if (model.Erros.Any())
                return View(model);

            #endregion

            if (model.Erros.Count() == 0)
            {
                var IdNotificacao = await _templateServices.SalvarTemplateAsync(model);
                TempData["MensagemRetornoTemplate"] = "O template foi salvo com sucesso! ";
                model.Id = IdNotificacao;
                return RedirectToAction("Editar", new { id = model.Id = IdNotificacao});
            }
            else
            {
                model.Erros.Add("Não foi possível salvar o template. Por favor tente novamente.");
            }

            return View(model);
        }

        [HttpDelete]
        public async System.Threading.Tasks.Task<IActionResult> Excluir(int id)
        {
            try
            {
                bool excluir = await _templateServices.ExcluirAsync(id);

                var json = new { status = excluir ? "sucesso" : "erro" };

                if (excluir)
                {
                    return Json(json);
                }
                else
                {
                    return NoContent();
                }
            }
            catch (NotificacaoAssociadaException ex)
            {
                return StatusCode(500, new { status = "erro", mensagem = ex.Message });
            }
        }
    }
}

