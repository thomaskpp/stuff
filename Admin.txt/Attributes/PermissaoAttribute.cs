﻿using Itau.SZ7.GPS.Admin.Domain.Carga.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Attributes
{
    public class PermissaoAttribute : Attribute, IAsyncActionFilter
    {
        private readonly Funcionalidade.Enum _funcionalidade;
        private readonly ISecurityServices _securityServices;
        private readonly IGerenciadorCargaRepository _gerCargaRepo;


        public PermissaoAttribute(Funcionalidade.Enum funcionalidade, ISecurityServices securityServices, IGerenciadorCargaRepository ger)
        {
            _funcionalidade = funcionalidade;
            _securityServices = securityServices;
            _gerCargaRepo = ger;
        }

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var autorizado = await _securityServices.VerificarPermissao(_funcionalidade);

            if (autorizado)
            {
                if (context.HttpContext.Request.Method == "POST" && !_gerCargaRepo.PermiteExecucao((int)_funcionalidade))
                {
                    context.Result = new RedirectResult(context.HttpContext.Request.Path + "?ExisteSimultanea=true");
                    return;
                }

                await next();
            }
            else
            {
                context.Result = new RedirectToActionResult("FalhaAcesso", "Error", new { area = "" });
            }
        }
    }
}
