﻿
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;

using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class InnerLoopStatusRepository : IInnerLoopStatusRepository
    {
        private readonly ISqlDataContext _sqlDataContext;

        public InnerLoopStatusRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
        }

        public async Task<IEnumerable<InnerLoopStatus>> GetStatus()
        {
            string query = "SELECT * FROM InnerLoopStatus (NOLOCK)";

            var status = await _sqlDataContext.SelectQueryToListAsync<InnerLoopStatus>(query);

            return status != null ? status : new List<InnerLoopStatus>();
        }
    }
}
