﻿


using Itau.SZ7.GPS.Admin.Domain.Carga.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Enums;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class GerenciadorCargaErroRepository : IGerenciadorCargaErroRepository
    {
        private readonly string _connectionString;

        public GerenciadorCargaErroRepository(IAppConfiguration appConfiguration)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public async Task<List<GerenciadorCargaErro>> GetGerenciadorCargaErros(int idCarga)
        {
            var result = new List<GerenciadorCargaErro>();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = $@"SELECT 
                                        Id,
                                        IdGerenciadorCarga,
                                        Passo,
                                        Linha,
                                        Erro
                                    FROM GerenciadorCargaErro (NOLOCK) WHERE IdGerenciadorCarga = {idCarga}";

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var registro = new GerenciadorCargaErro()
                            {
                                Id = reader.SafeGetInt32(0),
                                IdGerenciadorCarga = reader.SafeGetInt32(1),
                                Passo = (CargasPassos)reader.SafeGetByte(2),
                                Linha = reader.SafeGetInt32(3),
                                Erro = reader.SafeGetString(4)
                            };

                            result.Add(registro);
                        }
                    }
                }

                conn.Close();
            }

            return result;
        }

        public int Insert(GerenciadorCargaErro model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText =
$@"INSERT INTO GerenciadorCargaErro
VALUES(
{model.IdGerenciadorCarga},
{(int)model.Passo},
{model.Linha},
'{model.Erro.Replace("'", "\"")}'
)";

                var result = cmd.ExecuteNonQuery();

                conn.Close();

                return result;
            }
        }
    }
}
