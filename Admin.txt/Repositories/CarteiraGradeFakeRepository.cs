﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Configuration.Interface;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class CarteiraGradeFakeRepository : ICarteiraGradeFakeRepository
    {
        private readonly string _connectionString;
        private readonly ISqlDataContext _sqlDataContext;

        public CarteiraGradeFakeRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _sqlDataContext = sqlDataContext;
        }

        public async Task BulkInsert(List<CarteiraGradeFake> models)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                        sqlList.Add($"INSERT INTO CarteiraGradeFake (Ano, Mes, Carteira, Grade) VALUES ({item.Ano},{item.Mes},'{item.Carteira}',{item.Grade})");

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();

                    cmd.CommandText = string.Join("\n", sqlList.ToArray());

                    await cmd.ExecuteNonQueryAsync();

                    conn.Close();
                }
            }
        }

        public async Task RemoveItensMes(short ano, short mes)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();

                    cmd.CommandText = $"DELETE FROM CarteiraGradeFake WHERE Ano = {ano} AND Mes = {mes}";

                    await cmd.ExecuteNonQueryAsync();

                    conn.Close();
                }
            }
        }
        
        public IEnumerable<CarteiraGradeFake> GetCarteiraGradeFakes(short ano, short mes)
        {
            var resultado = _sqlDataContext.SelectQueryToList<CarteiraGradeFake>
                ($"SELECT * FROM CarteiraGradeFake (NOLOCK) WHERE Ano = {ano} AND Mes = {mes}");

            return resultado != null ? resultado : new List<CarteiraGradeFake>();
        }
    }
}
