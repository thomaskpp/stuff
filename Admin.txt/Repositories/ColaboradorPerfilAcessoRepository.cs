﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using Itau.SZ7.GPS.Admin.Domain.ControleAcesso.Interfaces.Repositories;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class ColaboradorPerfilAcessoRepository : IColaboradorPerfilAcessoRepository
    {
        public ColaboradorPerfilAcessoRepository(IAppConfiguration appConfiguration)
        {
        }

        public ColaboradorPerfilAcesso GetPerfilAcesso(string funcional)
        {
            throw new System.NotImplementedException();
        }
    }
}
