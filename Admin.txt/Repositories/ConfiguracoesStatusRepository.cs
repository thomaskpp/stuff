﻿using Itau.SZ7.GPS.Admin.Domain.Carga.Interfaces.Repositories;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class ConfiguracoesStatusRepository : IConfiguracoesStatusRepository
    {
    }
}
