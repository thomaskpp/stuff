﻿
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Helpers;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class ContratoMetasPersonnaliteRepository : IContratoMetasPersonnaliteRepository
    {
        private readonly ISqlDataContext _sqlDataContext;
        private readonly string _connectionString;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appConfiguration"></param>
        public ContratoMetasPersonnaliteRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }


        public async Task BulkInsertContratoMetas(IEnumerable<ContratoMetasPersonnaliteDTO> lstContratoMetas, int batchSize = 30)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in lstContratoMetas)
                        sqlList.Add(CriaInsertScriptContratoMetas(item));

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > batchSize ? batchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        await cmd.ExecuteNonQueryAsync();
                    }

                    conn.Close();
                }
            }
        }

        public void RemoveTodosItens()
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    cmd.CommandText = @"DELETE FROM ContratoMetasPersonnalite";
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }

        private string CriaInsertScriptContratoMetas(ContratoMetasPersonnaliteDTO contratMetas)
        {
            return $@"
                    INSERT INTO ContratoMetasPersonnalite 
                                (
                                    DataReferencia, 
                                    IdGradeItem,
                                    IdAgencia,
                                    Carteira, 
                                    ValorN1, 
                                    ValorN2, 
                                    ValorN3, 
                                    ValorN4, 
                                    ValorN5, 
                                    ValorProducao, 
                                    ValorPosicao
                                )
                         VALUES (
                                    '{contratMetas.DataReferencia}',
                                    {contratMetas.IdGradeItem},
                                    {contratMetas.IdAgencia},
                                    '{contratMetas.Carteira}',
                                    '{contratMetas.ValorN1}',
                                    '{contratMetas.ValorN2}',
                                    '{contratMetas.ValorN3}',
                                    '{contratMetas.ValorN4}',
                                    '{contratMetas.ValorN5}',
                                    '{contratMetas.ValorProducao}',
                                    {contratMetas.ValorPosicao.ToString().Replace(',','.')}
                                )
                    ";
        }

    }
}







