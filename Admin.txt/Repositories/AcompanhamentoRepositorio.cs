﻿using Itau.SZ7.GPS.Admin.Areas.Agir.Models;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class AcompanhamentoRepositorio : IAcompanhamentoRepositorio
    {
        private readonly ISqlDataContext _sqlDataContext;

        public AcompanhamentoRepositorio(ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
        }

        public async Task<IEnumerable<AcompanhamentoRelatorio>> ObterRelatorio(DateTime dataInicio, DateTime dataFim, int idSegmento)
        {
            var parametros = new Dictionary<string, object>()
            {
                {"dataInicio", dataInicio },
                {"dataFim", dataFim },
                {"idSegmento", idSegmento }
            };

            return await _sqlDataContext.SelectQueryToListAsync<AcompanhamentoRelatorio>("Acompanhamento_Obter_Relatorio", System.Data.CommandType.StoredProcedure, parametros);
        }
    }
}
