﻿
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Domain.PermissaoAcesso.Interfaces.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    /// <summary>
    /// 
    /// </summary>
    public class DelegacaoAcessoRepository : IDelegacaoAcessoRepository
    {
        private readonly ISqlDataContext _sqlDataContext;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appConfiguration"></param>
        public DelegacaoAcessoRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
        }

        //public void AtualizaDelegacoesExpiradas()
        //{
        //    var sql = $@"UPDATE DelegacaoAcesso 
        //                SET DataAtualizacao = @DataAtualizacao, CodigoStatusDelegacao = @CodigoStatusDelegacao
        //                WHERE DataFimVigencia < @DataFimVigencia AND CodigoStatusDelegacao = @CodStatus";

        //    var parametros = new Dictionary<string, object>()
        //    {
        //        { "DataAtualizacao", DateTime.Now },
        //        { "CodigoStatusDelegacao", Domain.PermissaoAcesso.StatusDelegacao.Expirado },
        //        { "DataFimVigencia", DateTime.Now },
        //        { "CodStatus", Domain.PermissaoAcesso.StatusDelegacao.AguardandoAprovacaoGRA }
        //    };

        //    _sqlDataContext.ExecuteNonQuery(sql, parametros);
        //}
    }
}
