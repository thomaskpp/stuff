﻿

using Itau.SZ7.GPS.Admin.Domain.Carga.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Configuration.Interface;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class GerenciadorCargaConfiguracaoRepository : IGerenciadorCargaConfiguracaoRepository
    {
        private readonly ISqlDataContext _sqlDataContext;
        private readonly string _connectionString;

        public GerenciadorCargaConfiguracaoRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _sqlDataContext = sqlDataContext;
        }

        public async Task<IEnumerable<GerenciadorCargaConfiguracao>> GetGerenciadorCargaConfiguracaos()
        {
            var query = @"SELECT 
	                            IdFuncionalidade,
	                            F.Descricao AS NOME,
	                            ISNULL(C.Funcional,''),
	                            ISNULL(C.Nome,'') AS NomeResponsavel,
	                            IdTipoPeriodo,
	                            ValorPeriodo,
	                            Ocultar,
	                            F.Url,
	                            TravaSimultanea
                            FROM GerenciadorCargaConfiguracao G WITH (NOLOCK)
                                INNER JOIN Funcionalidade F WITH (NOLOCK) ON G.IdFuncionalidade = F.id
                                LEFT JOIN Colaborador C (NOLOCK) ON G.idColaborador = C.Id
                            ORDER BY Nome";

            return await _sqlDataContext.SelectQueryToListAsync<GerenciadorCargaConfiguracao>(query);
        }

        public async Task<int> AtualizaOcultarAsync(int idFuncionalidade, bool ocultar)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                await conn.OpenAsync();

                cmd.CommandText =
                                $@"UPDATE GerenciadorCargaConfiguracao SET

                                Ocultar = {(ocultar ? 1 : 0)}

                                WHERE IdFuncionalidade = {idFuncionalidade}";

                var result = await cmd.ExecuteNonQueryAsync();

                conn.Close();

                return result;
            }
        }
    }
}
