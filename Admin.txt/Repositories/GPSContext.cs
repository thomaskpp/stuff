﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Entities;
using Microsoft.EntityFrameworkCore;

namespace Itau.SZ7.GPS.Admin.Data.Context
{
    public class GPSContext : DbContext
    {
        private readonly string _connectionString;

        public GPSContext(string connectionString) : base()
        {
            _connectionString = connectionString;
        }

        public GPSContext(DbContextOptions<GPSContext> options) : base(options)
        {

        }

        //public virtual DbSet<Agencia> Agencia { get; set; }
        //public virtual DbSet<Polo> Polo { get; set; }
        //public virtual DbSet<PoloPeso> PoloPeso { get; set; }
        //public virtual DbSet<Feriado> Feriado { get; set; }

        //public virtual DbSet<Segmento> Segmento { get; set; }

        //public virtual DbSet<Colaborador> Colaborador { get; set; }
        //public virtual DbSet<ColaboradorEngajamento> ColaboradorEngajamento { get; set; }
        //public virtual DbSet<ColaboradorCoachClick> ColaboradorCoachClick { get; set; }
        //public virtual DbSet<ColaboradorFerias> ColaboradorFerias { get; set; }

        //public virtual DbSet<PlanejamentoCheckin> PlanejamentoCheckin { get; set; }
        //public virtual DbSet<PlanejamentoCheckout> PlanejamentoCheckout { get; set; }
        //public virtual DbSet<PlanejamentoProducaoRealizada> PlanejamentoProducaoRealizada { get; set; }
        //public virtual DbSet<PlanejamentoProducaoRealizadaAnalitico> PlanejamentoProducaoRealizadaAnalitico { get; set; }
        //public virtual DbSet<PlanejamentoGradeCarteira> PlanejamentoGradeCarteira { get; set; }
        //public virtual DbSet<PlanejamentoItemGradeCarteira> PlanejamentoItemGradeCarteira { get; set; }
        //public virtual DbSet<PlanejamentoItemGrade> PlanejamentoItemGrade { get; set; }
        //public virtual DbSet<ComentarioPlanejamentoCarteira> ComentarioPlanejamentoCarteira { get; set; }
        //public virtual DbSet<ProdutoGradeItem> ProdutoGradeItem { get; set; }
        //public virtual DbSet<RegraFaixaParametrizacao> RegraFaixaParametrizacao { get; set; }        

        //public virtual DbSet<CompromissoColaborador> CompromissoColaborador { get; set; }
        //public virtual DbSet<CompromissoNotificacao> CompromissoNotificacao { get; set; }
        //public virtual DbSet<CompromissoParticipante> CompromissoPartipante { get; set; }

        //public virtual DbSet<NPS> NPS { get; set; }
        //public virtual DbSet<Reclamacao> Reclamacao { get; set; }
        //public virtual DbSet<Alavanca> Alavanca { get; set; }

        //public virtual DbSet<Alerta> Alerta { get; set; }

        //public virtual DbSet<Destinatario> Destinatario { get; set; }
        //public virtual DbSet<Notificacoes> Notificacoes { get; set; }
        //public virtual DbSet<NotificacoesTemplate> NotificacoesTemplate { get; set; }
        //public virtual DbSet<Remetente> Remetente { get; set; }
        ////public virtual DbSet<Trava> Trava { get; set; }


        //public virtual DbSet<LogAcesso> LogAcesso { get; set; }

        //public virtual DbSet<VendaAtivaClientes> VendaAtivaClientes { get; set; }
        //public virtual DbSet<VendaAtivaClientesEmail> VendaAtivaClientesEmail { get; set; }
        //public virtual DbSet<VendaAtivaClientesTelefone> VendaAtivaClientesTelefone { get; set; }
        //public virtual DbSet<VendaAtivaOfertas> VendaAtivaOfertas { get; set; }
        //public virtual DbSet<VendaAtivaOfertasReagendadas> VendaAtivaOfertasReagendadas { get; set; }
        //public virtual DbSet<VendaAtivaResultadoOfertas> VendaAtivaResultadoOfertas { get; set; }
        //public virtual DbSet<VendaAtivaCarteirasValidas> VendaAtivaCarteirasValidas { get; set; }
        //public virtual DbSet<VendaAtivaComboAceito> VendaAtivaComboAceito { get; set; }
        //public virtual DbSet<VendaAtivaComboMotivoRecusa> VendaAtivaComboMotivoRecusa { get; set; }
        //public virtual DbSet<VendaAtivaComboNaoLocalizado> VendaAtivaComboNaoLocalizado { get; set; }

        //public virtual DbSet<PerfilAcesso> PerfilAcesso { get; set; }
        //public virtual DbSet<ColaboradorPerfilAcesso> ColaboradorPerfilAcesso { get; set; }

        //public virtual DbSet<GerenciamentoCoachClick> GerenciamentoCoachClick { get; set; }

        //public virtual DbSet<MapaTelas> MapaTelas { get; set; }
        //public virtual DbSet<MapaCargos> MapaCargos { get; set; }




        //public virtual DbSet<GerenciadorCarga> GerenciadorCarga { get; set; }
        //public virtual DbSet<GerenciadorCargaErro> GerenciadorCargaErro { get; set; }


        //public virtual DbSet<DelegacaoAcesso> DelegacaoAcesso { get; set; }
        //public virtual DbSet<AgenciaPeso> AgenciaPeso { get; set; }

        //public virtual DbSet<InnerLoopLigacao> InnerLoopLigacao { get; set; }

        //public virtual DbSet<InnerLoopHistorico> InnerLoopHistorico { get; set; }
        //public virtual DbSet<InnerLoopStatus> InnerLoopStatus { get; set; }
        //public virtual DbSet<InnerLoopPergunta> InnerLoopPergunta { get; set; }
        //public virtual DbSet<InnerLoopResposta> InnerLoopResposta { get; set; }
        //public virtual DbSet<InnerLoopMeta> InnerLoopMeta { get; set; }
        //public virtual DbSet<InnerLoopLiberacaoFuncionalidade> InnerLoopLiberacaoFuncionalidade { get; set; }

        //public virtual DbSet<Funcionalidade> Funcionalidade { get; set; }
        //public virtual DbSet<Plataforma> Plataforma { get; set; }

        //public virtual DbSet<Logs> Logs { get; set; }

        //public virtual DbSet<NPSComentario> NPSComentario { get; set; }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    if (!optionsBuilder.IsConfigured)
        //    {
        //        optionsBuilder.UseSqlServer(_connectionString);
        //    }
        //}

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.ApplyConfiguration(new AgenciaConfiguration());
        //    modelBuilder.ApplyConfiguration(new PoloConfiguration());
        //    modelBuilder.ApplyConfiguration(new PoloPesoConfiguration());
        //    modelBuilder.ApplyConfiguration(new FeriadoConfiguration());
        //    modelBuilder.ApplyConfiguration(new SegmentoConfiguration());


        //    modelBuilder.ApplyConfiguration(new ColaboradorEngajamentoConfiguration());
        //    modelBuilder.ApplyConfiguration(new ColaboradorConfiguration());
        //    modelBuilder.ApplyConfiguration(new ColaboradorCoachClickConfiguration());
        //    modelBuilder.ApplyConfiguration(new ColaboradorFeriasConfiguration());

        //    modelBuilder.ApplyConfiguration(new PlanejamentoGradeCarteiraConfiguration());
        //    modelBuilder.ApplyConfiguration(new PlanejamentoItemGradeCarteiraConfiguration());
        //    modelBuilder.ApplyConfiguration(new PlanejamentoCheckinConfiguration());
        //    modelBuilder.ApplyConfiguration(new ComentarioPlanejamentoCarteiraConfiguration());
        //    modelBuilder.ApplyConfiguration(new ProdutoGradeItemConfiguration());
        //    modelBuilder.ApplyConfiguration(new PlanejamentoCheckoutConfiguration());

        //    modelBuilder.ApplyConfiguration(new CompromissoNotificacaoConfiguration());
        //    modelBuilder.ApplyConfiguration(new CompromissoColaboradorConfiguration());
        //    modelBuilder.ApplyConfiguration(new CompromissoParticipanteConfiguration());

        //    modelBuilder.ApplyConfiguration(new NPSConfiguration());
        //    modelBuilder.ApplyConfiguration(new ReclamacaoConfiguration());
        //    modelBuilder.ApplyConfiguration(new AlavancaConfiguration());

        //    modelBuilder.ApplyConfiguration(new AlertaConfiguration());

        //    modelBuilder.ApplyConfiguration(new DestinatarioConfiguration());
        //    modelBuilder.ApplyConfiguration(new NotificacoesConfiguration());
        //    modelBuilder.ApplyConfiguration(new NotificacoesTemplateConfiguration());
        //    modelBuilder.ApplyConfiguration(new RemetenteConfiguration());

        //    modelBuilder.ApplyConfiguration(new PlanejamentoProducaoRealizadaConfiguration());

        //    modelBuilder.ApplyConfiguration(new LogAcessoConfiguration());

        //    modelBuilder.ApplyConfiguration(new PerfilAcessoConfiguration());
        //    modelBuilder.ApplyConfiguration(new ColaboradorPerfilAcessoConfiguration());

        //    modelBuilder.ApplyConfiguration(new VendaAtivaClientesConfiguration());
        //    modelBuilder.ApplyConfiguration(new VendaAtivaClientesEmailConfiguration());
        //    modelBuilder.ApplyConfiguration(new VendaAtivaClientesTelefoneConfiguration());
        //    modelBuilder.ApplyConfiguration(new VendaAtivaOfertasConfiguration());
        //    modelBuilder.ApplyConfiguration(new VendaAtivaResultadoOfertasConfiguration());
        //    modelBuilder.ApplyConfiguration(new VendaAtivaComboAceitoConfiguration());
        //    modelBuilder.ApplyConfiguration(new VendaAtivaComboMotivoRecusaConfiguration());
        //    modelBuilder.ApplyConfiguration(new VendaAtivaComboNaoLocalizadoConfiguration());

        //    modelBuilder.ApplyConfiguration(new GerenciamentoCoachClickConfiguration());
        //    modelBuilder.ApplyConfiguration(new MapaTelasConfiguration());
        //    modelBuilder.ApplyConfiguration(new MapaCargosConfiguration());

        //    modelBuilder.ApplyConfiguration(new DelegacaoAcessoConfiguration());

        //    modelBuilder.ApplyConfiguration(new TravaConfiguration());

        //    modelBuilder.ApplyConfiguration(new PlanejamentoProducaoRealizadaAnaliticoConfiguration());
        //    modelBuilder.ApplyConfiguration(new PlanejamentoProducaoRealizadaAnaliticoDeleteConfiguration());

        //    modelBuilder.ApplyConfiguration(new GerenciadorCargaConfiguration());
        //    modelBuilder.ApplyConfiguration(new GerenciadorCargaErroConfiguration());
        //    modelBuilder.ApplyConfiguration(new GerenciadorCargaPassoConfiguration());

        //    modelBuilder.ApplyConfiguration(new PlanejamentoItemGradeConfiguration());
        //    modelBuilder.ApplyConfiguration(new RegraFaixaParametrizacaoConfiguration());
        //    modelBuilder.ApplyConfiguration(new VendaAtivaCarteirasValidasConfiguration());

        //    modelBuilder.ApplyConfiguration(new InnerLoopLigacaoConfiguration());
        //    modelBuilder.ApplyConfiguration(new InnerLoopHistoricoConfiguration());
        //    modelBuilder.ApplyConfiguration(new InnerLoopStatusConfiguration());
        //    modelBuilder.ApplyConfiguration(new InnerLoopPerguntaConfiguration());
        //    modelBuilder.ApplyConfiguration(new InnerLoopRespostaConfiguration());
        //    modelBuilder.ApplyConfiguration(new InnerLoopMetaConfiguration());
        //    modelBuilder.ApplyConfiguration(new InnerLoopLiberacaoFuncionalidadeConfiguration());

        //    modelBuilder.ApplyConfiguration(new LogAcessoConfiguration());
        //    modelBuilder.ApplyConfiguration(new AgenciaPesoConfiguration());

        //    modelBuilder.ApplyConfiguration(new NPSComentarioConfiguration());

        //}
    }
}
