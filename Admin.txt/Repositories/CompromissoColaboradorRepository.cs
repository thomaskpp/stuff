﻿
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Domain.Agenda.Interfaces.Repositories;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class CompromissoColaboradorRepository : ICompromissoColaboradorRepository
    {

        public CompromissoColaboradorRepository(IAppConfiguration config)
        { }
    }
}
