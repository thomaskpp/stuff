﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Domain.Carga.Interfaces.Repositories
{
    public interface IConfiguracoesStatusRepository
    {
    }
}
