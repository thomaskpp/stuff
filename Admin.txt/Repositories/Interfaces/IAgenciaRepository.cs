﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Entities.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories
{
    public interface IAgenciaRepository
    {
        IEnumerable<Agencia> GetAgencias();
        int BulkInsertUpdate(List<AgenciaMigracaoTemp> models, int? batchSize);
        int BulkInsertUpdate(List<AgenciaCoordenadoraRetroativo> models, int? batchSize);
        List<CalculoPesos> GetAgenciaxPesos(short? ano, short? mes);
        List<CalculoPesos> GetAgenciaxPesosPersonnalite(short? ano, short? mes);
        Task<int> BulkInsertUpdatePesos(List<ValorPesosSegmentos> models, int? batchSize);
        void InsertSQLPesos(ValorPesosSegmentos model);
        IEnumerable<AgenciaEstrutura> ObterAgenciaEstruturaPorPolos(int[] idPolos);

        AgenciaEstrutura ObterAgenciaEstrutura(int segmento, int agencia);

        IEnumerable<AgenciaEstrutura> ObterAgenciaEstrutura(IEnumerable<int> segmentos = null);
        int UpdateAgenciaCoordenadora(List<Agencia> models, int? batchSize);
        Agencia GetAgencia(string CodigoAgencia);
        int GetIdAgencia(string CodigoAgencia);
        IEnumerable<Admin.Entities.AgenciaMigracao> ObterAgencias();
        IEnumerable<AgenciaSimplificado> ObterIdECodigo();
        IEnumerable<Agencia> GetAgencias(IEnumerable<int> Ids);
    }   
}
