﻿using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories.Interfaces
{
    public interface IConfguracaoVPAPersonaliteRepository
    {
        Task<int> BulkInsertUpdate(List<ConfiguracaoVPAnaliticoPersonnalite> models, int? batchSize);

        Task<int> InsertUpdateSQL(ConfiguracaoVPAnaliticoPersonnalite model);
        void DeleteSQL(short mes, short ano);
    }
}
