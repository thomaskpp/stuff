﻿using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories.Interfaces
{
    public interface IColaboradorEngajamentoRepository
    {                
        List<DateTime> GetDiasUteisColaborador(string funcional, DateTime dataInicial, DateTime dataFinal, int codAgencia);
        void UpdateEngajamentoColaborador(string funcional, string origem);
        List<ColaboradorEngajamento> GetColaboradoresEngajamentoRegionalByMes(int idRegional, DateTime anoMes);
        List<ColaboradorEngajamento> GetColaboradoresEngajamentoRankingByMes(DateTime anoMes);
        List<ColaboradorEngajamento> GetAllEngajamentos(int mes, int ano);
        Task<bool> UpdateEngajamento(List<ColaboradorEngajamento> engajamentos);
        Task<bool> InsertEngajamento(List<ColaboradorEngajamento> engajamentos);
        void LimparTabelaEngajamento();

    }
}
