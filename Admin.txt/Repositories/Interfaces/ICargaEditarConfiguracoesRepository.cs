﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories.Interfaces
{
    public interface ICargaEditarConfiguracoesRepository
    {
        Task<int> BulkInsertUpdate(CargaEditarConfiguracoes models, int? batchSize);
        Task<GerenciadorCargaConfiguracao> GetGerenciadorCargaConfiguracaosAsync(int id);

        Task<IEnumerable<Funcionalidade>> ObterFuncionalidadesCarga();
    }
}
