﻿using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories
{
    public interface ICarteiraGradeFakeRepository
    {
        Task BulkInsert(List<CarteiraGradeFake> models);
        Task RemoveItensMes(short ano, short mes);
        IEnumerable<CarteiraGradeFake> GetCarteiraGradeFakes(short ano, short mes);
    }
}
