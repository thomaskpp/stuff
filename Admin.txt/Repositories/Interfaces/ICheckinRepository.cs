﻿using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories.Interfaces
{
    public interface ICheckinRepository
    {
        List<PlanejamentoCheckin> GetPlanejamentoCheckinsByAnoMes(short? ano, short? mes);

        List<PlanejamentoCheckin> GetPlanejamentoPersonnaliteCheckinsByAnoMes(short? ano, short? mes);

        int BulkInsertUpdatePlanejamentoCheckin(List<PlanejamentoCheckin> models, int? batchSize);

        Task<int> BulkInsertUpdatePlanejamentoCheckinPersonnalite(List<PlanejamentoCheckin> models, int? batchSize);


        List<PlanejamentoCheckin> GetAllCheckinsMesAno(int Mes, int Ano);

        bool RemoveExistentesPorItem(List<PlanejamentoCheckin> models, GerenciadorCarga gerenciador, int? batchSize);

        Task<IEnumerable<PlanejamentoCheckin>> GetAllCheckinsMesAnoAsync(int Mes, int Ano);
    }
}
