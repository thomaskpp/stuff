﻿using Itau.SZ7.GPS.Admin.Entities;

namespace Itau.SZ7.GPS.Admin.Repositories.Interfaces
{
    public interface IColaboradorPerfilAcessoRepository
    {
        ColaboradorPerfilAcesso GetPerfilAcesso(string funcional);
    }
}
