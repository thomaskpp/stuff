﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Domain.Base.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories
{
    public interface IAlavancaRepository
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mes"></param>
        /// <param name="ano"></param>
        /// <returns></returns>
        bool RemoveExistentesPorItem(List<Alavanca> models, GerenciadorCarga gerenciador, Action<GerenciadorCarga> gravarGerenciador, int? batchSize);
        Task<bool> BulkInsert(List<Alavanca> models, int? batchSize);
        int InsertSQL(Alavanca model);
    }
}
