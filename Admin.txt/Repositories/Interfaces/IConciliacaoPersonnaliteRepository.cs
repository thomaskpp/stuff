﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories.Interfaces
{
    public interface IConciliacaoPersonnaliteRepository
    {
        Task BulkInsert(List<ProducaoRealizadaAnalitico> models, int batchSize);
        bool RemoveExistentesPorItem(List<PlanejamentoProducaoRealizadaAnaliticoSimples> models, GerenciadorCarga gerenciador, Action<GerenciadorCarga> gravarGerenciador, int? batchSize);
        //void BulkRemove(List<PlanejamentoProducaoRealizadaAnalitico> models, int? batchSize);
        void InsertSQL(ProducaoRealizadaAnalitico model);

        void UpdateIndicadorAtivo(int CodigoItem, int IdSegmento, short Mes, short Ano, bool Ativo);

        ConciliacaoConfiguracoes ConsultarConciliacaoConfiguracoesPorCodItemMesAnoSegmento(int codItem, short mes, short ano, int IdSegmento);

        List<ConciliacaoTabelas> ConsultarNomeDasColunas(int codigoItem);

        List<ConciliacaoItens> GetConciliacaoItens(int ano, int mes);

        void InsertConfiguracoes(ConciliacaoConfiguracoes configuracoes);
        void InsertParametros(ConciliacaoParametros parametros);
        void DeletarConciliacao(int Ids);
        ConciliacaoConfiguracoes ObterConciliacaoConfiguracoes(string codigoItem, string idSegmento, short mes, short ano);
    }
}
