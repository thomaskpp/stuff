﻿using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories.Interfaces
{
    public interface ICheckoutRepository
    {
        IEnumerable<PlanejamentoCheckout> GetPlanejamentoCheckoutsByAnoMes(short ano, short mes);

        List<PlanejamentoCheckout> GetPlanejamentoPersonnaliteCheckoutsByAnoMesPersonnalite(short? ano, short? mes);

        int BulkInsertUpdatePlanejamentoCheckouts(List<PlanejamentoCheckout> models, int? batchSize);

        Task<int> BulkInsertUpdatePlanejamentoCheckoutsPersonnalite(List<PlanejamentoCheckout> models, int? batchSize);

        bool RemoveExistentesPorItem(List<PlanejamentoCheckout> models, GerenciadorCarga gerenciador, int? batchSize);

        Task<IEnumerable<PlanejamentoCheckout>> GetAllCheckoutsMesAnoAsync(int Mes, int Ano);

        Task<IEnumerable<PlanejamentoCheckout>> GetAllPlanejamentoCheckoutsMesAnoCarteira(string carteira, int mes, int ano);
    }
}