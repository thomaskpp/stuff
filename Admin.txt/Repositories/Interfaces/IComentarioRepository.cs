﻿using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Repositories.Interfaces
{
    public interface IComentarioRepository
    {
        List<ComentarioPlanejamentoCarteira> GetComentarioByCarteira(string carteira, int mes, int ano);
    }
}
