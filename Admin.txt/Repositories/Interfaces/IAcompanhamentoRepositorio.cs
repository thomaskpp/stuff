﻿using Itau.SZ7.GPS.Admin.Areas.Agir.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories.Interfaces
{
    public interface IAcompanhamentoRepositorio
    {
        Task<IEnumerable<AcompanhamentoRelatorio>> ObterRelatorio(DateTime dataInicio, DateTime dataFim, int idSegmento);
    }
}
