﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories.Interfaces
{
    public interface IColaboradorAgirRepository
    {
        IEnumerable<Entities.ColaboradorAgir> RetornaCarteirasVaziasParaMetas(short ano, short mes);
        int Inserir(List<Entities.ColaboradorAgir> models, int? batchSize);
        IEnumerable<Entities.ColaboradorAgir> RetornaTodos(short ano, short mes);
        IEnumerable<Entities.ColaboradorAgir> RetornaCarteirasVazias(short ano, short mes);
    }
}
