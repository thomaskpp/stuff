﻿namespace Itau.SZ7.GPS.Admin.Domain.Agenda.Interfaces.Repositories
{
    public interface ICompromissoColaboradorRepository
    {

    }
}
