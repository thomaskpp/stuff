﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories
{
    public interface IColaboradorRepository
    {
        Task<IEnumerable<Colaborador>> RetornarColaboradores();

        IEnumerable<Colaborador> GetColaboradorFromCache();
        int GetIdColaboradorPorCarteira(string carteira);

        Task<IEnumerable<Colaborador>> GetColaboradorAtivo();

        string GetFuncionalResponsavelPorId(int id);

        IEnumerable<Colaborador> GetColaboradorParaCargaMeta(int ano, int mes);

        IEnumerable<Colaborador> GetColaboradorParaCargaMeta(Segmentos segmento);

        Task<ColaboradorSimplificado> GetByFuncional(string funcional, bool isFromCache = true);

        Task<ColaboradorSimplificado> GetById(int id, bool isFromCache = true);

        Task<int> GetIdSegmentoByFuncionalAsync(string funcional);

        int BulkInsertColaborador(List<ColaboradorSimplificado> models, List<int> agirAtualizados, int? batchSize);

        Task<IEnumerable<Colaborador>> GetAllColaboradores();

        Task<IEnumerable<Colaborador>> GetColaborador(int codigoAgencia);

        Task<IEnumerable<ColaboradorFerias>> VerificarColaboradorFerias(string[] funcionais);

        bool ExisteCarteira(string carteira);

        bool ExisteCarteiraAgencia(string carteira, int codigoAgencia);

        Task<bool> ExisteCarteiraAgenciaPorSegmento(string carteira, int codigoAgencia, int idSegmento);
        IEnumerable<ColaboradorSimplificado> ObterColaboradores();
        IEnumerable<Colaborador> GetColaboradorParaCargaMetaPersonnalite(byte mes, short ano);
        List<ColaboradorAgir> ObterColaboradorAgirPorCarteiraMesAnoPersonnalite(byte mes, short ano);
        int AtualizaGestorDireto(List<Colaborador> models, int? batchSize);
        IEnumerable<Colaborador> GetColaboradoresComAgir(int ano, int mes);
        IEnumerable<Colaborador> GetColaboradorGGDGGN(int ano, int mes);
        IEnumerable<Colaborador> GetColaboradorExcetoAssistente(int ano, int mes);
    }
}