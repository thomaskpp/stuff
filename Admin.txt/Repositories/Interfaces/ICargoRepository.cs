﻿using Itau.SZ7.GPS.Admin.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories
{
    public interface ICargoRepository
    {
        Task<IEnumerable<Cargo>> ListarCargoAsync();

        Cargo GetCargo(string Cargo);

        int GetIdCargo(string Cargo);
    }
}
