﻿
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Domain.Interfaces.Control_M;
using Itau.SZ7.GPS.Admin.Domain.Notificacao.Interfaces.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class DestinatarioRepository : IDestinatarioRepository
    {
        private readonly string _connectionString;

        public DestinatarioRepository(IAppConfiguration appConfiguration)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public async Task<int> BulkInsertUpdate(List<Destinatario> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                    {
                        sqlList.Add(CriaInsertUpdateScript(item));
                    }

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;
                    resultado = sqlList.Count();
                    await conn.OpenAsync();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("destinatario-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                await cmd.ExecuteNonQueryAsync();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        private string CriaInsertUpdateScript(Destinatario item)
        {
            return $@"IF EXISTS(SELECT TOP 1 1 FROM NotificacaoDestinatario WITH(NOLOCK)
                        WHERE IdNotificacao={item.IdNotificacao} AND IdColaborador = '{item.IdColaborador}')
                    BEGIN
                        UPDATE NotificacaoDestinatario SET DataAtualizacao = '{item.DataAtualizacao.ToString("yyyy-MM-dd HH:mm:ss")}', DadosVariaveis = '{item.DadosVariaveis}', Status = '{item.Status}', Push = {item.Push}, Lido = {item.Lido}
                        WHERE IdNotificacao={item.IdNotificacao} AND IdColaborador = '{item.IdColaborador}' AND (DadosVariaveis != '{item.DadosVariaveis}' OR Status != '{item.Status}')                      
                    END 
                    ELSE 
                    BEGIN
                        INSERT INTO NotificacaoDestinatario (IdColaborador, IdNotificacao, DadosVariaveis, Status, Push, Lido, DataLeitura, DataCriacao, DataAtualizacao)
                        VALUES ('{item.IdColaborador}',{item.IdNotificacao},'{item.DadosVariaveis}','{item.Status}',{item.Push},{item.Lido},'{item.DataLeitura}','{item.DataCriacao.ToString("yyyy-MM-dd HH:mm:ss")}','{item.DataAtualizacao.ToString("yyyy-MM-dd HH:mm:ss")}')
                    END";
        }
    }
}