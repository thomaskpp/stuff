﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;



using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class DiasSemReclamacoesRepository: IDiasSemReclamacoesRepository
    {
        private readonly string _connectionString;
        private readonly ISqlDataContext _sqlDataContext;

        public DiasSemReclamacoesRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _sqlDataContext = sqlDataContext;
        }

        public void LimparTabela(TipoEstrutura t)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    cmd.CommandText = $"DELETE FROM ReclamacaoDiaSemReclamacao WHERE IdEstrutura = {((int)t)}";

                    cmd.ExecuteNonQuery();

                    conn.Close();
                }
            }
        }

        public async Task<int> BulkInsertUpdate(string script)
        {
            return await BulkInsertUpdate(new List<string> { script });
        }


        public async Task<int> BulkInsertUpdate(List<string> scripts)
        {
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();

                    using (var transaction = conn.BeginTransaction("diassemreclamacoes-bulk"))
                    {
                        cmd.Transaction = transaction;

                        try
                        {
                            cmd.CommandText = string.Join("\n", scripts.ToArray());

                            resultado += await cmd.ExecuteNonQueryAsync();

                            transaction.Commit();
                        }
                        catch
                        {
                            try
                            {
                                transaction.Rollback();
                            }
                            catch { }

                            throw;
                        }
                    }


                    conn.Close();
                }
            }

            return resultado;
        }

        public async Task AtualizarDiasSemReclamacoes()
        {
            string sql = $@"
                        IF OBJECT_ID('tempdb..#TempUpdateReclamacao') IS NOT NULL DROP TABLE #TempUpdateReclamacao
                        
                        SELECT DataOcorrencia, IdAgenciaCoordenadora, IdEstrutura 
                        INTO #TempUpdateReclamacao
                        FROM
                        (SELECT MAX(DataOcorrencia) AS DataOcorrencia,MAX(DataUltimaReclamacao) AS DataUltimaReclamacao, R.IdAgenciaCoordenadora, R.IdEstrutura
                        FROM Reclamacao R
                        INNER JOIN ReclamacaoDiaSemReclamacao DS ON DS.IdAgenciaCoordenadora = R.IdAgenciaCoordenadora AND R.IdEstrutura = DS.IdEstrutura
                        WHERE AgrupadorCanal LIKE '%Bacen - Entradas%' OR AgrupadorCanal LIKE '%Procon - Entradas%'  OR AgrupadorCanal LIKE '%Procon Fone%'
                        GROUP BY R.IdAgenciaCoordenadora,DS.IdAgenciaCoordenadora, R.IdEstrutura) AS A
                        WHERE DataOcorrencia > DataUltimaReclamacao
                        
                        Update ReclamacaoDiaSemReclamacao
                        SET DataUltimaReclamacao = TU.DataOcorrencia
                        FROM ReclamacaoDiaSemReclamacao DS 
                        INNER JOIN #TempUpdateReclamacao TU On TU.IdAgenciaCoordenadora = DS.IdAgenciaCoordenadora AND TU.IdEstrutura = DS.IdEstrutura
                        ";

            await _sqlDataContext.ExecuteNonQueryAsync(sql, null);
        }

    }
}

