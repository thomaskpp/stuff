﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Data.Sql;
using Itau.SZ7.GPS.Admin.Domain.Carga.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Entities.DTO;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Helpers;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class GerenciadorCargaRepository : IGerenciadorCargaRepository
    {
        private readonly ISqlDataContext _sqlDataContext;
        private readonly ISqlFactory _sqlFactory;
        private readonly string _connectionString;

        public GerenciadorCargaRepository(IAppConfiguration appConfiguration,
            ISqlDataContext sqlDataContext,
            ISqlFactory sqlFactory)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _sqlDataContext = sqlDataContext;
            _sqlFactory = sqlFactory;
        }

        public async Task<GerenciadorCarga> GetGerenciadorCarga(int idGerenciadorCarga)
        {
            var result = new GerenciadorCarga();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = $@"SELECT TOP 1 [Id],
	                                            [IdGerenciadorCargaConfiguracao],
	                                            [IdColaborador],
	                                            [IdSegmento],
	                                            [Arquivo],
	                                            [Inicio],
	                                            [Fim],
	                                            [TotalLinhas],
	                                            [PopupConclusao]
                                FROM GerenciadorCarga (NOLOCK) WHERE id = {idGerenciadorCarga}";

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var registro = new GerenciadorCarga()
                            {
                                Id = reader.SafeGetInt32(0),
                                IdGerenciadorCargaConfiguracao = reader.SafeGetInt32(1),
                                IdColaborador = reader.SafeGetInt32(2),
                                IdSegmento = reader.SafeGetByte(3),
                                Arquivo = reader.SafeGetString(4),
                                Inicio = reader.GetDateTime(5),
                                Fim = reader.SafeGetDateTime(6),
                                TotalLinhas = reader.SafeGetInt32(7),
                                PopupConclusao = reader.SafeGetBoolean(8)
                            };

                            result = registro;
                        }
                    }
                }

                conn.Close();
            }


            return result;
        }

        public async Task<IEnumerable<GerenciadorCarga>> GetGerenciadorCargas(int qtdRegistros)
        {
            if (qtdRegistros < 1)
                qtdRegistros = 1;

            var result = Enumerable.Empty<GerenciadorCarga>();

            var query = $@"DECLARE @gerenciador as TABLE(
                            [Id] [int] NOT NULL,
	                        [IdGerenciadorCargaConfiguracao] [int] NOT NULL,
	                        [IdColaborador] [int] NOT NULL,
	                        [IdSegmento] [tinyint] NOT NULL,
	                        [Arquivo] [varchar](50) NOT NULL,
	                        [Inicio] [datetime] NOT NULL,
	                        [Fim] [datetime] NULL,
	                        [TotalLinhas] [int] NOT NULL,
	                        [PopupConclusao] [bit] NOT NULL,
                            [NomeFuncional] varchar(30) NOT NULL
                        )

                        INSERT INTO @gerenciador
                        SELECT TOP {qtdRegistros} 
                            g.[Id],
	                        [IdGerenciadorCargaConfiguracao],
	                        [IdColaborador],
	                        [IdSegmento],
	                        [Arquivo],
	                        [Inicio],
	                        [Fim],
	                        [TotalLinhas],
	                        [PopupConclusao],
                            isnull(c.[Nome],'') AS NomeFuncional
                        FROM GerenciadorCarga g (NOLOCK)
                            LEFT JOIN Colaborador c ON c.Id = g.IdColaborador
                        ORDER BY Inicio DESC

                        SELECT * FROM @gerenciador

                        SELECT * FROM GerenciadorCargaPasso (NOLOCK) WHERE idGerenciadorCarga IN
                        (
                          SELECT Id FROM @gerenciador
                        )

                        SELECT IdFuncionalidade, Id FROM GerenciadorCargaConfiguracao (NOLOCK) WHERE Id IN
                        (
                            SELECT IdGerenciadorCargaConfiguracao FROM @gerenciador
                        )";

            using (var commad = _sqlFactory.Build<ISqlMultipleResult>()
                .Query(query))
            {
                var results = await commad.ExecuteAsync();
                var cargas = await results.CastAsync<GerenciadorCarga>();
                var gerenciadorCargaPasso = await results.CastAsync<GerenciadorCargaPasso>();
                var gerenciadorCargaConfiguracao = await results.CastAsync<GerenciadorCargaConfiguracao>();

                results.Close();

                foreach (var carga in cargas)
                {
                    carga.Passos = gerenciadorCargaPasso.Where(x => x.IdGerenciadorCarga == carga.Id).ToList();
                    carga.Configuracao = gerenciadorCargaConfiguracao.FirstOrDefault(x => x.Id == carga.IdGerenciadorCargaConfiguracao);
                    carga.IdFuncionalidade = (Funcionalidade.Enum)carga.Configuracao.IdFuncionalidade;
                }

                result = cargas;
            }

            return result;
        }

        public int Update(GerenciadorCarga model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText =
                                $@"UPDATE GerenciadorCarga SET
                                IdGerenciadorCargaConfiguracao = (SELECT Id FROM GerenciadorCargaConfiguracao WHERE IdFuncionalidade = {(int)model.IdFuncionalidade}),
                                IdColaborador = {model.IdColaborador},
                                IdSegmento = {model.IdSegmento},
                                Arquivo = '{model.Arquivo}',
                                Inicio = '{(model.Inicio.ToSqlDate())}',
                                Fim = {(model.Fim.HasValue ? "'" + model.Fim.Value.ToSqlDate() + "'" : "NULL")},
                                TotalLinhas = {model.TotalLinhas},
                                PopupConclusao = {model.PopupConclusao.GetHashCode()}        
                                WHERE id = {model.Id}";

                var result = cmd.ExecuteNonQuery();

                conn.Close();

                return result;
            }
        }

        public async Task<int> UpdateAsync(GerenciadorCarga model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                await conn.OpenAsync();

                cmd.CommandText =
                                $@"UPDATE GerenciadorCarga SET

                                IdGerenciadorCargaConfiguracao = (SELECT Id FROM GerenciadorCargaConfiguracao WHERE IdFuncionalidade = {(int)model.IdFuncionalidade}),
                                IdColaborador = {model.IdColaborador},
                                IdSegmento = {model.IdSegmento},
                                Arquivo = '{model.Arquivo}',
                                Inicio = '{(model.Inicio.ToSqlDate())}',
                                Fim = {(model.Fim.HasValue ? "'" + model.Fim.Value.ToSqlDate() + "'" : "NULL")},
                                TotalLinhas = {model.TotalLinhas},
                                PopupConclusao = {model.PopupConclusao.GetHashCode()}    


                                WHERE id = {model.Id}";

                var result = await cmd.ExecuteNonQueryAsync();

                conn.Close();

                return result;
            }
        }

        public int Insert(GerenciadorCarga model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText =

                                    $@"
                                    INSERT INTO GerenciadorCarga
                                        VALUES(
                                        (SELECT Id FROM GerenciadorCargaConfiguracao WHERE IdFuncionalidade = {(int)model.IdFuncionalidade}),
                                        {model.IdColaborador},
                                        {model.IdSegmento},
                                        '{model.Arquivo}',
                                        '{(model.Inicio.ToString("yyyy-MM-dd HH:mm:ss"))}',
                                        {(model.Fim.HasValue ? "'" + model.Fim.Value.ToString("yyyy-MM-dd HH:mm:ss") + "'" : "NULL")},
                                        {model.TotalLinhas},
                                        {model.PopupConclusao.GetHashCode()})

                                    SELECT @@IDENTITY";

                var retorno = cmd.ExecuteScalar();

                model.Id = IntExtension.TryParse(retorno.ToString());

                conn.Close();
            }

            return model.Id;
        }

        public async Task<List<GerenciadorCarga>> GetEachCargaLastRegisterAsync()
        {
            var result = new List<GerenciadorCarga>();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                await conn.OpenAsync();

                cmd.CommandText =
                                $@"SELECT idFuncionalidade, max(Fim)
                                FROM GerenciadorCarga A (NOLOCK) 
                                    INNER JOIN GerenciadorCargaConfiguracao B (NOLOCK) ON A.IdGerenciadorCargaConfiguracao = B.Id
                                GROUP BY idFuncionalidade";

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var registro = new GerenciadorCarga()
                            {
                                IdFuncionalidade = (Funcionalidade.Enum)reader.SafeGetInt16(0),
                                Fim = reader.SafeGetDateTime(1)
                            };

                            result.Add(registro);
                        }
                    }
                }

                conn.Close();
            }

            return result;
        }

        public async Task<IEnumerable<GerenciadorCargaGridConfiguracoes>> GetGridAllCargasConfiguracoes()
        {
            var query = @"SELECT 
	                            IdFuncionalidade,
	                            F.Descricao AS NOME,
	                            ISNULL(C.Funcional,''),
	                            ISNULL(C.Nome,'') AS NomeResponsavel,
	                            IdTipoPeriodo AS TipoPeriodo,
	                            ValorPeriodo,
	                            Ocultar,
	                            F.Url,
	                            TravaSimultanea
                            FROM GerenciadorCargaConfiguracao G WITH (NOLOCK)
                                INNER JOIN Funcionalidade F WITH (NOLOCK) ON G.IdFuncionalidade = F.id
                                LEFT JOIN Colaborador C (NOLOCK) ON G.idColaborador = C.Id
                            ORDER BY Nome";

            return await _sqlDataContext.SelectQueryToListAsync<GerenciadorCargaGridConfiguracoes>(query);
        }

        public async Task<int> UpdatePopupAsync(GerenciadorCarga model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText =
                                $@"UPDATE GerenciadorCarga SET
                                PopupConclusao = 0   


                                WHERE id = {model.Id}";

                var result = await cmd.ExecuteNonQueryAsync();

                conn.Close();

                return result;
            }
        }

        public bool PermiteExecucao(int idFuncionalidade)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText =
                                $@"SELECT COUNT(1) FROM GerenciadorCarga GC (nolock)
                                  INNER JOIN GerenciadorCargaConfiguracao GCC (nolock)
                                  ON GCC.Id = GC.IdGerenciadorCargaConfiguracao
                                  WHERE GCC.IdFuncionalidade = {idFuncionalidade} AND GCC.TravaSimultanea = 1 AND GC.Fim IS NULL";

                var result = (int)cmd.ExecuteScalar();

                conn.Close();

                return result <= 0;
            }
        }


        public async Task<IEnumerable<GerenciadorCargaAgendada>> ObterCargasAgendadas()
        {
            List<GerenciadorCargaAgendada> result = new List<GerenciadorCargaAgendada>();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                await conn.OpenAsync();

                cmd.CommandText = $@"SELECT
                                    GC.Id,
	                                C.Nome AS Colaborador, 
	                                C.Funcional,
	                                F.Descricao AS Carga,
	                                GC.Inicio
                                FROM Colaborador C WITH(NOLOCK)
                                JOIN GerenciadorCarga GC WITH(NOLOCK) ON C.Id = GC.IdColaborador
                                JOIN GerenciadorCargaConfiguracao GCC WITH(NOLOCK) ON GC.IdGerenciadorCargaConfiguracao = GCC.Id
                                JOIN Funcionalidade F WITH(NOLOCK) ON F.Id = GCC.IdFuncionalidade
                                WHERE Inicio >= CONVERT(DATE, GETDATE(), 0) AND Fim IS NULL";

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            //var registro = new[] { new GerenciadorCarga()
                            //{
                            //    Inicio = reader.GetDateTime(3)
                            //},
                            //    new Funcionalidade() {
                            //    Descricao = reader.SafeGetString(2)
                            //}, 
                            //    new Colaborador()
                            //    {
                            //         Nome = reader.SafeGetString(0),
                            //         Funcional = reader.SafeGetString(1)
                            //    }

                            //};

                            var registro = new GerenciadorCargaAgendada()
                            {
                                Id = reader.SafeGetInt32(0),
                                Colaborador = reader.SafeGetString(1),
                                Funcional = reader.SafeGetString(2),
                                Carga = reader.SafeGetString(3),
                                Inicio = reader.SafeGetDateTimeNotNull(4)
                            };

                            result.Add(registro);
                        }
                    }
                }

                conn.Close();

                return result;
            }
        }

        public async Task<int> AtualizaPorIdAsync([FromQuery] DateTime dataInicio, int Id)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                try
                {
                    await conn.OpenAsync();

                    cmd.CommandText = $@"UPDATE GerenciadorCarga SET inicio = '{dataInicio.ToSqlDate()}' WHERE Id = {Id}";

                    var result = await cmd.ExecuteNonQueryAsync();

                    conn.Close();

                    if (result != 0)
                        return result;

                }
                catch (Exception ex)
                {

                }

                return 0;
            }
        }

        public async Task<int> DeletaPorIdAsync(int Id)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                try
                {
                    await conn.OpenAsync();

                    cmd.CommandText = $@"DELETE FROM GerenciadorCarga WHERE Id = {Id}";

                    var result = await cmd.ExecuteNonQueryAsync();

                    conn.Close();

                    if (result != 0)
                        return result;
                }
                catch (Exception ex)
                {

                }

                return 0;

            }
        }
    }
}
