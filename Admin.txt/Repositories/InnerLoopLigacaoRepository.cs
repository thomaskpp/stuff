﻿using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class InnerLoopLigacaoRepository : IInnerLoopLigacaoRepository
    {

        private readonly BulkConfig _bulkConfig;
        private readonly string _connectionString;
        private readonly ISqlDataContext _sqlDataContext;

        public InnerLoopLigacaoRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };

            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _sqlDataContext = sqlDataContext;
        }

        public void BulkInsert(List<InnerLoopLigacao> models, int? batchSize)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaInsertScript(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        SqlTransaction transaction = conn.BeginTransaction("bulkinsert");
                        cmd.Transaction = transaction;

                        try
                        {
                            var sqlTemp = new List<string>();
                            var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                            sqlTemp.AddRange(sqlList.Take(_batchSize));
                            sqlList.RemoveRange(0, _batchSize);

                            cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                            cmd.ExecuteNonQuery();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            try
                            {
                                transaction.Rollback();
                            }
                            catch (Exception ex2)
                            {
                                throw ex2;
                            }

                            throw ex;
                        }

                    }

                    conn.Close();
                }
            }
        }

        public void InsertSQL(InnerLoopLigacao model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = CriaInsertScript(model, 0);

                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        public List<InnerLoopLigacao> GetLigacoesNovas()
        {
            var ligacoes = new List<InnerLoopLigacao>();
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;
                    cmd.CommandText = $"SELECT * FROM InnerLoopLigacao as lg WHERE lg.Id NOT IN (SELECT IdLigacao FROM InnerLoopHistorico)";
                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        ligacoes.Add(ConvertForLigacao(dr));
                    }
                    dr.Close();
                    conn.Close();
                }
            }

            return ligacoes;
        }


        public void RemoveLigacoes(List<InnerLoopLigacao> ligacoes, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaDeleteScript(ligacoes);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        cmd.ExecuteNonQuery();
                    }

                    conn.Close();
                }
            }
        }

        public void RemoveLigacoesExpurgo(List<InnerLoopLigacao> ligacoes)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaDeleteScript(ligacoes);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        cmd.ExecuteNonQuery();
                    }

                    conn.Close();
                }
            }
        }

        private List<string> CriaDeleteScript(List<InnerLoopLigacao> ligacoes)
        {
            var resultado = new List<string>();

            foreach (var item in ligacoes)
            {
                resultado.Add($"DELETE FROM InnerLoopLigacao WHERE Id = { item.Id }");
            }

            return resultado;
        }

        public List<InnerLoopLigacao> LigacoesARemover()
        {
            var ligacoes = new List<InnerLoopLigacao>();
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;
                    cmd.CommandText = $"SELECT * FROM InnerLoopLigacao WHERE DataCriacao < (GETDATE() - { InnerLoopLigacao.Periodo_Expurgo })";
                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        ligacoes.Add(ConvertForLigacao(dr));
                    }
                    dr.Close();
                    conn.Close();
                }
            }
            return ligacoes;
        }

        public int ExpurgarLigacoes()
        {
            int retorno = 0;
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;
                    cmd.CommandText = $"BEGIN " +
                        $"DELETE FROM InnerLoopHistorico WHERE IdLigacao IN (SELECT Id FROM InnerLoopLigacao NOLOCK WHERE DataCriacao < (GETDATE() - { InnerLoopLigacao.Periodo_Expurgo })) " +
                        $"DELETE FROM InnerLoopResposta WHERE IdLigacao IN (SELECT Id FROM InnerLoopLigacao NOLOCK WHERE DataCriacao < (GETDATE() - { InnerLoopLigacao.Periodo_Expurgo })) " +
                        $"DELETE FROM InnerLoopLigacao WHERE DataCriacao < (GETDATE() - { InnerLoopLigacao.Periodo_Expurgo }) " +
                        $"END";
                    conn.Open();
                    retorno = cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            return retorno;
        }

        private InnerLoopLigacao ConvertForLigacao(SqlDataReader dr)
        {
            var ligacao = new InnerLoopLigacao()
            {
                DataCriacao = Convert.ToDateTime(dr["DataCriacao"]),
                DataAtualizacao = Convert.ToDateTime(dr["DataAtualizacao"]),
                Id = Convert.ToInt32(dr["Id"]),
                Nome = dr["Nome"].ToString(),
                Nota = Convert.ToInt32(dr["Nota"]),
                Comentario = dr["Comentario"].ToString(),
                IdSegmentoColaborador = Convert.ToInt32(dr["IdSegmentoColaborador"]),
                Produto = dr["Produto"].ToString(),
                AgenciaCliente = Convert.ToInt32(dr["AgenciaCliente"]),
                ContaCliente = dr["ContaCliente"].ToString(),
                DataContato = Convert.ToDateTime(dr["DataContato"]),
                IdColaboradorResponsavel = Convert.ToInt32(dr["IdColaboradorResponsavel"]),
                IdAgenciaResponsavel = Convert.ToInt32(dr["IdAgenciaResponsavel"]),
                Responsavel = dr["Responsavel"].ToString(),
                AgenciaResponsavel = Convert.ToInt32(dr["AgenciaResponsavel"]),
                Telefone = dr["Telefone"].ToString(),
                Cnpj = dr["Cnpj"].ToString(),
                SegmentoCliente = dr["SegmentoCliente"].ToString(),
                Ocorrencia = dr["Ocorrencia"].ToString(),
                CnpjGrupo = dr["CnpjGrupo"].ToString(),
                Cidade = dr["Cidade"].ToString(),
                Infos = dr["Infos"].ToString(),
                IdColaboradorLigacao = Convert.ToInt32(dr["IdColaboradorLigacao"]),
                NomeContato = dr["NomeContato"].ToString(),
                Nps = dr["Nps"].ToString()
            };

            return ligacao;
        }

        private List<string> CriaInsertScript(List<InnerLoopLigacao> ligacoes)
        {
            var resultado = new List<string>();

            for (int i = 0; i < ligacoes.Count; i++)
            {
                resultado.Add(CriaInsertScript(ligacoes[i], i));
            }

            return resultado;
        }

        private string CriaInsertScript(InnerLoopLigacao ligacao, int i)
        {
            var resultado = $"DECLARE @id{i} INT " +
                            $"IF NOT EXISTS(SELECT 1 FROM InnerLoopLigacao (NOLOCK) WHERE DataContato = '" + ligacao.DataContato?.ToString("yyyy-MM-dd HH:mm:ss") + "' AND Telefone = '" + ligacao.Telefone + "') " +
                            $"INSERT INTO InnerLoopLigacao " +
                            $"([DataCriacao], [DataAtualizacao], [Nome], [Nota], [Comentario], [IdSegmentoColaborador], [Produto], [AgenciaCliente], [ContaCliente], [DataContato], " +
                            $"[IdColaboradorResponsavel], IdAgenciaResponsavel, Responsavel, [AgenciaResponsavel], [Telefone], [Cnpj], [SegmentoCliente], [Ocorrencia], [CnpjGrupo], [Cidade], [Infos], [IdColaboradorLigacao], [NomeContato], [Nps], [CpfCnpj], [TempoRelac])" +
                            $" VALUES (" +
                            $"'{ligacao.DataCriacao.ToString("yyyy-MM-dd HH:mm:ss")}'," +
                            $"'{ligacao.DataAtualizacao.ToString("yyyy-MM-dd HH:mm:ss")}'," +
                            $"'{ligacao.Nome}'," +
                            $"{ligacao.Nota}," +
                            $"'{ligacao.Comentario}'," +
                            $"{ligacao.IdSegmentoColaborador}," +
                            $"'{ligacao.Produto}'," +
                            $"{ligacao.AgenciaCliente}," +
                            $"'{ligacao.ContaCliente}'," +
                            $"'{ligacao.DataContato?.ToString("yyyy-MM-dd HH:mm:ss") ?? null }'," +
                            $"{ligacao.IdColaboradorResponsavel}," +
                            $"{ligacao.IdAgenciaResponsavel}," +
                            $"'{ligacao.Responsavel}'," +
                            $"{ligacao.AgenciaResponsavel}," +
                            $"'{ligacao.Telefone}'," +
                            $"'{ligacao.Cnpj}'," +
                            $"'{ligacao.SegmentoCliente}'," +
                            $"'{ligacao.Ocorrencia}'," +
                            $"'{ligacao.CnpjGrupo}'," +
                            $"'{ligacao.Cidade}'," +
                            $"'{ligacao.Infos}', " +
                            $"{ligacao.IdColaboradorLigacao}, " +
                            $"'{ligacao.NomeContato}', " +
                            $"'{ligacao.Nps}', " +
                            $"'{ligacao.CpfCnpj}', " +
                            $"'{ligacao.TempoRelac}' " +
                            $") " +
                            $"SELECT @id{i} = Id FROM InnerLoopLigacao (NOLOCK) WHERE DataContato = '" + ligacao.DataContato?.ToString("yyyy-MM-dd HH:mm:ss") + "' AND Telefone = '" + ligacao.Telefone + "' " +
                            $"IF NOT EXISTS(SELECT 1 FROM InnerLoopHistorico (NOLOCK) WHERE IdLigacao = @id{i}) " +
                            $"INSERT INTO InnerLoopHistorico " +
                            $"(DataCriacao, DataAtualizacao, IdLigacao, IdStatus) VALUES (" +
                              $"'{ligacao.DataCriacao.ToString("yyyy-MM-dd HH:mm:ss")}', " +
                              $"'{ligacao.DataAtualizacao.ToString("yyyy-MM-dd HH:mm:ss")}', " +
                              $"@id{i}, " +
                              $"1" +
                            $")";

            return resultado;
        }

        public bool VerificaDuplicidade(string DataContato, string Telefone)
        {
            bool Retorno = false;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;
                    cmd.CommandText = $"SELECT Id FROM InnerLoopLigacao WHERE DataContato = '" + Convert.ToDateTime(DataContato).ToString("yyyy-MM-dd HH:mm:ss") + "' AND Telefone = '" + Telefone + "'";
                    conn.Open();
                    Retorno = cmd.ExecuteReader().HasRows;
                    conn.Close();
                }
            }

            return Retorno;
        }

        private void InserirNoDescanso(int idLigacao, int descanso, string linha)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    conn.Open();

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;


                    cmd.CommandText = $"INSERT INTO InnerLoopDescanso (DataCriacao, IdLigacao, Descanso, LinhaArquivo) " +
                                                      "VALUES (GETDATE(), " + idLigacao + ", " + descanso + ", '" + linha + "')";

                    cmd.ExecuteNonQuery();
                }
                conn.Close();
            }
        }

        public string VerificaDescanso(string CPFCNPJ, string LinhaArquivo)
        {
            try
            {
                InnerLoopLigacao ligacao = RetornaLigacao(CPFCNPJ);

                if (ligacao != null && ligacao.Id > 0)
                {
                    InnerLoopJanela janela;

                    if (ligacao.IdSegmentoColaborador == 7 || ligacao.IdSegmentoColaborador == 10)
                    {
                        janela = ConsultaMeta(0);
                    }
                    else
                    {
                        janela = ConsultaMeta(ligacao.IdColaboradorLigacao.Value);
                    }

                    if (janela == null || (janela.Janela == 0 && janela.Descanso == 0))
                    {
                        return "Janela não encontrada";
                    }

                    IdLigacaoQuery jaFoiAtuada = JaFoiAtuada(CPFCNPJ, janela.Descanso);

                    if (jaFoiAtuada != null && jaFoiAtuada.IdLigacao > 0)
                    {
                        InserirNoDescanso(jaFoiAtuada.IdLigacao, janela.Descanso, LinhaArquivo);

                        return "Cliente em descanso";
                    }

                    var estaNoBolsao = EstaNoBolsao(CPFCNPJ, janela.Janela);

                    if (estaNoBolsao != null && estaNoBolsao.IdLigacao > 0)
                    {
                        InserirNoDescanso(estaNoBolsao.IdLigacao, janela.Descanso, LinhaArquivo);

                        return "Cliente em descanso";
                    }

                    return "";
                }
                else
                    return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public InnerLoopLigacao RetornaLigacao(string CPF_CNPJ_Descanso)
        {
            InnerLoopLigacao ligacao = new InnerLoopLigacao();
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;
                    cmd.CommandText = $"SELECT TOP 1 * FROM InnerLoopLigacao WHERE CpfCnpj = '" + CPF_CNPJ_Descanso + "' ORDER BY Id DESC";
                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                        ligacao = ConvertForLigacao(dr);

                    dr.Close();
                    conn.Close();
                }
            }
            return ligacao;
        }

        public InnerLoopJanela ConsultaMeta(int IdFuncionalLigacao)
        {
            var janela = new InnerLoopJanela();
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    if (IdFuncionalLigacao == 0)
                        cmd.CommandText = $@"
                                SELECT TOP 1 ILM.Janela, ILM.Descanso FROM InnerLoopMeta ILM
                                WHERE ILM.IdSegmento IN ({7}, {10})
                                ";
                    else
                        cmd.CommandText = $@"SELECT TOP 1 ILM.Janela, ILM.Descanso FROM Colaborador C
                                  INNER JOIN ColaboradorSatisfacao CS ON CS.IdColaborador = C.Id
                                  INNER JOIN InnerLoopMeta ILM ON ILM.IdCargo = CS.IdCargo AND ILM.IdSegmento = CS.IdSegmento
                                  WHERE C.Id = " + IdFuncionalLigacao;

                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        janela.Janela = Convert.ToInt32(dr["Janela"].ToString());
                        janela.Descanso = Convert.ToInt32(dr["Descanso"].ToString());
                    }

                    dr.Close();
                    conn.Close();
                }
            }
            return janela;
        }

        public IdLigacaoQuery JaFoiAtuada(string CPFCNPJ, int Descanso)
        {
            var atuada = new IdLigacaoQuery();
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;
                    cmd.CommandText = $@"SELECT MAX(ILL.Id) AS IdLigacao FROM InnerLoopLigacao  ILL
                                INNER JOIN InnerLoopHistorico ILH ON ILH.IdLigacao = ILL.Id
                                WHERE CpfCnpj = '{CPFCNPJ}' AND FORMAT(DATEADD(DAY, {Descanso}, ILH.DataCriacao), 'yyyy-MM-dd') >= FORMAT(GETDATE(), 'yyyy-MM-dd') AND ILH.IdStatus IN (2,3,4,5)";

                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                        atuada.IdLigacao = (dr["IdLigacao"].ToString() != "" ? Convert.ToInt32(dr["IdLigacao"].ToString()) : 0);

                    dr.Close();
                    conn.Close();
                }
            }
            return atuada;
        }

        public IdLigacaoQuery EstaNoBolsao(string CPFCNPJ, int Janela)
        {
            var atuada = new IdLigacaoQuery();
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;
                    cmd.CommandText = $@"SELECT MAX(ILL.Id) AS IdLigacao FROM InnerLoopLigacao  ILL
                                        INNER JOIN InnerLoopHistorico ILH ON ILH.IdLigacao = ILL.Id
                                        WHERE CpfCnpj = '{CPFCNPJ}' AND FORMAT(DATEADD(DAY, {Janela}, ILH.DataCriacao), 'yyyy-MM-dd') >= FORMAT(GETDATE(), 'yyyy-MM-dd') AND ILH.IdStatus IN (1)";

                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                        atuada.IdLigacao = (dr["IdLigacao"].ToString() != "" ? Convert.ToInt32(dr["IdLigacao"].ToString()) : 0);

                    dr.Close();
                    conn.Close();
                }
            }
            return atuada;
        }
    }
}

