﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class ColaboradorEngajamentoRepository : IColaboradorEngajamentoRepository
    {

        private readonly ISqlDataContext _sqlDataContext;
        private readonly string _connectionString;

        public ColaboradorEngajamentoRepository(IAppConfiguration appConfiguration, ISqlDataContext SqlDataContext)
        {
            _sqlDataContext = SqlDataContext;
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public async Task<IEnumerable<ColaboradorEngajamento>> GetAllEngajamentos(int mes, int ano)
        {
            return await _sqlDataContext.SelectQueryToListAsync<ColaboradorEngajamento>($"SELECT * FROM ColaboradorEngajamento WITH(NOLOCK) WHERE Mes = {mes} AND Ano = {ano} AND CodigoElegivelEngajamento != 0");
        }

        public async Task<bool> UpdateEngajamento(List<ColaboradorEngajamento> engajamentos)
        {
            int result = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in engajamentos)
                    {
                        sqlList.Add($@"update 
                                       ColaboradorEngajamento set 
                                       QuantidadeCheckin = {item.QuantidadeCheckin}, 
                                       QuantidadeCheckout = {item.QuantidadeCheckout}, 
                                       QuantidadePlanejamento = {item.QuantidadePlanejamento}, 
                                       ValorAderenciaCheckin = {item.ValorAderenciaCheckin.ToSql()}, 
                                       ValorAderenciaCheckout = {item.ValorAderenciaCheckout.ToSql()}, 
                                       ValorAderenciaPlanejamento = {item.ValorAderenciaPlanejamento.ToSql()}, 
                                       QuantidadeDiasUteis = {item.QuantidadeDiasUteis}, 
                                       DataAtualizacao = '{item.DataAtualizacao.ToSqlDate()}',
                                       IdPoloDicom = {(item.IdPoloDICOM == null ? "NULL" : item.IdPoloDICOM.ToString())}
                                       where Ano = {item.Ano} and Mes = {item.Mes} AND Funcional = {item.Funcional}");

                    }


                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();


                    using (var transaction = conn.BeginTransaction("planejamentoitemgrade-bulkinsert"))
                    {
                        cmd.Transaction = transaction;

                        try
                        {

                            cmd.CommandText = string.Join("\n", sqlList);

                            result = await cmd.ExecuteNonQueryAsync();

                            transaction.Commit();
                        }
                        catch
                        {
                            try
                            {
                                transaction.Rollback();
                            }
                            catch { conn.Close(); }

                            throw;
                        }
                    }


                    conn.Close();
                }
            }

            return result > 0;

        }

        public async Task<bool> InsertEngajamento(List<ColaboradorEngajamento> engajamentos)
        {
            int result = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in engajamentos)
                    {

                        StringBuilder Query = new StringBuilder();

                        Query.AppendLine("INSERT INTO[dbo].[ColaboradorEngajamento] ");
                        Query.AppendLine("([DataCriacao] ");
                        Query.AppendLine(",[DataAtualizacao] ");
                        Query.AppendLine(",[Funcional] ");
                        Query.AppendLine(",[AbreviacaoCargo] ");

                        if (item.CodigoAgencia != null && item.CodigoAgencia != 0)
                            Query.AppendLine(",[CodigoAgencia] ");

                        if (item.IdPoloRegional != null && item.IdPoloRegional != 0)
                            Query.AppendLine(",[IdPoloRegional] ");

                        if (item.IdPoloRegiao != null && item.IdPoloRegiao != 0)
                            Query.AppendLine(",[IdPoloRegiao] ");

                        if (!string.IsNullOrEmpty(item.Carteira))
                            Query.AppendLine(",[Carteira] ");

                        Query.AppendLine(",[Ano] ");
                        Query.AppendLine(",[Mes] ");
                        Query.AppendLine(",[QuantidadeCheckin] ");
                        Query.AppendLine(",[QuantidadeCheckout] ");
                        Query.AppendLine(",[QuantidadePlanejamento] ");
                        Query.AppendLine(",[ValorAderenciaCheckin] ");
                        Query.AppendLine(",[ValorAderenciaCheckout] ");
                        Query.AppendLine(",[ValorAderenciaPlanejamento] ");
                        Query.AppendLine(",[QuantidadeDiasUteis] ");
                        Query.AppendLine(",[QuantidadeDiasIndisponiveis] ");
                        Query.AppendLine(",[CodigoElegivelEngajamento] ");

                        if (item.IdPoloDICOM != null && item.IdPoloDICOM != 0)
                            Query.AppendLine(",[IdPoloDICOM] ");

                        Query.AppendLine(")");

                        Query.AppendLine("VALUES ");
                        Query.AppendLine($"('{item.DataCriacao.ToSqlDate()}' ");
                        Query.AppendLine($",'{item.DataAtualizacao.ToSqlDate()}' ");
                        Query.AppendLine($",'{item.Funcional}' ");
                        Query.AppendLine($",'{item.AbreviacaoCargo}' ");

                        if (item.CodigoAgencia != null && item.CodigoAgencia != 0)
                            Query.AppendLine($",{item.CodigoAgencia} ");

                        if (item.IdPoloRegional != null && item.IdPoloRegional != 0)
                            Query.AppendLine($",{item.IdPoloRegional} ");

                        if (item.IdPoloRegiao != null && item.IdPoloRegiao != 0)
                            Query.AppendLine($",{item.IdPoloRegiao} ");

                        if (!string.IsNullOrEmpty(item.Carteira))
                            Query.AppendLine($",'{item.Carteira}'");

                        Query.AppendLine($",{item.Ano} ");
                        Query.AppendLine($",{item.Mes} ");
                        Query.AppendLine($",{item.QuantidadeCheckin} ");
                        Query.AppendLine($",{item.QuantidadeCheckout} ");
                        Query.AppendLine($",{item.QuantidadePlanejamento} ");
                        Query.AppendLine($",{item.ValorAderenciaCheckin} ");
                        Query.AppendLine($",{item.ValorAderenciaCheckout} ");
                        Query.AppendLine($",{item.ValorAderenciaPlanejamento}");
                        Query.AppendLine($",{item.QuantidadeDiasUteis} ");
                        Query.AppendLine($",{item.QuantidadeDiasIndisponiveis} ");
                        Query.AppendLine($",{(int)item.CodigoElegivelEngajamento} ");

                        if (item.IdPoloDICOM != null && item.IdPoloDICOM != 0)
                            Query.AppendLine($",{item.IdPoloDICOM}");

                        Query.AppendLine(")");


                        sqlList.Add(Query.ToString().Replace(@"\r", string.Empty).Replace(@"\t", ""));
                    }

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();


                    using (var transaction = conn.BeginTransaction("planejamentoitemgrade-bulkinsert"))
                    {
                        cmd.Transaction = transaction;

                        try
                        {

                            cmd.CommandText = string.Join("\n", sqlList);

                            result = await cmd.ExecuteNonQueryAsync();

                            transaction.Commit();
                        }
                        catch
                        {
                            try
                            {
                                transaction.Rollback();
                            }
                            catch { conn.Close(); }

                            throw;
                        }
                    }


                    conn.Close();
                }
            }

            return result > 0;

        }

        public void LimparTabelaEngajamento()
        {
            _sqlDataContext.ExecuteNonQueryAsync($"DELETE FROM ColaboradorEngajamento WHERE Ano = {DateTime.Now.Year} AND Mes = {DateTime.Now.Month}", null);
            return;
        }

    }
}
