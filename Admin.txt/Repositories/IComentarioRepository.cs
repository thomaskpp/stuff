﻿using Itau.SZ7.GPS.Admin.Domain.Base.Interfaces.Repositories;
namespace Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories
{
    public interface IComentarioRepository
    {
    }
}
