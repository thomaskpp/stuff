﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class GradeCarteiraRepository : IGradeCarteiraRepository
    {
        private readonly ISqlDataContext _sqlDataContext;
        private readonly string _connectionString;

        public GradeCarteiraRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public void RemoveItens(short? Mes, short? Ano)
        {
            var parametros = new Dictionary<string, object>()
                {
                    { "@Mes", Mes },
                    { "@Ano", Ano }
                };

            _sqlDataContext.ExecuteNonQuery("GradeCarteira_RemoveTodos", System.Data.CommandType.StoredProcedure, parametros);
        }

        public int Inserir(List<GradeCarteira> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaScriptInsertUpdate(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("gradeCarteira-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = cmd.ExecuteNonQuery();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        private List<string> CriaScriptInsertUpdate(List<GradeCarteira> models)
        {
            var sql = new List<string>();

            foreach (var item in models)
            {
                sql.Add($@"IF NOT EXISTS(SELECT TOP 1 1 FROM GradeCarteira
			                    WHERE Carteira = '{item.Carteira}'
				                    AND Grade = {item.Grade}
				                    AND Mes = {item.Mes}
				                    AND Ano = {item.Ano} 
				                    AND Idagencia = {item.IdAgencia})
	                    BEGIN
		                    INSERT INTO GradeCarteira (Carteira, Grade, Mes, Ano, IdAgencia)
		                    VALUES ('{item.Carteira}', {item.Grade}, {item.Mes}, {item.Ano}, {item.IdAgencia})
	                    end");
            }

            return sql;
        }

        public bool Insere(List<GradeCarteira> models)
        {
            foreach(var model in models)
            {
                var parametros = new Dictionary<string, object>()
                {
                    { "@Grade", model.Grade },
                    { "@Carteira", model.Carteira },
                    { "@Mes", model.Mes },
                    { "@Ano", model.Ano },
                    { "@IdAgencia", model.IdAgencia }
                };

                _sqlDataContext.ExecuteNonQueryAsync("GradeCarteira_Insere", System.Data.CommandType.StoredProcedure, parametros);
            }

            return true;
        }

        public List<GradeCarteira> RetornaTodos()
        {
            return _sqlDataContext.SelectQueryToList<GradeCarteira>("GradeCarteira_SelecionaTodos", System.Data.CommandType.StoredProcedure, null)
                ?.ToList()
                ?? new List<GradeCarteira>();
        }

        public IEnumerable<GradeCarteira> RetornaTodos(short ano, short mes)
        {
            return _sqlDataContext.SelectQueryToList<GradeCarteira>
                (@"SELECT Carteira, Grade, IdAgencia, Ano, Mes FROM GradeCarteira (NOLOCK)
                    WHERE Ano = @ano AND Mes = @mes",
                System.Data.CommandType.Text, 
                new Dictionary<string, object>()
                {
                    { "ano", ano },
                    { "mes", mes }
                });
        }

        public short? GetGrade(string Carteira, short? Mes, short? Ano, int IdAgencia)
        {
            List<GradeCarteira> lista = new List<GradeCarteira>();

            lista = RetornaTodos();

            return lista.Where(x => x.Carteira == Carteira && x.Mes == Mes && x.Ano == Ano && x.IdAgencia == IdAgencia).Select(x => x.Grade).FirstOrDefault();
        }

        public int ObterIdGradeItemGradeMesAno(int grade, int codigoItem, byte mes, short ano)
        {

            var gradeRetorno = _sqlDataContext.SelectQuerySingleOrDefault<GradeCarteira>
                   (
                   $@"
                       SELECT [Id]
                              FROM [dbo].[GradeItem]
                              WHERE 
                              Grade = {grade}
                              AND CodigoItem = {codigoItem}
                              AND Mes = {mes}
                              AND Ano = {ano}");

            return gradeRetorno.Id;
        }

        public int SalvarGradeComplementar(List<GradeComplementarCarteiraPersonnalite> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaScriptInsertUpdate(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("gradeCarteira-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = cmd.ExecuteNonQuery();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        public int LimparGradeComplementar(List<Colaborador> models)
        {
            var _batchSize = 1;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaScriptDeletetUpdate(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("gradeCarteira-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = cmd.ExecuteNonQuery();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }


        private List<string> CriaScriptInsertUpdate(List<GradeComplementarCarteiraPersonnalite> models)
        {
            var sql = new List<string>();

            foreach (var item in models)
            {
                sql.Add($@"INSERT INTO GradeComplementarPersonnalite (IdColaboradorAgir, Grade, Agrupamento)
		                   VALUES ({item.IdColaboradorAgir}, {item.Grade}, {item.Agrupamento});");
            }

            return sql;
        }

        private List<string> CriaScriptDeletetUpdate(List<Colaborador> models)
        {
            var sql = new List<string>();

            string[] ids = new string[models.Count()];

            for (int i = 0; i < ids.Length; i++)
            {
                ids[i] = models[i].IdColaboradorAgir.ToString();
            }

            sql.Add($"DELETE FROM GradeComplementarPersonnalite WHERE IdColaboradorAgir in ({string.Join(',', ids)})");

            return sql;
        }
    }
}
