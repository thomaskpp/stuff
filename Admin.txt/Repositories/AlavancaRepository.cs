﻿
using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Enums;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class AlavancaRepository : IAlavancaRepository
    {
        private readonly string _connectionString;
        private readonly BulkConfig _bulkConfig;

        public AlavancaRepository(IAppConfiguration config)
        {
            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };

            _connectionString = config.GetConnectionStrings("GPSConnection");
        }

        public bool RemoveExistentesPorItem(List<Alavanca> models, GerenciadorCarga gerenciador, Action<GerenciadorCarga> gravarGerenciador, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;
            var passoAtual = gerenciador.Passos.First(x => x.Passo == CargasPassos.Remocao);

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaDeleteScript(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    var contadorLog = 0;

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        cmd.ExecuteNonQuery();

                        passoAtual.LinhasProcessadas = gerenciador.TotalLinhas - sqlList.Count;
                        passoAtual.Atualizado = DateTime.Now;

                        contadorLog++;

                        if (contadorLog % 100 == 0)
                        {
                            gravarGerenciador(gerenciador);
                            contadorLog = 0;
                        }
                    }

                    conn.Close();
                }
            }

            return true;
        }

        private List<string> CriaDeleteScript(List<Alavanca> models)
        {
            var resultado = new List<string>();

            foreach (var item in models)
                resultado.Add($"DELETE FROM dbo.ALAVANCA WHERE MONTH(DataReferencia) = MONTH('{(item.DataReferencia.ToString("yyyy-MM-dd HH:mm:ss"))}') AND YEAR(DataReferencia) = YEAR('{(item.DataReferencia.ToString("yyyy-MM-dd HH:mm:ss"))}')");

            return resultado;
        }
        public async Task<bool> BulkInsert(List<Alavanca> models, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                        sqlList.Add(CriaInsertScript(item));

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        await cmd.ExecuteNonQueryAsync();
                    }

                    conn.Close();
                }
            }

            return true;
        }

        public int InsertSQL(Alavanca model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = CriaInsertScript(model);

                var resultado = cmd.ExecuteNonQuery();

                conn.Close();

                return resultado;
            }
        }

        private string CriaInsertScript(Alavanca item)
        {
return $@"INSERT INTO [dbo].[Alavanca]
([DataCriacao]
,[DataAtualizacao]
,[DataReferencia]
,[CodigoAgencia]
,[AbreviacaoSegmento]
,[CodigoFamilia]
,[NomeFamilia]
,[CodigoItem]
,[NomeItem]
,[ValorICMCiclo]
,[ValorPotencial]
,[ValorCapturado])
VALUES
('{item.DataCriacao.ToString("yyyy-MM-dd HH:mm:ss")}',
'{item.DataAtualizacao.ToString("yyyy-MM-dd HH:mm:ss")}',
'{item.DataReferencia.ToString("yyyy-MM-dd HH:mm:ss")}',
{item.CodigoAgencia},
'{item.AbreviacaoSegmento}',
'{item.CodigoFamilia}',
'{item.NomeFamilia}',
'{item.CodigoItem}',
'{item.NomeItem}',
'{item.ValorICMCiclo.ToString().Replace(',', '.')}',
'{item.ValorPotencial.ToString().Replace(',', '.')}',
'{item.ValorCapturado.ToString().Replace(',', '.')}'
)";

            //            return $@"
            //INSERT INTO PlanejamentoProducaoRealizada
            //(DataCriacao,DataAtualizacao,DataReferencia,CodigoAgencia,Carteira,Grade,Ano,Mes,NomeSegmento,CodigoItem,ValorProducaoRealizada,ValorICMRealizado,ValorPontuacaoRealizada)
            //VALUES (
            //'{item.DataCriacao.ToString("yyyy-MM-dd HH:mm:ss")}',
            //'{item.DataAtualizacao.ToString("yyyy-MM-dd HH:mm:ss")}',
            //'{item.DataReferencia.ToString("yyyy-MM-dd HH:mm:ss")}',
            //{item.CodigoAgencia},
            //'{item.Carteira}',
            //{item.Grade},
            //{item.Ano},
            //{item.Mes},
            //'{item.NomeSegmento}',
            //{item.CodigoItem},
            //{item.ValorProducaoRealizada.ToString().Replace(',', '.')},
            //{item.ValorICMRealizado.ToString().Replace(',', '.')},
            //{item.ValorPontuacaoRealizada.ToString().Replace(',', '.')}
            //) ";

        }

    }
}
