﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class ColaboradorAgirRepository : IColaboradorAgirRepository
    {
        private readonly ISqlDataContext _sqlDataContext;
        private readonly string _connectionString;

        public ColaboradorAgirRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public IEnumerable<Entities.ColaboradorAgir> RetornaCarteirasVaziasParaMetas(short ano, short mes)
        {
            return _sqlDataContext.SelectQueryToList<Entities.ColaboradorAgir>(
                @"select 
                        Id as IdColaboradorAgir,
                        IdSegmento,
                        IdAgencia,
                        Carteira,
                        Grade
                  from ColaboradorAgir
                  where Ano = @ano 
                        AND Mes = @mes
                        AND IdSegmento in (1,2,3)
                        AND IdColaborador IS NULL
                        AND Grade > 0",
                System.Data.CommandType.Text,
                new Dictionary<string, object>()
                {
                    { "ano", ano },
                    { "mes", mes }
                });
        }

        public IEnumerable<Entities.ColaboradorAgir> RetornaCarteirasVazias(short ano, short mes)
        {
            return _sqlDataContext.SelectQueryToList<Entities.ColaboradorAgir>(
                @"select 
                        Id as IdColaboradorAgir,
                        IdSegmento,
                        IdAgencia,
                        Carteira,
                        Grade
                  from ColaboradorAgir
                  where Ano = @ano 
                        AND Mes = @mes
                        AND IdColaborador IS NULL",
                System.Data.CommandType.Text,
                new Dictionary<string, object>()
                {
                    { "ano", ano },
                    { "mes", mes }
                });
        }

        public IEnumerable<Entities.ColaboradorAgir> RetornaTodos(short ano, short mes)
        {
            return _sqlDataContext.SelectQueryToList<Entities.ColaboradorAgir>(
                @"select 
                        Id as IdColaboradorAgir,
                        IdSegmento,
                        IdAgencia,
                        Carteira,
                        Grade,
                        IdColaborador
                  from ColaboradorAgir
                  where Ano = @ano 
                        AND Mes = @mes",
                System.Data.CommandType.Text,
                new Dictionary<string, object>()
                {
                    { "ano", ano },
                    { "mes", mes }
                });
        }

        public int Inserir(List<Entities.ColaboradorAgir> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaScriptInsertUpdate(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        //using (var transaction = conn.BeginTransaction("colabAgir-bulkinsert"))
                        //{
                        //    cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join(Environment.NewLine, sqlTemp.ToArray());

                                resultado += cmd.ExecuteNonQuery();

                                //transaction.Commit();
                            }
                            catch
                            {
                                //try
                                //{
                                //    transaction.Rollback();
                                //}
                                //catch { }

                                //throw;
                            }
                        //}
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        private List<string> CriaScriptInsertUpdate(List<Entities.ColaboradorAgir> models)
        {
            var sql = new List<string>();

            foreach(var item in models)
            {
                if (item.IdColaboradorAgir > 0)
                {
                    sql.Add($@"UPDATE ColaboradorAgir
                                SET IdAgencia = {item.IdAgencia}, Grade = {item.Grade}, IdColaborador = {(item.IdColaborador == 0 ? "NULL" : item.IdColaborador.ToString())}
                                WHERE Id = {item.IdColaboradorAgir}");
                }
                else
                {
                    sql.Add($"INSERT INTO ColaboradorAgir (IdSegmento,IdAgencia,Carteira,Grade,IdColaborador,Ano,Mes)" +
                            $"VALUES ({item.IdSegmento},{item.IdAgencia},'{item.Carteira}',{item.Grade},{(item.IdColaborador == 0 ? "NULL" : item.IdColaborador.ToString())},{item.Ano},{item.Mes})");
                }
            }

            return sql;
        }
    }
}
