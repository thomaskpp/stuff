﻿using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class ConciliacaoPersonnaliteRepository : IConciliacaoPersonnaliteRepository
    {
        private readonly BulkConfig _bulkConfig;
        private readonly string _connectionString;
        private readonly ISqlDataContext _sqlDataContext;

        public ConciliacaoPersonnaliteRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };

            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _sqlDataContext = sqlDataContext;

        }

        public async Task BulkInsert(List<ProducaoRealizadaAnalitico> models, int batchSize)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                        sqlList.Add(CriaInsertScript(item));

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > batchSize ? batchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        await cmd.ExecuteNonQueryAsync();
                    }

                    conn.Close();
                }
            }
        }

        public void InsertSQL(ProducaoRealizadaAnalitico model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = CriaInsertScript(model);

                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private string CriaInsertScript(ProducaoRealizadaAnalitico item)
        {
            return $@"
                INSERT INTO ProducaoRealizadaAnalitico 
                (
                    DataCriacao,
                    DataAtualizacao,
                    DataReferencia,
                    Data,
                    DataDebito,
                    DescricaoProduto,
                    ClienteAgencia,
                    ClienteConta,
                    DescricaoCanal,
                    NomeColaborador,
                    ValorProducao,
                    ValorPonderado,
                    ValorProducaoPonderada,
                    DescricaoStatus,
                    Carteira,
                    CodigoItem,
                    IdAgencia,
                    IdSegmento
                )
                VALUES 
                ('{item.DataCriacao.ToSqlDate()}',
                '{item.DataAtualizacao.ToSqlDate()}',
                '{item.DataReferencia.ToSqlDate()}',
                '{item.Data.ToSqlDate()}',
                '{item.DataDebito.ToSqlDate()}',
                '{item.DescricaoProduto}',
                '{item.ClienteAgencia}',
                '{item.ClienteConta}',
                '{item.DescricaoCanal}',
                '{item.NomeColaborador}',
                {item.ValorProducao},
                {item.ValorPonderado},
                {item.ValorProducaoPonderada},
                '{item.DescricaoStatus}',
                '{item.Carteira}',
                {item.CodigoItem},
                {item.IdAgencia},
                {item.IdSegmento})";
        }

        /// <summary>
        /// Exclui os registros de acordo com o mês de referência, o cod. item, cód. agência e segmento
        /// </summary>
        /// <param name="models"></param>
        public bool RemoveExistentesPorItem(List<PlanejamentoProducaoRealizadaAnaliticoSimples> models, GerenciadorCarga gerenciador, Action<GerenciadorCarga> gravarGerenciador, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;
            var passoAtual = gerenciador.Passos.First(x => x.Passo == CargasPassos.Remocao);

            #region insere dados temporarios para utilizar na remoção

            var sqlList = CriaInsertScriptParaDelete(models);

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    cmd.CommandText = "truncate table ProducaoRealizadaAnaliticoDelete";
                    cmd.ExecuteNonQuery();

                    var contadorLog = 0;

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        cmd.ExecuteNonQuery();

                        passoAtual.LinhasProcessadas = gerenciador.TotalLinhas - sqlList.Count;
                        passoAtual.Atualizado = DateTime.Now;

                        contadorLog++;

                        if (contadorLog % 100 == 0)
                        {
                            gravarGerenciador(gerenciador);
                            contadorLog = 0;
                        }
                    }

                    conn.Close();
                }
            }

            #endregion

            #region remove dados da tabela de destino

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    cmd.CommandText = @"
                        delete p
                        from ProducaoRealizadaAnalitico p
	                        inner join ProducaoRealizadaAnaliticoDelete v on 
                                p.idagencia = v.idagencia and 
                                p.codigoitem = v.codigoitem and 
                                YEAR(p.DataReferencia) = v.ano and 
                                MONTH(p.DataReferencia) = v.mes and 
                                p.carteira = v.carteira
                        ";

                    cmd.ExecuteNonQuery();

                    conn.Close();
                }
            }

            #endregion

            return true;
        }

        private List<string> CriaInsertScriptParaDelete(List<PlanejamentoProducaoRealizadaAnaliticoSimples> models)
        {
            var resultado = new List<string>();

            foreach (var item in models)
                resultado.Add($@"
INSERT INTO ProducaoRealizadaAnaliticoDelete 
(
IdAgencia,
CodigoItem,
Ano,
Mes,
Carteira
) 
VALUES(
{item.IdAgencia}
,{item.CodigoItem}
,{item.Ano}
,{item.Mes}
,'{item.Carteira}'
)
");

            return resultado;
        }

        public void UpdateIndicadorAtivo(int CodigoItem, int IdSegmento, short Mes, short Ano, bool Ativo)
        {
            string query = "ConciliacaoAutomatica_Atualizar_IndicadorAtivoConciliacaoConfiguracoes";

            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { "CODIGOITEM", CodigoItem },
                { "IDSEGMENTO", IdSegmento },
                { "MES", Mes },
                { "ANO", Ano },
                { "INDICADORATIVO", Ativo.GetHashCode() },

            };

            _sqlDataContext.ExecuteNonQuery(query, CommandType.StoredProcedure, parameters);
        }

        public ConciliacaoConfiguracoes ConsultarConciliacaoConfiguracoesPorCodItemMesAnoSegmento(int codItem, short mes, short ano, int IdSegmento)
        {
            Dictionary<string, object> parameters = CriarParametrosProcedure(
                        VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_CONCILIACAOCONFIGURACOES_POR_CODIGOITEM_ANO_MES_SEGMENTO_PARAMETERS_NAME,
                        codItem, ano, mes, IdSegmento);
            var configuracao = GetSingle<ConciliacaoConfiguracoes>(VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_CONCILIACAOCONFIGURACOES_POR_CODIGOITEM_ANO_MES_SEGMENTO,
                                                                   parameters);
            if (configuracao.Id <= 0)
            {
                InsertConfiguracoes(codItem, mes, ano, IdSegmento, true);
                var configuracaoReload = GetSingle<ConciliacaoConfiguracoes>(VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_CONCILIACAOCONFIGURACOES_POR_CODIGOITEM_ANO_MES_SEGMENTO, parameters);
                configuracaoReload.parametros = new List<ConciliacaoParametros>();
                return configuracaoReload;
            }

            if (configuracao.Id > 0)
            {
                Dictionary<string, object> parametros = CriarParametrosProcedure(VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_CONCILIACAO_PARAMETROS_PARAMETERS_NAME,
                                                                                 configuracao.Id);

                var parametrosBase = GetList<ConciliacaoParametros>(VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_CONCILIACAO_PARAMETROS, parametros);

                configuracao.parametros = parametrosBase ?? new List<ConciliacaoParametros>();
            }


            return configuracao;

        }

        public List<ConciliacaoTabelas> ConsultarNomeDasColunas(int codigoItem)
        {
            Dictionary<string, object> parameters = CriarParametrosProcedure(
                        VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_COLUNASCHECKOUTEREALIZADO_PARAMETERS_NAME, codigoItem);
            var criterios = GetList<ConciliacaoTabelas>(VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_COLUNASCHECKOUTEREALIZADO, parameters);

            return criterios;
        }

        public List<ConciliacaoItens> GetConciliacaoItens(int ano, int mes)
        {
            Dictionary<string, object> parameters = CriarParametrosProcedure(
                VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_PLANEJAMENTOITEMGRADECARTEIRA_POR_ANO_MES_CARTEIRA_PARAMETERS_NAME,
                ano, mes);

            return GetList<ConciliacaoItens>(VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_PLANEJAMENTOITEMGRADECARTEIRA_POR_ANO_MES_CARTEIRA, parameters);
        }

        public void InsertConfiguracoes(ConciliacaoConfiguracoes configuracoes)
        {
            
            Dictionary<string, object> parameters = new Dictionary<string, object>();

                parameters = CriarParametrosProcedure(VerificadorProducaoPersonnaliteConfiguration.INSERIR_CONCILIACAOCONFIGURACOES_PARAMETERS_NAME,
                                                    configuracoes.CodigoItem,
                                                    configuracoes.IdSegmento,
                                                    configuracoes.Mes,
                                                    configuracoes.Ano,
                                                    configuracoes.IndicadorAtivo); 

                GetSingle<ConciliacaoConfiguracoes>(VerificadorProducaoPersonnaliteConfiguration.INSERIR_CONCILIACAOCONFIGURACOES, parameters);
            
            
        }
        public void InsertConfiguracoes(int codItem, short mes, short ano, int IdSegmento, bool indicadorAtivo)
        {

            Dictionary<string, object> parameters = new Dictionary<string, object>();

            parameters = CriarParametrosProcedure(VerificadorProducaoPersonnaliteConfiguration.INSERIR_CONCILIACAOCONFIGURACOES_PARAMETERS_NAME,
                                                codItem,
                                                IdSegmento,
                                                mes,
                                                ano,
                                                indicadorAtivo);

            GetSingle<ConciliacaoConfiguracoes>(VerificadorProducaoPersonnaliteConfiguration.INSERIR_CONCILIACAOCONFIGURACOES, parameters);


        }
        public void InsertParametros(ConciliacaoParametros parametros)
        {

                Dictionary<string, object> parameters = new Dictionary<string, object>();

                    parameters = CriarParametrosProcedure(VerificadorProducaoPersonnaliteConfiguration.INSERIR_CONCILIACAO_PARAMETROS_PARAMETERS_NAME,
                                                          parametros.IdConfiguracoes,
                                                          parametros.Data,
                                                          parametros.CodigoChave,
                                                          parametros.ColunaCheckout,
                                                          parametros.ColunaRealizado,
                                                          parametros.Tipo,
                                                          parametros.Criterio,
                                                          parametros.Intervalo,
                                                          parametros.Input);

                GetSingle<ConciliacaoConfiguracoes>(VerificadorProducaoPersonnaliteConfiguration.INSERIR_CONCILIACAO_PARAMETROS, parameters);
            

        }
        public ConciliacaoConfiguracoes ObterConciliacaoConfiguracoes(string codigoItem, string idSegmento, short mes, short ano)
        {
            {
                Dictionary<string, object> parameters = CriarParametrosProcedure(VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_CONCILIACAO_CONFIGURACOES_PARAMETERS_NAME,
                                                                                 codigoItem,
                                                                                 idSegmento,
                                                                                 mes,
                                                                                 ano);

                return GetSingle<ConciliacaoConfiguracoes>(VerificadorProducaoPersonnaliteConfiguration.CONSULTAR_CONCILIACAO_CONFIGURACOES,
                                                           parameters);
            }
        }

        public void DeletarConciliacao(int id)
        {
            Dictionary<string, object> parameters = CriarParametrosProcedure(VerificadorProducaoPersonnaliteConfiguration.DELETAR_CONCILIACAOCONFIGURACOES_PARAMETERS_NAME,
                                                                             id);
            _sqlDataContext.ExecuteNonQuery(VerificadorProducaoPersonnaliteConfiguration.DELETAR_CONCILIACAOCONFIGURACOES,
                                            CommandType.StoredProcedure,
                                            parameters);
        }

        public static class VerificadorProducaoPersonnaliteConfiguration
        {
            const string PARAMETER_NAME_CARTEIRA = "CARTEIRA";
            const string PARAMETER_NAME_CODIGOITEM = "CODIGOITEM";
            const string PARAMETER_NAME_NOMESEGMENTO = "NOMESEGMENTO";
            const string PARAMETER_NAME_IDSEGMENTO = "IDSEGMENTO";
            const string PARAMETER_NAME_MES = "MES";
            const string PARAMETER_NAME_ANO = "ANO";
            const string PARAMETER_NAME_DATA_INICIAL = "DATAINICIAL";
            const string PARAMETER_NAME_DATA_FINAL = "DATAFINAL";
            const string PARAMETER_NAME_INPUT = "INPUT";
            const string PARAMETER_NAME_IDCONFIGURACOES = "IDCONFIGURACOES";

            #region Parâmetros Conciliacao_Configuracao
            const string PARAMETER_NAME_ID = "ID";
            const string PARAMETER_NAME_DATA = "DATA";
            const string PARAMETER_NAME_CODIGOCHAVE = "CODIGOCHAVE";
            const string PARAMETER_NAME_COLUNACHECKOUT = "COLUNACHECKOUT";
            const string PARAMETER_NAME_COLUNAREALIZADO = "COLUNAREALIZADO";
            const string PARAMETER_NAME_TIPO = "TIPO";
            const string PARAMETER_NAME_CRITERIO = "CRITERIO";
            const string PARAMETER_NAME_INTERVALO = "INTERVALO";
            const string PARAMETER_NAME_INDICADORATIVO = "INDICADORATIVO";
            #endregion


            #region Conciliacao Automatica VP Personnalité - Procedures
            /// <summary>
            /// Procedure para consulta na tabela PlanejamentoGradeCarteira filtrando por Ano, Mes e Carteira.
            /// Parametros:
            /// CARTEIRA |
            /// ANO |
            /// MES
            /// </summary>
            public static string CONSULTAR_PLANEJAMENTOITEMGRADECARTEIRA_POR_ANO_MES_CARTEIRA => "ConciliacaoAutomatica_Consultar_ItensDiponiveisMesAno_Personnalite";
            public static string[] CONSULTAR_PLANEJAMENTOITEMGRADECARTEIRA_POR_ANO_MES_CARTEIRA_PARAMETERS_NAME => new string[] { PARAMETER_NAME_MES, PARAMETER_NAME_ANO };

            /// <summary>
            /// Procedure para consulta das colunas das tabelas CheckoutPersonnalite e ProducaoRealizadaPersonnalite.
            /// </summary>
            public static string CONSULTAR_COLUNASCHECKOUTEREALIZADO => "ConciliacaoAutomatica_Configuracoes_PreencherCombos_Personnalite";
            public static string[] CONSULTAR_COLUNASCHECKOUTEREALIZADO_PARAMETERS_NAME => new string[] { PARAMETER_NAME_CODIGOITEM };

            /// <summary>
            /// Procedure para consulta das colunas das tabelas PlanejamentoCheckout e PlanejamentoProducaoRealizada.
            /// </summary>
            public static string CONSULTAR_CONCILIACAO_CONFIGURACOES => "ConciliacaoAutomatica_Obter_Configuracoes";
            public static string[] CONSULTAR_CONCILIACAO_CONFIGURACOES_PARAMETERS_NAME => new string[] { PARAMETER_NAME_CODIGOITEM, PARAMETER_NAME_IDSEGMENTO, PARAMETER_NAME_MES, PARAMETER_NAME_ANO };
            /// <summary>
            /// Procedure para consulta na tabela ConciliacaoConfiguracoes filtrando por CodigoItemm, Ano, Mes e IdSegmento.
            /// Parametros:
            /// CARTEIRA |
            /// ANO |
            /// MES
            /// </summary>
            public static string CONSULTAR_CONCILIACAOCONFIGURACOES_POR_CODIGOITEM_ANO_MES_SEGMENTO => "ConciliacaoAutomatica_Consultar_ConfiguracoesPorItemMesAnoSegmento";
            public static string[] CONSULTAR_CONCILIACAOCONFIGURACOES_POR_CODIGOITEM_ANO_MES_SEGMENTO_PARAMETERS_NAME => new string[] { 
                PARAMETER_NAME_CODIGOITEM,
                PARAMETER_NAME_ANO,
                PARAMETER_NAME_MES,
                PARAMETER_NAME_IDSEGMENTO };

            /// <summary>
            /// Procedure para consulta na tabela ConciliacaoConfiguracoes filtrando por CodigoItemm, Ano, Mes e IdSegmento.
            /// Parametros:
            /// CARTEIRA |
            /// ANO |
            /// MES
            /// </summary>
            public static string CONSULTAR_CONCILIACAO_PARAMETROS => "ConciliacaoAutomatica_Obter_PARAMETROS";
            public static string[] CONSULTAR_CONCILIACAO_PARAMETROS_PARAMETERS_NAME => new string[] { PARAMETER_NAME_IDCONFIGURACOES };


            public static string INSERIR_CONCILIACAOCONFIGURACOES => "ConciliacaoAutomatica_Inserir_Configuracoes";
            public static string[] INSERIR_CONCILIACAOCONFIGURACOES_PARAMETERS_NAME => new string[] {
                PARAMETER_NAME_CODIGOITEM,
                PARAMETER_NAME_IDSEGMENTO ,
                PARAMETER_NAME_MES,
                PARAMETER_NAME_ANO ,
                PARAMETER_NAME_INDICADORATIVO               
                };

            public static string INSERIR_CONCILIACAO_PARAMETROS => "ConciliacaoAutomatica_Inserir_Parametros";
            public static string[] INSERIR_CONCILIACAO_PARAMETROS_PARAMETERS_NAME => new string[] {
                PARAMETER_NAME_IDCONFIGURACOES,
                PARAMETER_NAME_DATA,
                PARAMETER_NAME_CODIGOCHAVE,
                PARAMETER_NAME_COLUNACHECKOUT,
                PARAMETER_NAME_COLUNAREALIZADO,
                PARAMETER_NAME_TIPO,
                PARAMETER_NAME_CRITERIO,
                PARAMETER_NAME_INTERVALO,
                PARAMETER_NAME_INPUT
                };
            public static string ATUALIZAR_CONCILIACAOCONFIGURACOES => "ConciliacaoAutomatica_Atualizar_Configuracoes";
            public static string[] ATUALIZAR_CONCILIACAOCONFIGURACOES_PARAMETERS_NAME => new string[] {
                PARAMETER_NAME_ID,
                PARAMETER_NAME_CODIGOITEM,
                PARAMETER_NAME_IDSEGMENTO ,
                PARAMETER_NAME_DATA,
                PARAMETER_NAME_MES,
                PARAMETER_NAME_ANO ,
                PARAMETER_NAME_CODIGOCHAVE,
                PARAMETER_NAME_COLUNACHECKOUT,
                PARAMETER_NAME_COLUNAREALIZADO,
                PARAMETER_NAME_TIPO,
                PARAMETER_NAME_CRITERIO,
                PARAMETER_NAME_INTERVALO,
                PARAMETER_NAME_INPUT
                };

            public static string DELETAR_CONCILIACAOCONFIGURACOES => "ConciliacaoAutomatica_Deletar_Parametros";
            public static string[] DELETAR_CONCILIACAOCONFIGURACOES_PARAMETERS_NAME => new string[] { PARAMETER_NAME_ID };

            public static string DELETAR_CONCILIACAOCONFIGURACOES_CODIGOITEMSEGMENTOMESANO => "ConciliacaoAutomatica_Deletar_ConciliacaoConfiguracoesCodigoItemSegmentoAnoMes";
            public static string[] DELETAR_CONCILIACAOCONFIGURACOES_CODIGOITEMSEGMENTOMESANO_PARAMETERS_NAME => new string[] { PARAMETER_NAME_CODIGOITEM, PARAMETER_NAME_IDSEGMENTO, PARAMETER_NAME_MES, PARAMETER_NAME_ANO };
            #endregion
        }

        #region [ Auxiliares ]

        T GetSingle<T>(string procedureName, Dictionary<string, object> parameters) where T : class, new()
        {
            return _sqlDataContext.SelectQuerySingleOrDefault<T>(procedureName, parameters, CommandType.StoredProcedure);
        }

        List<T> GetList<T>(string procedureName, Dictionary<string, object> parameters) where T : class
        {
            IEnumerable<T> list = null;

            list = _sqlDataContext.SelectQueryToList<T>(procedureName, CommandType.StoredProcedure, parameters);

            if (list is null)
                return new List<T>();

            return list.ToList();
        }

        Dictionary<string, object> CriarParametrosProcedure(string[] paramsName, params object[] paramsValue)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            for (int i = 0; i < paramsName.Length; i++)
            {
                parameters.Add(paramsName[i], paramsValue[i]);
            }
            return parameters;
        }

        #endregion
    }
}
