﻿using Itau.SZ7.GPS.Admin.Areas.Home.Exceptions;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Domain.Home.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class HomeTemplateRepository : IHomeTemplateRepository
    {
        private readonly ISqlDataContext _sqlDataContext;

        public HomeTemplateRepository(ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
        }

        public async Task<int> InserirAsync(HomeTemplate homeTemplate)
        {
            var parametros = new Dictionary<string, object>()
            {
                {"Nome", homeTemplate.Nome },
                {"Html", homeTemplate.Html },
                {"Status", homeTemplate.Status },
                {"ModeloTemplate", homeTemplate.ModeloTemplate },
                {"Colaboradores", ConvertToDataTable(homeTemplate.Funcionais)},
                {"DataCriacao", DateTime.Now}

            };

            return await _sqlDataContext.ExecuteNonQueryAsync("HomeTemplate_Inserir_ComColaboradores", CommandType.StoredProcedure, parametros);
        }

        public async Task<HomeTemplate> ObterPorIdAsync(int id)
        {
            var parametros = new Dictionary<string, object>()
            {
                {"@Id", id }
            };

            return await _sqlDataContext.SelectQuerySingleOrDefaultAsync<HomeTemplate>("HomeTemplate_Obter_PorId", parametros, CommandType.StoredProcedure);
        }

        public async Task<object> ExisteTemplatePadrao(int id)
        {
            var parametros = new Dictionary<string, object>()
            {
                {"Id", id }
            };

            return await _sqlDataContext.ExecuteScalarAsync("HomeTemplate_Obter_IdTemplatePadrao", CommandType.StoredProcedure, parametros);
        }

        public async Task<int> EditarAsync(HomeTemplate homeTemplate)
        {
            var parametros = new Dictionary<string, object>()
            {
                {"@id", homeTemplate.Id },
                {"@nome", homeTemplate.Nome },
                {"@html", homeTemplate.Html },
                {"@status", homeTemplate.Status },
                {"@DataAtualizacao", DateTime.Now },
                {"@colaboradores", ConvertToDataTable(homeTemplate.Funcionais)}
            };

            return await _sqlDataContext.ExecuteNonQueryAsync("HomeTemplate_Alterar_PorColaboradores", CommandType.StoredProcedure, parametros);
        }

        public async Task<IEnumerable<HomeTemplate>> ListarAsync()
        {
            return await _sqlDataContext.SelectQueryToListAsync<HomeTemplate>("HomeTemplate_Obter_ListaOrdenada");
        }

        public async Task<IEnumerable<string>> ListarFuncionaisPorIdTemplateAsync(int id)
        {
            var parametros = new Dictionary<string, object>()
            {
                {"@id", id }
            };

            return await _sqlDataContext.SelectQueryToListAsync<string>("HomeTemplate_ObterColaboradores_PorIdTemplate", CommandType.StoredProcedure, parametros);
        }

        public async Task<int> ExcluirAsync(int id)
        {
            var parametros = new Dictionary<string, object>()
            {
                {"Id", id }
            };

            return await _sqlDataContext.ExecuteNonQueryAsync("HomeTemplate_Remover_RemoverHomeTemplateColaborador", CommandType.StoredProcedure, parametros);
        }

        public async Task<string> ObterPorFuncionalAsync(string funcional)
        {
            var parametros = new Dictionary<string, object>()
            {
                {"@funcional", funcional }
            };

            var homeTemplate = await _sqlDataContext.SelectQuerySingleOrDefaultAsync<HomeTemplate>("HomeTemplateObterPorFuncional", parametros, CommandType.StoredProcedure);

            if (homeTemplate.Html == null)
            {
                throw new ModeloHomeTemplateNaoEncontradoException();
            }

            return homeTemplate.Html;
        }

        private DataTable ConvertToDataTable(IEnumerable<string> lista)
        {
            var dataTable = new DataTable();

            dataTable.Columns.Add("funcional", typeof(string));

            foreach (var item in lista)
            {
                var row = dataTable.NewRow();

                row[0] = item;
                dataTable.Rows.Add(row);
            }

            return dataTable;
        }
    }
}
