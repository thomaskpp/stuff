﻿
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class InnerLoopMetaRepository : IInnerLoopMetaRepository
    {
        public InnerLoopMetaRepository(IAppConfiguration appConfiguration)
        {
        }
    }
}
