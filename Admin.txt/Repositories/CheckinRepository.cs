﻿using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class CheckinRepository : ICheckinRepository
    {
        private readonly string _connectionString;
        private readonly BulkConfig _bulkConfig;
        private readonly ISqlDataContext _sqlDataContext;

        public CheckinRepository(  IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext  )
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };
            _sqlDataContext = sqlDataContext;          
        }

        public const string PerformanceTime = "perfomance do time";
        private const string KeyMeta = "Meta";
        private const string KeyPeso = "Peso";
        private const string KeyICMMaximo = "IcmMaximo";

        #region RECALCULAR AGIR
        public List<PlanejamentoCheckin> GetPlanejamentoCheckinsByAnoMes(short? ano, short? mes)
        {
            try
            {
                var resultado = new List<PlanejamentoCheckin>();

                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    cmd.CommandText = $@"
                                         SELECT ckn.[Id]
		                                        ,ca.[IdAgencia]
		                                        ,ca.[Carteira]
		                                        ,ca.[Grade]
		                                        ,ca.[Ano]
		                                        ,ca.[Mes]
                                                ,ca.Id IdColaboradorAgir
		                                        ,pni.[CodigoItem]
		                                        ,ckn.[DataCriacao]
		                                        ,ckn.[ValorPontuacaoPlanejada]
		                                        ,ckn.[ValorProducaoPlanejada]
                                                ,pni.IdPlanejamento
                                                ,pni.Id IdPlanejamentoItem
		                                        FROM Planejamento p 
		                                        INNER JOIN PlanejamentoItem pni ON pni.IdPlanejamento = p.id
		                                        INNER JOIN [Checkin] ckn on pni.Id = ckn.IdPlanejamentoItem
		                                        INNER JOIN ColaboradorAgir ca ON ca.id = ckn.idColaboradorAgir
		                                        WHERE ca.Mes = {mes} AND ca.Ano = {ano}
		                                        ORDER BY ano, mes, carteira, codigoitem";

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                resultado.Add(new PlanejamentoCheckin()
                                {
                                    Id = reader.SafeGetInt32(0),
                                    IdAgencia = reader.SafeGetInt32(1),
                                    Carteira = reader.SafeGetString(2),
                                    Grade = reader.SafeGetInt16(3),
                                    Ano = reader.SafeGetInt16(4),
                                    Mes = reader.SafeGetInt16(5),
                                    CodigoItem = reader.SafeGetInt32(6),
                                    DataCriacao = reader.SafeGetDateTimeNotNull(7),
                                    ValorPontuacaoPlanejada = reader.SafeGetDecimal(8),
                                    ValorProducaoPlanejada = reader.SafeGetDecimal(9),
                                });
                            }
                        }
                    }

                    conn.Close();
                }

                return resultado;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<PlanejamentoCheckin> GetPlanejamentoPersonnaliteCheckinsByAnoMes(short? ano, short? mes)
        {
            try
            {
                var resultado = new List<PlanejamentoCheckin>();

                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    cmd.CommandText = $@" 
						SELECT ckn.[Id]
                               ,Ca.[IdAgencia]
                               ,Ca.[Carteira]
                               ,Ca.[Grade]
                               ,Ca.[Ano]
                               ,Ca.[Mes]
                               ,pip.[CodigoItem]
                               ,Ckn.[DataCriacao]
                               ,Ckn.[ValorPontuacaoPlanejada]
                               ,Ckn.[ValorProducaoPlanejada]
                               FROM PlanejamentoPersonnalite P 
                               INNER JOIN PlanejamentoItemPersonnalite pip ON pip.IdPlanejamento = P.id
                               INNER JOIN [CheckinPersonnalite] Ckn on pip.Id = Ckn.IdPlanejamentoItem
                               INNER JOIN ColaboradorAgir Ca ON Ca.id = Ckn.idColaboradorAgir
                               WHERE Ca.Mes = {mes} AND Ca.Ano = {ano}
                               ORDER BY ano, mes, carteira, codigoitem";

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                resultado.Add(new PlanejamentoCheckin()
                                {
                                    Id = (Int32)reader.SafeGetInt64(0),
                                    IdAgencia = reader.SafeGetInt32(1),
                                    Carteira = reader.SafeGetString(2),
                                    Grade = reader.SafeGetInt16(3),
                                    Ano = reader.SafeGetInt16(4),
                                    Mes = reader.GetByte(5),
                                    CodigoItem = reader.SafeGetInt32(6),
                                    DataCriacao = reader.SafeGetDateTimeNotNull(7),
                                    ValorPontuacaoPlanejada = reader.SafeGetDecimal(8),
                                    ValorProducaoPlanejada = reader.SafeGetDecimal(9),
                                });
                            }
                        }
                    }

                    conn.Close();
                }

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int BulkInsertUpdatePlanejamentoCheckin(List<PlanejamentoCheckin> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                        sqlList.Add(CriaInsertUpdateScriptPesos(item));

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("produtogradeitem-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = cmd.ExecuteNonQuery();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        public async Task<int> BulkInsertUpdatePlanejamentoCheckinPersonnalite(List<PlanejamentoCheckin> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                        sqlList.Add(CriaInsertUpdateScriptPesosPersonnalite(item));

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("produtogradeitem-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = await cmd.ExecuteNonQueryAsync();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        private string CriaInsertUpdateScriptPesos(PlanejamentoCheckin item)
        {

            return $@"UPDATE [dbo].[Checkin]
                        SET [DataAtualizacao] = getdate()
                        ,[ValorPontuacaoPlanejada] = '{item.ValorPontuacaoPlanejada}'
					    FROM Checkin ckn
                            WHERE ckn.id = {item.Id}";
        }

        private string CriaInsertUpdateScriptPesosPersonnalite(PlanejamentoCheckin item)
        {

            return $@"UPDATE [dbo].[CheckinPersonnalite]
                        SET [DataAtualizacao] = getdate()
                        ,[ValorPontuacaoPlanejada] = '{item.ValorPontuacaoPlanejada}'
					    FROM CheckinPersonnalite 
                            WHERE ckn.id = {item.Id}";
        }

        private List<string> CriaDeleteScript(List<PlanejamentoCheckin> models)
        {
            var resultado = new List<string>();

            foreach (var item in models)
                resultado.Add($@"");

            return resultado;
        }

        public List<PlanejamentoCheckin> GetAllCheckinsMesAno(int Mes, int Ano)
        {
            return _sqlDataContext.SelectQueryToList<PlanejamentoCheckin>($"SELECT * FROM Checkin WITH(NOLOCK) WHERE Mes={Mes} AND Ano={Ano}").ToList();
        }

        public bool RemoveExistentesPorItem(List<PlanejamentoCheckin> models, GerenciadorCarga gerenciador, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;
            var passoAtual = gerenciador.Passos.First(x => x.Passo == CargasPassos.Remocao);

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaDeleteScript(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    var contadorLog = 0;

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        cmd.ExecuteNonQuery();

                        passoAtual.LinhasProcessadas = gerenciador.TotalLinhas - sqlList.Count;
                        passoAtual.Atualizado = DateTime.Now;

                        contadorLog++;

                        if (contadorLog % 100 == 0)
                        {
                            //gravarGerenciador(gerenciador);
                            contadorLog = 0;
                        }
                    }

                    conn.Close();
                }
            }

            return true;
        }

        public async Task<IEnumerable<PlanejamentoCheckin>> GetAllCheckinsMesAnoAsync(int Mes, int Ano)
        {
            return await _sqlDataContext.SelectQueryToListAsync<PlanejamentoCheckin>($"SELECT * FROM Checkin WITH(NOLOCK) WHERE Mes={Mes} AND Ano={Ano}");
        }
        #endregion
    }
}
