﻿using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Extensions;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class FeriadoRepository : IFeriadoRepository
    {
        private readonly BulkConfig _bulkConfig;
        private readonly string _connectionString;
        private readonly ISqlDataContext _sqlDataContext;

        public FeriadoRepository(IAppConfiguration appConfiguration, ISqlDataContext SqlDataContext)
        {
            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };

            _sqlDataContext = SqlDataContext;
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public bool RemoveExistentesPorItem(List<Feriado> models, GerenciadorCarga gerenciador, Action<GerenciadorCarga> gravarGerenciador, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;
            var passoAtual = gerenciador.Passos.First(x => x.Passo == CargasPassos.Remocao);

            #region insere dados temporarios para utilizar na remoção           

            #endregion
            return true;
        }
        public async Task BulkInsertAsync(List<Feriado> models, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                        sqlList.Add(CriaInsertScript(item));

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        await cmd.ExecuteNonQueryAsync();
                    }

                    conn.Close();
                }
            }
        }

        private string CriaInsertScript(Feriado item)
        {
            return $@"IF NOT EXISTS(SELECT TOP 1 [idAgencia] FROM [Feriado] (NOLOCK) WHERE [idAgencia] = {item.idAgencia} AND Data = '{item.Data.ToString("yyyy-MM-dd HH:mm:ss")}')
                    INSERT INTO [Feriado]
                    ([idAgencia]
                    ,[Data])
                    VALUES
                    ({item.idAgencia}
                    ,'{item.Data.ToString("yyyy-MM-dd HH:mm:ss")}')";
        }

        public void InsertSQL(Feriado model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = CriaInsertScript(model);

                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        public async Task<IEnumerable<Feriado>> GetAllFeriados(int Mes, int Ano)
        {
            return await _sqlDataContext.SelectQueryToListAsync<Feriado>($"SELECT * FROM Feriado WITH(NOLOCK) WHERE Data BETWEEN '{new DateTime(Ano, Mes, 1).ToSqlDate()}' AND '{new DateTime(Ano, Mes, 1).AddMonths(1).AddDays(-1).ToSqlDate()}'");
        }

        public async Task<IEnumerable<Feriado>> GetAllFeriadosByAgenciaAndDate(int codigoAgencia, DateTime dataInicial, DateTime dataFinal)
        {
            return await _sqlDataContext.SelectQueryToListAsync<Feriado>($"SELECT * FROM [dbo].[Feriado] WITH(NOLOCK) WHERE CodigoAgencia = {codigoAgencia} AND Data BETWEEN '{dataInicial.ToSqlDate()}' AND '{dataFinal.ToSqlDate()}'");
        }
    }
}
