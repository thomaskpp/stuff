﻿using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Domain.Base.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories
{
    public interface IColaboradorEngajamentoRepository
    {                
        Task<IEnumerable<ColaboradorEngajamento>> GetAllEngajamentos(int mes, int ano);
        Task<bool> UpdateEngajamento(List<ColaboradorEngajamento> engajamentos);
        Task<bool> InsertEngajamento(List<ColaboradorEngajamento> engajamentos);
        void LimparTabelaEngajamento();

    }
}
