﻿
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;

using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class InnerLoopAgenciaNucleoRepository : IInnerLoopAgenciaNucleoRepository
    {

        private readonly ISqlDataContext _sqlDataContext;

        public InnerLoopAgenciaNucleoRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext) 
        {
            _sqlDataContext = sqlDataContext;
        }

        public bool CheckAgenciaAtendidaPeloNucleo(int codAgencia)
        {

            Dictionary<string, object> param = new Dictionary<string, object>
                        {
                        { "@codigoAgencia", codAgencia }
                    };

            string query = "SELECT * FROM InnerLoopAgenciaNucleo (NOLOCK) WHERE CodigoAgencia = @codigoAgencia";

            InnerLoopAgenciaNucleo agencia = _sqlDataContext.SelectQuerySingleOrDefault<InnerLoopAgenciaNucleo>(query, param);

            return agencia != null && agencia.AtendidaPeloNucleo;

        }
    }
}