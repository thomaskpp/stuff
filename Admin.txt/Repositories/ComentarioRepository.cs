﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class ComentarioRepository : IComentarioRepository
    {
        public ComentarioRepository(IAppConfiguration appConfiguration)
        {
        }
    }
}
