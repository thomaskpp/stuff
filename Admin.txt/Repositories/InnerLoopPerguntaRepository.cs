﻿using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class InnerLoopPerguntaRepository : IInnerLoopPerguntaRepository
    {

        private readonly BulkConfig _bulkConfig;
        private readonly string _connectionString;

        public InnerLoopPerguntaRepository(IAppConfiguration appConfiguration)
        {
            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };

            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public void BulkInsert(List<InnerLoopPergunta> models, int? batchSize)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaInsertScript(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        SqlTransaction transaction = conn.BeginTransaction("bulkinsert");
                        cmd.Transaction = transaction;

                        try
                        {
                            var sqlTemp = new List<string>();
                            var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                            sqlTemp.AddRange(sqlList.Take(_batchSize));
                            sqlList.RemoveRange(0, _batchSize);

                            cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                            cmd.ExecuteNonQuery();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            try
                            {
                                transaction.Rollback();
                            }
                            catch (Exception ex2)
                            {
                                throw ex2;
                            }

                            throw ex;
                        }

                    }

                    conn.Close();
                }
            }
        }

        public void InsertSQL(InnerLoopPergunta model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = CriaInsertScript(model);

                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        public void InativarArvore(int segmento)
        {
            int seg = segmento;            

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;
                    cmd.CommandText = $"UPDATE InnerLoopPergunta set Ativo = 0 WHERE IdSegmento = { seg }";
                    conn.Open();
                    cmd.ExecuteNonQuery();                    
                    conn.Close();
                }
            }
        }

        private List<string> CriaInsertScript(List<InnerLoopPergunta> perguntas)
        {
            var resultado = new List<string>();

            foreach (var pergunta in perguntas)
            {
                resultado.Add(CriaInsertScript(pergunta));
            }

            return resultado;
        }

        private string CriaInsertScript(InnerLoopPergunta pergunta)
        {
            var resultado = $"INSERT INTO InnerLoopPergunta (DataCriacao, DataAtualizacao, NumeroPergunta, NumeroPerguntaPai, Descricao, IdSegmento, Ativo, Relatorio, Tipo) " +
                            $"VALUES (" +
                            $"'{pergunta.DataCriacao.ToString("yyyy-MM-dd HH:mm:ss")}'," +
                            $"'{pergunta.DataAtualizacao.ToString("yyyy-MM-dd HH:mm:ss")}'," +
                            $"{pergunta.NumeroPergunta}," +
                            $"{pergunta.NumeroPerguntaPai}," +
                            $"'{pergunta.Descricao}'," +
                            $"{pergunta.IdSegmento}," +
                            $"1," +
                            $"'{pergunta.Relatorio}'," +
                            $"'{pergunta.Tipo}')";

            return resultado;
        }
    }
}
