﻿
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class GerenciamentoCoachClickRepository : IGerenciamentoCoachClickRepository
    {
        public GerenciamentoCoachClickRepository(IAppConfiguration appConfiguration)
        {
        }
    }
}
