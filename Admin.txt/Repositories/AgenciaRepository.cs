﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Entities.DTO;
using Itau.SZ7.GPS.Admin.Helpers;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Extensions;
using System.Text;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class AgenciaRepository : IAgenciaRepository
    {
        private readonly ISqlDataContext _sqlDataContext;
        private readonly string _connectionString;

        public AgenciaRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public IEnumerable<Agencia> GetAgencias()
        {
            return _sqlDataContext.SelectQueryToList<Agencia>(
                    $@"SELECT * FROM Agencia (NOLOCK)");
        }

        public IEnumerable<Entities.AgenciaMigracao> ObterAgencias()
        {
            return _sqlDataContext.SelectQueryToList<Entities.AgenciaMigracao>(
                    $@"SELECT * FROM Agencia (NOLOCK)");
        }

        #region metodos cargas

        public int BulkInsertUpdate(List<AgenciaMigracaoTemp> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                        sqlList.Add(CriaInsertUpdateScript(item));

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("agencia-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = $"DECLARE @idAgencia INT = 0 " +
                                                "DECLARE @proxId INT = 0 " +
                                    $"{string.Join("\n", sqlTemp.ToArray())}";

                                resultado = cmd.ExecuteNonQuery();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        public int BulkInsertUpdate(List<AgenciaCoordenadoraRetroativo> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                    {

                        sqlList.Add(CriaInsertUpdateScript(item));
                    }

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("agenciacordenadora-retroativo-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = cmd.ExecuteNonQuery();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        private string CriaInsertUpdateScript(AgenciaCoordenadoraRetroativo item)
        {
            return $@"BEGIN
                      UPDATE Agencia SET IdAgenciaCoordenadora= (SELECT TOP 1 Id FROM Agencia (NOLOCK) WHERE Codigo= '{item.CodigoAgenciaCoordenadora}')
                        WHERE Codigo = '{item.CodigoAgenciaFilha}'
                      END
                    ";
        }

        private string CriaInsertUpdateScript(AgenciaMigracaoTemp item)
        {
            var sql = $@"
        
                            IF EXISTS(SELECT TOP (1) 1 FROM Agencia (NOLOCK) WHERE Codigo = '{item.Codigo}')
                            BEGIN

                                SET @idAgencia = (SELECT TOP 1 Id FROM Agencia (NOLOCK) WHERE Codigo = '{item.Codigo}')

                                UPDATE Agencia 
                                SET 
                                    Ativo = {(item.Ativo ? 1 : 0)},
                                    DataAtualizacao = '{DateTime.Now.ToSqlDate()}',
                                    ValorLatitude = {(!string.IsNullOrEmpty(item.ValorLatitudeString) ? $"REPLACE('{item.ValorLatitudeString}', ',', '.')" : "NULL")},
                                    ValorLongitude = {(!string.IsNullOrEmpty(item.ValorLongitudeString) ? $"REPLACE('{item.ValorLongitudeString}', ',', '.')" : "NULL")},
                                    TextoEndereco = {(string.IsNullOrEmpty(item.TextoEndereco) ? "NULL" : $"'{item.TextoEndereco.Replace("'", "")}'")},
                                    SiglaEstado = {(string.IsNullOrEmpty(item.SiglaEstado) ? "NULL" : $"'{item.SiglaEstado}'")},
                                    NomeCidade = {(string.IsNullOrEmpty(item.NomeCidade) ? "NULL" : $"'{item.NomeCidade.Replace("'", "")}'")}
                                WHERE Id = @idAgencia

                            END ELSE BEGIN

                                SELECT @proxId = MAX(Id) + 1 FROM Agencia

                                SET IDENTITY_INSERT Agencia ON

                                INSERT INTO [dbo].[Agencia]
                                    ([Id]
                                    ,[DataCriacao]
                                    ,[DataAtualizacao]
                                    ,[Codigo]
                                    ,[Ativo]
                                    ,[ValorLatitude]
                                    ,[ValorLongitude]
                                    ,[TextoEndereco]
                                    ,[SiglaEstado]
                                    ,[NomeCidade]
                                    ,[IdAgenciaCoordenadora])
                                VALUES
                                    (@proxId
                                    ,'{DateTime.Now.ToSqlDate()}'
                                    ,'{DateTime.Now.ToSqlDate()}'
                                    ,'{item.Codigo}'
                                    ,{(item.Ativo ? 1 : 0)}
                                    ,{(!string.IsNullOrEmpty(item.ValorLatitudeString) ? $"REPLACE('{item.ValorLatitudeString}', ',', '.')" : "NULL")}
                                    ,{(!string.IsNullOrEmpty(item.ValorLongitudeString) ? $"REPLACE('{item.ValorLongitudeString}', ',', '.')" : "NULL")}
                                    ,{(string.IsNullOrEmpty(item.TextoEndereco) ? "NULL" : $"'{item.TextoEndereco.Replace("'", "")}'")}
                                    ,{(string.IsNullOrEmpty(item.SiglaEstado) ? "NULL" : $"'{item.SiglaEstado}'")}
                                    ,{(string.IsNullOrEmpty(item.NomeCidade) ? "NULL" : $"'{item.NomeCidade.Replace("'", "")}'")}
                                    ,{(item.IdAgenciaCoordenadora > 0 ? item.IdAgenciaCoordenadora.ToString() : "NULL")}                        
                                    )

                                SET @idAgencia = @@IDENTITY

                                SET IDENTITY_INSERT Agencia OFF

                            END";

            if (item.IdAgenciaCoordenadora == 0)
            {
                sql += $@"

                        IF (@idAgencia > 0) BEGIN
                            UPDATE Agencia SET IdAgenciaCoordenadora = @idAgencia WHERE Id = @idAgencia
                        END";
            }

            if (item.AgenciaEstrutura != null)
            {
                sql += CriaAgenciaEstruturaInsertUpdateScript(item.AgenciaEstrutura, item.IdSegmentos);
            }

            return sql;
        }

        public AgenciaEstrutura ObterAgenciaEstrutura(int segmento, int agencia)
        {
            var sql = $@"SELECT
                        Id,
                        IdAgencia,
                        IdSegmento,
                        IdPoloRegional,
                        IdPoloRegiao,
                        IdPoloDicom,
                        IdHierarquiaNivel
                    FROM AgenciaEstrutura (NOLOCK)";

                sql += $" WHERE IdSegmento = {segmento} and IdAgencia = {agencia}";

            IEnumerable<AgenciaEstrutura> agenciaEstrutura = _sqlDataContext.SelectQueryToList<AgenciaEstrutura>(sql);

            if (agenciaEstrutura != null)
                return agenciaEstrutura.FirstOrDefault();
            else
                return null;
        }

        public IEnumerable<AgenciaEstrutura> ObterAgenciaEstrutura(IEnumerable<int> segmentos = null)
        {
            var sql = $@"SELECT
                        Id,
                        IdAgencia,
                        IdSegmento,
                        IdPoloRegional,
                        IdPoloRegiao,
                        IdPoloDicom,
                        IdHierarquiaNivel
                    FROM AgenciaEstrutura (NOLOCK)";

            if (segmentos != null && segmentos.Any())
                sql += $" WHERE IdSegmento in ({string.Join(',', segmentos)})";

            return _sqlDataContext.SelectQueryToList<AgenciaEstrutura>(sql);
        }

        public IEnumerable<AgenciaEstrutura> ObterAgenciaEstruturaPorPolos(int[] idPolos)
        {
            string joined = string.Join(',', idPolos);
            return _sqlDataContext.SelectQueryToList<Entities.AgenciaEstrutura>(
                   $@"SELECT * FROM AgenciaEstrutura (NOLOCK) WHERE IdPoloDicom IN ({joined}) OR IdPoloRegiao IN ({joined}) OR IdPoloRegional IN ({joined})");
        }

        private string CriaAgenciaEstruturaInsertUpdateScript(AgenciaEstrutura item, int[] idSegmentos)
        {
            var sql = new StringBuilder();

            if (idSegmentos != null)
            {
                foreach (var idSegmento in idSegmentos)
                {
                    sql.Append($@"

IF EXISTS(SELECT TOP (1) Id FROM AgenciaEstrutura (NOLOCK) WHERE IdAgencia = @idAgencia AND IdSegmento = {idSegmento})
BEGIN 

    UPDATE AgenciaEstrutura SET 
        IdAgencia = @idAgencia
        ,IdPoloRegional = {(item.IdPoloRegional > 0 ? item.IdPoloRegional.ToString() : "NULL")}
        ,IdPoloDicom = {(item.IdPoloDicom > 0 ? item.IdPoloDicom.ToString() : "NULL")}
        ,IdPoloRegiao = {(item.IdPoloRegiao > 0 ? item.IdPoloRegiao.ToString() : "NULL")}
        ,IdSegmento = {idSegmento}
        ,IdHierarquiaNivel = {item.IdHierarquiaNivel}
    WHERE IdAgencia = @idAgencia AND IdSegmento = {idSegmento}

END ELSE BEGIN 

    SELECT @proxId = MAX(Id) + 1 FROM AgenciaEstrutura

    SET IDENTITY_INSERT AgenciaEstrutura ON

    INSERT INTO AgenciaEstrutura (Id, IdAgencia, IdPoloRegional, IdPoloDicom, IdPoloRegiao, IdSegmento, IdHierarquiaNivel) 
        VALUES (
            @proxId
            ,@idAgencia 
            ,{(item.IdPoloRegional > 0 ? item.IdPoloRegional.ToString() : "NULL")}
            ,{(item.IdPoloDicom > 0 ? item.IdPoloDicom.ToString() : "NULL")}
            ,{(item.IdPoloRegiao > 0 ? item.IdPoloRegiao.ToString() : "NULL")}
            ,{idSegmento}
            ,{item.IdHierarquiaNivel})

    SET IDENTITY_INSERT AgenciaEstrutura OFF

END");
                }
            }

            return sql.ToString();
        }

        #region Metodos completar as colunas de segmento

        public List<CalculoPesos> GetAgenciaxPesos(short? ano, short? mes)
        {
            try
            {

                var resultado = new List<CalculoPesos>();

                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    cmd.CommandText = $@"
                                SELECT ca.IdAgencia,
                                        CASE ISNULL(SUM(ca.metasAgencias),0) WHEN 0 THEN '0' ELSE '1' END +
                                        CASE ISNULL(SUM(ca.metasUniclass),0) WHEN 0 THEN '0' ELSE '1' END +
                                        CASE ISNULL(SUM(ca.metasEmpresas),0) WHEN 0 THEN '0' ELSE '1' END ChavePeso
                                         FROM (
                                         SELECT ca.IdAgencia, 
                                         CASE s.Nome WHEN 'AGENCIAS' THEN SUM(pli.valormeta) END MetasAgencias,
                                         CASE s.Nome WHEN 'UNICLASS' THEN SUM(pli.valormeta) END MetasUniclass,
                                         CASE s.Nome WHEN 'EMPRESAS' THEN SUM(pli.valormeta) END MetasEmpresas
                                         FROM PlanejamentoItem pli
                                         INNER JOIN Planejamento p ON pli.idPlanejamento = p.id
                                         INNER JOIN GradeItem gi ON pli.CodigoItem = gi.CodigoItem
                                         INNER JOIN ColaboradorAgir ca ON p.idColaboradorAgir = ca.id AND gi.Grade = ca.Grade AND gi.ano = ca.Ano AND gi.Mes = ca.Mes
                                         INNER JOIN Segmento s ON pli.IdSegmento = s.Id
                                         WHERE ca.mes = {mes}
                                         AND ca.Ano = {ano}
                                         GROUP BY ca.IdAgencia, s.Nome
                                         ) ca
                                         GROUP BY ca.IdAgencia";


                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                resultado.Add(new CalculoPesos()
                                {

                                    CodigoAgencia = reader.SafeGetInt32(0),
                                    ChavePeso = reader.SafeGetString(1)

                                });
                            }
                        }
                    }

                    conn.Close();
                }

                return resultado;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<CalculoPesos> GetAgenciaxPesosPersonnalite(short? ano, short? mes)
        {
            try
            {

                var resultado = new List<CalculoPesos>();

                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    cmd.CommandText = $@"SELECT ca.IdAgencia,
                                        CASE ISNULL(SUM(ca.metasAgencias),0) WHEN 0 THEN '0' ELSE '1' END +
                                        CASE ISNULL(SUM(ca.metasUniclass),0) WHEN 0 THEN '0' ELSE '1' END +
                                        CASE ISNULL(SUM(ca.metasEmpresas),0) WHEN 0 THEN '0' ELSE '1' END ChavePeso
                                         FROM (
                                         SELECT ca.IdAgencia, 
                                         CASE s.Nome WHEN 'AGENCIAS' THEN SUM(pli.valormeta) END MetasAgencias,
                                         CASE s.Nome WHEN 'UNICLASS' THEN SUM(pli.valormeta) END MetasUniclass,
                                         CASE s.Nome WHEN 'EMPRESAS' THEN SUM(pli.valormeta) END MetasEmpresas
                                         FROM PlanejamentoItemPersonnalite pli
                                         INNER JOIN PlanejamentoPersonnalite p ON pli.idPlanejamento = p.id
                                         INNER JOIN GradeItem gi ON pli.CodigoItem = gi.CodigoItem
                                         INNER JOIN ColaboradorAgir ca ON p.idColaboradorAgir = ca.id AND gi.Grade = ca.Grade AND gi.ano = ca.Ano AND gi.Mes = ca.Mes
                                         INNER JOIN Segmento s ON pli.IdSegmento = s.Id
                                         WHERE ca.mes = {mes}
                                         AND ca.Ano = {ano}
                                         GROUP BY ca.IdAgencia, s.Nome
                                         ) ca
                                         GROUP BY ca.IdAgencia";

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                resultado.Add(new CalculoPesos()
                                {

                                    CodigoAgencia = reader.SafeGetInt32(0),
                                    ChavePeso = reader.SafeGetString(1)

                                });
                            }
                        }
                    }

                    conn.Close();
                }

                return resultado;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> BulkInsertUpdatePesos(List<ValorPesosSegmentos> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                    {
                        sqlList.Add(CriaInsertUpdateScriptPesos(item));
                    }

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("produtogradeitem-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = await cmd.ExecuteNonQueryAsync();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        private string CriaInsertUpdateScriptPesos(ValorPesosSegmentos item)
        {

            return $@"UPDATE [dbo].[Agencia]
                        SET [ValorPesoSegmentoIA] = {item.ValorPesoIA}
                        ,[ValorPesoSegmentoIU] = {item.ValorPesoIU}
                        ,[ValorPesoSegmentoEmp4] = {item.ValorPesoEMP4}
                        WHERE 
                        CodigoAgencia = {item.CodigoAgencia}";



        }

        public void InsertSQLPesos(ValorPesosSegmentos model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = CriaInsertUpdateScriptPesos(model);

                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        #endregion

        //public int? GetIdPoloDicomByRegiao(int idRegiao)
        //{
        //    int? idDicom = GetAgenciaFromCache().Where(x => x.IdPoloRegiao == idRegiao).Select(x => x.IdPoloDICOM).FirstOrDefault();

        //    return idDicom;
        //}


        public int UpdateAgenciaCoordenadora(List<Agencia> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                        sqlList.Add($"UPDATE Agencia SET IdAgenciaCoordenadora = {item.CodigoAgenciaCoordenadora} WHERE Id = {item.CodigoAgencia}");

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("agenciacoordenadora"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = cmd.ExecuteNonQuery();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        public Agencia GetAgencia(string CodigoAgencia)
        {
            return _sqlDataContext.SelectQuerySingleOrDefault<Agencia>($@"SELECT Id FROM Agencia (NOLOCK) WHERE Codigo = '" + CodigoAgencia + "'");
        }

        public int GetIdAgencia(string CodigoAgencia)
        {
            Agencia ret = new Agencia();

            ret = GetAgencia(CodigoAgencia);

            return ret.Id;
        }

        public IEnumerable<AgenciaSimplificado> ObterIdECodigo()
        {
            return _sqlDataContext.SelectQueryToList<AgenciaSimplificado>($@"SELECT Id AS IdAgencia, Codigo FROM Agencia");

        }

        public IEnumerable<Agencia> GetAgencias(IEnumerable<int> Ids)
        {
            string joined = string.Join(',', Ids);
            return _sqlDataContext.SelectQueryToList<Entities.Agencia>(
                   $@"SELECT 
                        Id,
                        DataCriacao,
                        DataAtualizacao,
                        Codigo,
                        IdAgenciaCoordenadora,
                        Ativo,
                        TextoEndereco,
                        NomeCidade,
                        SiglaEstado,
                        ValorLatitude,
                        ValorLongitude
                     FROM Agencia (NOLOCK) WHERE Id IN ({joined})");
        }


        #endregion
    }
}
