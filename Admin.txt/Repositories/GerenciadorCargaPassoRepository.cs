﻿
using Itau.SZ7.GPS.Admin.Domain.Carga.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;

using System.Data.SqlClient;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Extensions;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class GerenciadorCargaPassoRepository : IGerenciadorCargaPassoRepository
    {
        private readonly string _connectionString;

        public GerenciadorCargaPassoRepository(IAppConfiguration appConfiguration)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public int UpInsert(GerenciadorCargaPasso model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                if(model.Id == 0)
                {
                    cmd.CommandText =
$@"      ALTER TABLE GerenciadorCargaPasso
            NOCHECK CONSTRAINT FK_616

            INSERT INTO GerenciadorCargaPasso
            VALUES ({model.IdGerenciadorCarga},
                {(int)model.Passo},
                '{model.Nome}',
                {model.LinhasProcessadas},
                {(model.Atualizado.HasValue ? "'" + model.Atualizado.Value.ToSqlDate() + "'" : "NULL")},
                {(model.Erro ? 1 : 0)},
                '{(model.Inicio.ToSqlDate())}',
                {(model.Fim.HasValue ? "'" + model.Fim.Value.ToSqlDate() + "'" : "NULL")})

    SELECT @@IDENTITY";
                }
                else
                {
                    cmd.CommandText =
$@"
    UPDATE GerenciadorCargaPasso
    SET 
        LinhasProcessadas = {model.LinhasProcessadas}, 
        Atualizado = {(model.Atualizado.HasValue ? "'" + model.Atualizado.Value.ToSqlDate() + "'" : "NULL")},
        Inicio = '{(model.Inicio.ToSqlDate())}',
        Fim = {(model.Fim.HasValue ? "'" + model.Fim.Value.ToSqlDate() + "'" : "NULL")},
        Erro = {(model.Erro ? 1 : 0)}
    WHERE Id = {model.Id}

    SELECT {model.Id}";
                }

                
                var resultado = cmd.ExecuteScalar();

                conn.Close();

                return IntExtension.TryParse(resultado.ToString());
            }
        }

        public async Task<int> UpInsertAsync(GerenciadorCargaPasso model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText =
$@"IF EXISTS(SELECT TOP 1 IdGerenciadorCarga FROM GerenciadorCargaPasso WHERE Passo = {(int)model.Passo} and IdGerenciadorCarga = {model.IdGerenciadorCarga})
BEGIN
    UPDATE GerenciadorCargaPasso
    SET Nome = '{model.Nome}', 
        LinhasProcessadas = {model.LinhasProcessadas}, 
        Atualizado = {(model.Atualizado.HasValue ? "'" + model.Atualizado.Value.ToSqlDate() + "'" : "NULL")},
        Inicio = '{(model.Inicio.ToSqlDate())}',
        Fim = {(model.Fim.HasValue ? "'" + model.Fim.Value.ToSqlDate() + "'" : "NULL")},
        Erro = {(model.Erro ? 1 : 0)}
    WHERE Passo = {(int)model.Passo} AND IdGerenciadorCarga = {model.IdGerenciadorCarga}

END ELSE BEGIN

    INSERT INTO GerenciadorCargaPasso
    VALUES ({model.IdGerenciadorCarga},
        {(int)model.Passo},
        '{model.Nome}',
        {model.LinhasProcessadas},
        {(model.Atualizado.HasValue ? "'" + model.Atualizado.Value.ToSqlDate() + "'" : "NULL")},
        {(model.Erro ? 1 : 0)},
        '{(model.Inicio.ToSqlDate())}',
        {(model.Fim.HasValue ? "'" + model.Fim.Value.ToSqlDate() + "'" : "NULL")}
)

END";

                var resultado = await cmd.ExecuteNonQueryAsync();

                conn.Close();

                return resultado;
            }
        }
    }
}
