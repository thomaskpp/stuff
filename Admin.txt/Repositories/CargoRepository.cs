﻿using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class CargoRepository : ICargoRepository
    {
        private readonly ISqlDataContext _sqlDataContext;

        public CargoRepository(ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
        }

        public async Task<IEnumerable<Cargo>> ListarCargoAsync()
        {
            return await _sqlDataContext.SelectQueryToListAsync<Cargo>("Cargo_Listar");
        }

        public Cargo GetCargo(string Cargo)
        {
            return _sqlDataContext.SelectQuerySingleOrDefault<Cargo>($@"SELECT Id FROM Cargo (NOLOCK) WHERE Nome = '" + Cargo + "'");
        }

        public int GetIdCargo(string Cargo)
        {
            Cargo ret = new Cargo();

            ret = GetCargo(Cargo);

            return ret.Id;
        }
    }
}