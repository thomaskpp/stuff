﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Extensions;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;



using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class ConfguracaoVPAPersonaliteRepository : IConfguracaoVPAPersonaliteRepository
    {
        private readonly string _connectionString;
        private readonly ISqlDataContext _sqlDataContext;
        private readonly IMemoryCache _memoryCache;

        public ConfguracaoVPAPersonaliteRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext, IMemoryCache memoryCache)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _sqlDataContext = sqlDataContext;
            _memoryCache = memoryCache;
        }

        public async Task<int> BulkInsertUpdate(List<ConfiguracaoVPAnaliticoPersonnalite> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models.Distinct())
                        sqlList.Add(CriaInsertUpdateScript(item));

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("reclamacoes-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = await cmd.ExecuteNonQueryAsync();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }


        private string CriaInsertUpdateScript(ConfiguracaoVPAnaliticoPersonnalite item)
        {
            return $@"
                INSERT INTO [dbo].[ConfiguracaoProducaoAnaliticoPersonnalite]
                           ([CodigoItem]
                           ,[NomeColuna])
                     VALUES
                           ({item.CodigoItem}
                           ,'{item.NomeColuna}')
";
        }


        public async Task<int> InsertUpdateSQL(ConfiguracaoVPAnaliticoPersonnalite model)
        {
            return await BulkInsertUpdate(new List<ConfiguracaoVPAnaliticoPersonnalite>() { model }, 1);
        }

        public async void DeleteSQL(short mes, short ano)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();

                    cmd.CommandText = $@"DELETE FROM [dbo].[ConfiguracaoProducaoAnaliticoPersonnalite]";

                    await cmd.ExecuteNonQueryAsync();

                    conn.Close();
                }
            }
        }
    }
}

