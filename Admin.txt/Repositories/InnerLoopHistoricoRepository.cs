﻿using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;


using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class InnerLoopHistoricoRepository : IInnerLoopHistoricoRepository
    {
        private readonly BulkConfig _bulkConfig;
        private readonly string _connectionString;
        private readonly ISqlDataContext _sqlDataContext;

        public InnerLoopHistoricoRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };

            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _sqlDataContext = sqlDataContext;
        }

        public async Task BulkInsert(List<InnerLoopHistorico> models, int? batchSize)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaInsertScript(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        await cmd.ExecuteNonQueryAsync();
                    }

                    conn.Close();
                }
            }
        }

        public void InsertSQL(InnerLoopHistorico model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = CriaInsertScript(model);

                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        public void RemoveHistorico(List<InnerLoopLigacao> ligacoes, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;


            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaDeleteScript(ligacoes);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        cmd.ExecuteNonQuery();

                    }

                    conn.Close();
                }
            }
        }

        public void RemoveHistoricoExpurgo(List<InnerLoopLigacao> ligacoes)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaDeleteScript(ligacoes);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        cmd.ExecuteNonQuery();

                    }
                    conn.Close();
                }
            }
        }

        private List<string> CriaDeleteScript(List<InnerLoopLigacao> ligacoes)
        {
            var resultado = new List<string>();

            foreach (var item in ligacoes)
            {
                resultado.Add($"DELETE FROM InnerLoopHistorico WHERE IdLigacao = {item.Id}");
            }

            return resultado;
        }

        private List<string> CriaInsertScript(List<InnerLoopHistorico> historicos)
        {
            var resultado = new List<string>();

            foreach (var historico in historicos)
            {
                resultado.Add(CriaInsertScript(historico));
            }

            return resultado;
        }

        private string CriaInsertScript(InnerLoopHistorico historico)
        {
            var resultado = $"INSERT INTO InnerLoopHistorico " +
                            $"(DataCriacao, DataAtualizacao, IdLigacao, IdStatus) values (" +
                              $"'{historico.DataCriacao.ToString("yyyy-MM-dd HH:mm:ss")}'," +
                              $"'{historico.DataAtualizacao.ToString("yyyy-MM-dd HH:mm:ss")}'," +
                              $"{historico.IdLigacao}," +
                              $"{historico.IdStatus}" +
                            $")";

            return resultado;
        }

        public async Task<IEnumerable<InnerLoopHistorico>> GetHistoricoLigacoes(int idLigacao)
        {
            Dictionary<string, object> param = new Dictionary<string, object>
            {
                { "@idLigacao", idLigacao }
            };

            string query = "SELECT * FROM InnerLoopHistorico (NOLOCK) where idLigacao = @idLigacao";

            IEnumerable<InnerLoopHistorico> historico = await _sqlDataContext.SelectQueryToListAsync<InnerLoopHistorico>(query, param);

            return historico != null ? (List<InnerLoopHistorico>)historico : new List<InnerLoopHistorico>();
        }

    }
}
