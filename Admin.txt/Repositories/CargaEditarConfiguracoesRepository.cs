﻿using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class CargaEditarConfiguracoesRepository : ICargaEditarConfiguracoesRepository
    {
        private readonly ISqlDataContext _sqlDataContext;
        private readonly string _connectionString;

        public CargaEditarConfiguracoesRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }
        public async Task<int> BulkInsertUpdate(CargaEditarConfiguracoes models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    if (models.TipoPeriodo.Equals(CargasTipoPeriodo.Diario.GetHashCode()))
                    {
                        sqlList.Add(CriaInsertUpdateScriptDiario(models));

                    }
                    else
                    if(models.TipoPeriodo.Equals(CargasTipoPeriodo.Semanal.GetHashCode()))
                    {
                        sqlList.Add(CriaInsertUpdateScriptSemanal(models));

                    }
                    else
                    if (models.TipoPeriodo.Equals(CargasTipoPeriodo.Mensal.GetHashCode()))
                    {
                        sqlList.Add(CriaInsertUpdateScriptMensal(models));

                    }
                    else
                    if (models.TipoPeriodo.Equals(CargasTipoPeriodo.Anual.GetHashCode()))
                    {
                        sqlList.Add(CriaInsertUpdateScriptMensal(models));

                    }

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("produtogradeitem-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = await cmd.ExecuteNonQueryAsync();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }
        private string CriaInsertUpdateScriptDiario(CargaEditarConfiguracoes item)
        {

            return $@"UPDATE 
                    GerenciadorCargaConfiguracao SET 
                    IdTipoPeriodo = {item.TipoPeriodo}, 
                    ValorPeriodo = '', 
                    TravaSimultanea = {(item.TravaSimultanea ? 1 : 0)}
                    WHERE IdFuncionalidade = {item.IdFuncionalidade}";

        }

        private string CriaInsertUpdateScriptSemanal(CargaEditarConfiguracoes item)
        {

            return $@"UPDATE 
                    GerenciadorCargaConfiguracao SET 
                    IdTipoPeriodo = {item.TipoPeriodo}, 
                    ValorPeriodo = '{item.ValorPeriodo}', 
                    TravaSimultanea = {(item.TravaSimultanea ? 1 : 0)}
                    WHERE IdFuncionalidade = {item.IdFuncionalidade}";

        }
        private string CriaInsertUpdateScriptMensal(CargaEditarConfiguracoes item)
        {

            return $@"UPDATE 
                    GerenciadorCargaConfiguracao SET 
                    IdTipoPeriodo = {item.TipoPeriodo}, 
                    ValorPeriodo = '{item.ValorPeriodo}', 
                    TravaSimultanea = {(item.TravaSimultanea ? 1 : 0)}
                    WHERE IdFuncionalidade = {item.IdFuncionalidade}";

        }

        public async Task<IEnumerable<Funcionalidade>> ObterFuncionalidadesCarga()
        {
            var query = @"SELECT * FROM Funcionalidade WHERE Url LIKE '%carga%'";

            return await _sqlDataContext.SelectQueryToListAsync<Funcionalidade>(query);
        }

        public async Task<GerenciadorCargaConfiguracao> GetGerenciadorCargaConfiguracaosAsync(int id)
        {
            var query = @"SELECT 
                        GCC.Id,
                        F.Descricao AS Nome,
                        C.Funcional AS FuncionalResponsavel,
                        C.Nome AS NomeResponsavel,
                        GCTP.Nome AS TipoPeriodo,
                        GCC.ValorPeriodo,
                        GCC.Ocultar,
                        F.Url,
                        GCC.IdFuncionalidade,
                        GCC.TravaSimultanea
                        FROM GerenciadorCargaConfiguracao GCC
                        INNER JOIN Funcionalidade F ON F.Id = GCC.IdFuncionalidade
                        LEFT JOIN  Colaborador C ON C.Id = GCC.IdColaborador
                        INNER JOIN GerenciadorCargaTipoPeriodo GCTP ON GCTP.Id = GCC.IdTipoPeriodo 
                        WHERE GCC.IdFuncionalidade = @id";

            var parametros = new Dictionary<string, object>()
            {
                { "@id", id }
            };

            return _sqlDataContext.SelectQuerySingleOrDefault<GerenciadorCargaConfiguracao>(query, parametros);
        }
    }
}