﻿using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class InnerLoopRespostaRepository : IInnerLoopRespostaRepository
    {

        private readonly BulkConfig _bulkConfig;
        private readonly string _connectionString;

        public InnerLoopRespostaRepository(IAppConfiguration appConfiguration)
        {

            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };

            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }

        public void RemoveRespostasExpurgo(List<InnerLoopLigacao> ligacoes)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaDeleteScript(ligacoes);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        cmd.ExecuteNonQuery();

                    }
                    conn.Close();
                }
            }
        }

        private List<string> CriaDeleteScript(List<InnerLoopLigacao> ligacoes)
        {
            var resultado = new List<string>();

            foreach (var item in ligacoes)
                resultado.Add($"DELETE FROM InnerLoopResposta WHERE IdLigacao = {item.Id}");

            return resultado;
        }
    }
}
