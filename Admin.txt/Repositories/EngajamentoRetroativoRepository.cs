﻿
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;
using System;
using System.Data.SqlClient;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class EngajamentoRetroativoRepository : IEngajamentoRetroativoRepository
    {
        public EngajamentoRetroativoRepository(IAppConfiguration appConfiguration)
        {
        }

        public DateTime GetServerDateTime(string connectionString)
        {
            DateTime dateTimeServer;
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = "SELECT SYSDATETIME()";

                cmd.ExecuteNonQuery();
                dateTimeServer = Convert.ToDateTime(cmd.ExecuteScalar());

                conn.Close();
            }
            return dateTimeServer;
        }
    }
}
