﻿using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Domain.Planejamento.Interfaces.Repositories;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Helpers.Interfaces;
using Itau.SZ7.GPS.Admin.Services.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class ColaboradorRepository : IColaboradorRepository
    {
        private readonly IMemoryCache _cache;
        private readonly ISqlDataContext _sqlDataContext;
        private readonly BulkConfig _bulkConfig;
        private readonly string _connectionString;
        private static string CACHE_EXPIRATION_KEY = "ColaboradorCacheExpiration";
        private static string DEFAULT_CACHE_EXPIRATION_KEY = "DefaultCacheExpiration";
        private readonly IAppConfiguration _appconfiguration;
        private readonly string _cacheExpirationKey = "ColaboradorCacheExpiration";
        protected readonly MemoryCacheEntryOptions _memoryCacheEntryOptions;
        private readonly ILogApplication _logApplication;


        public ColaboradorRepository(IAppConfiguration appConfiguration, IMemoryCache cache, 
            ISqlDataContext sqlDataContext, ILogApplication logApplication)
        {
            _cache = cache;
            _sqlDataContext = sqlDataContext;
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _appconfiguration = appConfiguration;
            _logApplication = logApplication;

            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };
        }

        public async Task<IEnumerable<Colaborador>> RetornarColaboradores()
        {
            return await _sqlDataContext.SelectQueryToListAsync<Colaborador>("SELECT * FROM Colaborador (NOLOCK)");
        }

        public bool ExisteCarteira(string carteira)
        {
            HashSet<string> cacheData;
            var cacheKey = $"{CACHE_EXPIRATION_KEY}carteira";

            if (!_cache.TryGetValue(cacheKey, out cacheData))
            {
                cacheData = _sqlDataContext.SelectQueryToList<Colaborador>
                    (
                    $@"SELECT ca.Carteira FROM Colaborador c
                        JOIN ColaboradorAgir ca ON c.id = ca.idColaborador
                        ORDER BY ca.Carteira"
                    )
                    .Select(x => x.Carteira)
                    .ToHashSet();

                _cache.Set(cacheKey, cacheData, _memoryCacheEntryOptions);
            }

            return cacheData.Contains(carteira);
        }

        public bool ExisteCarteiraAgencia(string carteira, int codigoAgencia)
        {
            HashSet<string> cacheData;
            var cacheKey = $"{CACHE_EXPIRATION_KEY}carteiraagencia";

            if (!_cache.TryGetValue(cacheKey, out cacheData))
            {
                cacheData = _sqlDataContext.SelectQueryToList<Colaborador>
                    (
                    $@"SELECT ca.idAgencia, ca.Carteira FROM Colaborador c
                       JOIN ColaboradorAgir ca ON c.id = ca.idColaborador
                       ORDER BY ca.idAgencia, ca.Carteira"
                    )
                    .Select(x => $"{x.Carteira}|{x.CodigoAgencia}")
                    .ToHashSet();

                _cache.Set(cacheKey, cacheData, _memoryCacheEntryOptions);
            }

            return cacheData.Contains($"{carteira}|{codigoAgencia}");
        }


        public async Task<bool> ExisteCarteiraAgenciaPorSegmento(string carteira, int codigoAgencia, int idSegmento)
        {

            var cacheKey = $"{CACHE_EXPIRATION_KEY}_ExisteCarteiraAgSegmento_{carteira}/{codigoAgencia}/{idSegmento}";
            var existe = false;

            if (!_cache.TryGetValue(cacheKey, out ColaboradorAgir result))
            {
                result = await _sqlDataContext.SelectQuerySingleOrDefaultAsync<ColaboradorAgir>
                    (
                     $@"SELECT COUNT(Id) AS Id FROM ColaboradorAgir (NOLOCK)
                        WHERE IdSegmento = {idSegmento}  AND (Carteira = '{carteira}' AND IdAgencia = {codigoAgencia})"
                    );

                _cache.Set(cacheKey, result, GetMemoryCacheEntryOptions());

                existe = result.Id > 0 ? true : false;
            }

            return existe;

        }


        private MemoryCacheEntryOptions GetMemoryCacheEntryOptions()
        {
            var cacheTime = _appconfiguration.GetApplicationSettings(_cacheExpirationKey);

            if (string.IsNullOrEmpty(cacheTime))
                cacheTime = _appconfiguration.GetApplicationSettings(DEFAULT_CACHE_EXPIRATION_KEY);

            double.TryParse(cacheTime, out double cacheExpiration);
            return new MemoryCacheEntryOptions()
                .SetAbsoluteExpiration(TimeSpan.FromMinutes(cacheExpiration))
                .SetPriority(CacheItemPriority.NeverRemove);
        }


        public IEnumerable<Colaborador> GetColaboradorFromCache()
        {
            var key = $"{CACHE_EXPIRATION_KEY}_GetColaboradorFromCacheAsync";

            if (!_cache.TryGetValue(key, out IEnumerable<Colaborador> result))
            {
                result = _sqlDataContext.SelectQueryToList<Colaborador>
                    (
                    $@"SELECT * FROM Colaborador (NOLOCK)
                        WHERE Ativo = 1"
                    );

                _cache.Set(key, result, GetMemoryCacheEntryOptions());
            }

            return result ?? new List<Colaborador>();
        }

        public int GetIdColaboradorPorCarteira(string carteira)
        {
            if (!string.IsNullOrWhiteSpace(carteira))
            {
                IEnumerable<ColaboradorAgir> IdColaborador = GetColaboradorAgir();

                ColaboradorAgir IdColaboradorEncontrado =
                    IdColaborador.FirstOrDefault(s =>
                    s.Carteira.Equals(carteira, StringComparison.OrdinalIgnoreCase));

                return IdColaboradorEncontrado?.Id ?? 0;
            }

            return 0;
        }

        public IEnumerable<ColaboradorAgir> GetColaboradorAgir()
        {

            string query = "SELECT [IdColaborador] FROM [dbo].[ColaboradorAgir] WITH(NOLOCK)";

            var carteira = _sqlDataContext.SelectQueryToList<ColaboradorAgir>(query, null);

            return carteira?.ToList() ?? new List<ColaboradorAgir>();
        }

        public List<ColaboradorAgir> ObterColaboradorAgirPorCarteiraMesAnoPersonnalite(byte mes, short ano)
        {

            var colaborador = _sqlDataContext.SelectQueryToList<ColaboradorAgir>
                   (
                   $@"SELECT [Id], [IdSegmento], [IdAgencia], [Carteira], [Grade], [IdColaborador], [Ano], [Mes] FROM [dbo].[ColaboradorAgir] WITH(NOLOCK)
                      WHERE Mes = {mes} AND Ano = {ano} AND IdSegmento = 5"
                   ).ToList();

            return colaborador;
        }


        public async Task<IEnumerable<Colaborador>> GetColaboradorAtivo()
        {
            return await _sqlDataContext.SelectQueryToListAsync<Colaborador>
                    (
                    $@"SELECT * FROM Colaborador (NOLOCK)
                        WHERE IndicadorAtivo = 1"
                    );
        }

        public IEnumerable<Colaborador> GetColaboradorParaCargaMeta(int ano, int mes)
        {
            return _sqlDataContext.SelectQueryToList<Colaborador>
                    (
                    $@"SELECT 
	                       [DataCriacao]
                          ,[DataAtualizacao]
                          ,[Funcional]
                          ,c.[Nome]
	                      ,[Carteira]
                          ,[Grade]
                          ,[Ano]
                          ,[Mes]
                          ,co.Nome as AbreviacaoCargo
                          ,c.IdCargo
                          ,ca.Id as IdColaboradorAgir
                          ,ca.IdColaborador
                          ,ca.IdAgencia
                          ,ca.IdSegmento
                          ,c.Id 

                         FROM Colaborador c (NOLOCK)
	                        JOIN Cargo co ON c.idCargo = co.id
	                        JOIN ColaboradorAgir ca on c.id = ca.idcolaborador
	                        WHERE c.Ativo = 1 
                                AND ca.IdAgencia > 0
                                AND ca.Carteira IS NOT NULL 
                                AND ca.Carteira <> '' 
                                AND ca.IdSegmento in (1,2,3)
                                AND co.Id not in (1,40)
                                AND ca.Ano = {ano} AND ca.Mes = {mes}
                                "
                    );
        }

        public IEnumerable<Colaborador> GetColaboradorExcetoAssistente(int ano, int mes)
        {
            return _sqlDataContext.SelectQueryToList<Colaborador>
                    (
                    $@"SELECT 
	                       [DataCriacao]
                          ,[DataAtualizacao]
                          ,[Funcional]
                          ,c.[Nome]
	                      ,[Carteira]
                          ,[Grade]
                          ,[Ano]
                          ,[Mes]
                          ,co.Nome as AbreviacaoCargo
                          ,c.IdCargo
                          ,ca.Id as IdColaboradorAgir
                          ,ca.IdColaborador
                          ,ca.IdAgencia
                          ,ca.IdSegmento
                          ,c.Id 

                         FROM Colaborador c (NOLOCK)
	                        JOIN Cargo co ON c.idCargo = co.id
	                        JOIN ColaboradorAgir ca on c.id = ca.idcolaborador
	                        WHERE c.Ativo = 1 
                                AND ca.IdSegmento in (1,2,3)
                                AND co.Id not in (1,40)
                                AND ca.Ano = {ano} AND ca.Mes = {mes}
                                "
                    );
        }

        public IEnumerable<Colaborador> GetColaboradorGGDGGN(int ano, int mes)
        {
            return _sqlDataContext.SelectQueryToList<Colaborador>
                    (
                    $@"SELECT 
	                       [DataCriacao]
                          ,[DataAtualizacao]
                          ,[Funcional]
                          ,c.[Nome]
	                      ,[Carteira]
                          ,[Grade]
                          ,[Ano]
                          ,[Mes]
                          ,co.Nome as AbreviacaoCargo
                          ,c.IdCargo
                          ,ca.Id as IdColaboradorAgir
                          ,ca.IdColaborador
                          ,ca.IdAgencia
                          ,ca.IdSegmento
                          ,c.Id 

                         FROM Colaborador c (NOLOCK)
	                        JOIN Cargo co ON c.idCargo = co.id
	                        JOIN ColaboradorAgir ca on c.id = ca.idcolaborador
	                        WHERE c.Ativo = 1 
                                AND ca.IdAgencia > 0
                                AND ca.Carteira IS NOT NULL 
                                AND ca.Carteira <> ''
                                AND ca.IdSegmento in (1,2,3)
                                AND co.Id in (9,11)
                                AND ca.Ano = {ano} AND ca.Mes = {mes}
                                "
                    );
        }

        public IEnumerable<Colaborador> GetColaboradoresComAgir(int ano, int mes)
        {
            var query = $@"SELECT 
	                        Funcional
	                        ,c.Nome
	                        ,Carteira
	                        ,Grade
	                        ,Ano
	                        ,Mes
	                        ,c.IdCargo
	                        ,ca.Id as IdColaboradorAgir
	                        ,ca.IdColaborador
	                        ,ca.IdAgencia
	                        ,ca.IdSegmento
	                        ,c.Id 
	                        ,p.Id as IdPlanejamento
                        FROM Colaborador c (NOLOCK)
	                        LEFT JOIN ColaboradorAgir ca (NOLOCK) on c.id = ca.idcolaborador AND Ano = @ano AND Mes = @mes
	                        LEFT JOIN Planejamento p (NOLOCK) on p.IdColaboradorAgir = ca.Id
                        --WHERE ca.IdSegmento <> 5
                        UNION
                        SELECT 
	                        Funcional
	                        ,c.Nome
	                        ,Carteira
	                        ,Grade
	                        ,Ano
	                        ,Mes
	                        ,c.IdCargo
	                        ,ca.Id as IdColaboradorAgir
	                        ,ca.IdColaborador
	                        ,ca.IdAgencia
	                        ,ca.IdSegmento
	                        ,c.Id 
	                        ,p.Id as IdPlanejamento
                        FROM Colaborador c (NOLOCK)
	                        LEFT JOIN ColaboradorAgir ca (NOLOCK) on c.id = ca.idcolaborador AND Ano = @ano AND Mes = @mes
	                        LEFT JOIN PlanejamentoPersonnalite p (NOLOCK) on p.IdColaboradorAgir = ca.Id
                        --WHERE ca.IdSegmento = 5 ";

            var parametros = new Dictionary<string, object> {
                {"@mes", mes },
                {"@ano", ano }
            };

            return _sqlDataContext.SelectQueryToList<Colaborador>(query, parametros);
        }

        public IEnumerable<Colaborador> GetColaboradorParaCargaMetaPersonnalite(byte mes, short ano)
        {
            return _sqlDataContext.SelectQueryToList<Colaborador>
                    (
                    $@"SELECT 
	                       [DataCriacao]
                          ,[DataAtualizacao]
                          ,[Funcional]
                          ,c.[Nome]
	                      ,[Carteira]
                          ,[Grade]
                          ,[Ano]
                          ,[Mes]
                          ,co.Nome as AbreviacaoCargo
                          ,c.IdCargo
                          ,ca.Id as IdColaboradorAgir
                          ,ca.IdColaborador
                          ,ca.IdAgencia
                          ,ca.IdSegmento

                         FROM Colaborador c (NOLOCK)
	                        RIGHT JOIN Cargo co ON c.idCargo = co.id
	                        RIGHT JOIN ColaboradorAgir ca on c.id = ca.idcolaborador
	                        WHERE (c.Ativo = 1 OR c.Ativo is null )
                                AND ca.IdAgencia > 0
                                AND ca.Carteira IS NOT NULL 
                                AND ca.Carteira <> '' 
                                AND ca.IdSegmento in (5)
                                AND (co.Id not in (29, 4, 5) OR co.Id IS NULL)
								AND ca.Mes = {mes}
								AND ca.Ano = {ano}
                                "
                    );
        }

        public IEnumerable<Colaborador> GetColaboradorParaCargaMeta(Segmentos segmento)
        {
            return _sqlDataContext.SelectQueryToList<Colaborador>
                    (
                    $@"SELECT * FROM Colaborador c (NOLOCK)
                            JOIN ColaboradorAgir ca ON c.id = ca.idColaborador
                            WHERE Ativo = 1 AND ca.IdAgencia IS NOT NULL AND ca.IdAgencia <> '' AND
                            ca.Carteira IS NOT NULL AND ca.Carteira <> '' AND IdSegmento = { segmento.GetHashCode() }"
                    );
        }

        public async Task<ColaboradorSimplificado> GetByFuncional(string funcional, bool isFromCache = true)
        {
            if (isFromCache)
            {
                var key = $"{CACHE_EXPIRATION_KEY}_GetByFuncional_{funcional}";

                if (!_cache.TryGetValue(key, out ColaboradorSimplificado result))
                {
                    result = await _sqlDataContext.SelectQuerySingleOrDefaultAsync<ColaboradorSimplificado>
                        (
                        $@"SELECT TOP 1 * FROM Colaborador (NOLOCK)
                        WHERE Ativo = 1 AND Funcional = '{funcional}'"
                        );

                    _cache.Set(key, result, GetMemoryCacheEntryOptions());
                }

                return result ?? new ColaboradorSimplificado();
            }
            else
            {
                var colaboradores = await _sqlDataContext.SelectQueryToListAsync<ColaboradorSimplificado>
                    (
                    $@"SELECT * FROM Colaborador (NOLOCK)
                        WHERE Ativo = 1 AND Funcional = '{funcional}'"
                    );
                return colaboradores.FirstOrDefault();
            }
        }

        public async Task<ColaboradorSimplificado> GetById(int id, bool isFromCache = true)
        {
            if (isFromCache)
            {
                var key = $"{CACHE_EXPIRATION_KEY}_GetById_{id}";

                if (!_cache.TryGetValue(key, out ColaboradorSimplificado result))
                {
                    result = await _sqlDataContext.SelectQuerySingleOrDefaultAsync<ColaboradorSimplificado>
                        (
                        $@"SELECT TOP 1 * FROM Colaborador (NOLOCK)
                        WHERE Id = {id}"
                        );

                    _cache.Set(key, result, GetMemoryCacheEntryOptions());
                }

                return result ?? new ColaboradorSimplificado();
            }
            else
            {
                var colaboradores = await _sqlDataContext.SelectQueryToListAsync<ColaboradorSimplificado>
                    (
                    $@"SELECT * FROM Colaborador (NOLOCK)
                        WHERE Id = {id}"
                    );
                return colaboradores.FirstOrDefault();
            }
        }

        public async Task<int> GetIdSegmentoByFuncionalAsync(string funcional)
        {
            int retorno = 0;
            ColaboradorSimplificado colaborador = new ColaboradorSimplificado();

            colaborador = await GetByFuncional(funcional, true);

            if (colaborador != null)
            {
                ColaboradorAgir agir = _sqlDataContext.SelectQuerySingleOrDefault<ColaboradorAgir>
                    (
                    $@"SELECT TOP 1 * FROM ColaboradorAgir (NOLOCK) WHERE IdColaborador = {colaborador.Id} ORDER BY Ano DESC, Mes DESC"
                    );

                if (agir != null)
                    retorno = agir.IdSegmento;
            }

            return retorno;
        }

        public string GetFuncionalResponsavelPorId(int id)
        {
            string query = $@"SELECT DISTINCT Funcional FROM [dbo].[Colaborador] WITH(NOLOCK) WHERE id = {id}";

            var Funcional = _sqlDataContext.SelectQueryToList<Colaborador>(query, null);

            return Funcional.ToString();
        }



        //public bool ExisteCarteira(string carteira)
        //{
        //    HashSet<string> cacheData;
        //    var cacheKey = $"{CACHE_EXPIRATION_KEY}carteira";

        //    if (!_cache.TryGetValue(cacheKey, out cacheData))
        //    {
        //        cacheData = _sqlDataContext.SelectQueryToList<Colaborador>
        //            (
        //            $@"SELECT Carteira FROM Colaborador (NOLOCK)
        //                GROUP BY Carteira"
        //            )
        //            .Select(x => x.Carteira)
        //            .ToHashSet();

        //        _cache.Set(cacheKey, cacheData, _memoryCacheEntryOptions);
        //    }

        //    return cacheData.Contains(carteira);
        //}

        //public bool ExisteCarteiraAgencia(string carteira, int codigoAgencia)
        //{
        //    HashSet<string> cacheData;
        //    var cacheKey = $"{CACHE_EXPIRATION_KEY}carteiraagencia";

        //    if (!_cache.TryGetValue(cacheKey, out cacheData))
        //    {
        //        cacheData = _sqlDataContext.SelectQueryToList<Colaborador>
        //            (
        //            $@"SELECT Carteira, CodigoAgencia FROM Colaborador (NOLOCK)
        //                GROUP BY Carteira, CodigoAgencia"
        //            )
        //            .Select(x => $"{x.Carteira}|{x.CodigoAgencia}")
        //            .ToHashSet();

        //        _cache.Set(cacheKey, cacheData, _memoryCacheEntryOptions);
        //    }

        //    return cacheData.Contains($"{carteira}|{codigoAgencia}");
        //}

        public int BulkInsertColaborador(List<ColaboradorSimplificado> models, List<int> agirAtualizados, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new StringBuilder();

                    foreach (var item in models)
                    {
                        sqlList.AppendLine(CriaInsertUpdateScript(item));

                        if (item.ColaboradorFerias.Count() > 0)
                        {
                            foreach (ColaboradorFerias ferias in item.ColaboradorFerias)
                            {
                                sqlList.AppendLine(CriaInsertUpdateScriptFerias(item.Id, ferias));
                            }
                        }

                        if (item.ColaboradorAgir != null)
                        {
                            sqlList.AppendLine(CriaInsertUpdateScriptSatisfacao(item.IdCargo.Value, item.ColaboradorAgir));
                            sqlList.AppendLine(CriaInsertUpdateScriptAgir(item, agirAtualizados));
                        }
                    }

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    using (var transaction = conn.BeginTransaction("colab-bulkinsert"))
                    {
                        cmd.Transaction = transaction;

                        try
                        {
                            cmd.CommandText = $"DECLARE @idColaborador INT {string.Join("\n", sqlList.ToString())}";

                            resultado += cmd.ExecuteNonQuery();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            _logApplication.RegistrarLog(LogTipo.Critico, Plataforma.Enum.Admin,
                                Funcionalidade.Enum.CargaColaboradorAdmin, null, null, null, null, null,
                                ex.StackTrace, ex.Message, "ColaboradorRepository > BulkInsertColaborador", "1.0");

                            try
                            {
                                transaction.Rollback();
                            }
                            catch { }

                            throw;
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        public int AtualizaGestorDireto(List<Colaborador> models, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                    {
                        sqlList.Add($@"UPDATE Colaborador 
                                    SET IdColaboradorGestorDireto = (SELECT TOP 1 Id FROM Colaborador WHERE Funcional = RIGHT('000000000' + '{item.FuncionalGestorDireto}', 9)) 
                                    WHERE Funcional = RIGHT('000000000' + '{item.Funcional}', 9)  ");
                    }

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        resultado += cmd.ExecuteNonQuery();
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        private string CriaInsertUpdateScript(ColaboradorSimplificado item)
        {
            var sql = new StringBuilder();

            sql.AppendLine($"set @idColaborador = {item.Id}");

            if (item.Id > 0)
            {
                sql.AppendLine($@"UPDATE Colaborador
                                SET 
                                    DataAtualizacao = GETDATE(),
                                    RACF = '{item.Racf}',
                                    Nome = '{(item.Nome.Length > 30 ? item.Nome.Substring(0, 30) : item.Nome)}',
                                    NomeCompleto = '{item.NomeCompleto.Replace("'", "''''")}',
                                    IdCargo = {item.IdCargo},
                                    Ativo = {(item.Ativo ? 1 : 0)},
                                    IdColaboradorGestorDireto = {item.IdColaboradorGestorDireto},
                                    DiasIndisponiveis = {item.DiasIndisponiveis},
                                    ElegivelEngajamento = {(item.ElegivelEngajamento ? 1 : 0)}
                                WHERE Id = {item.Id} ");
            }
            else
            {
                sql.AppendLine($@"INSERT INTO Colaborador
                                    (DataCriacao,
                                    DataAtualizacao,
                                    Funcional,
                                    RACF,
                                    Nome,
                                    NomeCompleto,
                                    IdCargo,
                                    Ativo,
                                    IdColaboradorGestorDireto,
                                    DiasIndisponiveis,
                                    ElegivelEngajamento)
                                VALUES 
                                    (GETDATE(),
                                    GETDATE(),
                                    RIGHT('000000000' + '{item.Funcional}', 9),
                                    '{item.Racf}',
                                    '{(item.Nome.Length > 30 ? item.Nome.Substring(0, 30) : item.Nome)}',
                                    '{item.NomeCompleto.Replace("'", "''''")}',
                                    {item.IdCargo},
                                    {(item.Ativo ? 1 : 0)},
                                    {item.IdColaboradorGestorDireto},
                                    {item.DiasIndisponiveis},
                                    {(item.ElegivelEngajamento ? 1 : 0)}) ");

                sql.AppendLine("SET @idColaborador = @@IDENTITY");
            }

            return sql.ToString();
        }

        private string CriaInsertUpdateScriptSatisfacao(int IdCargo, ColaboradorAgir Agir)
        {
            return $@"
            IF EXISTS(SELECT TOP 1 Id FROM ColaboradorSatisfacao (NOLOCK) WHERE IdColaborador = @idColaborador)
            BEGIN

                UPDATE ColaboradorSatisfacao
                SET 
                    IdCargo =  {IdCargo},
                    IdSegmento = {Agir.IdSegmento},
                    IdAgencia = {Agir.IdAgencia}
                WHERE IdColaborador = @idColaborador

            END ELSE BEGIN

                INSERT INTO ColaboradorSatisfacao
                    (IdColaborador,
                    IdCargo,
                    IdSegmento,
                    IdAgencia)
                VALUES 
                    (@idColaborador,
                    {IdCargo},
                    {Agir.IdSegmento},
                    {Agir.IdAgencia}) 

            END";
        }

        private string CriaInsertUpdateScriptFerias(int idColaborador, ColaboradorFerias Ferias)
        {
            return
            $@"
            IF EXISTS(SELECT Id FROM ColaboradorFerias (NOLOCK) WHERE IdColaborador = @idColaborador AND DataInicio = '{Convert.ToDateTime(Ferias.DataInicio).ToString("yyyy/MM/dd")}')
            BEGIN

                UPDATE ColaboradorFerias
                SET 
                    DataFim =  '{Convert.ToDateTime(Ferias.DataFim).ToString("yyyy/MM/dd")}',
                    [DataBase] = '{Convert.ToDateTime(Ferias.DataBase).ToString("yyyy/MM/dd")}'
                WHERE IdColaborador = @idColaborador
                    AND DataInicio = '{Convert.ToDateTime(Ferias.DataInicio).ToString("yyyy/MM/dd")}'

            END ELSE BEGIN

                INSERT INTO ColaboradorFerias
                    (DataCriacao,
                    IdColaborador,
                    DataInicio,
                    DataFim,
                    [DataBase])
                VALUES 
                    (GETDATE(),
                    @idColaborador,
                    '{Convert.ToDateTime(Ferias.DataInicio).ToString("yyyy/MM/dd")}',
                    '{Convert.ToDateTime(Ferias.DataFim).ToString("yyyy/MM/dd")}',
                    '{Convert.ToDateTime(Ferias.DataBase).ToString("yyyy/MM/dd")}') 

            END";
        }

        private string CriaInsertUpdateScriptAgir(ColaboradorSimplificado item, List<int> agirAtualizados)
        {
            var sql = new StringBuilder();
            var cargosMudancaCarteira = new int[]
            {
                (int)Cargos.GGC,
                (int)Cargos.GGD,
                (int)Cargos.GGN,
                (int)Cargos.GRN,
                (int)Cargos.GRE,
                (int)Cargos.GRED,
                (int)Cargos.GRU,
                (int)Cargos.GRUD,
                (int)Cargos.GRUE,
                (int)Cargos.GA,
                (int)Cargos.GRP,
                (int)Cargos.GRAP,
                (int)Cargos.GRA,
                (int)Cargos.SUPT,
                (int)Cargos.DICOM
            };

            var scriptCriacao = $@"INSERT INTO ColaboradorAgir
                                        (IdSegmento,
                                        IdAgencia,
                                        Carteira,
                                        Grade,
                                        IdColaborador,
                                        Ano,
                                        Mes)
                                    VALUES
                                        ({item.ColaboradorAgir.IdSegmento},
                                        {item.ColaboradorAgir.IdAgencia},
                                        '{item.ColaboradorAgir.Carteira}',
                                        {(item.ColaboradorAgir.Grade != null ? item.ColaboradorAgir.Grade.ToString() : "NULL")},
                                        @idColaborador,
                                        {item.ColaboradorAgir.Ano},
                                        {item.ColaboradorAgir.Mes})";

            if (!item.Ativo &&
                item.ColaboradorAgir.IdColaboradorAgir > 0)
            {
                if (item.ColaboradorAgir.IdPlanejamento > 0)
                {
                    sql.AppendLine($@"UPDATE ColaboradorAgir
                                    SET 
                                        IdColaborador = NULL
                                    WHERE Id = {item.ColaboradorAgir.IdColaboradorAgir}");
                }
                else if (item.ColaboradorAgir.IdCarteiraVazia > 0)
                {
                    sql.AppendLine($@"DELETE FROM ColaboradorEngajamento
                                    WHERE IdColaboradorAgir = {item.ColaboradorAgir.IdColaboradorAgir}");

                    sql.AppendLine($@"DELETE FROM ColaboradorAgir
                                    WHERE Id = {item.ColaboradorAgir.IdColaboradorAgir}");
                }
            }
            else if (item.IdCargo.HasValue &&
                //item.IdCargo != item.IdCargoAntigo &&
                //item.ColaboradorAgir.IdColaboradorAgir > 0 &&
                cargosMudancaCarteira.Contains(item.IdCargo.Value))
            {
                if (string.IsNullOrWhiteSpace(item.ColaboradorAgir.Carteira) &&
                    item.ColaboradorAgir.IdColaboradorAgir > 0 &&
                    item.ColaboradorAgir.IdPlanejamento > 0)
                {
                    if (!agirAtualizados.Contains(item.ColaboradorAgir.IdColaboradorAgir))
                    {
                        sql.AppendLine($@"UPDATE ColaboradorAgir SET IdColaborador = NULL WHERE Id = {item.ColaboradorAgir.IdColaboradorAgir}");
                    }

                    sql.AppendLine(scriptCriacao);
                }
                else if (item.ColaboradorAgir.IdCarteiraVazia > 0)
                {
                    if (item.ColaboradorAgir.IdColaboradorAgir > 0 &&
                        item.ColaboradorAgir.IdPlanejamento == null)
                    {
                        sql.AppendLine($@"DELETE FROM ColaboradorEngajamento
                                    WHERE IdColaboradorAgir in (SELECT Id FROM ColaboradorAgir 
                                        WHERE IdColaborador = @idColaborador AND Ano = {item.ColaboradorAgir.Ano} AND Mes = {item.ColaboradorAgir.Mes})");

                        sql.AppendLine($@"DELETE FROM ColaboradorAgir 
                            WHERE IdColaborador = @idColaborador AND Ano = {item.ColaboradorAgir.Ano} AND Mes = {item.ColaboradorAgir.Mes}");

                        agirAtualizados.Add(item.ColaboradorAgir.IdCarteiraVazia.Value);
                    }
                    else if (item.ColaboradorAgir.IdColaboradorAgir > 0 &&
                        (item.ColaboradorAgir.IdPlanejamento > 0 || item.ColaboradorAgir.IdPlanejamento == null) &&
                        item.ColaboradorAgir.IdColaboradorAgirPlanejamento == 0 || item.ColaboradorAgir.IdColaboradorAgirPlanejamento == null)
                    {
                        if (!agirAtualizados.Contains(item.ColaboradorAgir.IdColaboradorAgir))
                        {
                            sql.AppendLine($@"UPDATE ColaboradorAgir SET IdColaborador = NULL WHERE Id = {item.ColaboradorAgir.IdColaboradorAgir}");
                        }

                        agirAtualizados.Add(item.ColaboradorAgir.IdCarteiraVazia.Value);

                        sql.AppendLine($@"UPDATE ColaboradorAgir SET IdColaborador = @idColaborador 
                                WHERE Id = {item.ColaboradorAgir.IdCarteiraVazia}");

                    }
                    else if (item.ColaboradorAgir.IdCarteiraVazia > 0)
                    {
                        sql.AppendLine($@"UPDATE ColaboradorAgir SET IdColaborador = @idColaborador 
                                WHERE Id = {item.ColaboradorAgir.IdCarteiraVazia}");
                    }
                    else if (item.ColaboradorAgir.IdColaboradorAgir > 0 &&
                        (item.ColaboradorAgir.IdColaboradorAgirPlanejamento > 0 || item.ColaboradorAgir.IdPlanejamento > 0) &&
                        item.ColaboradorAgir.IdColaboradorAgir != item.ColaboradorAgir.IdColaboradorAgirPlanejamento)
                    {
                        sql.AppendLine($"RAISERROR('Encontrado mais de um planejamento para a carteira {item.ColaboradorAgir.Carteira}',-1,-1)");
                    }
                    else
                    {
                        sql.AppendLine($"RAISERROR('Não foi possível atualizar a carteira vazia {item.ColaboradorAgir.Carteira}',-1,-1)");
                    }

                }
                else if (item.ColaboradorAgir.IdColaboradorAgir > 0 &&
                    (item.ColaboradorAgir.IdColaboradorAgirPlanejamento > 0 || item.ColaboradorAgir.IdPlanejamento > 0) &&
                    item.ColaboradorAgir.IdColaboradorAgir != item.ColaboradorAgir.IdColaboradorAgirPlanejamento)
                {
                    if (!agirAtualizados.Contains(item.ColaboradorAgir.IdColaboradorAgir))
                    {
                        sql.AppendLine($@"UPDATE ColaboradorAgir SET IdColaborador = NULL WHERE Id = {item.ColaboradorAgir.IdColaboradorAgir}");
                    }

                    agirAtualizados.Add(item.ColaboradorAgir.IdColaboradorAgirPlanejamento);

                    sql.AppendLine($@"UPDATE ColaboradorAgir SET IdColaborador = @idColaborador 
                                    WHERE Id = {item.ColaboradorAgir.IdColaboradorAgirPlanejamento}");
                }
                else if (item.ColaboradorAgir.IdColaboradorAgir == 0 &&
                    (item.ColaboradorAgir.IdColaboradorAgirPlanejamento > 0 || item.ColaboradorAgir.IdPlanejamento > 0))
                {
                    agirAtualizados.Add(item.ColaboradorAgir.IdColaboradorAgirPlanejamento);

                    sql.AppendLine($@"UPDATE ColaboradorAgir SET IdColaborador = @idColaborador 
                                    WHERE Id = {item.ColaboradorAgir.IdColaboradorAgirPlanejamento}");
                }
                else if (item.ColaboradorAgir.IdColaboradorAgir == 0)
                {
                    sql.AppendLine(scriptCriacao);
                }

                else
                {
                    sql.AppendLine($@"UPDATE ColaboradorAgir
                                    SET 
                                        IdAgencia = {item.ColaboradorAgir.IdAgencia},
                                        Carteira = '{item.ColaboradorAgir.Carteira}',
                                        Grade = {(item.ColaboradorAgir.Grade != null ? item.ColaboradorAgir.Grade.ToString() : "NULL")},
                                        IdSegmento = {item.ColaboradorAgir.IdSegmento}
                                    WHERE Id = {item.ColaboradorAgir.IdColaboradorAgir}");
                }
            }
            else
            {
                if (item.ColaboradorAgir.IdColaboradorAgir > 0)
                {
                    if (item.ColaboradorAgir.IdPlanejamento > 0)//item.ColaboradorAgir.IdColaboradorAgirPlanejamento > 0 ||
                    {
                        sql.AppendLine($@"UPDATE ColaboradorAgir
                                    SET 
                                        IdColaborador = NULL
                                    WHERE Id = {item.ColaboradorAgir.IdColaboradorAgir}");

                    }

                    if (item.ColaboradorAgir.IdAgencia == 0 ||
                            //string.IsNullOrEmpty(item.ColaboradorAgir.Carteira) ||
                            item.ColaboradorAgir.IdSegmento == (int)Segmentos.Desconhecido)
                    {
                        sql.AppendLine($@"DELETE FROM ColaboradorEngajamento
                                    WHERE IdColaboradorAgir in (SELECT Id FROM ColaboradorAgir 
                                        WHERE IdColaborador = @idColaborador AND Ano = {item.ColaboradorAgir.Ano} AND Mes = {item.ColaboradorAgir.Mes})");

                        sql.AppendLine($@"DELETE FROM ColaboradorAgir 
                            WHERE IdColaborador = @idColaborador AND Ano = {item.ColaboradorAgir.Ano} AND Mes = {item.ColaboradorAgir.Mes}");
                    }
                    else
                    {
                        sql.AppendLine($@"UPDATE ColaboradorAgir
                                    SET 
                                        IdAgencia = {item.ColaboradorAgir.IdAgencia},
                                        Carteira = '{item.ColaboradorAgir.Carteira}',
                                        Grade = {(item.ColaboradorAgir.Grade != null ? item.ColaboradorAgir.Grade.ToString() : "NULL")},
                                        IdSegmento = {item.ColaboradorAgir.IdSegmento}
                                    WHERE Id = {item.ColaboradorAgir.IdColaboradorAgir}");
                    }
                }
                else
                {
                    sql.AppendLine(scriptCriacao);
                }
            }

            return sql.ToString();
        }

        public async Task<IEnumerable<Colaborador>> GetAllColaboradores()
        {
            return await _sqlDataContext.SelectQueryToListAsync<Colaborador>("SELECT * FROM Colaborador WITH(NOLOCK) WHERE ElegivelEngajamento = 1");
        }

        public IEnumerable<ColaboradorSimplificado> ObterColaboradores()
        {
            return _sqlDataContext.SelectQueryToList<ColaboradorSimplificado>("SELECT * FROM Colaborador WITH (NOLOCK)");
        }

        #region [ Performance Agir ]

        public async Task<IEnumerable<Colaborador>> GetColaborador(int codigoAgencia)
        {
            var result = await _sqlDataContext.SelectQueryToListAsync<Colaborador>
                    (
                    $@"SELECT * FROM Colaborador (NOLOCK)
                        WHERE IndicadorAtivo = 1 AND CodigoAgencia = {codigoAgencia}"
                    );

            if (result is null)
                return new List<Colaborador>();

            return result;
        }

        public async Task<IEnumerable<ColaboradorFerias>> VerificarColaboradorFerias(string[] funcionais)
        {
            var funcionalParam = funcionais.Select(f => $"'{f}'").Aggregate((f1, f2) => f1 + ',' + f2);
            var data = DateTime.Today.ToString("yyyy-MM-dd");
            var result = await _sqlDataContext.SelectQueryToListAsync<ColaboradorFerias>
                    (
                    $@"SELECT Funcional FROM ColaboradorFerias (NOLOCK)
                        WHERE Funcional IN ({funcionalParam}) AND DataInicio <= CAST('{data}' AS DATETIME) AND DataFim >= CAST('{data}' AS DATETIME)"
                    );

            if (result is null)
                return new List<ColaboradorFerias>();

            return result.ToList();
        }

        #endregion
    }
}