﻿using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;

using Itau.SZ7.GPS.Admin.Domain.Security.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class FuncionalidadeRepository : IFuncionalidadeRepository
    {
        private ISqlDataContext _sqlDataContext;

        public FuncionalidadeRepository(ISqlDataContext sqlDataContext)
        {
            _sqlDataContext = sqlDataContext;
        }

        public Task<IEnumerable<FuncionalidadeHome>> ListarAsync =>  _sqlDataContext.SelectQueryToListAsync<FuncionalidadeHome>("Funcionalidade_Consultar", null);
    }
}
