﻿using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using Itau.SZ7.GPS.Admin.Configuration.Interface;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class EstruturaRepository : IEstruturaRepository
    {
        private readonly IMemoryCache _cache;
        private const string _cacheKey = "EstruturaCacheKey";
        private const string _cacheKeyExpiration = "EstruturaCacheExpiration";
      //  private readonly MemoryCacheEntryOptions _memoryCacheEntryOptions;
        private readonly ISqlDataContext _sqlDataContext;

        public EstruturaRepository(ISqlDataContext sqlDataContext, IMemoryCache cache, IMemoryCacheConfiguration memoryCacheConfiguration)
        {
            _sqlDataContext = sqlDataContext;
           // _cache = cache;
           // _memoryCacheEntryOptions = memoryCacheConfiguration.GetConfiguracaoCache(_cacheKeyExpiration);
        }
        public IEnumerable<Estrutura> GetEstruturas()
        {
            #region MyRegion
            // var cacheKey = $"{_cacheKey}GetEstrutura";
            //  if (!_cache.TryGetValue(cacheKey, out IEnumerable<Estrutura> estruturas))
            // {
            //  _cache.Set(cacheKey, estruturas, _memoryCacheEntryOptions);
            // }

            #endregion

            string query = "SELECT [Id],[DataCriacao],[DataAtualizacao],[Nome] FROM [dbo].[Estrutura]";
            var estruturas = _sqlDataContext.SelectQueryToList<Estrutura>(query, null);

            return estruturas?.ToList() ?? new List<Estrutura>();
        }

        public Estrutura GetEstrutura(string estrutura)
        {
            IEnumerable<Estrutura> estruturas = GetEstruturas();
            return estruturas.FirstOrDefault(s => s.Nome.Equals(estrutura, StringComparison.OrdinalIgnoreCase)) ?? new Estrutura();
        }

        public Estrutura GetEstrutura(int idEstrutura)
        {
            IEnumerable<Estrutura> estruturas = GetEstruturas();
            return estruturas.SingleOrDefault(s => s.Id == idEstrutura);
        }
    }
}
