﻿using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Domain.Indicadores.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    public class InnerLoopLiberacaoFuncionalidadeRepository : IInnerLoopLiberacaoFuncionalidadeRepository
    {

        private readonly BulkConfig _bulkConfig;
        private readonly string _connectionString;

        public InnerLoopLiberacaoFuncionalidadeRepository(IAppConfiguration appConfiguration)
        {
            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };
            
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
        }


        public void BulkInsert(List<InnerLoopLiberacaoFuncionalidade> models, int? batchSize)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaInsertScript(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        SqlTransaction transaction = conn.BeginTransaction("bulkinsert");
                        cmd.Transaction = transaction;

                        try
                        {
                            var sqlTemp = new List<string>();
                            var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                            sqlTemp.AddRange(sqlList.Take(_batchSize));
                            sqlList.RemoveRange(0, _batchSize);

                            cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                            cmd.ExecuteNonQuery();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            try
                            {
                                transaction.Rollback();
                            }
                            catch (Exception ex2)
                            {

                            }

                            throw ex;
                        }

                    }

                    conn.Close();
                }
            }
        }

        public void InsertSQL(InnerLoopLiberacaoFuncionalidade model)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = CriaInsertScript(model, 0);

                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private List<string> CriaInsertScript(List<InnerLoopLiberacaoFuncionalidade> permissoes)
        {
            var resultado = new List<string>();

            for (int i = 0; i < permissoes.Count; i++)
            {
                resultado.Add(CriaInsertScript(permissoes[i], i));
            }

            return resultado;
        }

        private string CriaInsertScript(InnerLoopLiberacaoFuncionalidade permissao, int i)
        {
            var resultado = $"INSERT INTO InnerLoopLiberacaoFuncionalidade values(" +
                            $"{permissao.IdSegmentoColaborador}," +
                            $"{permissao.AgenciaResponsavel}," +
                            $"getdate()" +
                            $") ";
            return resultado;
        }

        public void RemoveRegistros()
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 600;

                conn.Open();

                cmd.CommandText = $"DELETE FROM InnerLoopLiberacaoFuncionalidade";

                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }
    }
}
