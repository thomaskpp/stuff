﻿using EFCore.BulkExtensions;
using Itau.SZ7.GPS.Admin.Configuration.Interface;
using Itau.SZ7.GPS.Admin.Data.Interface;
using Itau.SZ7.GPS.Admin.Entities;
using Itau.SZ7.GPS.Admin.Enums;
using Itau.SZ7.GPS.Admin.Helpers;
using Itau.SZ7.GPS.Admin.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Admin.Repositories
{
    /// <summary>
    /// 
    /// </summary>
    public class CheckoutRepository : ICheckoutRepository
    {
        private readonly string _connectionString;
        private readonly BulkConfig _bulkConfig;
        private readonly ISqlDataContext _sqlDataContext;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appConfiguration"></param>
        public CheckoutRepository(IAppConfiguration appConfiguration, ISqlDataContext sqlDataContext)
        {
            _connectionString = appConfiguration.GetConnectionStrings("GPSConnection");
            _bulkConfig = new BulkConfig
            {
                PreserveInsertOrder = false,
                SetOutputIdentity = false,
                UseTempDB = false,
                BatchSize = 30
            };
            _sqlDataContext = sqlDataContext;
        }

        #region RECALCULAR AGIR 
        public IEnumerable<PlanejamentoCheckout> GetPlanejamentoCheckoutsByAnoMes(short ano, short mes)
        {
            return _sqlDataContext.SelectQueryToList<PlanejamentoCheckout>($@"
                                SELECT    ckt.Id
                                          ,DataCheckout 
	                                      ,ckt.IdAgencia
	                                      ,ckt.Carteira
	                                      ,Ano
	                                      ,Mes
	                                      ,ckt.[CodigoItem]	
	                                      ,[AgenciaContaDac]
	                                      ,[IndicadorStatus]
	                                      ,[DataDebito]
	                                      ,[ValorCheckout]
	                                      ,[ValorPontuacao]
	                                      ,[ValorProducao]
	                                      ,[ValorICM]
	                                      ,[CPF]
	                                      ,ckt.[IdSegmento]
	                                      ,[Comentario]
	                                       FROM Checkout ckt
	                                       JOIN Produto pdt ON pdt.Id = ckt.IdProduto and ckt.IdSegmento = pdt.IdSegmento 
	                                       WHERE pdt.Mes = {mes} AND pdt.Ano = {ano}",
                                           System.Data.CommandType.Text,
                                           null);
        }

        public List<PlanejamentoCheckout> GetPlanejamentoPersonnaliteCheckoutsByAnoMesPersonnalite(short? ano, short? mes)
        {
            return _sqlDataContext.SelectQueryToList<PlanejamentoCheckout>
                        (
                        $@"SELECT [DataCheckout] 
	                          ,ca.[IdAgencia]
	                          ,ca.[Carteira]
	                          ,[Grade]
	                          ,ca.[Ano]
	                          ,ca.[Mes]
	                          ,ckt.[CodigoItem]	
	                          ,ca.[IdSegmento]
	                          ,[AgenciaContaDac]
	                          ,[IndicadorStatus]
	                          ,[DataDebito]
	                          ,[ValorCheckout]
	                          ,[ValorPontuacao]
	                          ,[ValorProducao]
	                          ,[ValorICM]
	                          ,[CPF]
	                          ,[Comentario]
	                           FROM CheckoutPersonnalite ckt
	                           JOIN Produto pdt ON pdt.codigoitem = ckt.codigoitem
	                           JOIN ColaboradorAgir ca ON ckt.idAgencia = ca.IdAgencia
	                           WHERE ca.Mes = {mes} AND ca.Ano = {ano}").ToList();
        }

        public int BulkInsertUpdatePlanejamentoCheckouts(List<PlanejamentoCheckout> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                        sqlList.Add(CriaInsertUpdateScriptCheckouts(item));

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("produtogradeitem-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = cmd.ExecuteNonQuery();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        public async Task<int> BulkInsertUpdatePlanejamentoCheckoutsPersonnalite(List<PlanejamentoCheckout> models, int? batchSize)
        {
            var _batchSize = batchSize ?? 30;
            var resultado = 0;

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = new List<string>();

                    foreach (var item in models)
                        sqlList.Add(CriaInsertUpdateScriptCheckoutsPersonnalite(item));

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    await conn.OpenAsync();

                    while (sqlList.Any())
                    {
                        using (var transaction = conn.BeginTransaction("produtogradeitem-bulkinsert"))
                        {
                            cmd.Transaction = transaction;

                            try
                            {
                                var sqlTemp = new List<string>();
                                var numRegistros = sqlList.Count > _batchSize ? _batchSize : sqlList.Count;

                                sqlTemp.AddRange(sqlList.Take(numRegistros));
                                sqlList.RemoveRange(0, numRegistros);

                                cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                                resultado = await cmd.ExecuteNonQueryAsync();

                                transaction.Commit();
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch { }

                                throw;
                            }
                        }
                    }

                    conn.Close();
                }
            }

            return resultado;
        }

        private string CriaInsertUpdateScriptCheckouts(PlanejamentoCheckout item)
        {
            return $@" UPDATE Checkout
	                    SET [DataCheckout] = GETDATE()
	                        ,[idAgencia] = {item.IdAgencia}
	                        ,[IdSegmento] = {item.IdSegmento}
	                        ,[ValorICM] = {item.ValorICM}
	                        ,[ValorPontuacao] = {item.ValorPontuacao}
	                    FROM Checkout ckt
	                    WHERE Id = {item.Id} ";
        }

        private string CriaInsertUpdateScriptCheckoutsPersonnalite(PlanejamentoCheckout item)
        {
            return $@" UPDATE CheckoutPersonnalite
	                SET [DataCheckout] = GETDATE()
	                ,[idAgencia] = {item.IdAgencia}
	                ,[IdSegmento] = {item.IdSegmento}
	                ,[ValorICM] = {item.ValorICM}
	                ,[ValorPontuacao] = {item.ValorPontuacao}
	                FROM CheckoutPersonnalite ckt
	                JOIN ColaboradorAgir ca ON ckt.idAgencia = ca.idAgencia 
	                WHERE [DataCheckout] = {item.DataCheckout}
	                AND ca.[Carteira] = '{item.Carteira}'
	                AND ca.[Ano] = {item.Ano}
	                AND ca.[Mes] = {item.Mes}
	                AND ckt.[CodigoItem] = {item.CodigoItem} ";
        }

        public bool RemoveExistentesPorItem(List<PlanejamentoCheckout> models, GerenciadorCarga gerenciador, int? batchSize)
        {
            _bulkConfig.BatchSize = batchSize ?? _bulkConfig.BatchSize;
            var passoAtual = gerenciador.Passos.First(x => x.Passo == CargasPassos.Remocao);

            using (var conn = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand())
                {
                    var sqlList = CriaDeleteScript(models);

                    cmd.Connection = conn;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandTimeout = 600;

                    conn.Open();

                    var contadorLog = 0;

                    while (sqlList.Any())
                    {
                        var sqlTemp = new List<string>();
                        var _batchSize = sqlList.Count > _bulkConfig.BatchSize ? _bulkConfig.BatchSize : sqlList.Count;

                        sqlTemp.AddRange(sqlList.Take(_batchSize));
                        sqlList.RemoveRange(0, _batchSize);

                        cmd.CommandText = string.Join("\n", sqlTemp.ToArray());

                        cmd.ExecuteNonQuery();

                        passoAtual.LinhasProcessadas = gerenciador.TotalLinhas - sqlList.Count;
                        passoAtual.Atualizado = DateTime.Now;

                        contadorLog++;

                        if (contadorLog % 100 == 0)
                        {
                            //gravarGerenciador(gerenciador);
                            contadorLog = 0;
                        }
                    }

                    conn.Close();
                }
            }

            return true;
        }

        private List<string> CriaDeleteScript(List<PlanejamentoCheckout> models)
        {
            var resultado = new List<string>();

            foreach (var item in models)
                resultado.Add($@"   DELETE [dbo].[PlanejamentoCheckout]
 WHERE CodigoAgencia = {item.CodigoAgencia}
   AND Carteira = '{item.Carteira}'
   AND Grade = {item.Grade}
   AND Ano = {item.Ano}
   AND Mes = {item.Mes}
   AND CodigoItem = {item.CodigoItem}");

            return resultado;
        }
        #endregion

        public async Task<IEnumerable<PlanejamentoCheckout>> GetAllCheckoutsMesAnoAsync(int Mes, int Ano)
        {
            return await _sqlDataContext.SelectQueryToListAsync<PlanejamentoCheckout>($"SELECT * FROM PlanejamentoCheckout WITH(NOLOCK) WHERE Mes = {Mes} AND Ano = {Ano}");
        }

        public async Task<IEnumerable<PlanejamentoCheckout>> GetAllPlanejamentoCheckoutsMesAnoCarteira(string carteira, int mes, int ano)
        {
            IEnumerable<PlanejamentoCheckout> planejamentoCheckouts = new List<PlanejamentoCheckout>();

            string query = "GPS_PlanejamentoCheckout_ConsultarCheckoutMesAnoCarteira";

            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { "carteira", carteira },
                { "ano", ano },
                { "mes", mes }
            };

            planejamentoCheckouts = await _sqlDataContext.SelectQueryToListAsync<PlanejamentoCheckout>(query, parameters);

            return planejamentoCheckouts;
        }
    }
}
