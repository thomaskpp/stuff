﻿using System;

namespace Itau.SZ7.GPS.Core.Excecoes.Tipos
{
    public class EnumNaoEncontradoException : Exception
    {
        public EnumNaoEncontradoException(string message) : base(message)
        {
        }
    }
}
