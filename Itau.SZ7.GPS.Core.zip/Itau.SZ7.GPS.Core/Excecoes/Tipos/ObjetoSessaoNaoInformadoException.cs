﻿using System;

namespace Itau.SZ7.GPS.Core.Excecoes.Tipos
{
    public class ObjetoSessaoNaoInformadoException : Exception
    {
        public ObjetoSessaoNaoInformadoException(string message) : base(message)
        {

        }
    }
}
