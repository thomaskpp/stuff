﻿using Itau.SZ7.GPS.Core.Extensoes.Tipos;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Excecoes
{
    public class GPSExceptionHandler
    {
        private readonly RequestDelegate _next;

        /// <summary>
        /// Create new instance of GPSExceptionHandler
        /// </summary>
        /// <param name="next"></param>
        /// <param name="logger"></param>
        public GPSExceptionHandler(RequestDelegate next)
        {
            _next = next;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext httpContext,
            ISessaoServico sessaoServico,
            IConfiguracaoServico configuracaoServico,
            ILogServico logServico)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception exception)
            {
                await HandleExceptionAsync(httpContext, exception, sessaoServico, configuracaoServico, logServico);
            }
        }

        private Task HandleExceptionAsync(HttpContext context, 
            Exception exception,
            ISessaoServico sessaoServico,
            IConfiguracaoServico configuracaoServico,
            ILogServico logServico)
        {
            var errorMessage = ExceptionExtension.RetornaInnerException(exception);
            //int statusCode = (int)HttpStatusCode.BadRequest;
            //var exceptionType = exception.GetType();
            var logAtivo = configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.CONFIG_LOGERRO_ATIVO, true);
            var sessao = sessaoServico.RetornaSessao();

            //switch (exception)
            //{
            //    case Exception e when exceptionType == typeof(UnauthorizedAccessException):
            //        statusCode = (int)HttpStatusCode.Unauthorized;
            //        break;

            //    case GPSApplicationException e when exceptionType == typeof(GPSApplicationException) || exceptionType.BaseType == typeof(GPSApplicationException):
            //        int.TryParse(e.Code, out statusCode);
            //        errorMessage = e.Message;
            //        break;

            //    default:
            //        statusCode = (int)HttpStatusCode.InternalServerError;
            //        errorMessage = exception.Message;
            //        break;
            //}

            var response = new { message = errorMessage };
            var payload = JsonConvert.SerializeObject(response);
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            if (logAtivo)
            {
                logServico.RegistrarCritico(
                    JsonConvert.SerializeObject(new
                    {
                        Excecao = ExceptionExtension.RetornaInnerException(exception),
                        StackTrace = ExceptionExtension.RetornaStackTrace(exception),
                        Sessao = new
                        {
                            sessao.Guid,
                            sessao.ApiGuid,
                            sessao.IdColaborador,
                            sessao.IdColaboradorAgir,
                            sessao.IdFuncionalidade,
                            sessao.IdPlataforma,
                            sessao.VersaoApi
                        }
                    }),
                    exception.TargetSite.ToString());
            }

            return context.Response.WriteAsync(payload);

        }
    }


    public static class GPSExceptionHandlerExtensions
    {
        /// <summary>
        /// Add GPSExceptionHandler to the application request pipeline
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseGPSExceptionHandler(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<GPSExceptionHandler>();
        }
    }
}
