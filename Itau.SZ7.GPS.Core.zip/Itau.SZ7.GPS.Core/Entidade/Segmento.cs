﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Core.Entidade
{
    public class Segmento
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Sigla { get; set; }
        public string Sinonimos { get; set; }
        public int IdEstrutura { get; set; }

        public enum Enum
        {
            Agencias = 1,

            Uniclass = 2,

            Empresas4 = 3,

            Operacional = 4,

            Personnalite = 5,

            OperacionalPersonnalite = 6,

            Empresas2 = 7,

            OperacionalDigitalPersonnalite = 8,

            OperacionalDigitalUniclass = 9,

            Empresas3 = 10,

            OperacionalDigitalEmpresas = 11,

            Adm = 12
        }

    }
}
