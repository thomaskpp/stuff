﻿namespace Itau.SZ7.GPS.Core.Entidade
{
    public class LogAcessoDadosAdicionais
    {
        public string Guid { get; set; }
        public string ApiGuid { get; set; }
        public string VersaoApi { get; set; }
    }
}
