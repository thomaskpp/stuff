﻿using System;

namespace Itau.SZ7.GPS.Core.Entidade
{
    public class Logs
    {
        public Logs()
        {
            DataCriacao = DateTime.Now;
        }

        public int Id { get; set; }
        public string Guid { get; set; }
        public string ApiGuid { get; set; }
        public DateTime DataCriacao { get; set; }
        public int? IdColaborador { get; set; }
        public int IdPlataforma { get; set; }
        public int IdFuncionalidade { get; set; }
        public int? IdColaboradorAgir { get; set; }
        public string StackTrace { get; set; }
        public string Descricao { get; set; }
        public int IdLogTipo { get; set; }
        public string MetodoOrigem { get; set; }
        public string Versao { get; set; }
        public string Servidor { get; set; }
        
    }
}
