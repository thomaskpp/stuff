﻿using System;

namespace Itau.SZ7.GPS.Core.Entidade
{
    public class LogAcesso
    {
        public LogAcesso()
        {
            Data = DateTime.Now;
        }

        public int Id { get; set; }
        public DateTime Data { get; set; }
        public int? IdColaborador { get; set; }
        public int IdPlataforma { get; set; }
        public int IdFuncionalidade { get; set; }
        public int CodigoEvento { get; set; }
        public int? IdColaboradorAgir { get; set; }
        public bool Sucesso { get; set; }
        public long TempoExecucao { get; set; }

        public string DadosAdicionais { get; set; }
    }
}
