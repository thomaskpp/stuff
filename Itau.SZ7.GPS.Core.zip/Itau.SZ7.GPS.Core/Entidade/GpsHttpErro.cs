﻿namespace Itau.SZ7.GPS.Core.Entidade
{
    public class GpsHttpErro
    {
        public string Mensagem { get; set; }
    }
}
