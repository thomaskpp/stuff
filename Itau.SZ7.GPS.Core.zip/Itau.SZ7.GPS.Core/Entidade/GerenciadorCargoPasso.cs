﻿using Itau.SZ7.GPS.Core.Dados.Enums.Admin;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Itau.SZ7.GPS.Core.Entidade
{
    public class GerenciadorCargaPasso
    {
        public GerenciadorCargaPasso()
        {
            ErroLinhas = new List<int>();
        }

        public int IdGerenciadorCarga { get; set; }
        public CargasPassos Passo { get; set; }
        public string Nome { get; set; }
        public int LinhasProcessadas { get; set; }
        public DateTime? Atualizado { get; set; }
        public bool Erro { get; set; }
        public DateTime? Inicio { get; set; }
        public DateTime? Fim { get; set; }

        [NotMapped]
        public List<int> ErroLinhas { get; set; }
        [NotMapped]
        public string TempoDecorrido
        {
            get
            {
                if (Fim.HasValue && Inicio.HasValue)
                    return Fim.Value.Subtract(Inicio.Value).ToString("hh\\:mm\\:ss");
                else if (Inicio.HasValue)
                    return DateTime.Now.Subtract(Inicio.Value).ToString("hh\\:mm\\:ss");
                else
                    return string.Empty;
            }
        }
    }
}
