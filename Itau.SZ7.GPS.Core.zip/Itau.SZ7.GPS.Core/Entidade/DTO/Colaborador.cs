﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Core.Entidade.DTO
{
    public class Colaborador
    {
        public int Id { get; set; }
        public string Funcional { get; set; }
        public string Racf { get; set; }
        public string Nome { get; set; }
        public int? IdCargo { get; set; }
        public bool Ativo { get; set; }

        public IEnumerable<ColaboradorAgir> ColaboradorAgir { get; set; }
    }
}
