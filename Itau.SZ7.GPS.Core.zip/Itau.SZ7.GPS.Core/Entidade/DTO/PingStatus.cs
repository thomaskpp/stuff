﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Core.Entidade.DTO
{
    public class PingStatus
    {
        public bool ConexaoDB { get; set; }
        public string ConnectionString { get; set; }
        public string ConfiguracaoEndpoint { get; set; }
        public string CaminhoFisico { get; set; }
        public string CaminhoVirtual { get; set; }
        public long TempoDecorrido { get; set; }
    }
}
