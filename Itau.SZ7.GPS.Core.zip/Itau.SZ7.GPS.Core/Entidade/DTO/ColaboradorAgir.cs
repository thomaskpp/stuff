﻿namespace Itau.SZ7.GPS.Core.Entidade.DTO
{
    public class ColaboradorAgir
    {
        public int Id { get; set; }
        public string Carteira { get; set; }
        public int IdColaborador { get; set; }
        public int IdAgencia { get; set; }
        public int IdSegmento { get; set; }
        public string CodigoAgencia { get; set; }
    }
}
