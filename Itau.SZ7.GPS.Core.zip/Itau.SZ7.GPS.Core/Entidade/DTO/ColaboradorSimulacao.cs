﻿namespace Itau.SZ7.GPS.Core.Entidade.DTO
{
    public class ColaboradorSimulacao
    {
        public string Usuario { get; set; }
        public string Senha { get; set; }
    }
}
