﻿using System;

namespace Itau.SZ7.GPS.Core.Entidade
{
    public class ConfiguracaoItem
    {
        public int Id { get; set; }
        public int IdConfiguracao { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public string Chave { get; set; }
        public string Valor { get; set; }
        public int IdConfiguracaoItemTipo { get; set; }
    }
}
