﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Entidade
{
    public class GpsHttpResponse<T>
    {
        private readonly HttpResponseMessage _resposta;

        public GpsHttpResponse(HttpResponseMessage resposta)
        {
            _resposta = resposta;
        }

        public bool IsSuccessStatusCode { get { return _resposta.IsSuccessStatusCode; }  }

        public HttpStatusCode StatusCode { get { return _resposta.StatusCode; } }

        public T Conteudo { get; private set; }

        public string Erro { get; private set; }

        public async Task CarregarConteudo()
        {
            if (IsSuccessStatusCode)
                Conteudo = await _resposta.Content.ReadAsAsync<T>();
            else
                Erro = await _resposta.Content.ReadAsStringAsync();
        }
    }
}
