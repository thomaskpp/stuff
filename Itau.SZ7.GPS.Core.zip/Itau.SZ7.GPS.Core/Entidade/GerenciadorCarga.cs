﻿using Itau.SZ7.GPS.Core.Dados.Enums.Admin;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Linq;
using System.Text;

namespace Itau.SZ7.GPS.Core.Entidade
{
    public class GerenciadorCarga
    {
        public GerenciadorCarga()
        {
            FileStream = new MemoryStream();
            Passos = new List<GerenciadorCargaPasso>();
            GravaCarga = true;
        }

        public int Id { get; set; }
        public Cargas IdCarga { get; set; }
        public string Arquivo { get; set; }
        public string Funcional { get; set; }
        public string NomeFuncional { get; set; }
        public DateTime? Inicio { get; set; }
        public DateTime? Fim { get; set; }
        public int TotalLinhas { get; set; }

        public Segmento.Enum Segmento { get; set; }
        public short? Ano { get; set; }
        public short? Mes { get; set; }
        public bool PopupConclusao { get; set; }


        [NotMapped]
        public List<GerenciadorCargaPasso> Passos { get; set; }

        [NotMapped]
        [JsonIgnore]
        public MemoryStream FileStream { get; set; }

        [NotMapped]
        public string InicioFormatado
        {
            get
            {
                return Inicio.HasValue ? Inicio.Value.ToString("dd/MM/yy HH:mm:ss") : string.Empty;
            }
        }

        [NotMapped]
        public string FimFormatado
        {
            get
            {
                return Fim.HasValue ? Fim.Value.ToString("dd/MM/yy HH:mm:ss") : string.Empty;
            }
        }

        [NotMapped]
        public string FimDataFormatado
        {
            get
            {
                return Fim.HasValue ? Fim.Value.ToString("dd/MM/yy") : string.Empty;
            }
        }

        [NotMapped]
        public string FimHoraFormatado
        {
            get
            {
                return Fim.HasValue ? Fim.Value.ToString("HH:mm:ss") : string.Empty;
            }
        }

        [NotMapped]
        public string TempoTermino
        {
            get
            {
                var tempo = Fim.HasValue ? Fim.Value.Subtract(Inicio.HasValue ? Inicio.Value : DateTime.Now) : DateTime.Now.TimeOfDay;
                return tempo.ToString();
            }
        }

        [NotMapped]
        public decimal ProgressoAtual
        {
            get
            {
                if (!Fim.HasValue && TotalLinhas > 0 && Passos.Count > 0)
                {
                    return Math.Ceiling((Convert.ToDecimal(Passos.Sum(x => x.LinhasProcessadas)) * 100)
                        / Convert.ToDecimal(TotalLinhas * Passos.Count));
                }
                else
                    return 0;
            }
        }

        [NotMapped]
        public string PassoAtual
        {
            get
            {
                return Passos.Count > 0 ? Passos.Last().Nome : "Iniciando";
            }
        }

        [NotMapped]
        public decimal PassoAtualProgresso
        {
            get
            {
                if (!Fim.HasValue && TotalLinhas > 0 && Passos.Count > 0)
                {
                    return Math.Ceiling((Convert.ToDecimal(Passos.Last().LinhasProcessadas) * 100)
                        / Convert.ToDecimal(TotalLinhas));
                }
                else
                    return 0;
            }
        }

        [NotMapped]
        public int PassoAtualLinhasProcessadas
        {
            get
            {
                return Passos.Count > 0 ? Passos.Last().LinhasProcessadas : 0;
            }
        }

        [NotMapped]
        public string PassoAtualAtualizadoEmFormatado
        {
            get
            {
                var data = Passos.Count > 0 && Passos.Last().Atualizado.HasValue
                    ? Passos.Last().Atualizado.Value
                    : DateTime.Now;

                return data.ToString("dd/MM/yy HH:mm:ss");

            }
        }

        [NotMapped]
        public string PassoAtualTempoDecorrido
        {
            get
            {
                var data = Passos.Count > 0 && Passos.Last().Atualizado.HasValue
                    ? Passos.Last().Atualizado.Value
                    : DateTime.Now;

                return DateTime.Now.Subtract(data).ToString("hh\\:mm\\:ss");

            }
        }

        [NotMapped]
        public bool Finalizado
        {
            get
            {
                return Fim.HasValue;
            }
        }

        [NotMapped]
        public bool ContemErro
        {
            get
            {
                return Passos.Any(x => x.Erro);
            }
        }

        [NotMapped]
        public string ArquivoApelido { get; set; }

        [NotMapped]
        public bool GravaCarga { get; set; }

        [NotMapped]
        public string TempoDecorrido
        {
            get
            {
                if (Inicio.HasValue)
                    return DateTime.Now.Subtract(Inicio.Value).ToString("hh\\:mm\\:ss");
                else
                    return string.Empty;
            }
        }

        [NotMapped]
        public int TotalLinhasInseridas
        {
            get
            {
                var passoInsercao = Passos.FirstOrDefault(x => x.Passo == CargasPassos.Insercao);

                if (passoInsercao != null)
                    return passoInsercao.LinhasProcessadas;
                else
                    return 0;
            }
        }

        public string TotalLinhasInseridasPercentual
        {
            get
            {
                if (TotalLinhasInseridas > 0)
                {
                    var perc = (Convert.ToDouble(TotalLinhasInseridas) / Convert.ToDouble(TotalLinhas)) * 100;

                    return $"{(perc > 99.5 ? 100 : Math.Round(perc, 2))}%";
                }
                else
                {
                    return "0%";
                }

            }
        }

        [NotMapped]
        public GerenciadorCargaConfiguracao Configuracao { get; set; }
    }
}
