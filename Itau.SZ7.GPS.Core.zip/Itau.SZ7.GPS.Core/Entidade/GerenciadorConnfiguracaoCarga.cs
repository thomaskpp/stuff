﻿using Itau.SZ7.GPS.Core.Dados.Enums.Admin;
using System;
using System.Collections.Generic;
using System.Text;

namespace Itau.SZ7.GPS.Core.Entidade
{
    public class GerenciadorCargaConfiguracao
    {
        public Cargas IdCarga { get; set; }
        public string Nome { get; set; }
        public string FuncionalResponsavel { get; set; }
        public string NomeResponsavel { get; set; }
        public CargasTipoPeriodo TipoPeriodo { get; set; }
        public string ValorPeriodo { get; set; }
        public bool Ocultar { get; set; }
        public bool TravaSimultanea { get; set; }
        public string DsUrl { get; set; }
        public int IdFuncionalidade { get; set; }
    }
}
