﻿using System;

namespace Itau.SZ7.GPS.Core.Entidade
{
    public class Endpoint
    {
        public string Nome { get; set; }
        public string Url { get; set; }

        public override bool Equals(object obj)
        {
            return obj is Endpoint endpoint &&
                   Nome == endpoint.Nome &&
                   Url == endpoint.Url;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Nome, Url);
        }
    }
}
