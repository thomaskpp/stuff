﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Extensoes
{
    public static class CacheExtension
    {
        public static async Task<TItem> RetornaOuCriaAsync<TItem>(this IMemoryCache cache, object key, Func<ICacheEntry, Task<TItem>> factory)
        {
            cache.TryGetValue(key, out object result);

            if (result == null)
            {
                var entry = cache.CreateEntry(key);
                result = await factory(entry);

                if (result != null)
                    entry.SetValue(result);

                entry.Dispose();
            }

            return (TItem)result;
        }
    }
}
