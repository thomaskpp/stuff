﻿using Itau.SZ7.GPS.Core.Dados;
using Itau.SZ7.GPS.Core.Dados.Http;
using Itau.SZ7.GPS.Core.Dados.Interface;
using Itau.SZ7.GPS.Core.Dados.Sql.Extensions;
using Itau.SZ7.GPS.Core.Excecoes;
using Itau.SZ7.GPS.Core.Repositorio;
using Itau.SZ7.GPS.Core.Repositorio.Interface;
using Itau.SZ7.GPS.Core.Seguranca;
using Itau.SZ7.GPS.Core.Servicos;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.PlatformAbstractions;
using Polly;
using Polly.Extensions.Http;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerUI;
using System;
using System.Collections.Generic;
using System.IO;

namespace Itau.SZ7.GPS.Core.Extensoes
{
    public static class StartupExtensions
    {
        private static IServiceCollection _serviceCollection;

        public static void RegistraServices(this IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            services.AddResponseCompression();
            services.ConfiguraSwagger();

            services.AddApiVersioning(p =>
            {
                p.DefaultApiVersion = new ApiVersion(1, 0);
                p.ReportApiVersions = true;
                p.AssumeDefaultVersionWhenUnspecified = true;
            });

            services.AddVersionedApiExplorer(p =>
            {
                p.GroupNameFormat = "'v'VVV";
                p.SubstituteApiVersionInUrl = true;
            });

            //implementar
            //services.AddHealthChecks();

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder.AllowAnyOrigin()
                      .AllowAnyMethod()
                      .AllowAnyHeader()
                      .AllowCredentials()
                      .WithExposedHeaders("X-fdad_token")
                .Build());
            });

            services.AddAuthentication((options) =>
            {
                options.DefaultAuthenticateScheme = GPSAuthenticationDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = GPSAuthenticationDefaults.AuthenticationScheme;
            }).AddGPSAuth();
        }

        public static void ConfiguraServices(
            this IApplicationBuilder app,
            string apiGuid)
        {
            app.UseHeaderParserHandler();
            app.UseLogAnaliticoHandler();
            app.UseConfigurarSqlDataContextHandler();
            app.UseDeveloperExceptionPage();
            app.UseGPSExceptionHandler();
            app.EnableSwagger();
            app.UseCors("CorsPolicy");
            app.UseStaticFiles();
            app.UseAuthentication();
            app.DefineApiGuid(apiGuid);

            //implementar
            //app.UseHealthChecks();

            app.UseMvc();
            app.UseApiVersioning();
        }

        public static void CoreDependencyMap(this IServiceCollection services)
        {
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>()
                .AddScoped<IUrlHelper>(x => x
                .GetRequiredService<IUrlHelperFactory>()
                .GetUrlHelper(x.GetRequiredService<IActionContextAccessor>().ActionContext));

            services.AddSingleton<IConfigurationBuilder, ConfigurationBuilder>();
            services.AddSingleton<ICache, Cache>();

            services.AddTransient<HttpRequestHeaderHandler>()
                .AddHttpClient<IGpsHttpClient, GpsHttpClient>()
                .AddHttpMessageHandler<HttpRequestHeaderHandler>();

            services.AddSingleton<ISessaoServico, SessaoServico>();

            services.AddSingleton<IConfiguracaoServico, ConfiguracaoServico>();
            services.AddScoped<ILogServico, LogServico>();
            services.AddScoped<ILogAcessoServico, LogAcessoServico>();

            services.AddSingleton<IConfiguracaoRepositorio, ConfiguracaoRepositorio>();
            services.AddScoped<ILogRepositorio, LogRepositorio>();
            services.AddScoped<ILogAcessoRepositorio, LogAcessoRepositorio>();

            services.AddScoped<IValidacaoUsuarioServico, ValidacaoUsuarioServico>();
            services.AddScoped<IValidacaoUsuarioRepositorio, ValidacaoUsuarioRepositorio>();


            services.ConfigurarSqlDataContext();

            _serviceCollection = services;
        }

        private static IApplicationBuilder DefineApiGuid(this IApplicationBuilder app, string apiGuid)
        {
            var scope = app.ApplicationServices.CreateScope();
            var servico = scope.ServiceProvider.GetService<IConfiguracaoServico>();

            servico.DefineApiGuid(apiGuid);

            return app;
        }

        #region swagger

        private static void ConfiguraSwagger(this IServiceCollection services)
        {
            services.AddSwaggerGen(x =>
            {
                x.SwaggerDoc("v1", new Info
                {
                    Description = "",
                    Version = "v1",
                    Title = "GPS API"
                });

                x.SwaggerDoc("v2", new Info
                {
                    Description = "",
                    Version = "v2",
                    Title = "GPS API"
                });

                x.SwaggerDoc("v3", new Info
                {
                    Description = "",
                    Version = "v3",
                    Title = "GPS API"
                });

                var security = new Dictionary<string, IEnumerable<string>>
                {
                    {"fdad_token", new string[] { }},
                    { "X-fdad_apitoken", new string[] { }}
                };

                x.AddSecurityDefinition("fdad_token", new ApiKeyScheme
                {
                    Description = "fdad_token: {token}",
                    Name = "fdad_token",
                    In = "header",
                    Type = "apiKey"
                });
                x.AddSecurityDefinition("X-fdad_apitoken", new ApiKeyScheme
                {
                    Description = "apitoken",
                    Name = "X-fdad_apitoken",
                    In = "header",
                    Type = "apiKey"
                });

                x.AddSecurityRequirement(security);

                x.CustomSchemaIds(itemType => itemType.FullName);

                string caminhoXmlDoc =
                    Path.Combine(PlatformServices.Default.Application.ApplicationBasePath, $"{PlatformServices.Default.Application.ApplicationName}.xml");

                if (File.Exists(caminhoXmlDoc))
                    x.IncludeXmlComments(caminhoXmlDoc);

                x.IgnoreObsoleteProperties();
                x.IgnoreObsoleteActions();
            });

        }

        private static void EnableSwagger(this IApplicationBuilder app)
        {
            var serviceProvider = _serviceCollection.BuildServiceProvider();
            var configuration = serviceProvider.GetRequiredService<IConfiguration>();
            var configurationBuilder = serviceProvider.GetRequiredService<IConfigurationBuilder>();
            var provider = serviceProvider.GetRequiredService<IApiVersionDescriptionProvider>();
            var appSettings = Configuracao.CriaArquivoConfiguracao(configuration, configurationBuilder);

            var swaggerBasePath = appSettings["SwaggerBasePath"] ?? string.Empty;

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                string basePath = Environment.GetEnvironmentVariable("ASPNETCORE_APPL_PATH");

                if (string.IsNullOrEmpty(basePath))
                    basePath = swaggerBasePath;

                foreach (var description in provider.ApiVersionDescriptions)
                {
                    c.SwaggerEndpoint(
                    $"{basePath.TrimEnd('/') ?? string.Empty}/swagger/{description.GroupName}/swagger.json",
                    description.GroupName.ToUpperInvariant());
                }

                c.DocExpansion(DocExpansion.List);
                c.RoutePrefix = string.Empty;
            });
        }

        #endregion

        #region polly


        public static IServiceCollection AddPollyPolicies(
            this IServiceCollection services,
            IConfiguracaoServico configuracaoServico)
        {
            bool.TryParse(configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.POLLY_HABILITADO), out bool habilitarPolly);

            if (habilitarPolly)
            {
                int.TryParse(configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.POLLY_HTTP_RETENTATIVA_QTDE), out int quantidadeTentativas);
                int.TryParse(configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.POLLY_HTTP_RETENTATIVA_TEMPO_ESPERA), out int tempoEspera);
                int.TryParse(configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.POLLY_HTTP_DIJUNTOR_EXCECOES_PERMITIDAS), out int excecoesPermitidas);
                int.TryParse(configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.POLLY_HTTP_DIJUNTOR_TEMPO_DESLIGADO), out int tempoDesligado);

                var policyRegistry = services.AddPolicyRegistry();
                policyRegistry.Add(
                    ChavesPadrao.POLLY_HTTP_RETENTATIVA,
                    HttpPolicyExtensions
                        .HandleTransientHttpError()
                        .WaitAndRetryAsync(
                            quantidadeTentativas,
                            retryAttempt => TimeSpan.FromSeconds(Math.Pow(tempoEspera, retryAttempt))));

                policyRegistry.Add(
                    ChavesPadrao.POLLY_HTTP_DIJUNTOR,
                    HttpPolicyExtensions
                        .HandleTransientHttpError()
                        .CircuitBreakerAsync(
                            handledEventsAllowedBeforeBreaking: excecoesPermitidas,
                            durationOfBreak: TimeSpan.FromSeconds(tempoDesligado)));
            }

            return services;
        }

        #endregion
    }
}
