﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace Itau.SZ7.GPS.Core.Extensoes.Tipos
{
    public static class StringExtensions
    {
        public static string RemoveSpecialCharacters(this string str)
        {
            return Regex.Replace(str, "[^a-zA-Z0-9_.]+", "", RegexOptions.Compiled);
        }

        public static string DecodeString(this string texto)
        {
            try
            {
                byte[] bytes = Convert.FromBase64String(texto);

                return Encoding.UTF8.GetString(bytes);
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}
