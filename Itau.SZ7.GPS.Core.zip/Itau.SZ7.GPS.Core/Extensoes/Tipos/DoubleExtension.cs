﻿using System.Globalization;

namespace Itau.SZ7.GPS.Core.Extensoes.Tipos
{
    public static class DoubleExtension
    {
        public static double TryParse(this string value)
        {
            double.TryParse(value, NumberStyles.Float, CultureInfo.CreateSpecificCulture("en-US"), out double result);

            return result;
        }
    }
}
