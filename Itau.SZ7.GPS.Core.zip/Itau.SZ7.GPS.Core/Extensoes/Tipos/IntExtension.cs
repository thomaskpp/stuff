﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Core.Extensoes.Tipos
{
    public static class IntExtension
    {
        public static int TryParse(this string value)
        {
            int.TryParse(value, out int result);

            return result;
        }

        public static int TryParse(this double value)
        {
            int.TryParse(value.ToString(), out int result);

            return result;
        }

        public static int TryParse(this object value)
        {
            if (value == null)
                return 0;

            int.TryParse(value.ToString(), out int result);

            return result;
        }

        public static IEnumerable<int> ToEnumerable(this string[] numeros)
        {
            return numeros.Select(x => TryParse(x));
        }

        public static IEnumerable<int> ToEnumerable(this IEnumerable<string> numeros)
        {
            return numeros.Select(x => TryParse(x));
        }
    }
}
