﻿using System;

namespace Itau.SZ7.GPS.Core.Extensoes.Tipos
{
    public static class TimeSpanExtension
    {
        public static TimeSpan TryParse(this string value)
        {
            TimeSpan.TryParse(value, out TimeSpan result);

            return result;
        }
    }
}
