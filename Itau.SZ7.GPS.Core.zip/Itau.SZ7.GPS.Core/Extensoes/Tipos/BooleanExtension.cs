﻿namespace Itau.SZ7.GPS.Core.Extensoes.Tipos
{
    public static class BooleanExtension
    {
        public static bool TryParse(this string value)
        {
            if (value.Equals("1"))
                value = "true";

            bool.TryParse(value, out bool result);

            return result;
        }
    }
}
