﻿namespace Itau.SZ7.GPS.Core.Extensoes.Tipos
{
    public static class ByteExtension
    {
        public static byte TryParse(this string value)
        {
            byte.TryParse(value, out byte result);

            return result;
        }
    }
}
