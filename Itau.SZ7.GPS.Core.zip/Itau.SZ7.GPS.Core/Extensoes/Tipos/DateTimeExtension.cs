﻿using System;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Core.Extensoes.Tipos
{
    public static class DateTimeExtension
    {
        public static DateTime TryParse(this string value)
        {
            DateTime.TryParse(value, out DateTime result);
            return result;
        }

        public static DateTime TryParseDouble(this string value)
        {
            if (DoubleExtension.TryParse(value) > 0)
                return DateTime.FromOADate(DoubleExtension.TryParse(value));

            DateTime.TryParse(value, out DateTime result);
            return result;
        }

        public static string ToSqlDate(this DateTime value)
        {
            return value.ToString("yyyy-MM-dd HH:mm:ss");
        }

        public static string ToQueryString(this DateTime value)
        {
            return value.ToString("yyyy-MM-dd");
        }

        public static DateTime ProximoDiaUtil(this DateTime value)
        {
            var primeiroDiaMes = new DateTime(value.Year, value.Month, 1);
            var finalSemana = new List<DayOfWeek> { DayOfWeek.Saturday, DayOfWeek.Sunday };

            if (finalSemana.Contains(primeiroDiaMes.DayOfWeek))
                if (value.DayOfWeek.Equals(0))
                    value.AddDays(1);
                else
                    value.AddDays(2);

            return value;
        }

        public static DateTime UltimoDiaUtil(this DateTime value)
        {
            var ultimoDiaMes = new DateTime(value.Year, value.Month + 1, 1).AddDays(-1);
            var finalSemana = new List<DayOfWeek> { DayOfWeek.Saturday, DayOfWeek.Sunday };

            if (finalSemana.Contains(ultimoDiaMes.DayOfWeek))
                if (value.DayOfWeek.Equals(0))
                    value.AddDays(-2);
                else
                    value.AddDays(-1);

            return value;
        }

        public static string DiaSemanaPorExtenso(int diaDaSemana)
        {
            switch (diaDaSemana)
            {
                case 0:
                    return "Domingo";
                case 1:
                    return "Segunda";
                case 2:
                    return "Terça";
                case 3:
                    return "Quarta";
                case 4:
                    return "Quinta";
                case 5:
                    return "Sexta";
                case 6:
                    return "Sábado";
                default:
                    return "";
            }
        }
    }
}
