﻿namespace Itau.SZ7.GPS.Core.Extensoes.Tipos
{
    public static class LongExtension
    {
        public static long TryParse(this object value)
        {
            if (value == null)
                return 0;

            long.TryParse(value.ToString(), out long result);

            return result;
        }

        public static long TryParse(this string value)
        {
            long.TryParse(value, out long result);

            return result;
        }
    }
}
