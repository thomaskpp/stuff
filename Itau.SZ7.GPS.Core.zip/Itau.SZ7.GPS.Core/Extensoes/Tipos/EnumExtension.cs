﻿using Itau.SZ7.GPS.Core.Excecoes.Tipos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;

namespace Itau.SZ7.GPS.Core.Extensoes.Tipos
{
    public static class EnumExtension
    {
        public static T ToEnum<T>(this string enumString)
        {
            return (T)Enum.Parse(typeof(T), enumString, true);
        }

        public static string Description(this Enum enumValue)
        {
            return enumValue.GetType()
                            .GetMember(enumValue.ToString())
                            .First()
                            .GetCustomAttribute<DescriptionAttribute>()
                            .Description;
        }

        public static T RetornaEnumPorDescricao<T>(this string descricao)
        {
            var tipo = typeof(T);

            foreach (var campo in tipo.GetFields())
            {
                var atributo
                    = Attribute.GetCustomAttribute(campo, typeof(DescriptionAttribute)) as DescriptionAttribute;

                if (atributo == null)
                    continue;

                if (atributo.Description == descricao)
                    return (T)campo.GetValue(null);
            }

            if (!Enum.IsDefined(tipo, 0))
                throw new EnumNaoEncontradoException($"Não existe Enum padrão para {tipo.Name}");

            return default(T);
        }

        public static IEnumerable<T> ParaLista<T>()
        {
            return Enum.GetValues(typeof(T)).Cast<T>();
        }
    }
}
