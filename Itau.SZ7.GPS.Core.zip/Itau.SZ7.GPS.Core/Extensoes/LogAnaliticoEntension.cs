﻿using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Extensoes
{
    public static class LogAnaliticoEntensions
    {
        public static IApplicationBuilder UseLogAnaliticoHandler(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<LogAnaliticoHandler>();
        }
    }

    public class LogAnaliticoHandler
    {
        private readonly RequestDelegate _next;

        public LogAnaliticoHandler(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext,
            ISessaoServico sessaoServico,
            IConfiguracaoServico configuracaoServico,
            ILogAcessoServico logAcessoServico)
        {
            var watch = new Stopwatch();
            watch.Start();

            await _next(httpContext);

            if (httpContext.Request.Path.HasValue &&
                (
                    !httpContext.Request.Path.Value.ToLower().Contains("index.html") &&
                    !httpContext.Request.Path.Value.ToLower().Contains("swagger") &&
                    !httpContext.Request.Path.Value.ToLower().Contains("favicon") &&
                    !httpContext.Request.Path.Value.ToLower().Contains("obtemconfiguracao") &&
                    !httpContext.Request.Path.Value.ToLower().Contains("/logacesso/")
                ))
            {
                var logAtivo = configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.CONFIG_LOGDETALHADO_ATIVO, false);

                if (logAtivo)
                {
                    var sessao = sessaoServico.RetornaSessao();
                    watch.Stop();

                    try
                    {
                        await logAcessoServico.InsereLogAcesso(new Entidade.LogAcesso()
                        {
                            IdColaborador = sessao.IdColaborador,
                            IdColaboradorAgir = sessao.IdColaboradorAgir,
                            IdFuncionalidade = sessao.IdFuncionalidade ?? 0,
                            IdPlataforma = (int)Enums.Plataforma.Api,
                            Sucesso = true,
                            TempoExecucao = watch.ElapsedMilliseconds,
                            DadosAdicionais = JsonConvert.SerializeObject(new Entidade.LogAcessoDadosAdicionais()
                            {
                                Guid = sessao.Guid,
                                ApiGuid = sessao.ApiGuid,
                                VersaoApi = sessao.VersaoApi
                            })
                        });
                    }
                    catch { }
                }
            }
        }
    }
}
