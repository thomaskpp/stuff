﻿using Itau.SZ7.GPS.Core.Extensoes.Tipos;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using System;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Extensoes
{
    public static class HeaderParserExtension
    {
        public static IApplicationBuilder UseHeaderParserHandler(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<HeaderParserHandler>();
        }
    }

    public class HeaderParserHandler
    {
        private readonly RequestDelegate _next;

        public HeaderParserHandler(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(
            HttpContext httpContext,
            ISessaoServico sessaoServico,
            IConfiguracaoServico configuracaoServico,
            IValidacaoUsuarioServico validacaoUsuarioServico)
        {
            #region valores header

            var sessao = sessaoServico.RetornaSessao();
            var idColaborador = 0;
            var idColaboradorAgir = 0;

            if (httpContext.Request.Headers.TryGetValue(ChavesPadrao.AuthorizationHeaderName, out StringValues values))
            {
                string token = string.Empty;

                if (values.Count > 0)
                {
                    token = values.First();
                    validacaoUsuarioServico.ValidaToken(token, out string funcional, out idColaborador, out idColaboradorAgir);
                }
            }

            if (string.IsNullOrEmpty(sessao.ApiGuid))
                sessao.ApiGuid = configuracaoServico.RetornaApiGuid();

            httpContext.Request.Headers.TryGetValue(ChavesPadrao.AuthenticationRequestGuidName, out StringValues guid);
            if (string.IsNullOrEmpty(guid)) //&& string.IsNullOrEmpty(sessao.Guid)
                sessao.Guid = Guid.NewGuid().ToString();
            else if (!string.IsNullOrEmpty(guid))
                sessao.Guid = guid;

            httpContext.Request.Headers.TryGetValue(ChavesPadrao.CABECALHO_FUNCIONALIDADE, out StringValues funcionalidade);
            if (!string.IsNullOrEmpty(funcionalidade))
                sessao.IdFuncionalidade = IntExtension.TryParse(funcionalidade);

            httpContext.Request.Headers.TryGetValue(ChavesPadrao.CABECALHO_PLATAFORMA, out StringValues plataforma);
            if (!string.IsNullOrEmpty(plataforma))
                sessao.IdPlataforma = IntExtension.TryParse(plataforma);

            httpContext.Request.Headers.TryGetValue(ChavesPadrao.CABECALHO_COLABORADOR, out StringValues colaborador);
            if (string.IsNullOrEmpty(colaborador) && idColaborador > 0)
                sessao.IdColaborador = idColaborador;
            else if (!string.IsNullOrEmpty(colaborador))
                sessao.IdColaborador = IntExtension.TryParse(colaborador);

            httpContext.Request.Headers.TryGetValue(ChavesPadrao.CABECALHO_COLABORADORAGIR, out StringValues colaboradorAgir);
            if (string.IsNullOrEmpty(colaboradorAgir) && idColaboradorAgir > 0)
                sessao.IdColaboradorAgir = idColaboradorAgir;
            else if (!string.IsNullOrEmpty(colaboradorAgir))
                sessao.IdColaboradorAgir = IntExtension.TryParse(colaboradorAgir);

            if (string.IsNullOrEmpty(sessao.VersaoApi))
                sessao.VersaoApi = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version;

            sessaoServico.DefineSessao(sessao);

            #endregion

            await _next(httpContext);
        }
    }
}
