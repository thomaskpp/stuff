﻿using Itau.SZ7.GPS.Core.Dados.Interface;
using Itau.SZ7.GPS.Core.Entidade;
using Itau.SZ7.GPS.Core.Util;

namespace Itau.SZ7.GPS.Core.Servicos
{
    public class SessaoServico : Interface.ISessaoServico
    {
        #region campos

        private Sessao _sessao;
        private readonly ICache _cache;

        #endregion

        #region construtor
        public SessaoServico(ICache cache)
        {
            _cache = cache;
        }

        #endregion

        #region métodos públicos

        public void DefineSessao(Sessao sessao)
        {
            _sessao = sessao;
        }

        public Sessao RetornaSessao()
        {
            if (_sessao != null && (_sessao.ApiGuid?.Length ?? 0) == 0)
                _sessao.ApiGuid = _cache.RetornaValor<string>(ChavesPadrao.CACHE_APIGUID);

            return _sessao ?? new Sessao();
        }

        #endregion


    }
}
