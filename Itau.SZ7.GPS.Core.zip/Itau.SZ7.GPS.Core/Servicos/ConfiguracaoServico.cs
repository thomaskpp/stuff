﻿using Itau.SZ7.GPS.Core.Dados.Interface;
using Itau.SZ7.GPS.Core.Extensoes.Tipos;
using Itau.SZ7.GPS.Core.Repositorio.Interface;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Servicos
{
    public class ConfiguracaoServico : IConfiguracaoServico
    {
        #region campos

        private readonly ICache _cache;
        private readonly IConfiguracaoRepositorio _configuracaoRepositorio;
        private readonly IConfiguration _configuration;
        private readonly IConfigurationBuilder _configurationBuilder;
        private readonly string CHAVE_CACHE_CONFIGURACAO_ITENS = $"{ChavesPadrao.CACHE_CONFIGURACAO_SERVICO}itens";

        private string ApiGuid
        {
            get
            {
                return RetornaApiGuid();
            }
            set
            {
                DefineApiGuid(value);
            }
        }
        private IEnumerable<Entidade.ConfiguracaoItem> ItensConfiguracaoPadrao => RetornaItensPadrao();
        private IEnumerable<Entidade.ConfiguracaoItem> ItensConfiguracaoPadraoApi => RetornaItensPadraoApi();
        private IConfigurationSection _appSetting;

        #endregion

        #region construtor

        public ConfiguracaoServico(
            ICache cache,
            IConfiguracaoRepositorio configuracaoRepositorio,
            IConfiguration configuration,
            IConfigurationBuilder configurationBuilder
            )
        {
            _cache = cache;
            _configuracaoRepositorio = configuracaoRepositorio;
            _configurationBuilder = configurationBuilder;
            _configuration = configuration;

            _appSetting = Configuracao.CriaArquivoConfiguracao(configuration, configurationBuilder);

            _configuracaoRepositorio.DefineConfiguracaoEndpoint(_appSetting["ConfiguracaoEndpoint"] ?? string.Empty);
        }

        #endregion

        #region métodos públicos

        public async Task EnviaConfiguracaoParaCache(string apiGuid = "")
        {
            if (!string.IsNullOrEmpty(apiGuid))
                ApiGuid = apiGuid;

            var configuracoes = await _configuracaoRepositorio.RetornaConfiguracaoPadrao();

            await DefineItens(configuracoes?.ToList() ?? new List<Entidade.ConfiguracaoItem>());
        }

        public int RetornaTempoCachePadrao()
        {
            var tempoCache = RetornaValorConfiguracao(ChavesPadrao.CONFIG_CACHE_TEMPO_PADRAO);

            if (string.IsNullOrEmpty(tempoCache))
                return ChavesPadrao.TEMPO_CACHE_PADRAO;


            var tempo = IntExtension.TryParse(tempoCache);

            return tempo >= 0 ? tempo : ChavesPadrao.TEMPO_CACHE_PADRAO;
        }

        public string RetornaConnectionString()
        {
            return RetornaValorConfiguracao(ChavesPadrao.CONFIG_CONNECTIONSTRING);
        }

        public string RetornaValorConfiguracao(string chave)
        {
            if (!string.IsNullOrEmpty(_appSetting[chave]))
                return _appSetting[chave];

            if (ItensConfiguracaoPadraoApi.Any(x => x.Chave.ToLower().Equals(chave.ToLower())))
                return ItensConfiguracaoPadraoApi.FirstOrDefault(x => x.Chave.ToLower().Equals(chave.ToLower())).Valor;

            if (ItensConfiguracaoPadrao.Any(x => x.Chave.ToLower().Equals(chave.ToLower())))
                return ItensConfiguracaoPadrao.FirstOrDefault(x => x.Chave.ToLower().Equals(chave.ToLower())).Valor;

            return string.Empty;
        }

        public T RetornaValorConfiguracao<T>(string chave, T valorPadrao) where T : new()
        {
            var valor = RetornaValorConfiguracao(chave);

            if (string.IsNullOrEmpty(valor))
                return valorPadrao;

            return (T)Convert.ChangeType(valor, typeof(T));
        }

        public string RetornaApiGuid()
        {
            return _cache.RetornaValor<string>(ChavesPadrao.CACHE_APIGUID);
        }

        public void DefineApiGuid(string guid)
        {
            _cache.DefineValor(
                ChavesPadrao.CACHE_APIGUID, 
                guid, 
                Microsoft.Extensions.Caching.Memory.CacheItemPriority.NeverRemove);
        }

        public bool ExisteConfiguracao()
        {
            return ItensConfiguracaoPadrao.Any();
        }

        #endregion

        #region métodos privados

        private IEnumerable<Entidade.ConfiguracaoItem> RetornaItensPadrao()
        {
            var resultado = _cache.RetornaValor<List<Entidade.ConfiguracaoItem>>(CHAVE_CACHE_CONFIGURACAO_ITENS);

            if (resultado != null)
                return resultado;

            return Enumerable.Empty<Entidade.ConfiguracaoItem>();
        }

        private async Task DefineItens(List<Entidade.ConfiguracaoItem> itens)
        {
            if (itens.Any())
            {
                await _cache.DefineValor(CHAVE_CACHE_CONFIGURACAO_ITENS, itens);
            }
        }

        private IEnumerable<Entidade.ConfiguracaoItem> RetornaItensPadraoApi()
        {
            var idConfiguracaoTipo = EnumExtension.RetornaEnumPorDescricao<Enums.ConfiguracaoItemTipo>(ApiGuid);

            if (!ItensConfiguracaoPadrao.Any(x => x.IdConfiguracaoItemTipo.Equals((int)idConfiguracaoTipo)))
                return new List<Entidade.ConfiguracaoItem>();

            return ItensConfiguracaoPadrao.Where(x => x.IdConfiguracaoItemTipo.Equals((int)idConfiguracaoTipo));
        }

        protected string RetornaConnectionStringConfiguracao()
        {
            if (!string.IsNullOrEmpty(_appSetting[ChavesPadrao.CONFIG_CONNECTIONSTRING_CONFIGURACAO]))
                return _appSetting[ChavesPadrao.CONFIG_CONNECTIONSTRING_CONFIGURACAO];

            return string.Empty;
        }

        protected string RetornaConfiguracaoEndpoint()
        {
            return _appSetting["ConfiguracaoEndpoint"] ?? string.Empty;
        }

        #endregion
    }
}
