﻿using Itau.SZ7.GPS.Core.Extensoes.Tipos;
using Itau.SZ7.GPS.Core.Repositorio.Interface;
using Itau.SZ7.GPS.Core.Seguranca;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Servicos
{
    public class ValidacaoUsuarioServico : IValidacaoUsuarioServico
    {
        #region campos

        private static string userOpen = "abrirsenha";
        private static string hashOpen = "pwsd1390%%%%3aas";
        private readonly IValidacaoUsuarioRepositorio _validacaoUsuarioRepositorio;
        private readonly IConfiguracaoServico _configuracaoServico;

        #endregion

        #region construtor

        public ValidacaoUsuarioServico(
            IValidacaoUsuarioRepositorio validacaoUsuarioRepositorio, 
            IConfiguracaoServico configuracaoServico)
        {
            _validacaoUsuarioRepositorio = validacaoUsuarioRepositorio;
            _configuracaoServico = configuracaoServico;
        }

        #endregion

        #region métodos públicos

        public bool ValidaToken(string tokenKey, out string funcional, out int idColaborador, out int idColaboradorAgir)
        {
            funcional = string.Empty;
            idColaborador = 0;
            idColaboradorAgir = 0;
            bool isValid = false;

            try
            {
                if (string.IsNullOrEmpty(tokenKey) || tokenKey == "null")
                    return false;

                string[] tokens = tokenKey.Split(new char[] { ']', ':', '[' }, StringSplitOptions.RemoveEmptyEntries);
                string tokenSecret = Encrypt.DecryptString(tokens[1], string.Format("{0}:{1}", userOpen, hashOpen));
                string[] secures = tokenSecret.Split(':');
                string token = Encrypt.DecryptString(tokens[0], string.Format("{0}:{1}", secures[0], secures[1]));
                string[] infos = token.Split(';');

                long ticks;
                long.TryParse(infos[0].Replace("d:", ""), out ticks);
                bool.TryParse(infos[1].Replace("a:", ""), out isValid);

                if (isValid)
                {
                    DateTime d = new DateTime(ticks);
                    var dif = d - DateTime.Now;
                    if (dif.TotalSeconds < 0)
                        isValid = false;
                }

                if (isValid)
                {
                    string user = infos[2].Replace("k:", "");
                    var dados = user.Split(new char[] { ']', ':', '[' }, StringSplitOptions.RemoveEmptyEntries);
                    funcional = dados[0];

                    if(dados.Length > 2)
                    {
                        idColaborador = IntExtension.TryParse(dados[1]);
                        idColaboradorAgir = IntExtension.TryParse(dados[2]);
                    }
                }
            }
            catch
            {
                return false;
            }

            return isValid;
        }

        public string CriaToken(bool autorizado, string usuario, string senha, int idColaborador = 0, int idColaboradorAgir = 0)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("d:{0};", DateTime.Today.AddDays(1d).Ticks);
            sb.AppendFormat("a:{0};", autorizado);
            sb.AppendFormat("k:{0};", string.Format("{0}]:[{1}]:[{2}]:[{3}", usuario, senha, idColaborador, idColaboradorAgir));
            string token = Encrypt.EncryptString(sb.ToString(), string.Format("{0}:{1}", usuario, senha));
            string tokenSecret = Encrypt.EncryptString(string.Format("{0}:{1}", usuario, senha), string.Format("{0}:{1}", userOpen, hashOpen));
            return string.Concat(token, ":", tokenSecret);
        }

        public async Task<Entidade.DTO.Colaborador> ObterColaborador(string funcional)
        {
            return await _validacaoUsuarioRepositorio.ObterColaboradorPorFuncional(funcional);
        }

        public async Task<bool> AutenticaColaboradorSimulacao(string usuario, string senha)
        {
            return await _validacaoUsuarioRepositorio.ObterColaboradorSimulacao(usuario, senha);
        }

        public bool AutenticaAD(string racf, string password, out string funcional, out Dictionary<string, string> retornoAd)
        {
            ActiveDirectoryHelper adHelper = new ActiveDirectoryHelper(_configuracaoServico);

            return adHelper.Login(racf, password, out funcional, out retornoAd);
        }

        #endregion
    }
}
