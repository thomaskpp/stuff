﻿using Itau.SZ7.GPS.Core.Entidade;
using Itau.SZ7.GPS.Core.Repositorio.Interface;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Servicos
{
    public class LogAcessoServico : ILogAcessoServico
    {
        #region campos

        private readonly ILogAcessoRepositorio _logAcessoRepositorio;

        #endregion

        #region construtor

        public LogAcessoServico(ILogAcessoRepositorio logAcessoRepositorio)
        {
            _logAcessoRepositorio = logAcessoRepositorio;
        }

        #endregion

        #region métodos públicos

        public async Task InsereLogAcesso(LogAcesso logAcesso)
        {
            await _logAcessoRepositorio.InserirLogAcesso(logAcesso);
        }

        #endregion



    }
}
