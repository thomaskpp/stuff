﻿using Itau.SZ7.GPS.Core.Entidade;
using System;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Servicos.Interface
{
    public interface ILogServico
    {
        Task RegistrarInformacao(
            string descricao,
            [System.Runtime.CompilerServices.CallerMemberName] string metodoOrigem = "",
            Sessao sessao = null,
            [System.Runtime.CompilerServices.CallerLineNumber] int numeroLinha = 0);
        Task RegistrarAviso(
            string descricao, 
            [System.Runtime.CompilerServices.CallerMemberName] string metodoOrigem = "",
            Sessao sessao = null,
            [System.Runtime.CompilerServices.CallerLineNumber] int numeroLinha = 0);
        Task RegistrarErro(
            string descricao, 
            [System.Runtime.CompilerServices.CallerMemberName] string metodoOrigem = "",
            Sessao sessao = null,
            [System.Runtime.CompilerServices.CallerLineNumber] int numeroLinha = 0);
        Task RegistrarCritico(
            string descricao, 
            [System.Runtime.CompilerServices.CallerMemberName] string metodoOrigem = "",
            Sessao sessao = null,
            [System.Runtime.CompilerServices.CallerLineNumber] int numeroLinha = 0);
        Task RegistrarExcecao(
            Exception ex, 
            Sessao sessao = null,
            [System.Runtime.CompilerServices.CallerMemberName] string metodoOrigem = "",
            [System.Runtime.CompilerServices.CallerLineNumber] int numeroLinha = 0);
    }
}
