﻿using Itau.SZ7.GPS.Core.Entidade;

namespace Itau.SZ7.GPS.Core.Servicos.Interface
{
    public interface ISessaoServico
    {
        void DefineSessao(Sessao sessao);
        Sessao RetornaSessao();
    }
}
