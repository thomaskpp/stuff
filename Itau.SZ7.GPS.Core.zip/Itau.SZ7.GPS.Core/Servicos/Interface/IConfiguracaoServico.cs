﻿using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Servicos.Interface
{
    public interface IConfiguracaoServico
    {
        Task EnviaConfiguracaoParaCache(string apiGuid = "");
        int RetornaTempoCachePadrao();
        string RetornaConnectionString();
        string RetornaValorConfiguracao(string chave);
        T RetornaValorConfiguracao<T>(string chave, T valorPadrao) where T : new();
        void DefineApiGuid(string guid);
        string RetornaApiGuid();
        bool ExisteConfiguracao();
    }
}
