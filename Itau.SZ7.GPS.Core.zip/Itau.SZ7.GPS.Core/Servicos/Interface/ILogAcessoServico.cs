﻿using Itau.SZ7.GPS.Core.Entidade;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Servicos.Interface
{
    public interface ILogAcessoServico
    {
        Task InsereLogAcesso(LogAcesso logAcesso);
    }
}
