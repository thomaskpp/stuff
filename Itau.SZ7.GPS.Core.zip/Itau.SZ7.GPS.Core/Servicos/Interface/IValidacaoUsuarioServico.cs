﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Servicos.Interface
{
    public interface IValidacaoUsuarioServico
    {
        bool ValidaToken(string tokenKey, out string funcional, out int idColaborador, out int idColaboradorAgir);
        string CriaToken(bool autorizado, string usuario, string senha, int idColaborador = 0, int idColaboradorAgir = 0);
        Task<Entidade.DTO.Colaborador> ObterColaborador(string funcional);
        Task<bool> AutenticaColaboradorSimulacao(string usuario, string senha);
        bool AutenticaAD(string racf, string password, out string funcional, out Dictionary<string, string> retornoAd);
    }
}
