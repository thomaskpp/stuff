﻿using Itau.SZ7.GPS.Core.Entidade;
using Itau.SZ7.GPS.Core.Enums;
using Itau.SZ7.GPS.Core.Extensoes.Tipos;
using Itau.SZ7.GPS.Core.Repositorio.Interface;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using System;
using System.Threading.Tasks;
using System.Linq;
using System.Diagnostics;
using System.Reflection;

namespace Itau.SZ7.GPS.Core.Servicos
{
    public class LogServico : ILogServico
    {
        #region campos

        private readonly ILogRepositorio _logRepositorio;
        private readonly Sessao _sessao;
        private readonly bool _logAtivo;

        #endregion

        #region construtor

        public LogServico(ISessaoServico sessaoServico, ILogRepositorio logRepositorio, IConfiguracaoServico configuracaoServico)
        {
            _sessao = sessaoServico.RetornaSessao();
            _logRepositorio = logRepositorio;

            _logAtivo = configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.CONFIG_LOGERRO_ATIVO, true);
        }

        #endregion

        #region métodos públicos

        public async Task RegistrarInformacao(
            string descricao,
            [System.Runtime.CompilerServices.CallerMemberName] string metodoOrigem = "",
            Sessao sessao = null,
            [System.Runtime.CompilerServices.CallerLineNumber] int numeroLinha = 0)
        {
            if (!_logAtivo)
                return;

            Logs log = new Logs
            {
                IdLogTipo = (int)LogTipo.Informacao,
                IdPlataforma = IntExtension.TryParse(sessao?.IdPlataforma ?? _sessao.IdPlataforma),
                IdFuncionalidade = IntExtension.TryParse(sessao?.IdFuncionalidade ?? _sessao.IdFuncionalidade),
                IdColaborador = sessao?.IdColaborador,
                IdColaboradorAgir = sessao?.IdColaboradorAgir,
                ApiGuid = sessao?.ApiGuid ?? _sessao.ApiGuid,
                StackTrace = string.Empty,
                Descricao = descricao,
                MetodoOrigem = $"{RetornaNamespace()}.{metodoOrigem} ({numeroLinha})",
                Versao = sessao?.VersaoApi ?? _sessao.VersaoApi,
                Servidor = Environment.MachineName,
                Guid = sessao?.Guid ?? _sessao.Guid
            };

            await _logRepositorio.RegistrarLog(log);
        }

        public async Task RegistrarAviso(
            string descricao,
            [System.Runtime.CompilerServices.CallerMemberName] string metodoOrigem = "",
            Sessao sessao = null,
            [System.Runtime.CompilerServices.CallerLineNumber] int numeroLinha = 0)
        {
            if (!_logAtivo)
                return;

            Logs log = new Logs
            {
                IdLogTipo = (int)LogTipo.Aviso,
                IdPlataforma = IntExtension.TryParse(sessao?.IdPlataforma ?? _sessao.IdPlataforma),
                IdFuncionalidade = IntExtension.TryParse(sessao?.IdFuncionalidade ?? _sessao.IdFuncionalidade),
                IdColaborador = sessao?.IdColaborador,
                IdColaboradorAgir = sessao?.IdColaboradorAgir,
                ApiGuid = sessao?.ApiGuid ?? _sessao.ApiGuid,
                StackTrace = string.Empty,
                Descricao = descricao,
                MetodoOrigem = $"{RetornaNamespace()}.{metodoOrigem} ({numeroLinha})",
                Versao = sessao?.VersaoApi ?? _sessao.VersaoApi,
                Servidor = Environment.MachineName,
                Guid = sessao?.Guid ?? _sessao.Guid
            };

            await _logRepositorio.RegistrarLog(log);
        }

        public async Task RegistrarErro(
            string descricao,
            [System.Runtime.CompilerServices.CallerMemberName] string metodoOrigem = "",
            Sessao sessao = null,
            [System.Runtime.CompilerServices.CallerLineNumber] int numeroLinha = 0)
        {
            if (!_logAtivo)
                return;

            Logs log = new Logs
            {
                IdLogTipo = (int)LogTipo.Erro,
                IdPlataforma = IntExtension.TryParse(sessao?.IdPlataforma ?? _sessao.IdPlataforma),
                IdFuncionalidade = IntExtension.TryParse(sessao?.IdFuncionalidade ?? _sessao.IdFuncionalidade),
                IdColaborador = sessao?.IdColaborador,
                IdColaboradorAgir = sessao?.IdColaboradorAgir,
                ApiGuid = sessao?.ApiGuid ?? _sessao.ApiGuid,
                StackTrace = string.Empty,
                Descricao = descricao,
                MetodoOrigem = $"{RetornaNamespace()}.{metodoOrigem} ({numeroLinha})",
                Versao = sessao?.VersaoApi ?? _sessao.VersaoApi,
                Servidor = Environment.MachineName,
                Guid = sessao?.Guid ?? _sessao.Guid
            };

            await _logRepositorio.RegistrarLog(log);
        }

        public async Task RegistrarCritico(
            string descricao,
            [System.Runtime.CompilerServices.CallerMemberName] string metodoOrigem = "",
            Sessao sessao = null,
            [System.Runtime.CompilerServices.CallerLineNumber] int numeroLinha = 0)
        {
            if (!_logAtivo)
                return;

            Logs log = new Logs
            {
                IdLogTipo = (int)LogTipo.Critico,
                IdPlataforma = IntExtension.TryParse(sessao?.IdPlataforma ?? _sessao.IdPlataforma),
                IdFuncionalidade = IntExtension.TryParse(sessao?.IdFuncionalidade ?? _sessao.IdFuncionalidade),
                IdColaborador = sessao?.IdColaborador,
                IdColaboradorAgir = sessao?.IdColaboradorAgir,
                ApiGuid = sessao?.ApiGuid ?? _sessao.ApiGuid,
                StackTrace = string.Empty,
                Descricao = descricao,
                MetodoOrigem = $"{RetornaNamespace()}.{metodoOrigem} ({numeroLinha})",
                Versao = sessao?.VersaoApi ?? _sessao.VersaoApi,
                Servidor = Environment.MachineName,
                Guid = sessao?.Guid ?? _sessao.Guid
            };

            await _logRepositorio.RegistrarLog(log);
        }

        public async Task RegistrarExcecao(
            Exception ex,
            Sessao sessao = null,
            [System.Runtime.CompilerServices.CallerMemberName] string metodoOrigem = "",
            [System.Runtime.CompilerServices.CallerLineNumber] int numeroLinha = 0)
        {
            if (!_logAtivo)
                return;

            var metodo = new StackTrace(ex)
                .GetFrames()
                .Select(f => f.GetMethod())
                .FirstOrDefault(m => m.Module.Assembly.FullName.StartsWith("Itau"));

            if (metodo != null || metodo.ReflectedType != null)
                metodoOrigem = $"{metodo.ReflectedType.FullName}.{metodo.Name} ({numeroLinha})";

            Logs log = new Logs
            {
                IdLogTipo = (int)LogTipo.Erro,
                IdPlataforma = IntExtension.TryParse(sessao?.IdPlataforma ?? _sessao.IdPlataforma),
                IdFuncionalidade = IntExtension.TryParse(sessao?.IdFuncionalidade ?? _sessao.IdFuncionalidade),
                IdColaborador = sessao?.IdColaborador,
                IdColaboradorAgir = sessao?.IdColaboradorAgir,
                ApiGuid = sessao?.ApiGuid ?? _sessao.ApiGuid,
                StackTrace = ExceptionExtension.RetornaStackTrace(ex),
                Descricao = ExceptionExtension.RetornaInnerException(ex).Message,
                MetodoOrigem = metodoOrigem,
                Versao = sessao?.VersaoApi ?? _sessao.VersaoApi,
                Servidor = Environment.MachineName,
                Guid = sessao?.Guid ?? _sessao.Guid
            };

            await _logRepositorio.RegistrarLog(log);
        }

        #endregion

        #region auxiliar

        private string RetornaNamespace()
        {
            return new StackTrace()
                .GetFrames()
                .Select(f => f.GetMethod())
                .Where(m => m.Module.Assembly.FullName.StartsWith("Itau") && m.Name != "MoveNext")
                .Skip(2)
                .FirstOrDefault()?
                .ReflectedType?
                .FullName ?? string.Empty;
        }

        #endregion

    }
}
