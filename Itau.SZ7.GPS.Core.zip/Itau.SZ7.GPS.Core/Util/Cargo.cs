﻿using Itau.SZ7.GPS.Core.Extensoes.Tipos;
using System.Collections.Generic;
using System.Linq;

namespace Itau.SZ7.GPS.Core.Util
{
    public static class Cargo
    {
        public static Enums.Cargo[] CargosGG()
        {
            return new Enums.Cargo[]
            {
                Enums.Cargo.GGC,
                Enums.Cargo.GGD,
                Enums.Cargo.GGN,
                Enums.Cargo.GA
            };
        }

        public static Enums.Cargo[] CargosGGParaDelegacaoAcesso()
        {
            return new Enums.Cargo[]
            {
                Enums.Cargo.GGC,
                Enums.Cargo.GGD,
                Enums.Cargo.GGN,
                Enums.Cargo.GGE,
                Enums.Cargo.GO,
                Enums.Cargo.GA
            };
        }

        public static IEnumerable<int> IdCargosGG()
        {
            return CargosGG().Select(x => (int)x);
        }

        public static IEnumerable<int> IdCargosGGParaDelegacaoAcesso()
        {
            return CargosGGParaDelegacaoAcesso().Select(x => (int)x);
        }

        public static bool EhGerenteGeral(string nomeCargo)
        {
            return CargosGGParaDelegacaoAcesso().Contains(EnumExtension.ToEnum<Enums.Cargo>(nomeCargo));
        }

        public static Enums.Cargo[] CargosAssistente()
        {
            return new Enums.Cargo[]
            {
                Enums.Cargo.A
            };
        }

        public static IEnumerable<int> IdCargosAssistente()
        {
            return CargosAssistente().Select(x => (int)x);
        }

        public static bool EhAssistente(string nomeCargo)
        {
            return CargosAssistente().Contains(EnumExtension.ToEnum<Enums.Cargo>(nomeCargo));
        }

    }
}
