﻿namespace Itau.SZ7.GPS.Core.Util.Mensagens
{
    public static class Controller
    {
        public const string PARAMETRO_ENTRADA_NAO_INFORMADO = "Um ou mais parâmetros não foram enviados";
        public const string PARAMETRO_ENTRADA_INVALIDO = "Um ou mais parâmetros são inválidos";
        public const string ERRO_RETORNO_DADOS = "Não foi possível retornar dados";
        public const string ERRO_INSERIR_DADOS = "Não foi possível inserir os registros";

    }

    public static class Servico
    {

    }

    public static class Repositorio
    {

    }
}
