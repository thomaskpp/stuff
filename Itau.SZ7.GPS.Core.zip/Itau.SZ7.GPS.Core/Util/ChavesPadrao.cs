﻿namespace Itau.SZ7.GPS.Core.Util
{
    public static class ChavesPadrao
    {
        public const string AuthenticationResponseHeaderName = "X-fdad_token";
        public const string AuthorizationHeaderName = "fdad_token";
        public const string AuthenticationRequestHeaderName = "fdad_user";
        public const string AuthenticationRequestGuidName = "X-fdad_guid";
        public const string AuthenticationRequestApiGuid = "X-fdad_apiguid";
        public const string AuthenticationRequestApiToken = "X-fdad_apitoken";

        //cabecalho
        public const string CABECALHO_PLATAFORMA = "X-fdad_plataforma";
        public const string CABECALHO_FUNCIONALIDADE = "X-fdad_funcionalidade";
        public const string CABECALHO_COLABORADOR = "X-fdad_colaborador";
        public const string CABECALHO_COLABORADORAGIR = "X-fdad_colaboradoragir";

        public const string API_CHAVEAUTENTICACAO = "DB6C2579-EEA1-4E6D-807F-C80CE2993BD0";

        //polly
        public const string POLLY_HABILITADO = "HabilitarPolly";
        public const string POLLY_HTTP_RETENTATIVA = "HttpTentativa";
        public const string POLLY_HTTP_RETENTATIVA_QTDE = "HttpTentativaQuantidade";
        public const string POLLY_HTTP_RETENTATIVA_TEMPO_ESPERA = "HttpTentativaTempoEspera";
        public const string POLLY_HTTP_DIJUNTOR = "HttpDijuntor";
        public const string POLLY_HTTP_DIJUNTOR_TEMPO_DESLIGADO = "HttpDijuntorTempoDesligado";
        public const string POLLY_HTTP_DIJUNTOR_EXCECOES_PERMITIDAS = "HttpDijuntorQtdeExcecoesAntesDesligar";

        //cache
        public const string CACHE_APIGUID = "CacheApiGuid";
        public const string CACHE_CONFIGURACAO_SERVICO = "CacheConfiguracaoServico_";
        public const string CACHE_CONFIGURACAO_REPOSITORIO = "CacheConfiguracaoRepositorio_";
        public const string CACHE_COLABORADOR_SERVICO = "CacheColaboradorServico_";
        public const string CACHE_COLABORADOR_REPOSITORIO = "CacheColaboradorRepositorio_";
        public const string CACHE_COLABORADORSIMULACAO_REPOSITORIO = "CacheColaboradorSimulacaoRepositorio_";
        public const string CACHE_COACHCLICK_SERVICO = "CacheCoachClickServico_";
        public const string CACHE_COACHCLICK_REPOSITORIO = "CacheCoachClickRepositorio_";
        public const string CACHE_SEGMENTO_SERVICO = "CacheSegmentoServico_";
        public const string CACHE_SEGMENTO_REPOSITORIO = "CacheSegmentoRepositorio_";
        public const string CACHE_FERIADO_SERVICO = "CacheSegmentoServico_";
        public const string CACHE_FERIADO_REPOSITORIO = "CacheSegmentoRepositorio_";
        public const string CACHE_AGENCIA_SERVICO = "CacheAgenciaServico_";
        public const string CACHE_AGENCIA_REPOSITORIO = "CacheAgenciaRepositorio_";
        public const string CACHE_NOTIFICACOES_SERVICO = "CacheNotificacoesServico_";
        public const string CACHE_NOTIFICACOES_REPOSITORIO = "CacheNotificacoesRepositorio_";
        public const string CACHE_GERENCIADORCARGACONFIGURACAO_SERVICO = "CacheGerenciadorCargaConfiguracaoServico_";
        public const string CACHE_GERENCIADORCARGACONFIGURACAO_REPOSITORIO = "CacheGerenciadorCargaConfiguracaoRepositorio_";
        public const string CACHE_FUNCIONALIDADE_SERVICO = "CacheFuncionalidadeServico_";
        public const string CACHE_FUNCIONALIDADE_REPOSITORIO = "CacheFuncionalidadeRepositorio_";
        public const string CACHE_CARGO_SERVICO = "CacheCargoServico_";
        public const string CACHE_CARGO_REPOSITORIO = "CacheCargoRepositorio_";
        public const string CACHE_CARGOSEGMENTO_SERVICO = "CacheCargoSegmentoServico_";
        public const string CACHE_CARGOSEGMENTO_REPOSITORIO = "CacheCargoSegmentoRepositorio_";
        public const string CACHE_ESTRUTURA_SERVICO = "CacheEstruturaServico_";
        public const string CACHE_ESTRUTURA_REPOSITORIO = "CacheEstruturaRepositorio_";
        public const string CACHE_PERFIL_SERVICO = "CachePerfilServico_";
        public const string CACHE_PERFIL_REPOSITORIO = "CachePerfilRepositorio_";
        public const string CACHE_PERFILPERMISSAO_SERVICO = "CachePerfilPermissaoServico_";
        public const string CACHE_PERFILPERMISSAO_REPOSITORIO = "CachePerfilPermissaoRepositorio_";
        public const string CACHE_HOMETEMPLATE_REPOSITORIO = "CacheHomeTemplateRepositorio_";
        public const string CACHE_HOMETEMPLATE_SERVICO = "CacheHomeTemplateServico_";
        public const string CACHE_VERIFICADORPRODUCAO_REPOSITORIO = "CacheVerificadorProducaoRepositorio_";
        public const string CACHE_VERIFICADORPRODUCAO_SERVICO = "CacheVerificadorProducaoServico_";
        public const string CACHE_VERIFICADORPRODUCAOANALITICO_REPOSITORIO = "CacheVerificadorProducaoAnaliticoRepositorio_";
        public const string CACHE_COLABORADORAGIR_SERVICO = "CacheColaboradorAgirServico_";
        public const string CACHE_COLABORADORAGIR_REPOSITORIO = "CacheColaboradorAgirRepositorio_";
        public const string CACHE_VAI_SERVICO = "CacheVaiServico_";
        public const string CACHE_VAI_REPOSITORIO = "CacheVaiRepositorio_";
        public const string CACHE_NPS_SERVICO = "CacheNpsServico_";
        public const string CACHE_NPS_REPOSITORIO = "CacheNpsRepositorio_";
        public const string CACHE_VISAOGERENCIAL_SERVICO = "CacheVisaoGerencialServico_";
        public const string CACHE_VISAOGERENCIAL_REPOSITORIO = "CacheVisaoGerencialRepositorio_";
        public const string CACHE_PRODUTO_REPOSITORIO = "CacheProdutoRepositorio_";
        public const string CACHE_COLABORADORENGAJAMENTO_REPOSITORIO = "CacheColaboradorEngajamentoRepositorio_";
        public const string CACHE_PLATAFORMA_REPOSITORIO = "CachePlataformaRepositorio_";
        public const string CACHE_CHECKIN_REPOSITORIO = "CacheCheckinRepositorio_";
        public const string CACHE_CHECKOUT_REPOSITORIO = "CacheCheckoutRepositorio_";
        public const string CACHE_PLANEJAMENTO_REPOSITORIO = "CachePlanejamentoRepositorio_";
        public const string CACHE_DELEGACAOACESSO_REPOSITORIO = "CacheDelegacaoAcessoRepositorio_";
        public const string CACHE_PLANEJAMENTO_SIMULACAO_REPOSITORIO = "CachePlanejamentoSimulacaoRepositorio_";
        public const string CACHE_COLABORADOR_AFASTAMENTO_REPOSITORIO = "CacheColaboradorAfastamentoRepositorio_";
        public const string CACHE_COLABORADOR_AGENCIAMONITORAMENTO_REPOSITORIO = "CacheAgenciaMonitoramentoRepositorio_";
        public const string CACHE_COLABORADOR_GRUPORISCO_REPOSITORIO = "CacheColaboradorGrupoRiscoRepositorio_";
        public const string CACHE_COLABORADOR_ATUANTE_REPOSITORIO = "CacheColaboradorAfastamentoRepositorio_";
        public const string CACHE_COLABORADOR_AGENCIAMONITORAMENTO_CARGO_REPOSITORIO = "CacheColaboradorAgenciaMonitoramentoCargoRepositorio_";

        //configuração
        public const int TEMPO_CACHE_PADRAO = 60;
        public const int HTTP_TIMEOUT_PADRAO = 10000;
        public const string CONFIG_CONNECTIONSTRING = "ConnectionString";
        public const string CONFIG_CONNECTIONSTRING_CONFIGURACAO = "ConnectionStringConfiguracao";
        public const string CONFIG_CACHE_TEMPO_PADRAO = "CacheTempoPadrao";
        public const string CONFIG_LOGDETALHADO_ATIVO = "LogDetalhadoAtivo";
        public const string CONFIG_LOGERRO_ATIVO = "LogErroAtivo";
        public const string CONFIG_LDAPSETTINGS_BASE = "LDAPSettings_";
        public const string CONFIG_CACHE_TEMPO_COLABORADORSIMULACAO = "CacheTempoColaboradorSimulacao";
        public const string CONFIG_CACHE_TEMPO_COLABORADOR_COLABORADORAGIR = "CacheTempoColaboradorColaboradorAgirSimulacao";
        public const string CONFIG_HTTP_REQUEST_TIMEOUT = "HttpRequestTimeout";

        //api url
        public const string CONFIG_APIURL_LOGS = "ApiUrlLogs";
        public const string CONFIG_APIURL_COLABORADOR = "ApiUrlColaborador";
        public const string CONFIG_APIURL_LOGACESSO = "ApiUrlLogAcesso";
        public const string CONFIG_APIURL_FUNCIONALIDADE = "ApiUrlFuncionalidade";
        public const string CONFIG_APIURL_CARGO = "ApiUrlCargo";
        public const string CONFIG_APIURL_COLABORADORAGIR = "ApiUrlColaboradorAgir";
        public const string CONFIG_APIURL_COACHCLICK = "ApiUrlCoachClick";
        public const string CONFIG_APIURL_AGENCIA = "ApiUrlAgencia";
        public const string CONFIG_APIURL_PLANEJAMENTO = "ApiUrlPlanejamento";
        public const string CONFIG_APIURL_PLATAFORMA = "ApiUrlPlataforma";
        public const string CONFIG_APIURL_CHECKOUT = "ApiUrlCheckout";
        public const string CONFIG_APIURL_CHECKIN = "ApiUrlCheckin";
        public const string CONFIG_APIURL_FERIADO = "ApiUrlFeriado";
        public const string CONFIG_APIURL_COLABORADORAFERIAS = "ApiUrlColaboradorFerias";
        public const string CONFIG_APIURL_RECLAMACAO = "ApiUrlReclamacao";
        public const string CONFIG_APIURL_NOTIFICACAO = "ApiUrlNotificacao";
        public const string CONFIG_APIURL_NPS = "ApiUrlNps";
        public const string CONFIG_APIURL_PRODUTO = "ApiUrlProduto";
        public const string CONFIG_APIURL_COLABORADOR_ENGAJAMENTO = "ApiUrlColaboradorEngajamento";
        public const string CONFIG_APIURL_VERIFICADORPRODUCAO = "ApiUrlVerificadorProducao";
        public const string CONFIG_APIURL_SEGMENTO = "ApiUrlSegmento";
        public const string CONFIG_APIURL_DELEGACAOACESSO = "ApiUrlDelegacaoAcesso";
        public const string CONFIG_APIURL_ESTRUTURA = "ApiUrlEstrutura";

        public const string CONFIG_APIURL_CHECKOUT_PERSONNALITE = "ApiUrlCheckoutPersonnalite";
        public const string CONFIG_APIURL_CHECKIN_PERSONNALITE = "ApiUrlCheckinPersonnalite";
        public const string CONFIG_APIURL_PLANEJAMENTO_PERSONNALITE = "ApiUrlPlanejamentoPersonnalite";
        public const string CONFIG_APIURL_COLABORADORAGIR_PERSONNALITE = "ApiUrlColaboradorAgirPersonnalite";
        public const string CONFIG_APIURL_VERIFICADORPRODUCAO_PERSONNALITE = "ApiUrlVerificadorProducaoPersonnalite";
        public const string CONFIG_APIURL_PRODUTO_PERSONNALITE = "ApiUrlProdutoPersonnalite";

        //api guids
        public const string API_COLABORADOR_MONITORAMENTO_GUID = "7B211111-06A0-4093-8DAE-F8E0B895CUCU";
        public const string API_COLABORADOR_GUID = "7B271358-06A0-4093-8DAE-F8E0B895CAE2";
        public const string API_AGENCIA_GUID = "2E4F44A6-0A0B-4F60-87CF-3C9C5F5392FB";
        public const string API_PLANEJAMENTO_GUID = "62EFDDFC-BD36-4AB9-8F93-4C504BB27918";
        public const string API_COLABORADORAGIR_GUID = "A656C2E7-098D-45EB-AFD7-5BB7C7E9FBC0";
        public const string API_PLATAFORMA_GUID = "D03CE04B-A1E0-4BFE-8095-49E9D7F787E2";
        public const string API_COACHCLICK_GUID = "BC2B75EC-8A04-492E-AA54-6C0CFDB6BE46";
        public const string API_SEGURANCA_GUID = "0EFB5157-AE66-47F7-8F72-0054206FCC5F";
        public const string API_LOG_GUID = "E3A4E0AB-5937-469E-959E-3F2E1F99AFDD";
        public const string API_HOME_GUID = "157C6193-E330-4A16-B8AC-11C56B3C807F";
        public const string API_CHECKOUT_GUID = "C9F312A3-BEC4-4842-9FB4-1274B08B1388";
        public const string API_VERIFICADORPRODUCAO_GUID = "3F3E54A9-9125-43FB-9B40-2F4C3D30FE4C";
        public const string API_CHECKIN_GUID = "3BF580AB-3EBB-4C26-929D-B0021F17413B";
        public const string API_VAI_GUID = "8232E761-2E35-485D-A5B4-C4FE5AE07A70";
        public const string API_NOTIFICACOES_GUID = "61F42F40-0ECC-499E-B2F5-0D57D88D9FC2";
        public const string API_PERSONNALITE_PLANEJAMENTO_GUID = "54FE5CE9-C4F7-4A09-8531-5FA27E4C0289";
        public const string API_PERSONNALITE_CHECKIN_GUID = "2BCB665A-7482-42DB-8A88-8D5235F25F8C";
        public const string API_PERSONNALITE_CHECKOUT_GUID = "EFEDF1D6-D2E3-4865-BDE5-EE2997C59F55";
        public const string API_PERSONNALITE_PRODUCAO_GUID = "E9452C7E-8D6D-48C5-9D52-16DA6DB94C87";
        public const string API_COLABORADOR_ENGAJAMENTO_GUID = "DB6C2579-EEA1-4E6D-807F-C80CE2993BD0";
        public const string API_VISAOGERENCIAL_GUID = "A3E2FB40-7A45-41E4-A52D-80EF6569D9A1";
        public const string API_GESTAOFINANCEIRA_GUID = "5EE12C68-9156-4CB4-B3A4-61421D6F8CE2";
        
    }
}

