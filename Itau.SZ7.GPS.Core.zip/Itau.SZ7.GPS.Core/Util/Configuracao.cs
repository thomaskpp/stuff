﻿using Microsoft.Extensions.Configuration;
using System;
using System.IO;

namespace Itau.SZ7.GPS.Core.Util
{
    public static class Configuracao
    {
        public static IConfigurationSection CriaArquivoConfiguracao(IConfiguration configuration, IConfigurationBuilder configurationBuilder)
        {
            var diretorioAtual = Directory.GetCurrentDirectory();
            var environmentVariableName = configuration.GetSection("AppSettings")["EnviromentVariableName"];
            var environment = Environment.GetEnvironmentVariable(environmentVariableName, EnvironmentVariableTarget.Machine);

            if (string.IsNullOrEmpty(environment))
                environment = Environment.GetEnvironmentVariable(environmentVariableName);

            if (string.IsNullOrEmpty(environment))
                environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");


            if (configurationBuilder.Sources.Count == 0)
            {
                configurationBuilder.SetBasePath(diretorioAtual);
                configurationBuilder
                    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                    .AddJsonFile($"appsettings.{environment}.json", optional: true, reloadOnChange: true);

            }

            var root = configurationBuilder.Build();
            return root.GetSection("AppSettings");
        }
    }
}
