﻿using System.ComponentModel;

namespace Itau.SZ7.GPS.Core.Enums
{
    public enum Segmentos
    {
        [Description("Agencias")]
        Agencias = 1,
        [Description("Uniclass")]
        Uniclass = 2,
        [Description("Empresas 4")]
        Empresas4 = 3,
        [Description("Operacional")]
        Operacional = 4,
        [Description("Personnalite")]
        Personnalite = 5,
        [Description("Operacional Personnalite")]
        OperacionalPersonnalite = 6,
        [Description("Empresas 2")]
        Empresas2 = 7,
        [Description("Operacional Digital Personnalite")]
        OperacionalDigitalPersonnalite = 8,
        [Description("Operacional Digital Uniclass")]
        OperacionalDigitalUniclass = 9,
        [Description("Empresas 3")]
        Empresas3 = 10,
        [Description("Operacional Digital Empresas")]
        OperacionalDigitalEmpresas = 11,
        [Description("ADM")]
        ADM = 12
    }
}
