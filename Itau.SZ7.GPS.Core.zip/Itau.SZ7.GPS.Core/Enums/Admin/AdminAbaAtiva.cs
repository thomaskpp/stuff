﻿namespace Itau.SZ7.GPS.Core.Dados.Enums.Admin
{
    public enum AbaAtiva
    {
        Status,
        Carregar,
        Visualizar,
        Configuracao,
        Concluidas,
    }
}
