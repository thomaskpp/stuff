﻿namespace Itau.SZ7.GPS.Core.Dados.Enums.Admin
{
    public enum VisualizarArquivoVisao
    {
       Metas = 1,
       Grade = 2
    }
}
