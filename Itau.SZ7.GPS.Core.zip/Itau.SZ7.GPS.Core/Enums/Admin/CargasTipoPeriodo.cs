﻿namespace Itau.SZ7.GPS.Core.Dados.Enums.Admin
{
    public enum CargasTipoPeriodo
    {
        Diario = 1, //ESCOLHE UM DIA EXATO
        Semanal = 2, // TODA SEMANA
        Mensal = 3, //
        Anual = 4
    }
}
