﻿namespace Itau.SZ7.GPS.Core.Enums
{
    public enum LogTipo
    {
        Informacao = 1,
        Aviso = 2,
        Erro = 3,
        Critico = 4
    }
}
