﻿namespace Itau.SZ7.GPS.Core.Enums
{
    public enum LogAcessoEvento
    {
        Acesso = 1,
        Inserir = 2,
        Alterar = 3,
        Excluir = 4
    }
}
