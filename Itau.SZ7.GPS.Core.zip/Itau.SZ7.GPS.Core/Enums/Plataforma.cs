﻿namespace Itau.SZ7.GPS.Core.Enums
{
    public enum Plataforma
    {
        App = 1,
        Web = 2,
        Admin = 3,
        Api = 4
    }
}
