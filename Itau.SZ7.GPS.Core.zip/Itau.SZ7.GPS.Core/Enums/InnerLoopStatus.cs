﻿namespace Itau.SZ7.GPS.Core.Enums
{
    public enum InnerLoopStatus
    {
        ARealizar = 1,
        NaoAtendida = 2,
        Agendada = 3,
        Finalizada = 4
    }
}
