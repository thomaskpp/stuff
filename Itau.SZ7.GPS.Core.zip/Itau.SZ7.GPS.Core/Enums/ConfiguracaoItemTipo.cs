﻿using Itau.SZ7.GPS.Core.Util;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Itau.SZ7.GPS.Core.Enums
{
    public enum ConfiguracaoItemTipo
    {
        [Description("")]
        Desconhecido = 0,
        [Description("")]
        AppSetting = 1,
        [Description("")]
        Tema = 2,
        [Description("")]
        Rota = 3,
        [Description("")]
        ProducaoAgir = 4,
        [Description(ChavesPadrao.API_CHECKOUT_GUID)]
        Checkout = 5,
        [Description(ChavesPadrao.API_VAI_GUID)]
        VendaAtiva = 6,
        [Description(ChavesPadrao.API_CHECKIN_GUID)]
        Checkin = 7,
        [Description(ChavesPadrao.API_PLANEJAMENTO_GUID)]
        Planejamento = 8,
        [Description("")]
        Alavancas = 9,
        [Description(ChavesPadrao.API_NOTIFICACOES_GUID)]
        Notificacao = 10,
        [Description("")]
        Compromisso = 11,
        [Description("")]
        Engajamento = 12,
        [Description(ChavesPadrao.API_PLATAFORMA_GUID)]
        Plataforma = 13,
        [Description("")]
        NPS = 14,
        [Description("")]
        Reclamacao = 15,
        [Description(ChavesPadrao.API_COACHCLICK_GUID)]
        CoachClick = 16,
        [Description("")]
        DelegacaoAcesso = 17,
        [Description(ChavesPadrao.API_LOG_GUID)]
        LogAcesso = 18,
        [Description(ChavesPadrao.API_COLABORADOR_GUID)]
        Colaborador = 19,
        [Description(ChavesPadrao.API_VERIFICADORPRODUCAO_GUID)]
        VerificadorProducao = 20,
        [Description(ChavesPadrao.API_AGENCIA_GUID)]
        Agencia = 21,
        [Description(ChavesPadrao.API_SEGURANCA_GUID)]
        Seguranca = 22,
        [Description(ChavesPadrao.API_COLABORADORAGIR_GUID)]
        ColaboradorAgir = 23,
        [Description(ChavesPadrao.API_PERSONNALITE_PLANEJAMENTO_GUID)]
        PersonnalitePlanejamento = 24,
        [Description(ChavesPadrao.API_PERSONNALITE_CHECKIN_GUID)]
        PersonnaliteCheckin = 25,
        [Description(ChavesPadrao.API_PERSONNALITE_CHECKOUT_GUID)]
        PersonnaliteCheckout = 26,
        [Description(ChavesPadrao.API_PERSONNALITE_PRODUCAO_GUID)]
        PersonnaliteProducao = 27,
        [Description(ChavesPadrao.API_HOME_GUID)]
        Home = 28,
        [Description(ChavesPadrao.API_VISAOGERENCIAL_GUID)]
        VisaoGerencial = 29,
        [Description(ChavesPadrao.API_GESTAOFINANCEIRA_GUID)]
        GestaoFinanceira = 30

    }
}
