﻿using Microsoft.AspNetCore.Authentication;

namespace Itau.SZ7.GPS.Core.Seguranca
{
    public class GPSAuthenticationOptions : AuthenticationSchemeOptions
    {
    }
}
