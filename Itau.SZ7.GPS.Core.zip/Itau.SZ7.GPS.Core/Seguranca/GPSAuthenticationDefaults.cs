﻿namespace Itau.SZ7.GPS.Core.Seguranca
{
    public class GPSAuthenticationDefaults
    {
        /// <summary>
        /// Authentication Scheme Name
        /// </summary>
        public const string AuthenticationScheme = "GPSAuth";

        /// <summary>
        /// Chave do Token armazenado no contexto
        /// </summary>
        public const string CLAIM_TOKEN = "t";
        /// <summary>
        /// Chave da funcional armazenado no contexto
        /// </summary>
        public const string CLAIM_FUNCIONAL = "funcional";
        /// <summary>
        /// Chave da racf armazenado no contexto
        /// </summary>
        public const string CLAIM_RACF = "racf";
        /// <summary>
        /// Chave da carteira armazenado no contexto
        /// </summary>
        public const string CLAIM_CARTEIRA = "carteira";
        /// <summary>
        /// Chave do cargo armazenado no contexto
        /// </summary>
        public const string CLAIM_CARGO = "cargo";
        /// <summary>
        /// Chave do nome armazenado no contexto
        /// </summary>
        public const string CLAIM_NOME = "nome";

        public const string CLAIM_APITOKEN = "apitoken";
    }
}
