﻿using Itau.SZ7.GPS.Core.Seguranca.Entidades;
using Microsoft.AspNetCore.Authentication;
using Newtonsoft.Json;

namespace Itau.SZ7.GPS.Core.Seguranca
{
    public static class GPSAuthenticationExtensions
    {
        public static AuthenticationBuilder AddGPSAuth(this AuthenticationBuilder builder)
        {
            return builder.AddScheme<GPSAuthenticationOptions, GPSAuthenticationHandler>(
                GPSAuthenticationDefaults.AuthenticationScheme, _ => { });
        }

        public static string GenerateAuthorizationData(string user, string password)
        {
            var userModel = new UserAuthentication();

            userModel.L = user; // user.ToBase64();
            userModel.P = password; // password.ToBase64();

            return JsonConvert.SerializeObject(userModel); //.ToBase64();
        }
    }
}
