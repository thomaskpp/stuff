﻿using Itau.SZ7.GPS.Core.Entidade;
using Itau.SZ7.GPS.Core.Seguranca.Entidades;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Seguranca
{
    public class GPSAuthenticationHandler : AuthenticationHandler<GPSAuthenticationOptions>
    {
        private readonly IValidacaoUsuarioServico _validacaoUsuarioServico;
        private readonly ILogServico _logServico;
        private readonly ILogAcessoServico _logAcessoServico;
        private Sessao _sessao;
        private string _erroAutenticacao = "RACF ou senha inválido";

        public GPSAuthenticationHandler(
            IOptionsMonitor<GPSAuthenticationOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock,
            IValidacaoUsuarioServico validacaoUsuarioServico,
            ILogServico logServico,
            ILogAcessoServico logAcessoServico,
            ISessaoServico sessaoServico)
        : base(options, logger, encoder, clock)
        {
            _validacaoUsuarioServico = validacaoUsuarioServico;
            _logServico = logServico;
            _logAcessoServico = logAcessoServico;

            _sessao = sessaoServico.RetornaSessao();
            _sessao.ApiGuid = ChavesPadrao.API_COLABORADOR_GUID;
            _sessao.IdFuncionalidade = (int)Enums.Funcionalidade.Login;
            _sessao.IdPlataforma = (int)Enums.Plataforma.Web;
        }

        protected override Task HandleChallengeAsync(AuthenticationProperties properties)
        {
            Response.StatusCode = 401;

            if(_erroAutenticacao.Length > 0)
            {
                var erro = Encoding.GetEncoding("UTF-8").GetBytes(_erroAutenticacao);
                Response.Body.WriteAsync(erro, 0, erro.Length);
            }

            return Task.CompletedTask;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            if (!Request.Headers.ContainsKey(ChavesPadrao.AuthenticationRequestApiToken) &&
                !Request.Headers.ContainsKey(ChavesPadrao.AuthenticationRequestHeaderName) &&
                !Request.Headers.ContainsKey(ChavesPadrao.AuthorizationHeaderName))
            {
                return default;
            }

            if ((Request.Headers.ContainsKey(ChavesPadrao.AuthenticationRequestApiToken) &&
                string.IsNullOrEmpty(Request.Headers[ChavesPadrao.AuthenticationRequestApiToken])) ||

                (Request.Headers.ContainsKey(ChavesPadrao.AuthenticationRequestHeaderName) &&
                string.IsNullOrEmpty(Request.Headers[ChavesPadrao.AuthenticationRequestHeaderName])) ||

                (Request.Headers.ContainsKey(ChavesPadrao.AuthorizationHeaderName) &&
                string.IsNullOrEmpty(Request.Headers[ChavesPadrao.AuthorizationHeaderName])))
            {
                return default;
            }

            if (string.IsNullOrEmpty(Request.Headers[ChavesPadrao.AuthenticationRequestApiToken]))
                return await AutenticacaoPortal();
            else
                return await AutenticacaoApi();
        }

        private async Task<AuthenticateResult> AutenticacaoApi()
        {
            if (Request.Headers[ChavesPadrao.AuthenticationRequestApiToken] != ChavesPadrao.API_CHAVEAUTENTICACAO)
                return await Task.FromResult(AuthenticateResult.Fail("Não autorizado"));

            return await Task.FromResult(
                AuthenticateResult.Success(
                    new AuthenticationTicket(
                        new ClaimsPrincipal(
                            new ClaimsIdentity(
                                Enumerable.Repeat(
                                    new Claim(GPSAuthenticationDefaults.CLAIM_APITOKEN,
                                        Request.Headers[ChavesPadrao.AuthenticationRequestApiToken]), 1), Scheme.Name))
                        , Scheme.Name)));
        }

        private async Task<AuthenticateResult> AutenticacaoPortal()
        {
            string funcional = string.Empty;
            int idColaborador = 0;
            int idColaboradorAgir = 0;
            string token = string.Empty;
            string user = string.Empty;
            UserAuthentication userData = null;
            Entidade.DTO.Colaborador colaborador = null;

            try
            {
                token = await TokenVerify();
                user = await ValidateTokenValues();

                if (!string.IsNullOrEmpty(token))
                {
                    if (!_validacaoUsuarioServico.ValidaToken(token, out funcional, out idColaborador, out idColaboradorAgir))
                    {
                        await _logServico.RegistrarInformacao(
                            $"Token inválido: {token}",
                            sessao: _sessao);

                        return AuthenticateResult.Fail(_erroAutenticacao);
                    }

                    colaborador = new Entidade.DTO.Colaborador()
                    {
                        Funcional = funcional
                    };
                }
                else if (string.IsNullOrEmpty(user))
                {
                    await _logServico.RegistrarInformacao(
                        $"Dados de acesso inválidos. {ChavesPadrao.AuthenticationRequestHeaderName}:'{user}'",
                        "HandleAuthenticateAsync",
                        _sessao);

                    return AuthenticateResult.Fail(_erroAutenticacao);
                }
                else
                {
                    userData = GetAuthorizationData(user);
                    bool Fake = false;
                    bool AD = false;

                    if (string.IsNullOrEmpty(userData.L) || string.IsNullOrEmpty(userData.P))
                    {
                        await _logServico.RegistrarAviso(
                            $"Usuário ou senha em branco: {userData.L}, {userData.P}",
                            "HandleAuthenticateAsync",
                            _sessao);
                    }

                    try
                    {
                        Fake = await _validacaoUsuarioServico.AutenticaColaboradorSimulacao(userData.L, userData.P);

                        if (Fake)
                            funcional = userData.L;
                    }
                    catch (Exception ex)
                    {
                        await _logServico.RegistrarExcecao(ex);
                    }

                    if (!Fake)
                    {
                        if (userData.L.Length != 7)
                        {
                            return AuthenticateResult.Fail(_erroAutenticacao);
                        }

                        try
                        {
                            AD = _validacaoUsuarioServico.AutenticaAD(userData.L, userData.P, out funcional, out Dictionary<string, string> retornoAd);

                            if (!int.TryParse(funcional, out int resultParse) ||
                                (retornoAd != null && retornoAd.Count > 0))
                            {
                                if (retornoAd.Count > 0)
                                {
                                    await _logServico.RegistrarInformacao(
                                        $"Retorno AD: {string.Join(";", retornoAd.Select(x => x.Key + "=" + x.Value).ToArray())}",
                                        "HandleAuthenticateAsync",
                                        _sessao);
                                }

                                await _logServico.RegistrarAviso(
                                    "Campo description do AD não retornou a funcional do usuário",
                                    "HandleAuthenticateAsync",
                                    _sessao);

                                return AuthenticateResult.Fail(ErrosAD.RetornaErro(retornoAd.Last().Value));
                            }
                        }
                        catch (Exception ex)
                        {
                            await _logServico.RegistrarExcecao(ex);
                        }
                    }


                    colaborador = await ObterColaborador(funcional);
                    idColaboradorAgir = colaborador.ColaboradorAgir.FirstOrDefault()?.Id ?? 0;

                    if (colaborador == null || !colaborador.Ativo)
                    {
                        return AuthenticateResult.Fail(_erroAutenticacao);
                    }


                    token = _validacaoUsuarioServico.CriaToken(true, funcional, string.Empty, colaborador.Id, idColaboradorAgir);
                    Request.HttpContext.Response.Headers.Add(ChavesPadrao.AuthenticationResponseHeaderName, token);

                    await _logAcessoServico.InsereLogAcesso(new Entidade.LogAcesso()
                    {
                        IdColaborador = colaborador.Id,
                        IdPlataforma = (int)Enums.Plataforma.Web,
                        IdFuncionalidade = (int)Enums.Funcionalidade.Login,
                        CodigoEvento = 1,
                        Sucesso = true,
                        DadosAdicionais = userData.L
                    });
                }

                var claims = new List<Claim>
                {
                    new Claim(GPSAuthenticationDefaults.CLAIM_FUNCIONAL, colaborador.Funcional),
                    new Claim(GPSAuthenticationDefaults.CLAIM_RACF, colaborador.Racf ?? string.Empty),
                    new Claim(GPSAuthenticationDefaults.CLAIM_TOKEN, token),
                    new Claim(GPSAuthenticationDefaults.CLAIM_CARGO, colaborador.IdCargo?.ToString() ?? string.Empty),
                    new Claim(GPSAuthenticationDefaults.CLAIM_NOME, colaborador.Nome ?? string.Empty)
                };

                ClaimsIdentity userIdentity = new ClaimsIdentity(claims, Scheme.Name);
                ClaimsPrincipal principal = new ClaimsPrincipal(userIdentity);
                var ticket = new AuthenticationTicket(principal, Scheme.Name);

                return AuthenticateResult.Success(ticket);
            }
            catch (Exception ex)
            {
                await _logServico.RegistrarExcecao(ex, _sessao);

                return AuthenticateResult.Fail(_erroAutenticacao);
            }
        }

        private async Task<Entidade.DTO.Colaborador> ObterColaborador(string funcional)
        {
            var colaborador = await _validacaoUsuarioServico.ObterColaborador(funcional);

            if (colaborador == null)
            {
                await _logServico.RegistrarAviso(
                    $"Colaborador {funcional} não encontrado",
                    "HandleAuthenticateAsync",
                    _sessao);

                return default;
            }
            else if (!colaborador.Ativo)
            {
                await _logServico.RegistrarAviso(
                    $"Colaborador {funcional} não está ativo",
                    "HandleAuthenticateAsync",
                    _sessao);

                return default;
            }

            return colaborador;
        }

        private async Task<string> TokenVerify()
        {
            string token = string.Empty;
            //verificar se o token foi enviado, se sim verifica se está válido
            if (Request.Headers.TryGetValue(ChavesPadrao.AuthorizationHeaderName, out StringValues values))
            {
                if (values.Count <= 0)
                {
                    await _logServico.RegistrarAviso(
                        "Não foi possível ler 'AuthorizationHeaderName'. A variável values estava menor ou igual a 0.",
                        "TokenVerify",
                        _sessao);
                }

                token = values.First();
            }
            return token;
        }

        private async Task<string> ValidateTokenValues()
        {
            string user = string.Empty;
            //verificar se o token foi enviado, se sim verifica se está válido
            if (Request.Headers.TryGetValue(ChavesPadrao.AuthenticationRequestHeaderName, out StringValues userValues))
            {
                if (userValues.Count <= 0)
                {
                    await _logServico.RegistrarAviso(
                        "Não foi possível ler 'AuthenticationRequestHeaderName'. A variável values estava menor ou igual a 0.",
                        "ValidateTokenValues",
                        _sessao);
                }

                user = userValues.First();
            }
            return user;
        }

        private UserAuthentication GetAuthorizationData(string user)
        {
            byte[] userParams = Convert.FromBase64String(user);
            string userLogin = Encoding.UTF8.GetString(userParams);

            var userData = JsonConvert.DeserializeObject<UserAuthentication>(userLogin);

            byte[] mybyte = Convert.FromBase64String(userData.L);
            userData.L = Encoding.UTF8.GetString(mybyte);

            mybyte = Convert.FromBase64String(userData.P);
            userData.P = Encoding.UTF8.GetString(mybyte);

            return userData;
        }
    }
}
