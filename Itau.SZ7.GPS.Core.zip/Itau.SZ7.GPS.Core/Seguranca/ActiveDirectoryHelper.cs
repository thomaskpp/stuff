﻿using Itau.SZ7.GPS.Core.Extensoes.Tipos;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.DirectoryServices;
using System.Text;

namespace Itau.SZ7.GPS.Core.Seguranca
{
    internal class ActiveDirectoryHelper
    {
        private const string LDAP_USER_FILTER = "UserFilterDCLogin";
        private const string LDAP_USER_PROPERTIES_DC = "UserPropertiesDC";
        private const string LDAP_ADDRESS_DC_AGE = "AddressDC_AGE";
        private const string LDAP_ADDRESS_DC_ADMCENTRAL = "AddressDC_ADMCentral";
        private const string LDAP_ADDRESS_DC_ITAUCORP = "AddressDC_ITAUCORP";
        private const string LDAP_FUNCIONAL_KEY = "description";
        private readonly IConfiguracaoServico _configuracaoServico;

        public ActiveDirectoryHelper(IConfiguracaoServico configuracaoServico)
        {
            _configuracaoServico = configuracaoServico;
        }

        internal bool Login(string racf, string password, out string funcional, out Dictionary<string, string> retornoAd)
        {
            funcional = "";
            retornoAd = new Dictionary<string, string>();

            try
            {
                int result = 0;
                // Verificar se o usuario existe na agencia 
                Dictionary<string, string> r = ValidateUser(LDAP_ADDRESS_DC_AGE, LDAP_USER_FILTER, racf, password);

                if (r.ContainsKey("Erro"))
                    retornoAd.Add("Erro", r["Erro"]);

                if (r != null && r.Count > 0)
                {
                    funcional = r[LDAP_FUNCIONAL_KEY];
                    if (int.TryParse(funcional, out result))
                        return true;

                    funcional = "";
                }

                // verificar se o usuario exsite na adm central 
                r = ValidateUser(LDAP_ADDRESS_DC_ADMCENTRAL, LDAP_USER_FILTER, racf, password);

                if (r.ContainsKey("Erro"))
                    retornoAd.Add("Erro", r["Erro"]);

                if (r != null && r.Count > 0)
                {
                    funcional = r[LDAP_FUNCIONAL_KEY];
                    if (int.TryParse(funcional, out result))
                        return true;

                    funcional = "";
                }

                // verificar se o usuario exsite na adm central 
                r = ValidateUser(LDAP_ADDRESS_DC_ITAUCORP, LDAP_USER_FILTER, racf, password);

                if (r.ContainsKey("Erro"))
                    retornoAd.Add("Erro", r["Erro"]);

                if (r != null && r.Count > 0)
                {
                    funcional = r[LDAP_FUNCIONAL_KEY];

                    if (int.TryParse(funcional, out result))
                        return true;

                    funcional = "";
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
            }

            return false;
        }

        private Dictionary<string, string> ValidateUser(string configAddres, string configFilter, string racf, string senhaServico)
        {
            try
            {
                string sFromWhere = GetAddress(configAddres);
                DirectoryEntry deBase = new DirectoryEntry(sFromWhere, racf, senhaServico);
                DirectorySearcher dsLookForDomain = new DirectorySearcher(deBase);
                dsLookForDomain.Filter = string.Format(GetUserFilter(configFilter), racf);
                string[] filtros = GetUserProperties();
                foreach (var filtro in filtros)
                {
                    dsLookForDomain.PropertiesToLoad.Add(filtro);
                }

                SearchResult result = dsLookForDomain.FindOne();
                Dictionary<string, string> valores = new Dictionary<string, string>(filtros.Length);
                if (result != null)
                {
                    foreach (var filtro in filtros)
                    {
                        StringBuilder sb = new StringBuilder();
                        foreach (var item in result.Properties[filtro])
                        {
                            sb.AppendFormat("{0}", item);
                        }

                        valores.Add(filtro, sb.ToString());
                    }
                }

                return valores;
            }
            catch (Exception ex)
            {
                return new Dictionary<string, string>()
                {
                    { "Erro", ExceptionExtension.RetornaInnerException(ex).Message }
                };
            }
        }


        private string GetAddress(string config)
        {
            return _configuracaoServico.RetornaValorConfiguracao($"{ChavesPadrao.CONFIG_LDAPSETTINGS_BASE}{config}");
        }

        private string GetUserFilter(string config)
        {
            string filter = _configuracaoServico.RetornaValorConfiguracao($"{ChavesPadrao.CONFIG_LDAPSETTINGS_BASE}{config}");
            return filter.Replace("|And|", "&");
        }

        private string[] GetUserProperties()
        {
            string props = _configuracaoServico.RetornaValorConfiguracao($"{ChavesPadrao.CONFIG_LDAPSETTINGS_BASE}{LDAP_USER_PROPERTIES_DC}");
            string[] propList = props.Split('|');
            return propList;
        }
    }
}
