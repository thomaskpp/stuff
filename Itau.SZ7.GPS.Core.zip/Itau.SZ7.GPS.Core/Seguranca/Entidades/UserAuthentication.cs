﻿namespace Itau.SZ7.GPS.Core.Seguranca.Entidades
{
    public class UserAuthentication
    {
        /// <summary>
        /// Login
        /// </summary>
        public string L { get; set; }

        /// <summary>
        /// Password
        /// </summary>
        public string P { get; set; }
    }
}
