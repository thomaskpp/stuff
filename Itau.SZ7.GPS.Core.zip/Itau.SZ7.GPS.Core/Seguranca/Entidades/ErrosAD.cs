﻿using System.Collections.Generic;

namespace Itau.SZ7.GPS.Core.Seguranca.Entidades
{
    public static class ErrosAD
    {
        private static Dictionary<string, string> _erros = new Dictionary<string, string>
        {
            { "user name does not exist", "RACF não encontrada" },
            { "user name is correct but the password is wrong", "Senha incorreta" },
            { "expires password", "Senha expirada" },
            { "user is currently locked out", "RACF bloqueada" },
            { "user name does not exist user name is correct but password is wrong", "RACF não encontrada" }
        };

        public static string RetornaErro(string erroAD)
        {
            var key = erroAD.ToLower().Replace(".", "").Trim();
            return _erros.ContainsKey(key) ? _erros[key] : string.Empty;
        }
    }
}
