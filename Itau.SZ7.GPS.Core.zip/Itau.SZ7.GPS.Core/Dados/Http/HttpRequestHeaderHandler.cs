﻿using Itau.SZ7.GPS.Core.Entidade;
using Itau.SZ7.GPS.Core.Enums;
using Itau.SZ7.GPS.Core.Excecoes.Tipos;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Dados.Http
{
    internal class HttpRequestHeaderHandler : DelegatingHandler
    {
        private Sessao _sessao;
        private readonly ISessaoServico _sessaoServico;

        public HttpRequestHeaderHandler(ISessaoServico sessaoServico)
        {
            _sessaoServico = sessaoServico;
            //_sessao = _sessaoServico.RetornaSessao();
        }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            CabecalhoPadrao(request);
            return base.SendAsync(request, cancellationToken);
        }

        void CabecalhoPadrao(HttpRequestMessage requisicao)
        {
            _sessao = _sessaoServico.RetornaSessao();

            if (_sessao == null)
                throw new ObjetoSessaoNaoInformadoException("Parâmetro sessão não informado");

            AdicionarItemCabecalho(requisicao, ChavesPadrao.AuthenticationRequestGuidName, _sessao?.Guid);
            AdicionarItemCabecalho(requisicao, ChavesPadrao.CABECALHO_COLABORADOR, _sessao?.IdColaborador.ToString());
            AdicionarItemCabecalho(requisicao, ChavesPadrao.CABECALHO_COLABORADORAGIR, _sessao?.IdColaboradorAgir.ToString());
            AdicionarItemCabecalho(requisicao, ChavesPadrao.CABECALHO_FUNCIONALIDADE, _sessao?.IdFuncionalidade.ToString());

            //AdicionarItemCabecalho(requisicao, ChavesPadrao.AuthenticationRequestApiGuid, _sessao?.ApiGuid, true);
            AdicionarItemCabecalho(requisicao, ChavesPadrao.CABECALHO_PLATAFORMA, System.Convert.ToString((int)Plataforma.Api), true);
            AdicionarItemCabecalho(requisicao, ChavesPadrao.AuthenticationRequestApiToken, ChavesPadrao.API_CHAVEAUTENTICACAO, true);
        }

        void AdicionarItemCabecalho(HttpRequestMessage requisicao, string nomeItem, string valorItem)
        {
            if (!requisicao.Headers.Contains(nomeItem))
                requisicao.Headers.Add(nomeItem, valorItem);
        }

        void AdicionarItemCabecalho(HttpRequestMessage requisicao, string nomeItem, string valorItem, bool removerExistente)
        {
            if (removerExistente)
                requisicao.Headers.Remove(nomeItem);

            AdicionarItemCabecalho(requisicao, nomeItem, valorItem);
        }
    }
}
