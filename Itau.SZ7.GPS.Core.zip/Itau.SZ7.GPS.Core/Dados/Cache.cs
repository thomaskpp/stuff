﻿using Itau.SZ7.GPS.Core.Extensoes;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Dados
{
    public class Cache : Interface.ICache
    {
        #region campos

        private readonly IMemoryCache _memoryCache;
        private readonly MemoryCacheEntryOptions _memoryCacheEntryOptions;
        private ConcurrentBag<string> _chavesUtilizadas;
        private bool _desligado;

        #endregion

        #region construtor

        public Cache(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
            _chavesUtilizadas = new ConcurrentBag<string>();
            _desligado = false;

            _memoryCacheEntryOptions = new MemoryCacheEntryOptions();
            _memoryCacheEntryOptions.SetPriority(CacheItemPriority.Normal);
            _memoryCacheEntryOptions.SetAbsoluteExpiration(TimeSpan.FromMinutes(60));
        }

        #endregion

        #region métodos públicos

        public T RetornaValor<T>(string chave)
        {
            if (_memoryCache.TryGetValue(chave, out T result))
                return result;

            return default;
        }

        public async Task<T> RetornaOuDefineValor<T>(
            string chave, 
            Func<Task<T>> retornaDados, 
            int expiracaoEmMinutos = 0, 
            CacheItemPriority prioridade = CacheItemPriority.Normal)
        {
            if (_desligado && retornaDados != null)
                return await retornaDados.Invoke();

            return await _memoryCache.RetornaOuCriaAsync(chave, async (cacheEntry) =>
            {
                var opcoes = _memoryCacheEntryOptions;

                if (expiracaoEmMinutos > 0)
                    opcoes.SetAbsoluteExpiration(TimeSpan.FromMinutes(expiracaoEmMinutos));

                if (prioridade != CacheItemPriority.Normal)
                    opcoes.SetPriority(prioridade);
                
                cacheEntry.SetOptions(opcoes);

                AdicionaChaveUtilizada(chave);

                if (retornaDados != null)
                    return await retornaDados.Invoke();

                return default;
            });
        }

        public async Task DefineValor<T>(string chave, T dados, CacheItemPriority prioridade = CacheItemPriority.Normal)
        {
            await RetornaOuDefineValor<T>(chave, () =>
            {
                return Task.FromResult(dados);
            }, 
            prioridade: prioridade);
        }

        public void DefineTempoCache(int minutos)
        {
            if (minutos == 0)
                _desligado = true;
            else
            {
                _memoryCacheEntryOptions.SetAbsoluteExpiration(TimeSpan.FromMinutes(minutos));
                _desligado = false;
            }

        }

        public void LimpaCachePorChaves(IList<string> chaves)
        {
            foreach (var chave in chaves)
                _memoryCache.Remove(chave);
        }

        public void LimpaTodasChavesUtilizadas(string iniciaEm)
        {
            if (_chavesUtilizadas == null || _chavesUtilizadas.IsEmpty)
                return;

            foreach (var chave in _chavesUtilizadas.Where(x => x.StartsWith(iniciaEm)))
                _memoryCache.Remove(chave);
        }

        #endregion

        #region auxiliares

        private void AdicionaChaveUtilizada(string chave)
        {
            if (_chavesUtilizadas == null)
                _chavesUtilizadas = new ConcurrentBag<string>();

            if (!_chavesUtilizadas.Contains(chave))
                _chavesUtilizadas.Add(chave);
        }

        #endregion
    }
}
