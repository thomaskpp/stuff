﻿using System;
using System.Collections.Generic;
using System.Data;

namespace Itau.SZ7.GPS.Core.Dados.Sql.Interface
{
    public interface ISqlMultipleExecuteData
    {
        Type ReturnType { get; set; }
        string CommandText { get; set; }
        CommandType CommandType { get; }
        Dictionary<string, object> Parameters { get; set; }
        bool IsReturnList { get; set; }
        object Result { get; }
        void SetResult(object value);
        void Cast<TOut>(out TOut result);
    }

    public interface ISqlMultipleExecuteData<T> : ISqlMultipleExecuteData
    {
        new T Result { get; }
    }
}
