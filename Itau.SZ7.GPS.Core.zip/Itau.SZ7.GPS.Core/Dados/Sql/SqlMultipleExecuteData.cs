﻿using Itau.SZ7.GPS.Core.Dados.Sql.Interface;
using System;
using System.Collections.Generic;
using System.Data;

namespace Itau.SZ7.GPS.Core.Dados.Sql
{
    public class SqlMultipleExecuteData<T> : ISqlMultipleExecuteData<T>
    {
        public SqlMultipleExecuteData()
        {
            CommandType = CommandType.StoredProcedure;
        }

        public Type ReturnType { get; set; }

        public string CommandText { get; set; }
        public CommandType CommandType { get; private set; }
        public Dictionary<string, object> Parameters { get; set; }
        public bool IsReturnList { get; set; }

        object ISqlMultipleExecuteData.Result
        {
            get { return Result; }
        }

        public T Result { get; set; }

        public void SetResult(object value)
        {
            Result = (T)value;
        }

        public void Cast<TOut>(out TOut result)
        {
            result = (TOut)Convert.ChangeType(Result, typeof(TOut));
        }
    }
}
