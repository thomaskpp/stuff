﻿using Itau.SZ7.GPS.Core.Dados.Sql.Interface;
using System.Collections;
using System.Collections.Generic;

namespace Itau.SZ7.GPS.Core.Dados.Sql
{
    public class SqlMultipleExecuteDataCollection : ICollection<ISqlMultipleExecuteData>
    {
        private readonly List<ISqlMultipleExecuteData> _collection;
        private IEnumerator<ISqlMultipleExecuteData> _enumerator;

        public SqlMultipleExecuteDataCollection()
        {
            _collection = new List<ISqlMultipleExecuteData>();
        }

        public SqlMultipleExecuteDataCollection(List<ISqlMultipleExecuteData> collection)
        {
            _collection = collection;
        }

        public int Count => _collection.Count;

        public bool IsReadOnly => false;

        public void Add(ISqlMultipleExecuteData item)
        {
            _collection.Add(item);
        }

        public void Clear()
        {
            _enumerator = null;
            _collection.Clear();
        }

        public bool Contains(ISqlMultipleExecuteData item)
        {
            return _collection.Contains(item);
        }

        public void CopyTo(ISqlMultipleExecuteData[] array, int arrayIndex)
        {
            _collection.CopyTo(array, arrayIndex);
        }

        public IEnumerator<ISqlMultipleExecuteData> GetEnumerator()
        {
            return _collection.GetEnumerator();
        }

        public bool Remove(ISqlMultipleExecuteData item)
        {
            _enumerator = null;
            return _collection.Remove(item);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public T GetNextResult<T>()
        {
            T result = default;

            if (_enumerator is null)
                _enumerator = GetEnumerator();

            if (_enumerator.MoveNext())
            {
                _enumerator.Current.Cast(out result);
            }

            return result;
        }

        public SqlMultipleExecuteDataCollection GetNextResult<T>(out T result)
        {
            result = GetNextResult<T>();
            return this;
        }
    }
}
