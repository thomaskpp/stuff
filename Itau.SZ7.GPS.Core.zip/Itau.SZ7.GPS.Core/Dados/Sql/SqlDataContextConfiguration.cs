﻿namespace Itau.SZ7.GPS.Core.Dados.Sql
{
    public class SqlDataContextConfiguration
    {
        public string Conexao { get; set; }
        public int TempoExpiracao { get; set; }
    }
}
