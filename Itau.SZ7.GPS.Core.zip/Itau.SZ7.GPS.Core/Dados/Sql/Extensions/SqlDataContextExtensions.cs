﻿using Itau.SZ7.GPS.Core.Dados.Interface;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Dados.Sql.Extensions
{
    public static class SqlDataContextExtensions
    {
        public static IServiceCollection ConfigurarSqlDataContext(this IServiceCollection services)
        {
            services.AddSingleton((provider) => new SqlDataContextConfiguration());
            services.AddScoped<ISqlDataContext, SqlDataContext>();

            return services;
        }

        public static IApplicationBuilder UseConfigurarSqlDataContextHandler(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<SqlDataContextHandler>();
        }
    }

    public class SqlDataContextHandler
    {
        private readonly RequestDelegate _next;

        public SqlDataContextHandler(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext, SqlDataContextConfiguration opcoes, IConfiguracaoServico configuracaoServico)
        {
            if (httpContext.Request.Path.HasValue &&
                (
                    !httpContext.Request.Path.Value.ToLower().Contains("index.html") &&
                    !httpContext.Request.Path.Value.ToLower().Contains("swagger") &&
                    !httpContext.Request.Path.Value.ToLower().Contains("favicon") &&
                    !httpContext.Request.Path.Value.ToLower().Contains("obtemconfiguracao")
                ))
            {
                if (string.IsNullOrEmpty(opcoes.Conexao) ||
                    !configuracaoServico.ExisteConfiguracao())
                {
                    await configuracaoServico.EnviaConfiguracaoParaCache();
                    opcoes.Conexao = configuracaoServico.RetornaConnectionString();
                }
            }

            await _next(httpContext);
        }
    }
}
