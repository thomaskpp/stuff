﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;

namespace Itau.SZ7.GPS.Core.Dados.Sql.Extensions
{
    public static class SqlDataReaderExtensions
    {
        public static object SqlDataReaderToObject(this SqlDataReader sqlDataReader, Type dataType)
        {
            switch (dataType)
            {
                case var expBool when expBool == typeof(bool):
                case var expByte when expByte == typeof(byte):
                case var expChar when expChar == typeof(char):
                case var expDecimal when expDecimal == typeof(decimal):
                case var expDouble when expDouble == typeof(double):
                case var expFloat when expFloat == typeof(float):
                case var expInt32 when expInt32 == typeof(int):
                case var expInt64 when expInt64 == typeof(long):
                case var expInt16 when expInt16 == typeof(short):
                case var expString when expString == typeof(string):
                case var expDateTime when expDateTime == typeof(DateTime):
                    return SqlDataReaderToType(sqlDataReader, dataType);
                default:
                    PropertyInfo[] properties = GetProperties(dataType);
                    var instance = CreateInstance(dataType);

                    IEnumerable<string> dataReaderColuns = sqlDataReader.GetColumnsName();

                    foreach (var prop in properties)
                    {
                        if (dataReaderColuns.Contains(prop.Name.ToUpper()))
                        {
                            object value = sqlDataReader[prop.Name];
                            SetValue(instance, prop, value);
                        }
                    }

                    return instance;
            }
        }

        public static object SqlDataReaderToType(this SqlDataReader sqlDataReader, Type dataType)
        {
            try
            {
                return Convert.ChangeType(sqlDataReader[0], dataType);
            }
            catch (InvalidCastException)
            {
                return null;
            }
        }

        public static T SqlDataReaderToObject<T>(this SqlDataReader sqlDataReader)
        {
            Type dataType = GetType<T>();

            return (T)SqlDataReaderToObject(sqlDataReader, dataType);
        }

        private static object CreateInstance(Type genericType)
        {
            var instance = Activator.CreateInstance(genericType);
            return instance;
        }

        private static Type GetType<T>()
        {
            return typeof(T);
        }

        private static PropertyInfo[] GetProperties(Type genericType)
        {
            return genericType.GetProperties();
        }

        private static void SetValue<T>(T instance, PropertyInfo prop, object value)
        {
            if (!(value is null) && value.GetType() != DBNull.Value.GetType())
            {
                prop.SetValue(instance, value);
            }
        }
        public static IEnumerable<string> GetColumnsName(this SqlDataReader sqlDataReader)
        {
            for (int i = 0; i < sqlDataReader.FieldCount; i++)
            {
                yield return sqlDataReader.GetName(i).ToUpper();
            }
        }
    }
}
