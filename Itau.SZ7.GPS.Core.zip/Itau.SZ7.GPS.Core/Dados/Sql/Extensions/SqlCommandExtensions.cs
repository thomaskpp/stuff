﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Itau.SZ7.GPS.Core.Dados.Sql.Extensions
{
    public static class SqlCommandExtensions
    {

        public static void AddParameter(this SqlCommand sqlCommand, Dictionary<string, object> parameters)
        {
            if (parameters != null && parameters.Count > 0)
            {
                foreach (var item in parameters)
                {
                    sqlCommand.Parameters.AddWithValue(item.Key, item.Value ?? DBNull.Value);
                }
            }
        }
    }
}
