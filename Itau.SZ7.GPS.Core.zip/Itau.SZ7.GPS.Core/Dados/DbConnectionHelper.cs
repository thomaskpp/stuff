﻿using Itau.ST.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace Itau.SZ7.GPS.Core.Dados.Data
{
    public static class DbConnectionHelper
    {
        public static string GetSqlConnection(string itauDbConnection)
        {
            DbProviderFactory factory = ST.Data.SqlClient.ItauSqlClientFactory.Instance;
            ItauDbConnection connection = (ItauDbConnection)factory.CreateConnection();
            connection.ConnectionString = itauDbConnection;
            var sqlConnection = connection.GetTypedConnection<SqlConnection>();
            return sqlConnection.ConnectionString;
        }
    }
}
