﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Dados.Interface
{
    public interface ICache
    {
        T RetornaValor<T>(string chave);
        Task<T> RetornaOuDefineValor<T>(
            string chave,
            Func<Task<T>> retornaDados,
            int expiracaoEmMinutos = 0,
            CacheItemPriority prioridade = CacheItemPriority.Normal);
        Task DefineValor<T>(
            string chave, 
            T dados, 
            CacheItemPriority prioridade = CacheItemPriority.Normal);
        void DefineTempoCache(int minutos);
        void LimpaCachePorChaves(IList<string> chaves);
        void LimpaTodasChavesUtilizadas(string iniciaEm);
    }
}
