﻿using Itau.SZ7.GPS.Core.Dados.Sql;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Dados.Interface
{
    public interface ISqlDataContext
    {
        string ConnectionString { get; }

        Task<IEnumerable<T>> SelectQueryToListAsync<T>(string query, Dictionary<string, object> parameters = null);

        Task<T> SelectQuerySingleOrDefaultAsync<T>(string query, Dictionary<string, object> parameters = null);

        Task<int> ExecuteNonQueryAsync(string query, Dictionary<string, object> parameters = null);
        Task<int> ExecuteNonQueryAsync<T>(string query, IEnumerable<T> entityData, Func<IEnumerable<T>, Dictionary<string, object>> funcGetParameters, int batchSize);

        Task<object> ExecuteScalarAsync(string query, Dictionary<string, object> parameters = null);

        Task MultipleExecute(SqlMultipleExecuteDataCollection multipleExecuteData);
        void DefineConnectionString(string conexao);
    }
}