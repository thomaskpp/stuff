﻿using System.Net.Http;
using System.Collections.Generic;
using System.Threading.Tasks;
using Itau.SZ7.GPS.Core.Entidade;

namespace Itau.SZ7.GPS.Core.Dados.Interface
{
    public interface IGpsHttpClient
    {
        Task<GpsHttpResponse<TSaida>> EnviarAsync<TSaida>(HttpMethod metodo, string url);

        Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, TEntrada corpo);

        Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, Dictionary<string, string> cabecalho);

        Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, TEntrada corpo, Dictionary<string, string> cabecalho);

        void DefineTimeout(int milesegundos);
    }
}
