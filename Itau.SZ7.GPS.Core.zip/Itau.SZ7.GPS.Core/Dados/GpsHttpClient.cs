﻿using Itau.SZ7.GPS.Core.Dados.Interface;
using Itau.SZ7.GPS.Core.Entidade;
using Itau.SZ7.GPS.Core.Enums;
using Itau.SZ7.GPS.Core.Excecoes.Tipos;
using Itau.SZ7.GPS.Core.Util;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Dados
{
    public class GpsHttpClient : IGpsHttpClient
    {
        private readonly HttpClient _httpClient;
        private int _timeout;

        public GpsHttpClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _timeout = ChavesPadrao.HTTP_TIMEOUT_PADRAO;

            System.Net.ServicePointManager.Expect100Continue = false;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

        }

        public async Task<GpsHttpResponse<TSaida>> EnviarAsync<TSaida>(HttpMethod metodo, string url)
        {
            return await ExecutarRequisicao<TSaida>(
                CriarRequisicao(metodo, url, null, null));
        }

        public async Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, TEntrada corpo)
        {
            return await ExecutarRequisicao<TSaida>(
                CriarRequisicao(metodo, url, corpo, null));
        }

        public async Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, Dictionary<string, string> cabecalho)
        {
            return await ExecutarRequisicao<TSaida>(
                CriarRequisicao(metodo, url, null, cabecalho));
        }

        public async Task<GpsHttpResponse<TSaida>> EnviarAsync<TEntrada, TSaida>(HttpMethod metodo, string url, TEntrada corpo, Dictionary<string, string> cabecalho)
        {
            return await ExecutarRequisicao<TSaida>(
                CriarRequisicao(metodo, url, corpo, cabecalho));
        }

        HttpRequestMessage CriarRequisicao(HttpMethod metodo, string url, object corpo, Dictionary<string, string> cabecalho)
        {
            HttpRequestMessage requisicao = new HttpRequestMessage(metodo, url);

            PreencherCabecalho(requisicao, cabecalho);
            PreencherCorpo(requisicao, corpo);

            return requisicao;
        }

        public void DefineTimeout(int milesegundos)
        {
            _timeout = milesegundos;
        }

        async Task<GpsHttpResponse<TSaida>> ExecutarRequisicao<TSaida>(HttpRequestMessage requisicao)
        {
            var cts = new CancellationTokenSource();
            cts.CancelAfter(TimeSpan.FromMilliseconds(_timeout));

            try
            {
                var respostaPadrao = new GpsHttpResponse<TSaida>(
                    await _httpClient.SendAsync(requisicao, cts.Token));

                await respostaPadrao.CarregarConteudo();

                return respostaPadrao;
            }
            catch (Exception ex) 
            { }

            return new GpsHttpResponse<TSaida>(new HttpResponseMessage());
        }

        void PreencherCabecalho(HttpRequestMessage requisicao, Dictionary<string, string> cabecalho)
        {
            if (!(cabecalho is null))
            {
                foreach (var item in cabecalho)
                {
                    requisicao.Headers.TryAddWithoutValidation(item.Key, item.Value);
                }
            }
        }

        void PreencherCorpo<TEntrada>(HttpRequestMessage requisicao, TEntrada corpo)
        {
            if (corpo != null)
            {
                requisicao.Content = new StringContent(JsonConvert.SerializeObject(corpo), Encoding.UTF8, "application/json");
            }
        }
    }
}
