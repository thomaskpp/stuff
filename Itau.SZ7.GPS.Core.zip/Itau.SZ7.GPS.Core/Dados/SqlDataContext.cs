﻿using Itau.SZ7.GPS.Core.Dados.Interface;
using Itau.SZ7.GPS.Core.Dados.Sql;
using Itau.SZ7.GPS.Core.Dados.Sql.Extensions;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Dados
{
    public class SqlDataContext : ISqlDataContext
    {
        private readonly ILogServico _logServico;
        private readonly SqlDataContextConfiguration _opcoes;
        public string ConnectionString { get; private set; }

        public SqlDataContext(ILogServico logServico, SqlDataContextConfiguration opcoes)
        {
            _logServico = logServico;
            _opcoes = opcoes;
            ConnectionString = opcoes.Conexao;
        }

        public async Task<IEnumerable<T>> SelectQueryToListAsync<T>(string query, Dictionary<string, object> parameters = null)
        {
            try
            {
                using (var sqlConnection = await CreateAndOpenSqlConnectionAsync())
                {
                    using (SqlCommand sqlCommand = CreateSqlCommand(sqlConnection, query, parameters))
                    {
                        using (SqlDataReader sqlDataReader = await sqlCommand.ExecuteReaderAsync())
                        {
                            return await CreateListAsync<T>(sqlDataReader);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                await _logServico.RegistrarExcecao(ex);
            }

            return Enumerable.Empty<T>();
        }

        public async Task<T> SelectQuerySingleOrDefaultAsync<T>(string query, Dictionary<string, object> parameters = null)
        {
            try
            {
                using (var sqlConnection = await CreateAndOpenSqlConnectionAsync())
                {
                    using (SqlCommand sqlCommand = CreateSqlCommand(sqlConnection, query, parameters))
                    {
                        using (SqlDataReader sqlDataReader = await sqlCommand.ExecuteReaderAsync())
                        {
                            if (await sqlDataReader.ReadAsync())
                            {
                                return sqlDataReader.SqlDataReaderToObject<T>();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                await _logServico.RegistrarExcecao(ex);
            }

            return default;
        }

        public async Task<int> ExecuteNonQueryAsync(string query, Dictionary<string, object> parameters = null)
        {
            try
            {
                using (var sqlConnection = await CreateAndOpenSqlConnectionAsync())
                {
                    using (SqlCommand sqlCommand = CreateSqlCommand(sqlConnection, query, parameters))
                    {
                        return await sqlCommand.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                await _logServico.RegistrarExcecao(ex);
            }

            return default;
        }

        public async Task<int> ExecuteNonQueryAsync<T>(string query, IEnumerable<T> entityData, Func<IEnumerable<T>, Dictionary<string, object>> funcGetParameters, int batchSize)
        {
            try
            {
                using (var sqlConnection = await CreateAndOpenSqlConnectionAsync())
                {
                    int count = 0, taskCount = 1;

                    if (entityData.Count() > batchSize)
                        taskCount = entityData.Count() / batchSize;

                    ICollection<Task<int>> tarefas = new List<Task<int>>(taskCount);

                    while (taskCount > count)
                    {
                        var batchData = entityData.Skip((count) * batchSize).Take(batchSize);
                        var parameters = funcGetParameters(batchData);

                        SqlCommand sqlCommand = CreateSqlCommand(sqlConnection, query, parameters);
                        var task = sqlCommand.ExecuteNonQueryAsync();
                        tarefas.Add(task);

                        count++;
                    }

                    var rowsAffected = await Task.WhenAll(tarefas);

                    return rowsAffected.Sum();
                }
            }
            catch (Exception ex)
            {
                await _logServico.RegistrarExcecao(ex);
            }

            return default;
        }

        public async Task<object> ExecuteScalarAsync(string query, Dictionary<string, object> parameters = null)
        {
            try
            {
                using (var sqlConnection = await CreateAndOpenSqlConnectionAsync())
                {
                    using (SqlCommand sqlCommand = CreateSqlCommand(sqlConnection, query, parameters))
                    {
                        return await sqlCommand.ExecuteScalarAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                await _logServico.RegistrarExcecao(ex);
            }

            return new object();
        }

        public async Task MultipleExecute(SqlMultipleExecuteDataCollection multipleExecuteData)
        {
            try
            {
                using (var sqlConnection = await CreateAndOpenSqlConnectionAsync())
                {
                    foreach (var executeData in multipleExecuteData)
                    {
                        try
                        {
                            using (SqlCommand sqlCommand = CreateSqlCommand(sqlConnection, executeData.CommandText, executeData.Parameters))
                            {
                                using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                                {
                                    if (executeData.IsReturnList)
                                    {
                                        var listType = typeof(List<>).MakeGenericType(executeData.ReturnType);
                                        IList listItem = (IList)Activator.CreateInstance(listType);

                                        while (await sqlDataReader.ReadAsync())
                                        {
                                            object item = sqlDataReader.SqlDataReaderToObject(executeData.ReturnType);
                                            listItem.Add(item);
                                        }

                                        executeData.SetResult(listItem);
                                    }
                                    else
                                    {
                                        if (await sqlDataReader.ReadAsync())
                                        {
                                            var dataReaderObject = sqlDataReader.SqlDataReaderToObject(executeData.ReturnType);

                                            if (!(dataReaderObject is null))
                                            {
                                                executeData.SetResult(dataReaderObject);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            await _logServico.RegistrarExcecao(ex);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                await _logServico.RegistrarExcecao(ex);
            }
        }

        /// <summary>
        /// Somente utilizado pela API de configuração (inicio do processo)
        /// </summary>
        /// <param name="conexao"></param>
        public void DefineConnectionString(string conexao)
        {
            ConnectionString = conexao;
        }

        private void VerificaConnectionString()
        {
            if (string.IsNullOrEmpty(ConnectionString))
            {
                ConnectionString = _opcoes.Conexao;
            }
        }

        private async Task<SqlConnection> CreateAndOpenSqlConnectionAsync()
        {
            VerificaConnectionString();

            var sqlConnection = new SqlConnection(ConnectionString);

            await sqlConnection.OpenAsync();

            return sqlConnection;
        }

        private SqlCommand CreateSqlCommand(SqlConnection sqlConnection, string query, Dictionary<string, object> parameters = null)
        {
            var sqlCommand = new SqlCommand(query, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure,
                CommandTimeout = 300
            };

            sqlCommand.AddParameter(parameters);

            return sqlCommand;
        }

        private async Task<IEnumerable<T>> CreateListAsync<T>(SqlDataReader sqlDataReader)
        {
            var collection = new Collection<T>();

            while (await sqlDataReader.ReadAsync())
            {
                collection.Add(SqlDataReaderExtensions.SqlDataReaderToObject<T>(sqlDataReader));
            }

            return collection;
        }

    }
}