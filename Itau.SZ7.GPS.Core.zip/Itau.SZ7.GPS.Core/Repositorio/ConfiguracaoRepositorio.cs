﻿using Itau.SZ7.GPS.Core.Dados.Interface;
using Itau.SZ7.GPS.Core.Util;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Repositorio
{
    public class ConfiguracaoRepositorio : Interface.IConfiguracaoRepositorio
    {
        #region campos

        private readonly ICache _cache;
        private readonly IGpsHttpClient _gpsHttpClient;
        private string _configuracaoEndpoint;

        #endregion

        #region construtor

        public ConfiguracaoRepositorio(ICache cache, IGpsHttpClient gpsHttpClient)
        {
            _cache = cache;
            _gpsHttpClient = gpsHttpClient;
            _gpsHttpClient.DefineTimeout(ChavesPadrao.HTTP_TIMEOUT_PADRAO);
        }

        #endregion

        #region métodos públicos
        
        public void DefineConfiguracaoEndpoint(string endpoint)
        {
            _configuracaoEndpoint = endpoint;
        }

        public async Task<IEnumerable<Entidade.ConfiguracaoItem>> RetornaConfiguracaoPadrao()
        {
            var chaveCache = $"{ChavesPadrao.CACHE_CONFIGURACAO_REPOSITORIO}RetornaConfiguracaoPadrao";

            var configuracoes = await _cache.RetornaOuDefineValor<List<Entidade.ConfiguracaoItem>>(chaveCache, async () =>
              {
                  try
                  {
                      var retorno = await _gpsHttpClient.EnviarAsync<List<Entidade.ConfiguracaoItem>>(
                    HttpMethod.Get,
                    $"{_configuracaoEndpoint}ObtemConfiguracao/0/0");

                      if (retorno.IsSuccessStatusCode)
                          return retorno.Conteudo;
                  }
                  catch { }

                  return null;
              });

            return configuracoes;
        }

        #endregion
    }
}
