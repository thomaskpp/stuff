﻿using Itau.SZ7.GPS.Core.Dados.Interface;
using Itau.SZ7.GPS.Core.Entidade;
using Itau.SZ7.GPS.Core.Excecoes;
using Itau.SZ7.GPS.Core.Repositorio.Interface;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using System.Net.Http;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Repositorio
{
    public class LogRepositorio : ILogRepositorio
    {
        private readonly IGpsHttpClient _gpsHttpClient;
        private readonly string _logApiEndpoint;

        public LogRepositorio(IGpsHttpClient gpsHttpClient, IConfiguracaoServico configuracaoServico)
        {
            _gpsHttpClient = gpsHttpClient;
            _logApiEndpoint = configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.CONFIG_APIURL_LOGS);
        }

        public async Task RegistrarLog(Logs log)
        {
            if (string.IsNullOrEmpty(_logApiEndpoint))
                throw new GPSApplicationException(log.Descricao);

            var retorno = await _gpsHttpClient.EnviarAsync<Logs,int>(
                HttpMethod.Post,
                $"{_logApiEndpoint}Inserir",
                log);
        }
    }
}
