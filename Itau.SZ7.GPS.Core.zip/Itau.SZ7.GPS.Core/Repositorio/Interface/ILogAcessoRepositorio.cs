﻿using Itau.SZ7.GPS.Core.Entidade;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Repositorio.Interface
{
    public interface ILogAcessoRepositorio
    {
        Task<int> InserirLogAcesso(LogAcesso logAcesso);
    }
}
