﻿using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Repositorio.Interface
{
    public interface IValidacaoUsuarioRepositorio
    {
        Task<Entidade.DTO.Colaborador> ObterColaboradorPorFuncional(string funcional);
        Task<bool> ObterColaboradorSimulacao(string usuario, string senha);
        Task<bool> VerificaColaboradorAtivo(string funcional);
    }
}
