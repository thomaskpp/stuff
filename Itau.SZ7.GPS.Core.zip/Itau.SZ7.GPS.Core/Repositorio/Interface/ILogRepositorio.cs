﻿using Itau.SZ7.GPS.Core.Entidade;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Repositorio.Interface
{
    public interface ILogRepositorio
    {
        Task RegistrarLog(Logs log);
    }
}
