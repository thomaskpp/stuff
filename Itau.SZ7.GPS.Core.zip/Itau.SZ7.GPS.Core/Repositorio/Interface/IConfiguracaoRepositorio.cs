﻿using Itau.SZ7.GPS.Core.Entidade;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Repositorio.Interface
{
    public interface IConfiguracaoRepositorio
    {
        Task<IEnumerable<ConfiguracaoItem>> RetornaConfiguracaoPadrao();
        void DefineConfiguracaoEndpoint(string endpoint);
    }
}
