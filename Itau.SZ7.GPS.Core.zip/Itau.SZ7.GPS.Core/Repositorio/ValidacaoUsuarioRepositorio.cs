﻿using Itau.SZ7.GPS.Core.Dados.Interface;
using Itau.SZ7.GPS.Core.Repositorio.Interface;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using System.Net.Http;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Repositorio
{
    public class ValidacaoUsuarioRepositorio : IValidacaoUsuarioRepositorio
    {
        #region campos

        private readonly IGpsHttpClient _gpsHttpClient;
        private readonly string _colaboradorEndpoint;

        #endregion

        #region construtor

        public ValidacaoUsuarioRepositorio(IGpsHttpClient gpsHttpClient, IConfiguracaoServico configuracaoServico)
        {
            _gpsHttpClient = gpsHttpClient;
            _colaboradorEndpoint = configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.CONFIG_APIURL_COLABORADOR);
        }

        #endregion

        #region métodos públicos

        public async Task<Entidade.DTO.Colaborador> ObterColaboradorPorFuncional(string funcional)
        {
            var retorno = await _gpsHttpClient.EnviarAsync<Entidade.DTO.Colaborador>(
                HttpMethod.Get,
                $"{_colaboradorEndpoint}funcional/{funcional}");

            if (retorno.IsSuccessStatusCode)
                return retorno.Conteudo;

            return default;
        }

        public async Task<bool> VerificaColaboradorAtivo(string funcional)
        {
            var retorno = await _gpsHttpClient.EnviarAsync<bool>(
                HttpMethod.Get,
                $"{_colaboradorEndpoint}funcional/{funcional}/ativo");

            if (retorno.IsSuccessStatusCode)
                return retorno.Conteudo;

            return default;
        }

        public async Task<bool> ObterColaboradorSimulacao(string usuario, string senha)
        {
            var retorno = await _gpsHttpClient.EnviarAsync<Entidade.DTO.ColaboradorSimulacao, Entidade.DTO.ColaboradorSimulacao>(
                HttpMethod.Post,
                $"{_colaboradorEndpoint}simulacao",
                new Entidade.DTO.ColaboradorSimulacao()
                {
                    Usuario = usuario,
                    Senha = senha
                });

            if (retorno.IsSuccessStatusCode)
                return retorno.Conteudo != null;

            return default;
        }

        #endregion
    }
}
