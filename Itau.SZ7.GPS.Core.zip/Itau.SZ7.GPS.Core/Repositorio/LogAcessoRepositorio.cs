﻿using Itau.SZ7.GPS.Core.Dados.Interface;
using Itau.SZ7.GPS.Core.Entidade;
using Itau.SZ7.GPS.Core.Servicos.Interface;
using Itau.SZ7.GPS.Core.Util;
using System.Net.Http;
using System.Threading.Tasks;

namespace Itau.SZ7.GPS.Core.Repositorio
{
    public class LogAcessoRepositorio : Interface.ILogAcessoRepositorio
    {
        #region campos

        private readonly IGpsHttpClient _gpsHttpClient;
        private string _logAcessoApiEndpoint;

        #endregion

        #region construtor

        public LogAcessoRepositorio(IGpsHttpClient gpsHttpClient, IConfiguracaoServico configuracaoServico)
        {
            _gpsHttpClient = gpsHttpClient;
            _logAcessoApiEndpoint = configuracaoServico.RetornaValorConfiguracao(ChavesPadrao.CONFIG_APIURL_LOGACESSO);
        }

        #endregion

        #region métodos públicos

        public async Task<int> InserirLogAcesso(LogAcesso logAcesso)
        {
            var retorno = await _gpsHttpClient.EnviarAsync<LogAcesso, int>(
                HttpMethod.Post,
                $"{_logAcessoApiEndpoint}Inserir",
                logAcesso);

            if (retorno.IsSuccessStatusCode)
                return retorno.Conteudo;

            return 0;
        }

        #endregion

    }
}
